import {useState, useEffect} from 'react';

const useFetch = url => {
  const [theData, setTheData] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let controller = new AbortController();
    const fetchData = async () => {
      try {
        const time = Date.now();

        const result = await fetch(url, {
          signal : controller.signal
        });
        const delay = Math.max(500 - (Date.now() - time), 0);
        const data = await result.json();

        setTimeout(() => {
          controller = null;
          setLoading(false);
          setTheData(data);
        }, delay);
      } catch (requestError) {
        setError(requestError);
        setLoading(false);
      }

      return () => controller && controller.abort();
    };

    setLoading(true);
    fetchData();
  }, [url]);

  return [theData, error, loading];
};

export {useFetch};
