import Box from '@mui/material/Box';
import {DataGrid} from '@mui/x-data-grid';
import './Trades.less';

const columns = [
  {
    field           : 'time',
    headerName      : 'Time',
    width           : 130,
    headerClassName : 'trades__header'
  },
  {
    field           : 'instrumentName',
    headerName      : 'Instrument Name',
    flex            : 1,
    headerClassName : 'trades__header'
  },
  {
    field           : 'strikeA',
    headerName      : 'Strike A',
    width           : 110,
    type            : 'number',
    headerClassName : 'trades__header',
    headerAlign     : 'left'
  },
  {
    field           : 'strikeB',
    headerName      : 'Strike B',
    type            : 'number',
    width           : 110,
    headerClassName : 'trades__header',
    headerAlign     : 'left'
  },
  {
    field           : 'type',
    headerName      : 'Type',
    width           : 150,
    headerClassName : 'trades__header'
  },
  {
    field           : 'size',
    headerName      : 'Size',
    width           : 110,
    type            : 'number',
    headerClassName : 'trades__header',
    headerAlign     : 'left'
  },
  {
    field           : 'price',
    headerName      : 'Price',
    width           : 110,
    type            : 'number',
    headerClassName : 'trades__header',
    headerAlign     : 'left'
  },
  {
    field           : 'counterParty',
    headerName      : 'Counter Party',
    flex            : 1,
    headerClassName : 'trades__header'
  },
  {
    field           : 'tradeId',
    headerName      : 'Trade Id#',
    width           : 150,
    headerClassName : 'trades__header'
  }
];

const rows = [
  {
    id             : 1,
    time           : '2024/31/01 13:55:01',
    instrumentName : 'Sample 1',
    strikeA        : 1001,
    strikeB        : 1011,
    price          : 999,
    type           : 'Type',
    size           : 100,
    counterParty   : 'Counter party 1',
    tradeId        : '987654321'
  }
];

const TradesGridComponent = () => (
  <Box sx={{width : '100%'}}>
    <DataGrid
      getRowClassName={() => 'trades__row'}
      columnHeaderHeight={25}
      rowHeight={25}
      rows={rows}
      columns={columns}
      initialState={{
        pagination : {
          paginationModel : {
            pageSize : 5
          }
        }
      }}
      pageSizeOptions={[10]}
      disableRowSelectionOnClick={false}
    />
  </Box>
);

export default TradesGridComponent;
