// eslint-disable-next-line no-restricted-exports
export {default} from './Trades.container.jsx';
