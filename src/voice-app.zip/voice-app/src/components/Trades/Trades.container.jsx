import TradesGridComponent from './TradesGrid.component.jsx';

const TradesContainer = () => <TradesGridComponent />;

export default TradesContainer;
