import {useContext} from 'react';

import MainContext from '@context/Main';
import GridXAxisComponent from './GridXAxis.component.jsx';

const GridXAxisContainer = () => {
  const {selectedGrids} = useContext(MainContext);

  return selectedGrids.map(grid => <GridXAxisComponent
    key={grid.matrixId}
    headers = {grid.columnHeaderList}
  />);
};

export default GridXAxisContainer;
