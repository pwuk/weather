import './GridXAxis.less';

import PropTypes from "prop-types";
import classnames from "classnames";

const  GridXAxisComponent = ({headers}) =>
    <div className={classnames('grid-x-axis', { 'grid-x-axis__wide':  headers.length > 1})}>
        <ul>
            {
                headers.map(text=><li key={text}><span>{text}</span></li>)
            }
        </ul>
    </div>

GridXAxisComponent.propTypes = {
    headers: PropTypes.arrayOf(PropTypes.string)
}

export default GridXAxisComponent;