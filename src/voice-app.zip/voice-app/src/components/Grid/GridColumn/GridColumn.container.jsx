import PropTypes from 'prop-types';
import GridColumnComponent from './GridColumn.component.jsx';

const GridColumnContainer = ({columnIndex, grid}) => {
  const columnInstruments = grid.instrumentList
    .filter(instrument => instrument.columnIndex === columnIndex)
    .sort((rowA, rowB) => rowA.rowIndex - rowB.rowIndex);

  const maxRows = Math.max(...grid.instrumentList.map(({rowIndex}) => rowIndex));
  const newCol = Array.from({length : maxRows + 1}, () => []);

  columnInstruments.forEach(row => newCol[row.rowIndex].push(row));

  return <GridColumnComponent
    columnIndex={columnIndex}
    columnInstruments={newCol}
  />;
};

GridColumnContainer.propTypes = {
  columnIndex : PropTypes.number,
  grid        : PropTypes.object
};

export default GridColumnContainer;
