import './GridColumn.less';

import PropTypes from 'prop-types';
import GridColumnCellContainer from '@components/Grid/GridColumnCell';

const GridColumnComponent = ({columnIndex, columnInstruments}) => (
  <div className={`grid-column grid-colum-${columnIndex}` }>
    {
      columnInstruments.map((instrumentArray, rowIndex) => (instrumentArray.length > 0 ? <GridColumnCellContainer
        key={rowIndex}
        instrument={instrumentArray}
        columnIndex={instrumentArray[0].columnIndex}
        rowIndex={instrumentArray[0].rowIndex}
      /> : <div key={rowIndex} className={'grid-column-inactive-cell'}></div>))
    }
  </div>
);

GridColumnComponent.propTypes = {
  columnIndex       : PropTypes.number,
  columnInstruments : PropTypes.arrayOf(PropTypes.array)
};

export default GridColumnComponent;
