import {useContext} from 'react';

import MainContext from '@context/Main';
import GridMainComponent from './GridMain.component.jsx';

const GridContainer = () => {
  const {selectedGrids} = useContext(MainContext);

  return <GridMainComponent tileLayouts = {selectedGrids} />;
};

export default GridContainer;
