import {useContext} from 'react';

import MainPage from '@context/Main';
import GridYAxisComponent from './GridYAxis.component.jsx';

const GridYAxisContainer = () => {
  const {selectedGrids, selectedInstrument} = useContext(MainPage);

  return <GridYAxisComponent
    headers={selectedGrids[0].rowHeaderList}
    selected={selectedInstrument.rowIndex}
  />;
};

export default GridYAxisContainer;
