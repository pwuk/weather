import './GridYAxis.less';

import PropTypes from "prop-types";

const  GridYAxisComponent = ({
    selected,
    headers
}) =>
    <div className={'grid-y-axis'}>
        <ul>
            <li></li>
            {
                headers.map((text, index)=>
                    <li
                        className={selected === index ? 'grid-y-axis__selected': null}
                        key={text}>
                        <span>{text}</span>
                    </li>
                )
            }
        </ul>
    </div>

GridYAxisComponent.propTypes = {
    selected: PropTypes.number,
    headers: PropTypes.arrayOf(PropTypes.string)
}

export default GridYAxisComponent;