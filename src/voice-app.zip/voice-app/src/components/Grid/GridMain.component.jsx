import './Grid.less';
import GridYAxis from '@components/Grid/GridYAxis';
import GridData from '@components/Grid/GridData';
import GridXAxis from '@components/Grid/GridXAxis';

const GridMain = () => <div className={'grid-layout'}>
  <GridYAxis/>
  <div className={'grid-layout__inner'}>
    <div className={'grid-layout__header'}>
      <GridXAxis />
    </div>
    <GridData/>
  </div>
</div>;

export default GridMain;
