import './GridColumnCell.less';

import PropTypes from 'prop-types';
import classnames from 'classnames';
import {PRODUCT_TYPES} from '@constants/resources.js';

const GridColumnCellComponent = ({
  inlineComponent,
  popupOpen,
  popupClickHandler,
  cellRef,
  columnIndex,
  rowIndex,
  instrument,
  clickHandler,
  selected,
  displayValue
}) => <div
  ref={cellRef}
  key={instrument[0].instrumentId}
  className={ classnames(
    `grid-column__cell grid-colum-${columnIndex}-${rowIndex}`,
    {
      'grid-column__cell--selected' : selected,
      'grid-column__cell--inactive' : !displayValue
    }
  ) }
  onClick={() => {
    if (clickHandler) {
      clickHandler(instrument);
    }
  }}
>
  {inlineComponent}{displayValue}
  {popupOpen && <div className={'grid-column__cell--popup'}>
    {
      PRODUCT_TYPES.filter(item => !item.hideFromMenu)
        .filter(item => instrument.find(instrumentSelection => instrumentSelection.type === item.dataKey))
        .map(item => <div
          className={'grid-column__cell--popup--menu-item'}
          onClick={event => {
            event.preventDefault();
            event.stopPropagation();
            popupClickHandler(instrument, item);
          }}
          key={item.name}>
          {item.name}
        </div>)
    }
  </div>}

</div>;

GridColumnCellComponent.propTypes = {
  displayValue : PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  inlineComponent   : PropTypes.object,
  popupClickHandler : PropTypes.func,
  popupOpen         : PropTypes.bool,
  cellRef           : PropTypes.object,
  columnIndex       : PropTypes.number,
  rowIndex          : PropTypes.number,
  instrument        : PropTypes.array,
  clickHandler      : PropTypes.func,
  selected          : PropTypes.bool
};

export default GridColumnCellComponent;
