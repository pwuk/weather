import PropTypes from 'prop-types';
import {useContext, useRef, useState} from 'react';
import MainContext from '@context/Main';
import useOnClickOutside from '@hooks/useOnClickOutside.js';
import {getCellLookupId, getSelectedProduct} from '@utils';
import GridColumnCellComponent from './GridColumnCell.component.jsx';

const GridColumnCellContainer = ({
  rowIndex,
  columnIndex,
  instrument
}) => {
  const [open, setOpen] = useState(false);
  const cellRef = useRef(null);
  const {
    priceData,
    selectedInstrument,
    setSelectedInstrument,
    selections,
    cellSelections,
    setCellSelection
  } = useContext(MainContext);
  const popupMode = getSelectedProduct(selections).hideFromMenu;
  const cellId = getCellLookupId(rowIndex, columnIndex);
  const inline = popupMode && cellSelections[cellId] ? <div>{cellSelections[cellId].name}</div> : null;
  const displayValue = popupMode && !inline ? '-' : priceData[rowIndex][columnIndex];

  const popupClickHandler = (instruments, selection) => {
    setOpen(false);
    setSelectedInstrument(instruments.find(item => item.type === selection.dataKey));
    setCellSelection({...cellSelections, [getCellLookupId(instruments[0].rowIndex, instruments[0].columnIndex)] : selection});
  };
  const clickHandler = instrumentSelection => {
    setOpen(true);
    setSelectedInstrument(instrumentSelection[0]);
  };

  useOnClickOutside(cellRef, () => setOpen(false));

  return <GridColumnCellComponent
    inlineComponent={inline}
    popupOpen={popupMode && open}
    popupClickHandler={popupClickHandler}
    cellRef={cellRef}
    rowIndex={rowIndex}
    columnIndex={columnIndex}
    instrument={instrument}
    selected={selectedInstrument?.instrumentId === instrument[0].instrumentId}
    clickHandler={displayValue ? clickHandler : null}
    displayValue={displayValue || null}
  />;
};

GridColumnCellContainer.propTypes = {
  columnIndex : PropTypes.number,
  rowIndex    : PropTypes.number,
  instrument  : PropTypes.array
};

export default GridColumnCellContainer;
