// eslint-disable-next-line no-restricted-exports
export {default} from './GridData.container.jsx';
