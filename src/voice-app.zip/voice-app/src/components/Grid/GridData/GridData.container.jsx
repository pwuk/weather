import {useContext} from 'react';

import MainContext from '@context/Main';
import GridDataComponent from './GridData.component.jsx';

const GridDataContainer = () => {
  const {selectedGrids} = useContext(MainContext);

  return <GridDataComponent grids={selectedGrids} />;
};

export default GridDataContainer;
