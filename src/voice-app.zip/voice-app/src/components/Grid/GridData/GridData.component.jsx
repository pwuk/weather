import './GridData.less';

import PropTypes from "prop-types";
import classnames from "classnames";
import GridColumnContainer from "@components/Grid/GridColumn";

const  GridDataComponent = ({grids}) => {
    return (
        <div className={'grid-data__container'}>
            {
                grids.map(grid =>
                    <div key={grid.matrixId} className={
                        classnames(
                            'grid-data__item', {
                            'grid-data__item-wide': grid.columnHeaderList.length > 1
                        })}>
                        {
                            grid.columnHeaderList.map((header, columnIndex) =>
                                <GridColumnContainer key={header} columnIndex={columnIndex} grid={grid} />
                            )
                        }
                    </div>
                )

            }
        </div>
    )
}

GridDataComponent.propTypes = {
    grids: PropTypes.arrayOf(PropTypes.object)
}

export default GridDataComponent;