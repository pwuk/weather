// import PropTypes from "prop-types";
import {useContext} from 'react';
import MainContext from '@context/Main';
import './ShowSelectedProduct.less';

const ShowSelectedProduct = () => {
  const {selectedInstrument, selections} = useContext(MainContext);

  let typeName = null;

  if (selectedInstrument.type) {
    const prodType = selections
      .filter(item => !item.hideFromMenu)
      .find(item => item.dataKey === selectedInstrument.type);

    if (prodType) {
      typeName = prodType.name;
    }
  } else {
    const prodType = selections
      .filter(item => item.selected);

    if (prodType.length === 1) {
      typeName = prodType[0].name;
    }
  }

  return (
    <div className={'show-selected-product'}>{typeName} {selectedInstrument?.name ?? 'No selection'}</div>
  );
};

export default ShowSelectedProduct;
