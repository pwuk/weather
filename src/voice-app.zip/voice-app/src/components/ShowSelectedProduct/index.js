export {default} from './ShowSelectedProduct.component.jsx';
