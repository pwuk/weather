import './Main.less';
import Grid from '@components/Grid';
import PageHeader from '@components/Header';
import Trades from '@components/Trades';
import TradeEntryForm from '@components/TradeEntryForm';
import ProductSelector from '@components/ProductSelector';

import PropTypes from 'prop-types';
import FormHeader from '@components/TradeEntryForm/FormHeader.component';

const MainComponent = ({
  mainBodyRef,
  mainBodySize,
  dragHandler
}) => <section className={'main__layout'}>
  <PageHeader/>
  <div className={'main__body'} ref={mainBodyRef}>
    <div className={'main__left'} style={{flex : mainBodySize.left}}>
      <ProductSelector/>
      <Grid/>
    </div>
    <div
      onDragEnd={dragHandler}
      draggable
      className={'main__drag-bar'}></div>
    <div className={'main__right'} style={{flex : mainBodySize.right}}>
      <TradeEntryForm/>
    </div>
  </div>
  <div className={'main__footer'}>
    <Trades />
  </div>
</section>;

MainComponent.propTypes = {
  mainBodyRef  : PropTypes.object,
  mainBodySize : PropTypes.object,
  dragHandler  : PropTypes.func
};

export default MainComponent;
