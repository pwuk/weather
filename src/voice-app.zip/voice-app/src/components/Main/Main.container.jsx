import Loading from '@components/Loading';
import {useEffect, useRef, useState} from 'react';

import {buildCompositeGrid, getProductSelectionsFromData} from '@utils';
import {DEFAULT_THEME, ONE_HUNDRED, PRODUCT_TYPES} from '@constants/resources.js';
import {StyledEngineProvider} from '@mui/material';
import {useFetch} from '@hooks/useFetch.js';
import MainContext from '@context/Main';
import MainComponent from './Main.component.jsx';

const MainContainer = () => {
  const [data, error, loading] = useFetch('BGC EUR IRO - CCP.json');
  const [priceData, priceError, priceLoading] = useFetch('prices.json');
  const [selections, setSelectedProduct] = useState(null);
  const [selectedInstrument, setSelectedInstrument] = useState({});
  const [currentTheme, setCurrentTheme] = useState(DEFAULT_THEME);
  const [mainSize, setMainSize] = useState({left : '66%', right : '33%'});
  const mainBodyRef = useRef(null);
  const [cellSelections, setCellSelection] = useState({});
  const [selectedGrids, setSelectedGrids] = useState([]);

  useEffect(() => {
    if (data && data.tileLayouts) {
      const prodTypes = getProductSelectionsFromData(data.tileLayouts, PRODUCT_TYPES);
      const compositeGrid = buildCompositeGrid(data.tileLayouts);

      setSelectedProduct(prodTypes);
      setSelectedGrids([compositeGrid]);
    }
  }, [data, loading]);

  const dragHandler = event => {
    const {width} = mainBodyRef.current.getBoundingClientRect();
    const newLeftWidth = (event.clientX / width) * ONE_HUNDRED;

    if (newLeftWidth > 0) {
      setMainSize({left : `${newLeftWidth}%`, right : ` ${ONE_HUNDRED - newLeftWidth}%`});
    }
  };

  if (loading || !selections || priceLoading) {
    return <Loading />;
  }
  if (error || priceError) {
    return <div>Error</div>;
  }

  return (
    <MainContext.Provider value={{
      data,
      selections,
      setSelectedProduct,
      selectedInstrument,
      setSelectedInstrument,
      currentTheme,
      setCurrentTheme,
      cellSelections,
      setCellSelection,
      selectedGrids,
      setSelectedGrids,
      priceData,
      pageName : 'Voice Grids',
      userName : 'a.broker@bgcg.com'
    }}>
      <StyledEngineProvider injectFirst>
        <MainComponent
          mainBodyRef = {mainBodyRef}
          mainBodySize = {mainSize}
          dragHandler = {dragHandler}

        />
      </StyledEngineProvider>
    </MainContext.Provider>
  );
};

export default MainContainer;
