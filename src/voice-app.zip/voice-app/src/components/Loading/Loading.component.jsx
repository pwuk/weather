import './Loading.css';

const  Loading = () =>
        <div className={'loading'}>
            Loading <img alt='loading' src={'/loading-small.gif'} />
        </div>

export default Loading;