import './Header.less';
import PropTypes from 'prop-types';
import classnames from 'classnames';

const HeaderComponent = ({
  themes,
  themeRef,
  themeOpen,
  setThemeOpen,
  setTheme,
  pageName,
  userName,
  currentTheme
}) => (
  <div className={'header'}>
    <button alt="bgc logo" className="header__logo"></button>
    <h1>{pageName}</h1>

    <div className="header__status"></div>

    <div className="header__user-menu">
      <div className="header__user-card">
        <div className="header__user-card__name">
          <a title="Click to logout">
            {userName}
            {' '}
            <i className={'fa fa-sign-out'}></i>
          </a>
        </div>
      </div>
      <i className="fa fa-cog" ref={themeRef} onClick={() => setThemeOpen(true)}>
        {themeOpen && <div className={'header__theme-popup'}>
          <div>Themes:</div>
          {
            themes.map(item => <div
              className={classnames('header__theme-popup--menu-item', {
                'header__theme-popup--menu-item-selected' : item.number === currentTheme
              })}
              onClick={event => {
                event.stopPropagation();
                setTheme(item.number);
              }}
              key={item.name}>
              {item.name}
            </div>)
          }
        </div>}
      </i>
      <i className="fa fa-info-circle"></i>
    </div>
  </div>
);

HeaderComponent.propTypes = {
  themes       : PropTypes.arrayOf(PropTypes.object),
  themeRef     : PropTypes.object,
  themeOpen    : PropTypes.bool,
  setThemeOpen : PropTypes.func,
  pageName     : PropTypes.string,
  userName     : PropTypes.string,
  setTheme     : PropTypes.func,
  currentTheme : PropTypes.number
};
export default HeaderComponent;
