import {useContext, useRef, useState} from 'react';

import {THEMES} from '@constants/resources.js';
import MainContext from '@context/Main';
import useOnClickOutside from '@hooks/useOnClickOutside.js';
import HeaderComponent from './Header.component.jsx';

const HeaderContainer = () => {
  const {
    pageName, userName, currentTheme, setCurrentTheme
  } = useContext(MainContext);
  const [themeOpen, setThemeOpen] = useState(false);
  const themeRef = useRef(null);

  const setTheme = themeNumber => {
    const nextTheme = `volumematch-theme${themeNumber}`;
    const prevTheme = `volumematch-theme${currentTheme}`;

    document.documentElement.classList.replace(prevTheme, nextTheme);
    setCurrentTheme(themeNumber);
    setThemeOpen(false);
  };

  useOnClickOutside(themeRef, () => setThemeOpen(false));

  return <HeaderComponent
    themes={THEMES}
    themeRef={themeRef}
    themeOpen={themeOpen}
    setThemeOpen={setThemeOpen}
    pageName={pageName}
    userName={userName}
    setTheme={setTheme}
    currentTheme={currentTheme}
  />;
};

export default HeaderContainer;
