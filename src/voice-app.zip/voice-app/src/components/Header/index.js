// eslint-disable-next-line no-restricted-exports
export {default} from './Header.container.jsx';
