import TradeEntryForm from './TradeEntryForm.component.jsx';

const mSTP = state => ({})

const mDTP = dispatch => ({})

export default TradeEntryForm;