/* eslint-disable implicit-arrow-linebreak */
import React from 'react';
import {
  TextField, Autocomplete, InputAdornment, IconButton
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import './TraderSelection.less';

function TraderSelection () {
  const [values, setValues] = React.useState({
    selectedFirm      : '',
    firmList          : ['Firm 1', 'Firm 2', 'Firm 3'],
    selectedTrader    : '',
    traderList        : ['trader 1', 'trader 2', 'trader 3'],
    selectedLegalName : '',
    legalNameList     : ['legal name 1', 'legal name 2', 'legal name 3'],
    selectedBroker    : '',
    brokerList        : ['broker 1', 'broker 2', 'broker 3'],
    isPrimaryBroker   : true,
    size              : ''
  });

  const handleChange = key => event => {
    setValues({...values, [key] : event.target.type === 'checkbox' ? event.target.checked : event.target.value});
  };

  return (<div className={'traderSelection'}>
    <form>
      <div className='traderSelection_row'>
        <label htmlFor="firm" className='inputLabel'>Firm</label>
        <Autocomplete
          id='firm'
          options={values.firmList}
          onChange={handleChange('selectedFirm')}
          name='selectedFirm'
          renderInput={params =>
            <TextField {...params} value={values.selectedFirm}
              size="small" name='selectedFirm' onChange={handleChange('selectedFirm')} placeholder={'Firm name'}/>}
        />
        {/* {this.props.deleteButton && <IconButton aria-label="delete"
          sx={{height : '30px', width : '30px'}}
          onClick={values.delete}><DeleteIcon /></IconButton>} */}
      </div>
      <div className='traderSelection_row'>
        <label htmlFor="trader" className='inputLabel'>Trader</label>
        <Autocomplete
          id='trader'
          options={values.traderList}
          renderInput={params =>
            <TextField {...params} value={values.selectedTrader}
              size="small" name='selectedTrader' onChange={handleChange('selectedTrader')}/>}
        />
      </div>
      <div className='traderSelection_row'>
        <label htmlFor="legalName" className='inputLabel'>Legal Name</label>
        <Autocomplete
          id='legalName'
          options={values.legalName}
          renderInput={params =>
            <TextField {...params} value={values.legalName}
              size="small" name='legalName' onChange={handleChange('legalName')}/>}
        />
      </div>
      <div className='traderSelection_row'>
        <label htmlFor="broker" className='inputLabel'>Broker</label>
        <Autocomplete
          id='broker'
          options={values.brokerList}
          renderInput={params =>
            <TextField {...params} value={values.selectedBroker}
              size="small" name='selectedBroker' onChange={handleChange('selectedBroker')}/>}
        />
      </div>
      <div className='traderSelection_row'>
        <label htmlFor='isPrimaryBroker' className='inputLabel'>Primary Broker</label>
        <input id='isPrimaryBroker' type='checkbox'
          defaultChecked={values.isPrimaryBroker} name='isPrimaryBroker' value={values.isPrimaryBroker} onChange={handleChange('isPrimaryBroker')}/>
      </div>
      <div className='traderSelection_row'>
        <label htmlFor="size" className='inputLabel'>Size</label>
        <TextField
          id='size'
          defaultValue={values.size}
          className='inputSize'
          size='small'
          placeholder={''}
          InputProps={{
            endAdornment : <InputAdornment position="end">MM</InputAdornment>
          }}
        />
      </div>
    </form>
  </div>);
}

export default TraderSelection;
