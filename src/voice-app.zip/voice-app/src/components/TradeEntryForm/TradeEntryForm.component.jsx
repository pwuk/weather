import React from 'react';
import {IconButton} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import TradeDetails from './TradeDetails';
import TraderSelection from './TraderSelection';

import './TradeEntryForm.less';
import FormHeader from '@components/TradeEntryForm/FormHeader.component.jsx';

const TRADER = {
  selectedFirm      : '',
  selectedTrader    : '',
  selectedLegalName : '',
  selectedBroker    : '',
  isPrimaryBroker   : true,
  size              : ''
};

class TradeEntryForm extends React.Component {
  constructor (props) {
    super(props);
    this.state = {
      buyers  : [TRADER],
      sellers : [TRADER]
    };

    this.addBuyer = this.addBuyer.bind(this);
    this.addSeller = this.addSeller.bind(this);

    this.handleDeleteBuyer = this.handleDeleteBuyer.bind(this);
    this.handleDeleteSeller = this.handleDeleteSeller.bind(this);
    this.formRef = React.createRef();
  }

  addBuyer () {
    this.setState(currentState => ({
      ...currentState,
      buyers : this.state.buyers.concat(TRADER)
    }));
  }

  scrollToBottom () {
    if (this.formRef.current) {
      this.formRef.current.scrollTop = this.formRef.current.scrollHeight;
    }
  }

  componentDidUpdate (prevProps, prevState) {
    const shouldScroll = (prevState.buyers.length !== this.state.buyers.length) ||
        (prevState.sellers.length !== this.state.sellers.length);

    if (shouldScroll) {
      this.scrollToBottom();
    }
  }

  addSeller () {
    this.setState(currentState => ({
      ...currentState,
      sellers : this.state.sellers.concat(TRADER)
    }));
  }

  handleDeleteBuyer (deleteIndex) {
    this.setState(prevState => ({
      ...prevState,
      buyers : prevState.buyers.filter((item, traderIndex) => traderIndex !== deleteIndex)
    }));
  }

  handleDeleteSeller (idx) {
    this.setState(prevState => ({
      ...prevState,
      sellers : prevState.sellers.filter((item, traderIndex) => traderIndex !== idx)
    }));
  }

  render () {
    return (
      <div className='trade-entry-form__layout'>
        <FormHeader />
        <div className='trade-entry-form__body'>
          <TradeDetails className='trade-entry-form__body__tradeDetails'/>
          <div className='trade-entry-form__trader_row'>
            <label className='trade-entry-form__tradeSideHeader'>
              Buyer<IconButton aria-label="addBuyer"
                onClick={this.addBuyer}
                sx={{
                  marginLeft : '1rem',
                  color      : 'var(--app-button-text)',
                  background : 'var(--submit-button-background)',
                  height     : '20px',
                  width      : '20px'
                }}><AddIcon/></IconButton>
            </label>
            <label className='trade-entry-form__tradeSideHeader'>
              Seller<IconButton aria-label="addSeller" onClick={this.addSeller}
                sx={{
                  marginLeft : '1rem',
                  color      : 'var(--app-button-text)',
                  background : 'var(--submit-button-background)',
                  height     : '20px',
                  width      : '20px'
                }}><AddIcon/></IconButton>
            </label>
          </div>
          <div className={'trade-entry-form__trader_row trade-entry-form__scroll'} ref={this.formRef} >
            <div className='trade-entry-form__buyer'>
              {this.state.buyers.map((buyer, idx) => <TraderSelection key={idx} side={'buy'} trader={buyer}
                delete={() => this.handleDeleteBuyer(idx, this.state.buyers)}
                deleteButton={this.state.buyers.length > 1}/>)}
            </div>
            <div className='trade-entry-form__seller'>
              {this.state.sellers.map((seller, idx) => <TraderSelection key={idx} side={'sell'} trader={seller}
                delete={() => this.handleDeleteSeller(idx, this.state.buyers)}
                deleteButton={this.state.sellers.length > 1}/>)}
            </div>
          </div>
          <div>
          </div>
        </div>
        <div className='trade-entry-form__footer'>
          <button className='trade-entry-form__button' style={{width : '25%'}}>Reset</button>
          <button className='trade-entry-form__button' style={{width : '25%'}}>Submit</button>
        </div>
      </div>
    );
  }
}

export default TradeEntryForm;
