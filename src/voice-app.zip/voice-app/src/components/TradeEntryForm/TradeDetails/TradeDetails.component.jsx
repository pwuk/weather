import React from 'react';
import {FormControlLabel, Checkbox} from '@mui/material';
import {LocalizationProvider, DateTimePicker} from '@mui/x-date-pickers';
import {AdapterDayjs} from '@mui/x-date-pickers/AdapterDayjs';
import {Input} from '@mui/base';
import './TradeDetails.less';

function TradeDetails () {
  const [values, setValues] = React.useState({
    premium      : '',
    premiumOne   : '',
    premiumTwo   : '',
    strike       : '',
    strikeOne    : '',
    strikeTwo    : '',
    hedge        : false,
    hedgePremium : '',
    hedgeStrike  : '',
    hedgeNOTL    : '',
    excutionTime : new Date()
  });

  const handleChange = key => event => {
    setValues({...values, [key] : event.target.type === 'checkbox' ? event.target.checked : event.target.value});
  };

  return (<div className={'tradeDetails'}>
    <div className='tradeDetails_header'>Trade Details</div>
    <form>
      <div className={'tradeDetails__row'}>
        <label className={'tradeDetails__label-col1'} htmlFor='premium'>Premium  </label>
        <Input id='premium' value={values.premium} onChange={handleChange('premium')}/>
        <label className={'tradeDetails__label-col1'} htmlFor='strike'>Strike  </label>
        <Input id='strike' value={values.strike} onChange={handleChange('strike')}/>
      </div>
      <div className={'tradeDetails__row'}>
        <label className={'tradeDetails__label-col1'} htmlFor='premiumOne'>Premium 1  </label>
        <Input id='premiumOne' value={values.premiumOne} onChange={handleChange('premiumOne')}/>
        <label className={'tradeDetails__label-col1'} htmlFor='strikeOne'>Strike 1 </label>
        <Input id='strikeOne' value={values.strikeOne} onChange={handleChange('strikeOne')}/>
      </div>
      <div className={'tradeDetails__row'}>
        <label className={'tradeDetails__label-col1'} htmlFor='premiumTwo'>Premium 2  </label>
        <Input id='premiumTwo' value={values.premiumTwo} onChange={handleChange('premiumTwo')}/>
        <label className={'tradeDetails__label-col1'} htmlFor='strikeTwo'>Strike 2 </label>
        <Input id='strikeTwo' value={values.strikeTwo} onChange={handleChange('strikeTwo')}/>
      </div>
      <div className={'tradeDetails__row'}>
        <label htmlFor='excutionTime'>Execution Time</label>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DateTimePicker className='dateTimePicker'/>
        </LocalizationProvider>
      </div>
      <div className={'tradeDetails__row'}>
        <FormControlLabel
          value="hedge"
          label="Hedge"
          labelPlacement="start"
          control={<Checkbox
            value={values.hedge}
            onChange={handleChange('hedge')}/>
          }/>
      </div>
      {values.hedge &&
        <div className={'tradeDetails__row'}>
          <label className={'tradeDetails__label-col1'} htmlFor='premiumTwo'>Premium 2  </label>
          <Input id='premiumTwo' value={values.premiumTwo} onChange={handleChange('premiumTwo')}/>
          <label className={'tradeDetails__label-col1'} htmlFor='strikeTwo'>Strike 2 </label>
          <Input id='strikeTwo' value={values.strikeTwo} onChange={handleChange('strikeTwo')}/>
          <label className={'tradeDetails__label-col1'} htmlFor='strikeTwo'>Strike 2 </label>
          <Input id='strikeTwo' value={values.strikeTwo} onChange={handleChange('strikeTwo')}/>
        </div>
      }
    </form>
  </div>);
}

export default TradeDetails;
