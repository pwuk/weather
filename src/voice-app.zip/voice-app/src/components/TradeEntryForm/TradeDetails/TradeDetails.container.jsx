import TradeDetails from './TradeDetails.component.jsx';

const mSTP = state => ({})

const mDTP = dispatch => ({})

export default TradeDetails;