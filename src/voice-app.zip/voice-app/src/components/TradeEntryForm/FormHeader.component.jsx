import ShowSelectedProductComponent from '@components/ShowSelectedProduct';
import './form-header.less';

const FormHeader = () => <div className={'form-header'}>
  <div>Trade Entry</div>
  <div style={{flex : 1}}></div>
  <ShowSelectedProductComponent />
</div>;

export default FormHeader;
