import './ProductSelector.less';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import ShowSelectedProductComponent from '@components/ShowSelectedProduct/index.js';

const ProductSelectorComponent = ({
  selections,
  clickHandler,
  selectedInstrument,
  selectedProductType
}) => <div className={'product-selector'}>
  {
    selections.map((item, index) => <button
      key={index}
      className={classnames({
        selected : item.selected
      })}
      onClick={() => clickHandler(item)}
    >
      {item.name}
    </button>)
  }
  <div style={{flex : 1}}></div>
  <ShowSelectedProductComponent />
</div>;

ProductSelectorComponent.propTypes = {
  selections     : PropTypes.arrayOf(PropTypes.object),
  clickHandler   : PropTypes.func,
  buttonClass    : PropTypes.string,
  containerClass : PropTypes.string
};

export default ProductSelectorComponent;
