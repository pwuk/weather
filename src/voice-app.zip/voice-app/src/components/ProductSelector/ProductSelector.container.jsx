import './ProductSelector.less';

import {useContext} from 'react';
import {PRODUCT_TYPES} from '@constants/resources.js';
import MainContext from '@context/Main';
import {buildCompositeGrid, getProductSelectionsFromData} from '@utils';
import ProductSelector from './ProductSelector.component';

const ProductSelectorContainer = () => {
  const {
    selections, selectedProduct, setSelectedProduct,
    selectedInstrument,
    setSelectedGrids,
    data: {tileLayouts}
  } = useContext(MainContext);

  const clickHandler = selectedProductType => {
    const currentSelected = selections.find(({selected}) => selected);

    if (currentSelected === selectedProductType) {
      setSelectedProduct(selections.map(item => ({...item, selected : false})));
      setSelectedGrids(tileLayouts);

      const prodTypes = getProductSelectionsFromData(tileLayouts, PRODUCT_TYPES);
      const compositeGrid = buildCompositeGrid(tileLayouts);

      setSelectedProduct(prodTypes);
      setSelectedGrids([compositeGrid]);
    } else {
      const newSelections = selections.map(item => ({...item, selected : item.shortCode === selectedProductType.shortCode}));

      setSelectedProduct(newSelections);
      setSelectedGrids(
        tileLayouts.filter(layoutItem => layoutItem.matrixName === selectedProductType.dataKey)
      );
    }
  };

  return (
    <ProductSelector
      selectedInstrument={selectedInstrument}
      selectedProductType={selectedProduct}
      containerClass={'product-selector'}
      buttonClass={'product-selector__button'}
      selections={selections.filter(item => !item.hideFromMenu)}
      selected={selectedProduct}
      clickHandler={clickHandler}
    />
  );
};

export default ProductSelectorContainer;
