import {PRODUCT_TYPES} from '@constants/resources.js';

export const getSelectedProduct = selections => selections.find(item => item.selected) ?? selections[0];

// eslint-disable-next-line no-magic-numbers
export const getCellLookupId = (rowIndex, colIndex) => `${rowIndex.toString().padStart(3, '0')}-${colIndex.toString().padStart(3, '0')}`;

export const getProductTypeDataKey = (dataKey, selections) => selections.find(item => item.dataKey === dataKey);

const matrixTemplate = {
  matrixId         : 'COMPOSITE',
  matrixName       : 'COMPOSITE',
  layoutType       : 'matrix',
  columnHeaderList : [],
  rowHeaderList    : [],
  instrumentList   : []
};

const buildInstrumentList = (existing, list, type) => {
  const newList = [...existing];

  list.forEach(instrument => {
    const found = newList.find(item => item.name === instrument.name);

    if (found) {
      newList.push({
        ...instrument, type, rowIndex : found.rowIndex, colIndex : found.colIndex
      });
    } else {
      newList.push({...instrument, type});
    }
  });

  return newList;
};

const buildHeaderList = headerList => headerList.map((header, index) => ({text : header, order : index}));

/**
 * Create a composite grid from the product type grids.
 *
 * Takes the 4 individual Product type grids.
 *
 *
 *
 * @param tileLayouts
 * @returns {{matrixName: string, columnHeaderList: [], layoutType: string, matrixId: string, instrumentList: [], rowHeaderList: []}}
 */
export const buildCompositeGrid = tileLayouts => {
  const newMatrix = {...matrixTemplate};

  const headers1 = [];
  const headers2 = [];

  tileLayouts.forEach(grid => {
    headers1.push(...buildHeaderList(grid.rowHeaderList));
    headers2.push(...buildHeaderList(grid.columnHeaderList));

    newMatrix.instrumentList = buildInstrumentList(newMatrix.instrumentList, grid.instrumentList, grid.matrixName);
  });

  headers1.sort((i1, i2) => i1.order - i2.order);
  headers2.sort((i1, i2) => i1.order - i2.order);

  newMatrix.rowHeaderList = [...new Set([...headers1.map(item => item.text)])];
  newMatrix.columnHeaderList = [...new Set([...headers2.map(item => item.text)])];

  return newMatrix;
};

export const getProductSelectionsFromData = (tileLayouts, types) => {
  const foundTypes = types.filter(typeItem => tileLayouts.find(layoutItem => layoutItem.matrixName === typeItem.dataKey));

  return [PRODUCT_TYPES[0], ...foundTypes];
};
