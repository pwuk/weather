export const LAYOUT_TYPES = {
  OUTRIGHT : 'outright',
  MATRIX   : 'matrix',
  SPREAD   : 'spread',
  TRIANGLE : 'triangle'
};
export const PRODUCT_TYPES = [
  {
    name         : 'Unselected',
    fullName     : 'Select an individual cell',
    hideFromMenu : true
  },
  {
    name      : 'Straddle',
    fullName  : 'Straddle swaptions',
    shortCode : 'S',
    selected  : false,
    dataKey   : 'STRADDLE'
  },
  {
    name      : 'Payer',
    fullName  : 'Payer swaptions',
    shortCode : 'P',
    selected  : false,
    dataKey   : 'PAYER'
  },
  {
    name      : 'Receiver',
    fullName  : 'Receiver swaptions',
    shortCode : 'R',
    selected  : false,
    dataKey   : 'RECEIVER'
  },
  {
    name      : 'Strangle',
    fullName  : 'Strangle swaptions',
    shortCode : 'A',
    selected  : false,
    dataKey   : 'STRANGLE'
  }
];

export const ONE_HUNDRED = 100;

export const THEMES = [
  {
    name   : 'Pearl',
    number : 3
  },
  {
    name   : 'Charcoal',
    number : 4
  },
  {
    name   : 'Onyx',
    number : 5
  }
];
export const DEFAULT_THEME = 3;
