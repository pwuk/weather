import {
  createContext
} from 'react';

const MainContext = createContext({});

export default MainContext;
