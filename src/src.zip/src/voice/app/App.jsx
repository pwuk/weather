import {useSelector} from 'react-redux';
import {selectAppStatus, AppStates} from '../store/appSlice';
import {selectLogin} from '../store/loginSlice';
import Splash from '../features/splash';
import Main from '../features/main';
import './App.css';
import Header from '../features/header';
import Footer from '../features/footer';

export default function App () {
  const {state, statusMsg} = useSelector(selectAppStatus);
  const {username} = useSelector(selectLogin);

  return (
    <>
      <Header pageName={'Voice Grids'} userName={username}/>
      {state === AppStates.APP_ONLINE ? <Main/> : <Splash statusText={statusMsg}/>}
      <Footer/>
    </>
  );
}
