import {
  createSlice, createEntityAdapter, createAsyncThunk, createSelector
} from '@reduxjs/toolkit';
import {logger} from '@core-tech/web-api';

export const subscribeInstruments = createAsyncThunk(
  'instruments/subscribe',
  async (param, thunkAPI) => {
    const {extra : shell} = thunkAPI;
    const {context, subscriptionKey : pageKey} = param;

    try {
      logger.info(`[instrumentsSlice] Requesting shell to subscribe securities - context '${context}'`);

      // Use the shell to subscribe to securities by the subscription key
      await shell.subscribe({
        context,
        pageKey
      });
    } catch (err) {
      logger.error(`[instrumentsSlice->subscribeInstruments] Error subscribing to securities: ${err}`);

      throw err;
    }
  }
);

const instrumentsAdapter = createEntityAdapter();

const instrumentsSlice = createSlice({
  name         : 'instruments',
  initialState : instrumentsAdapter.getInitialState(),
  reducers     : {
    instrumentsUpdated (state, action) {
      const {instruments = []} = action.payload;

      instrumentsAdapter.upsertMany(state, instruments);
    },
    instrumentPriceUpdated (state, action) {
      const {entries, tradableInstrumentId: {symbol, tradingSystemId}} = action.payload;
      const [entry] = entries;

      if (entry) {
        instrumentsAdapter.updateOne(state, {
          id      : `${tradingSystemId}|${symbol}`,
          changes : {
            price : entry.price
          }
        });
      }
    }
  }
});

// Entity selectors
export const {
  selectById: selectInstrumentById,
  selectIds: selectInstrumentIds,
  selectAll: selectInstruments
} = instrumentsAdapter.getSelectors(state => state.instruments);

// Instrument selectors
export const selectInstrumentsByContext = (state, context) => selectInstruments(state).filter(instrument => instrument.context === context);

export const {instrumentsUpdated, instrumentPriceUpdated} = instrumentsSlice.actions;

export default instrumentsSlice.reducer;
