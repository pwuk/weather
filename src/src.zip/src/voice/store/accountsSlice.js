import {createEntityAdapter, createSlice, createSelector} from '@reduxjs/toolkit';
import {GTI_PROTOCOL, logger} from '@core-tech/web-api';

export const subscribeToAccounts = options => (dispatch, getState, shell) => {
  const {context = 'Voice', desks = []} = options;

  try {
    // For each of the login's desks, dispatch a trading-session command (through the App Shell) to subscribe site accounts (broker, trader account details)
    desks.forEach(desk => {
      logger.info(`[accountsSlice] Calling shell to dispatch trading-session '${GTI_PROTOCOL.COMMAND.SITE_LIST_REQUEST}' for ${desk} desk`);

      shell.sendTradingSessionCmd(context, GTI_PROTOCOL.COMMAND.SITE_LIST_REQUEST, {
        desk,
        userId           : shell.userId,
        subscriptionType : 'subscribe'
      });
    });
  } catch (err) {
    logger.error(`[accountsSlice->subscribeToAccounts] Error posting '${GTI_PROTOCOL.COMMAND.SITE_LIST_REQUEST}' command: ${err}`);
  }
};

const accountsAdapter = createEntityAdapter({
  selectId : site => site.code
});

const accountsSlice = createSlice({
  name         : 'accounts',
  initialState : accountsAdapter.getInitialState(),
  reducers     : {
    accountsUpdated (state, action) {
      const {sites = []} = action.payload;

      accountsAdapter.upsertMany(state, sites);
    }
  }
});

// Entity selectors
export const {
  selectById: selectSiteById,
  selectIds: selectSiteIds,
  selectAll: selectAllSites
} = accountsAdapter.getSelectors(state => state.sites);

// Memoized selectors
export const selectUsersBySite = createSelector(
  [selectAllSites, (state, siteId) => siteId],
  (sites, siteId) => sites.filter(site => site.code === siteId)
);

// Actions
export const {accountsUpdated} = accountsSlice.actions;

// Reducer
export default accountsSlice.reducer;
