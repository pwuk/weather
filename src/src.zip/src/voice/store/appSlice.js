import {createSlice} from '@reduxjs/toolkit';

export const AppStates = {
  APP_LOADING : 'Loading',
  APP_ONLINE  : 'Online',
  APP_LATENCY : 'Latency',
  APP_OFFLINE : 'Offline'
};

const appSlice = createSlice({
  initialState : null,
  name         : 'app',
  reducers     : {
    appStatusUpdated (state, action) {
      const {state : appState, statusMsg} = action.payload;

      if (Object.values(AppStates).includes(appState)) {
        state.appStatus = {
          state : appState,
          statusMsg
        };
      }
    }
  },
  extraReducers : builder => {
    builder

      // Report status of all API shell thunks here - in the app 'status' field
      .addMatcher(action => action.type.endsWith('pending'), (state, action) => {
        const {type} = action;

        state.appStatus.statusMsg = `App Loader -> ${type}`;
      })
      .addMatcher(action => action.type.endsWith('fulfilled'), (state, action) => {
        const {type} = action;

        state.appStatus.statusMsg = `App Loader -> ${type}`;
      })
      .addMatcher(action => action.type.endsWith('rejected'), (state, action) => {
        const {type, error} = action;

        state.appStatus.statusMsg = `App Loader -> ${type} : ${error.name} - ${error.message}`;
      });
  }
});

export const selectApp = state => state.app;
export const selectAppStatus = state => selectApp(state).appStatus;

export const {appStatusUpdated} = appSlice.actions;

export default appSlice.reducer;
