import {createSlice} from '@reduxjs/toolkit';


// Create a selected instrument cell id from row and colum number.
// Used by universal grid to lookup selected instrument for a cell.
// row: 2, col 10 => returns '02-10'
// eslint-disable-next-line no-magic-numbers
const cellLookupKey = (row, col) => `${row.toString().padStart(2, '0')}-${col.toString().padStart(2, '0')}`;

const initialState = {
  selectedInstrumentId   : null,
  selectedDocumentId     : null,
  voiceTradeResponse     : null,
  selectedCellInstrument : {},
};
/*
    Shared UI presentation state, specific to voice app.
 */
const voiceSlice = createSlice({
  name     : 'voice',
  initialState,
  reducers : {
    tradeResponseUpdated (state, action) {
      state.voiceTradeResponse = action.payload || null;
    },
    selectedInstrumentUpdated (state, action) {
      state.selectedInstrumentId = action.payload;
    },
    selectedDocumentUpdated (state, action) {
      state.selectedDocumentId = action.payload;
    },

    // Store universal grid instrument selection.
    // The format is RR-CC: {} - { "06-10": {instrument} }
    cellInstrumentUpdated (state, action) {
      state.selectedCellInstrument = {
        ...state.selectedCellInstrument,
        [cellLookupKey(action.payload.row, action.payload.col)] : action.payload.instrument
      };
    }
  }
});

// Selectors
export const voiceStatus = state => state.voice;

export const selectCellInstrument = (state, row, col) => {
  return state.voice.selectedCellInstrument?.[cellLookupKey(row, col)];
};

// Actions
export const {
  cellInstrumentUpdated,
  selectedDocumentUpdated,
  selectedInstrumentUpdated,
  tradeResponseUpdated
} = voiceSlice.actions;

// Reducer
export default voiceSlice.reducer;
