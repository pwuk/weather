import {
  createAsyncThunk, createEntityAdapter, createSelector, createSlice
} from '@reduxjs/toolkit';
import {logger} from '@core-tech/web-api';
import {groupBy, pick, uniqBy} from 'lodash';
import {selectInstrumentById, selectInstrumentIds, selectInstruments} from './instrumentsSlice';
import {getStore} from './index';

export const fetchDashboard = createAsyncThunk(
  'layout/dashboard',
  async (param, thunkAPI) => {
    const {extra : shell} = thunkAPI;

    try {
      logger.info('[layoutSlice] Requesting shell to fetch \'Dashboard\' layout');

      // Use shell to fetch the application 'Dashboard' from the layout service
      return await shell.loadAppDashboard();
    } catch (err) {
      logger.error(`[layoutSlice->fetchDashboard] Error fetching 'Dashboard' layout: ${err}`);

      throw err;
    }
  }
);

export const fetchDocument = createAsyncThunk(
  'layout/document',
  async (param, thunkAPI) => {
    const {extra : shell} = thunkAPI;
    const {desk, context, instruments} = param;

    try {
      logger.info(`[layoutSlice] Requesting shell to fetch '${context}' document layout`);

      // Use shell to fetch the document/page layout from the layout service
      return await shell.buildPageLayout(instruments.map(instrument => {
        const {id, productKey, shortName} = instrument;

        // Extract and transform instrument attributes to make them compatible with the existing Layout API (N.B Refactor ASAP)
        return {
          attributes : {
            instrumentId      : id,
            shortName,
            productKey,
            productAttributes : {
              ...pick(instrument, ['optionTenor', 'swapTenor', 'indexName', 'maturity', 'startDate'])
            }
          }
        };
      }), desk, context);
    } catch (err) {
      logger.error(`[layoutSlice->fetchDashboard] Error fetching '${context}' document layout: ${err}`);

      throw err;
    }
  }
);

const layoutAdapter = createEntityAdapter({
  selectId : document => document.linkName
});

const layoutSlice = createSlice({
  name          : 'layout',
  initialState  : layoutAdapter.getInitialState(),
  extraReducers : builder => {
    builder
      .addCase(fetchDashboard.fulfilled, (state, action) => {
        const {pageList = []} = action.payload;

        layoutAdapter.upsertMany(state, pageList);
      })
      .addCase(fetchDocument.fulfilled, (state, action) => {
        const {pageId, settings, tileLayouts} = action.payload;

        layoutAdapter.updateOne(state, {id : pageId, changes : {settings, tileLayouts}});
      });
  }
});

// Entity Selectors
export const {
  selectById: selectDocumentById,
  selectAll: selectDocuments
} = layoutAdapter.getSelectors(state => state.layout);

// Selectors
export const selectUniqueDesks = state => {
  const documents = selectDocuments(state);

  return uniqBy(documents, 'desk').map(document => document.desk);
};

export const selectMatrixLayoutFromDocument = (state, documentId) => {
  const document = selectDocumentById(state, documentId);

  if (document) {
    return document.tileLayouts.find(({layoutType = ''}) => layoutType === 'matrix');
  }

  return {};
};

/*
    Select the matrix layout types from the passed in documents
 */
export const selectAllMatrixLayouts = documents => documents.reduce((accum, document) => {
  const matrix = document.tileLayouts.find(
    ({layoutType = ''}) => layoutType === 'matrix'
  );

  accum.push(matrix);

  return accum;
}, []);

export const selectMatrixByInstrumentIds = createSelector(
  [
    state => state,
    selectDocuments,
    (state, instrumentIds = []) => instrumentIds
  ],
  (state, documents, instrumentIds) => {
    const instrumentContexts = instrumentIds.map(instrumentId => selectInstrumentById(state, instrumentId)).map(({context}) => context);
    const scopedDocuments = documents.filter(document => instrumentContexts.includes(document.linkName));

    return selectAllMatrixLayouts(scopedDocuments);
  }
);

// For a given list of instruments select related matrix "short names" (for menu)
export const selectMatrixNamesByInstrumentIds = createSelector(
  [
    state => state,
    (state, instrumentIds = []) => instrumentIds
  ],
  (state, instrumentIds) => selectMatrixByInstrumentIds(state, instrumentIds).map(({matrixShortName}) => matrixShortName)
);


// converts 1W to 7 days, 2W 14, 1M 30, 2Y 720
export const convertTenorToDays = text => {
  if (!text) {
    return 0;
  }
  const [numericPart, textPart] = text.match(/[a-zA-Z]+|[0-9]+/g);

  return parseInt(numericPart, 10) * {
    // eslint-disable-next-line id-length
    D : 1, W : 7, M : 30, Y : 365
  }[textPart.toUpperCase()] || 1;
};

/**
 * Sub function for Universal grid selector.
 * Collates instruments for a cell from the available product types.
 *
 * @param rowTenorGroup List of rows for the cell
 * @param colTenorGroup List of columns for the cell
 * @param instrumentMatrix Lookup instruments by matrix type
 * @returns {*[]} Returns a list of instruments for a single cell
 */
const getInstrumentIdsForCell = (
  rowTenorGroup,
  colTenorGroup,
  instrumentMatrix
) => rowTenorGroup.reduce((cellInstruments, rowCell) => {
  const colCell = colTenorGroup.find(colItem => colItem.matrixId === rowCell.matrixId);

  if (colCell) {
    const instrument = instrumentMatrix[rowCell.matrixId].find(
      matrixInstrument => matrixInstrument.rowIndex === rowCell.rowIndex &&
                  matrixInstrument.columnIndex === colCell.columnIndex
    );

    // Add the instrument
    if (instrument) {
      cellInstruments.push(instrument.instrumentId);
    }
  }

  return cellInstruments;
}, []);

/*
    Create a "universal grid" from the available document.matrix layouts
    Returns a matrix "like" object, with instrument list and row column headers
    This is a memorised selector, so it should only be called once.
 */
export const selectUniversalGrid = createSelector(
  [selectDocuments],
  allDocuments => {
    const rowHeader = [];
    const colHeader = [];
    const allMatrices = selectAllMatrixLayouts(allDocuments);

    // Product type to instrument list map.
    const instrumentMatrix = {};

    // All the instruments combined for the all product types.
    const newInstrumentList = [];

    // Create a combined  list of all row column headers
    allMatrices.forEach(matrix => {
      const {
        columnHeaderList, rowHeaderList, matrixShortName, instrumentList
      } = matrix;

      rowHeader.push(...rowHeaderList.map((header, index) => ({header, rowIndex : index, matrixId : matrixShortName})));
      colHeader.push(...columnHeaderList.map((header, index) => ({header, columnIndex : index, matrixId : matrixShortName})));

      // Instrument lookup by matrix type
      instrumentMatrix[matrixShortName] = instrumentList;
    });

    // Object grouped by tenor text, array entry per matrix.
    // e.g. { 6M: [... text:'6M', order, matrixId :'Straddle] }
    // const rowTenorGroups = Object.groupBy(rowHeader, ({header}) => header);
    // const colTenorGroups = Object.groupBy(colHeader, ({header}) => header);
    const rowTenorGroups = groupBy(rowHeader, ({header}) => header);
    const colTenorGroups = groupBy(colHeader, ({header}) => header);

    // Unique headers, these are the visual axes for the universal grid, a superset of all matrices.
    // Sorted by Tenor.
    const uniqueRows = uniqBy(rowHeader, 'header')
      .map(({header}) => header)
      .sort((headerA, headerB) => convertTenorToDays(headerA) - convertTenorToDays(headerB));
    const uniqueCols = uniqBy(colHeader, 'header')
      .map(({header}) => header)
      .sort((headerA, headerB) => convertTenorToDays(headerA) - convertTenorToDays(headerB));

    // For each cell (row/col) collate the available instruments for each matrix type.
    uniqueRows.forEach((uniqueRow, rowIndex) => {
      uniqueCols.forEach((uniqueCol, columnIndex) => {
        // row/columnIndex refer to the coordinates of the combined headers
        newInstrumentList.push({
          rowIndex,
          columnIndex,
          instruments : getInstrumentIdsForCell(
            rowTenorGroups[uniqueRow],
            colTenorGroups[uniqueCol],
            instrumentMatrix
          )
        });
      });
    });

    return {
      rowHeaderList    : uniqueRows,
      columnHeaderList : uniqueCols,
      instrumentList   : newInstrumentList
    };
  }
);


export const {layoutUpdated} = layoutSlice.actions;

export default layoutSlice.reducer;
