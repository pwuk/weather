import {configureStore} from '@reduxjs/toolkit';
import {logger} from '@core-tech/web-api';
import appReducer, {AppStates} from './appSlice';
import accountsReducer from './accountsSlice';
import loginReducer from './loginSlice';
import layoutReducer from './layoutSlice';
import instrumentsReducer from './instrumentsSlice';
import tradesReducer from './tradesSlice';
import voiceReducer from './voiceSlice';

let store = null;

function createStore (shell) {
  logger.info('[store->createStore] Creating Redux store');

  const {
    id, appType, version, brand, tsAdapterType, userId
  } = shell;

  store = configureStore({
    reducer : {
      app         : appReducer,
      accounts    : accountsReducer,
      instruments : instrumentsReducer,
      layout      : layoutReducer,
      login       : loginReducer,
      trades      : tradesReducer,
      voice       : voiceReducer
    },
    middleware : getDefaultMiddleware => getDefaultMiddleware({
      thunk : {
        extraArgument : shell
      }
    }),
    preloadedState : {
      // Set any pre-laded state from the application shell here
      app : {
        id,
        appType,
        version,
        brand,
        tsAdapterType,
        appStatus : {
          state     : AppStates.APP_LOADING,
          statusMsg : `Loading ${id} App v${version}.`
        }
      },
      login : {
        username : userId
      },
      voice : {}
    }
  });

  return store;
}
export const getStore = () => store;
export default createStore;
