import {createEntityAdapter, createSlice} from '@reduxjs/toolkit';
import {logger} from '@core-tech/web-api';

export const subscribeToTrades = () => (dispatch, getState, shell) => {
  try {
    // Subscribe to trade capture reports through the application shell
    logger.info('[tradesSlice] Requesting shell to subscribe trade capture reports');

    shell.subscribeToTrades({
      executionStyle   : 'DISCRETIONARY',
      subscriptionType : 'subscribe'
    });
  } catch (err) {
    logger.error(`[tradesSlice->subscribeToTrades] Error subscribing to trade capture reports: ${err}`);
  }
};

const tradesAdapter = createEntityAdapter({
  selectId : trade => trade.execId
});

const tradesSlice = createSlice({
  name         : 'trades',
  initialState : tradesAdapter.getInitialState(),
  reducers     : {
    tradeUpdated (state, action) {
      const {
        context, counterpartyName, deliverTo, displayName, execId, legs, tradeTime
      } = action.payload;
      const {account} = deliverTo.traderId;

      // For now assume all instruments are single leg outrights
      const {price, tradeQuantity : size, side} = legs[0];

      // Derive counterparties depending upon whether this is the buy or sell side execution report
      const counterparties = side === 'buy' ? {
        buyAccount : account,
        sellFirm   : counterpartyName
      } : {
        sellAccount : account,
        buyFirm     : counterpartyName
      };

      tradesAdapter.upsertOne(state, {
        execId,
        tradeTime,
        context,
        displayName,
        price,
        size,
        ...counterparties
      });
    }
  }
});

// Entity selectors
export const {
  selectById: selectTradeById,
  selectIds: selectTradeIds,
  selectAll: selectAllTrades
} = tradesAdapter.getSelectors(state => state.trades);

// Actions
export const {tradeUpdated} = tradesSlice.actions;

// Reducer
export default tradesSlice.reducer;
