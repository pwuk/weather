import {GTI_PROTOCOL, logger} from '@core-tech/web-api';
import {getStore} from './index';
import {accountsUpdated} from './accountsSlice';
import {
  instrumentPriceUpdated, instrumentsUpdated, selectInstrumentById, selectInstruments
} from './instrumentsSlice';
import {tradeUpdated} from './tradesSlice';
import {selectLogin} from './loginSlice';
import {tradeResponseUpdated} from './voiceSlice';

// trading-session thunks to post GTI commands through the shell api
export const postTradeRequest = tradeRequest => (dispatch, getState, shell) => {
  const {
    context = 'Voice', instrumentId, tradeDetails, tradeCounterparties : voiceCounterParties
  } = tradeRequest;

  try {
    const {tradableInstrumentId, displayName} = selectInstrumentById(getState(), instrumentId);
    const {userId} = selectLogin(getState());

    logger.info(`[tradingSessionMiddleware] Calling shell to dispatch trading-session '${GTI_PROTOCOL.COMMAND.VOICE_TRADE_REQUEST}'
    : ${displayName}|${instrumentId}`);

    shell.sendTradingSessionCmd(context, GTI_PROTOCOL.COMMAND.VOICE_TRADE_REQUEST, {
      userId,
      tradableInstrumentId,
      ...tradeDetails,
      voiceCounterParties
    });
  } catch (err) {
    logger.error(`[tradingSessionMiddleware] Error sending '${GTI_PROTOCOL.VOICE_TRADE_REQUEST}': ${instrumentId} ${err}`);
  }
};

export const msgProcessor = tradingSessionMsg => {
  const {messageType} = tradingSessionMsg;
  const {dispatch} = getStore();

  switch (messageType) {
    case GTI_PROTOCOL.MESSAGE.SECURITY_LIST:
      logger.info(`[tradingSessionMiddleware->msgProcessor] Processing ${messageType}`);

      dispatch(instrumentsUpdated(tradingSessionMsg));
      break;
    case GTI_PROTOCOL.MESSAGE.MARKET_DATA:
      logger.info(`[tradingSessionMiddleware->msgProcessor] Processing ${messageType}`);

      dispatch(instrumentPriceUpdated(tradingSessionMsg));
      break;
    case GTI_PROTOCOL.MESSAGE.SITE_LIST:
      logger.info(`[tradingSessionMiddleware->msgProcessor] Processing ${messageType}`);

      dispatch(accountsUpdated(tradingSessionMsg));
      break;
    case GTI_PROTOCOL.MESSAGE.TRADE_CAPTURE_REPORT:
      logger.info(`[tradingSessionMiddleware->msgProcessor] Processing ${messageType}`);

      dispatch(tradeUpdated(tradingSessionMsg));
      break;
    case GTI_PROTOCOL.MESSAGE.VOICE_TRADE_RESPONSE:
      logger.info(`[tradingSessionMiddleware->msgProcessor] Processing ${messageType}`);

      dispatch(tradeResponseUpdated(tradingSessionMsg));
      break;

    default:
      logger.info(`Dropping unknown '${messageType}' message`);
  }
};
