import {createAsyncThunk, createSlice} from '@reduxjs/toolkit';
import {logger} from '@core-tech/web-api';

export const openTradingSession = createAsyncThunk(
  'login/tradingSession',
  async (userId, thunkAPI) => {
    const {extra : shell} = thunkAPI;

    try {
      logger.info(`[loginSlice] Requesting shell to open trading session for ${userId}`);

      // Use the shell to open a (GTI) trading session and make the websocket connection for message streaming
      await shell.connect();

      return {
        login          : shell.login,
        appVersion     : shell.version,
        gtiInstance    : shell.tradingSession.gtiInstance,
        gtiVersion     : shell.tradingSession.gtiVersion,
        portalVersion  : shell.sessionSettings.portalVersion,
        portalHostname : shell.sessionSettings.hostname
      };
    } catch (err) {
      logger.error(`[loginSlice->openTradingSession] Error opening GTI trading session: ${err}`);

      throw err;
    }
  }
);

const loginSlice = createSlice({
  initialState  : null,
  name          : 'login',
  extraReducers : builder => {
    builder
      .addCase(openTradingSession.fulfilled, (state, action) => {
        const {
          payload: {
            login = {},
            appVersion = '',
            gtiInstance = '',
            gtiVersion = '',
            portalVersion = '',
            portalHostname = ''
          } = {}
        } = action;

        if (Reflect.has(login, 'username')) {
          state.username = login.username;
        }

        if (Reflect.has(login, 'role')) {
          state.externalId = login.role;
        }

        if (Reflect.has(login, 'desks')) {
          state.desks = login.desks;
        }

        state.appVersion = appVersion;
        state.gtiInstance = gtiInstance;
        state.gtiVersion = gtiVersion;
        state.portalVersion = portalVersion;
        state.portalHostname = portalHostname;
      });
  }
});

// Selectors
export const selectLogin = state => state.login;

// Reducer
export default loginSlice.reducer;
