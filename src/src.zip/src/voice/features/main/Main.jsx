import './main.css';
import TradeEntryForm from '../trade-entry';
import ProductSelector from '../product-selector';
import Grid from '../grid';
import TradeGrid from '../trade-grid';

const Main = () => (
  <div id={'main'}>
    <div id={'body'} >
      <div id={'left'}>
        <ProductSelector />
        <Grid />
      </div>
      <div id={'separator-bar'} />
      <div id={'right'}>
        <TradeEntryForm/>
      </div>
    </div>
    <div id={'trade-grid'}>
      <TradeGrid />
    </div>
  </div>
);

export default Main;
