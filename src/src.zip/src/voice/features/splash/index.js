export {default} from './Splash.jsx';
