import PropTypes from 'prop-types';
import './splash.css';


const Splash = ({
  statusText
}) => (
  <div id="splash">
    <div className="main-content">
      <span className="brand-logo"/>
      <div className="message-block">
        <div className="message-header">
          {statusText}
        </div>
      </div>
    </div>
  </div>
);

Splash.propTypes = {
  statusText : PropTypes.string
};

export default Splash;
