import PropTypes from 'prop-types';
import {useSelector} from 'react-redux';
import {voiceStatus} from '../../store/voiceSlice';
import {selectMatrixLayoutFromDocument} from '../../store/layoutSlice';

const ProductSelectorButton = ({
  documentId,
  clickHandler
}) => {
  const {selectedDocumentId} = useSelector(voiceStatus);
  const {matrixShortName = '', matrixName = ''} = useSelector(state => selectMatrixLayoutFromDocument(state, documentId));

  return (
    <button
      onClick={clickHandler}
      className={selectedDocumentId === documentId ? 'selected' : ''}
    >
      {matrixShortName || matrixName}
    </button>
  );
};

ProductSelectorButton.propTypes = {
  documentId   : PropTypes.string,
  clickHandler : PropTypes.func
};

export default ProductSelectorButton;
