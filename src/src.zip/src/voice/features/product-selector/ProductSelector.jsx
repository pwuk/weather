import './productSelector.css';
import {useSelector} from 'react-redux';
import ProductSelectorButton from './ProductSelectorButton.jsx';

import {
  voiceStatus,
  selectedDocumentUpdated,
  selectedInstrumentUpdated
} from '../../store/voiceSlice';
import {getStore} from '../../store';
import {selectInstrumentById} from '../../store/instrumentsSlice';
import {selectMatrixLayoutFromDocument} from '../../store/layoutSlice';

const ProductSelector = () => {
  const documentIdList = useSelector(state => state.layout.ids);
  const {selectedDocumentId, selectedInstrumentId} = useSelector(voiceStatus);
  const {matrixShortName = ''} = useSelector(state => selectMatrixLayoutFromDocument(state, selectedDocumentId));

  const instrument = useSelector(state => selectInstrumentById(state, selectedInstrumentId));
  const {shortName: instrumentShortName = ''} = instrument || {shortName : ''};
  const {dispatch} = getStore();

  const clickHandler = newSelectedDocumentId => {
    if (newSelectedDocumentId === selectedDocumentId) {
      dispatch(selectedDocumentUpdated(null));
    } else {
      dispatch(selectedDocumentUpdated(newSelectedDocumentId));
      dispatch(selectedInstrumentUpdated(''));
    }
  };

  return (
    <div id="productSelector">
      <div id="productSelectorButtons">
        {
          documentIdList.map(documentId => <ProductSelectorButton
            key={documentId}
            documentId={documentId}
            clickHandler={() => clickHandler(documentId)}
          />)
        }
      </div>
      <div id="productSelection">{matrixShortName}</div>
      <div style={{flex : 1}}/>
      <div id="productSelectorDisplay">
        {instrumentShortName}
      </div>
    </div>
  );
};


export default ProductSelector;
