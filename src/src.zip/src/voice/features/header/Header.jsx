import './header.css';
import PropTypes from 'prop-types';
import {useState} from 'react';
import {Popover} from '@mui/material';
import Version from '../version';

const Header = ({
  pageName,
  userName
}) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const handleClose = () => setAnchorEl(null);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  return (
    <div id={'header'}>
      <button alt="bgc logo" id={'logo'}></button>
      <div id={'pageName'}>{pageName}</div>
      <div id={'connectionStatus'}/>
      <div id={'userMenu'}>
        <a id={'userName'} title="Click to logout" onClick={() => window.location = '/logout'}>
          {userName}
          {' '}
          <i className={'fa fa-sign-out'}></i>
        </a>
        <i className="fa fa-cog"/>
        <i className="fa fa-info-circle" onClick={handleClick}/>
        <Popover
          open={Boolean(anchorEl)}
          id={'version-popover'}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{vertical : 'bottom', horizontal : 'right'}}
        ><Version />
        </Popover>
      </div>
    </div>
  );
};

Header.propTypes = {
  pageName : PropTypes.string,
  userName : PropTypes.string
};


export default Header;
