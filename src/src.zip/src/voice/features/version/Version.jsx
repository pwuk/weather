import './version.css';
import {useSelector} from 'react-redux';
import copy from 'copy-to-clipboard';
import {selectLogin} from '../../store/loginSlice';
import sha from '../../../../buildInfo.json';

const Version = () => {
  const {
    appVersion, gtiInstance, gtiVersion, portalVersion, portalHostname
  } = useSelector(selectLogin);

  const copyToClipboard = () => {
    copy(`Version information
    Voice Grids ${appVersion} (${sha.git_sha}) ${sha.date}
    GTI Middleware: ${gtiVersion} (${gtiInstance})
    BGCT Portal: ${portalVersion} (${portalHostname})`);
  };

  return (
    <div id="version">
      <label className="header copy-clipboard"
        title={'Copy to clipboard'}
        onClick={copyToClipboard}>Version Information<i className="fa fa-fw fa-copy"/>
      </label>
      <label className="sub-header"
        title={sha.date}>Voice Grids:<label className="sub-info">{appVersion} ({sha.git_sha})</label>
      </label>
      <label className="sub-header">
          GTI Middleware: <label className="sub-info">{gtiVersion} ({gtiInstance})</label>
      </label>
      <label className="sub-header">BGCT Portal:<label className="sub-info">{portalVersion} ({portalHostname}) </label>
      </label>
    </div>
  );
};

Version.propTypes = {};

export default Version;
