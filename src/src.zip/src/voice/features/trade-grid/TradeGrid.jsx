import {round} from 'lodash';
import {DataGrid} from '@mui/x-data-grid';
import './tradeGrid.css';
import {useSelector} from 'react-redux';
import {selectAllTrades} from '../../store/tradesSlice';

const formatDate = date => {
  const year = date.getFullYear();
  // eslint-disable-next-line no-magic-numbers
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const seconds = date.getSeconds().toString().padStart(2, '0');

  return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
};

const columns = [
  {
    field           : 'tradeTime',
    headerName      : 'Time',
    flex            : 0.30,
    headerClassName : 'trade-grid-header',
    renderCell      : ({row: {tradeTime}}) => formatDate(new Date(tradeTime))
  },
  {
    field           : 'displayName',
    headerName      : 'Instrument',
    flex            : 0.4,
    headerClassName : 'trade-grid-header'
  },
  {
    field           : 'size',
    headerName      : 'Size',
    flex            : 0.25,
    headerClassName : 'trade-grid-header',
    align           : 'left'
  },
  {
    field           : 'price',
    headerName      : 'Price',
    flex            : 0.25,
    headerClassName : 'trade-grid-header',
    align           : 'left',
    // eslint-disable-next-line no-magic-numbers
    renderCell      : ({row: {price}}) => round(price, 5)
  },

  // {
  //   field           : 'size',
  //   headerName      : 'Trade',
  //   flex            : 0.25,
  //   headerClassName : 'trade-grid-header',
  //   cellClassName   : 'trade-grid-size',
  //   renderCell      :({row:{size, price}}) => <><span>{size}</span> <span>{price}</span></>
  // },
  {
    field           : 'buyAccount',
    headerName      : 'Buyer',
    flex            : 1,
    headerClassName : 'trade-grid-header',
    cellClassName   : 'trade-grid-buyer',
    headerAlign     : 'center',
    renderCell      : ({row:{buyAccount, buyFirm}}) => <><span>{buyAccount}</span> <span>{buyFirm}</span></>
  },
  {
    field           : 'sellAccount',
    headerName      : 'Seller',
    flex            : 1,
    headerClassName : 'trade-grid-header',
    cellClassName   : 'trade-grid-seller',
    headerAlign     : 'center',
    renderCell      : ({row:{sellAccount, sellFirm}}) => <><span>{sellAccount}</span> <span>{sellFirm}</span></>
  }
];

const TradesGrid = () => {
  const trades = useSelector(selectAllTrades);

  return (
    <DataGrid
      autoPageSize
      localeText={{noRowsLabel : 'No trades'}}
      getRowId={({execId}) => execId}
      getRowClassName={() => 'trade-grid-row'}
      columnHeaderHeight={25}
      rowHeight={25}
      rows={trades}
      columns={columns}
      pagination
      sx={{
        '& .MuiDataGrid-footerContainer ' : {
          height    : 20,
          minHeight : 20
        }
      }}
      initialState={{
        pagination : {
          paginationModel : {
            pageSize : 5
          }
        }
      }}
      pageSizeOptions={[10]}
      disableRowSelectionOnClick={false}
    />
  );
};

export default TradesGrid;
