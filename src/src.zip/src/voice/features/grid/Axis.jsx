import PropTypes from 'prop-types';


const Axis = ({
  orientation,
  headerList,
  selectedCell: {row, col}
}) => (
  <div id={`axis-${orientation}`} className={`axis-${orientation} axis-header`}>
    {
      headerList.map((headerItem, index) => <div
        key={`${orientation}-${headerItem} `}
        className={
          `axis-header-cell ${orientation === 'vertical' && index === row ? 'selected-axis-header-cell' : ''}
          ${orientation === 'horizontal' && index === col ? 'selected-axis-header-cell' : ''}`
        }>
        {headerItem}
      </div>)
    }
  </div>
);

Axis.propTypes = {
  orientation  : PropTypes.string,
  headerList   : PropTypes.arrayOf(PropTypes.string),
  selectedCell : PropTypes.object
};

export default Axis;
