import {useSelector} from 'react-redux';
import {
  voiceStatus
} from '../../store/voiceSlice';
import {
  selectMatrixLayoutFromDocument,
  selectUniversalGrid
} from '../../store/layoutSlice';
import GridComponent from './GridComponent.jsx';

const GridContainer = () => {
  // Current document, null means Universal grid
  const {selectedDocumentId} = useSelector(voiceStatus);
  const isUniversalGrid = !selectedDocumentId;

  // Selected matrix (from document id, if there is one)
  const matrix = useSelector(state => selectMatrixLayoutFromDocument(state, selectedDocumentId));

  // Universal "matrix"
  const universal = useSelector(selectUniversalGrid);

  return (
    <GridComponent
      layout={isUniversalGrid ? universal : matrix }
      isUniversalGrid={isUniversalGrid}
    />
  );
};

export default GridContainer;
