import './instrumentSelector.css';
import {Popover} from '@mui/material';
import PropTypes from 'prop-types';
import {useSelector} from 'react-redux';
import {selectMatrixNamesByInstrumentIds} from '../../store/layoutSlice';

const InlineInstrumentSelector = ({
  inlinePopupState: {
    cellAnchorElement,
    availableInstruments,
    selectedCell
  },
  handleSelection,
  handleClose
}) => {
  const productTypes = useSelector(state => selectMatrixNamesByInstrumentIds(state, availableInstruments));

  return <Popover
    open={Boolean(cellAnchorElement)}
    id={'version-popover'}
    anchorEl={cellAnchorElement}
    onClose={handleClose}
    anchorOrigin={{vertical : 'bottom', horizontal : 'left'}}
    transformOrigin={{vertical : -4, horizontal : 0}}
  >
    <div className={'inline-instrument-selector'}
      style={{minWidth : cellAnchorElement.offsetWidth}}
    >
      {
        productTypes.map((productType, index) => <button
          className={selectedCell?.productType === productType ? 'selected' : ''}
          key={productType}
          onClick={() => handleSelection(availableInstruments[index], productType)}
        >
          {productType}
        </button>)
      }
    </div>
  </Popover>;
};

InlineInstrumentSelector.propTypes = {
  inlinePopupState : PropTypes.object,
  handleSelection  : PropTypes.func,
  handleClose      : PropTypes.func
};

export default InlineInstrumentSelector;
