import PropTypes from 'prop-types';
import {useSelector} from 'react-redux';
import {round} from 'lodash';
import {selectInstrumentById} from '../../store/instrumentsSlice';

const Cell = ({
  instrumentId,
  instrumentCount,
  displayPrice = false
}) => {
  // Subscribe to instrument entity, This ensures that when the price changes, only this component is re-rendered
  const instrument = useSelector(state => selectInstrumentById(state, instrumentId));
  let price = '';

  if (instrument && instrument.price) {
    // eslint-disable-next-line no-magic-numbers
    price = round(instrument.price, 5);
  }

  return <span className={'cell-inner' }>
    {displayPrice ? price : instrument.displayName}
    {instrumentCount > 1 && <span className={'cell-selector fa fa-chevron-down'}></span>}
  </span>;
};

Cell.propTypes = {
  instrumentId    : PropTypes.string,
  instrumentCount : PropTypes.number,
  displayPrice    : PropTypes.bool
};

export default Cell;
