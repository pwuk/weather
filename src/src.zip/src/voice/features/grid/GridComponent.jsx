import './grid.css';
import PropTypes from 'prop-types';
import {useState} from 'react';
import Axis from './Axis.jsx';
import Cell from './Cell.jsx';
import InlineInstrumentSelector from './InlineInstrumentSelector.jsx';
import {selectMatrixNamesByInstrumentIds} from '../../store/layoutSlice';
import {getStore} from '../../store';
import {selectCellInstrument, cellInstrumentUpdated, selectedInstrumentUpdated} from '../../store/voiceSlice';

// This handles the logic for handling grid and instrument display.
//
// Universal grid (multiple product types/instruments per cell) :
//   Each cell has 3 states, depending on number of instruments:
//   1) 0, Just disable the cell.
//   2) 1, Display the product type and subscribe to the instrument entity.
//   3) 2+, Where a selection has previously been made, update the redux store with instrument id.
//          Display popup selector with available instruments.
//            From popup selection update both selected instrument id and the selected instrument for the
//            individual cell.
//
// Single product grid:
//    One instrument per cell.


const GridComponent = ({
  layout: {
    rowHeaderList,
    columnHeaderList,
    instrumentList
  },
  isUniversalGrid
}) => {
  const {dispatch} = getStore();
  const [inlinePopupState, setInlinePopupState] = useState(null);
  const [selectedCell, setSelectedCell] = useState({row : -1, col : -1});

  const handleProductSelectionClick = (instrumentId, productType) => {
    // hide popup
    setInlinePopupState(null);

    // Update the selected instrument
    dispatch(selectedInstrumentUpdated(instrumentId));

    // Update the instrument for the cell
    dispatch(cellInstrumentUpdated({
      instrument : {instrumentId, productType},
      row        : selectedCell.row,
      col        : selectedCell.col
    }));
  };

  const handleUniversalGridCellClick = ({
    row, col, instrument, event
  }) => {
    if (instrument.instruments.length === 1) {
      // immediate selection
      dispatch(selectedInstrumentUpdated(instrument.instruments[0]));
    } else {
      const selectedCellInstrument = selectCellInstrument(getStore().getState(), row, col);

      setInlinePopupState({
        availableInstruments : instrument.instruments,
        cellAnchorElement    : event.currentTarget,
        selectedCell         : selectedCellInstrument
      });

      dispatch(selectedInstrumentUpdated(selectedCellInstrument ? selectedCellInstrument.instrumentId : null));
    }

    setSelectedCell({row, col});
  };


  const findUniversalGridInstrument = (row, col) => {
    const instrument = instrumentList.find(({rowIndex, columnIndex}) => rowIndex === row && columnIndex === col);

    const instrumentCount = instrument.instruments.length;

    // 0 instruments, disable the cell
    if (instrumentCount === 0) {
      return false;
    }

    const selectedCell = selectCellInstrument(getStore().getState(), row, col);

    // no selection made, return the first in the available list
    if (!selectedCell) {
      return {
        ...instrument,
        instrumentId : instrument.instruments[0],
        instrumentCount,

        // include the product type for display
        productType : selectMatrixNamesByInstrumentIds(getStore().getState(), instrument.instruments)[0]
      };
    }

    // multiple instruments available, if selection already made then  set its instrument id
    return {
      ...instrument,
      ...selectedCell,
      instrumentCount
    };
  };

  const findSingleGridInstrument = (row, col) => ({
    displayPrice : true,
    ...instrumentList.find(({rowIndex, columnIndex}) => rowIndex === row && columnIndex === col)
  });
  const handleSingleGridCellClick = ({row, col, instrument}) => {
    dispatch(selectedInstrumentUpdated(instrument.instrumentId));

    setSelectedCell({row, col});
  };

  const handleCellClick = isUniversalGrid ? handleUniversalGridCellClick : handleSingleGridCellClick;
  const findCellInstrument = isUniversalGrid ? findUniversalGridInstrument : findSingleGridInstrument;

  return (
    <>
      {
        Boolean(inlinePopupState) &&
          <InlineInstrumentSelector
            inlinePopupState={inlinePopupState}
            handleClose={() => setInlinePopupState(null)}
            handleSelection={handleProductSelectionClick}
          />
      }
      <div id="grid" className={'grid'}>
        <div className={'grid-vertical-axis'}>
          <div className={'axis-header-tl-corner'} />
          <Axis orientation={'vertical'} headerList={rowHeaderList} selectedCell={selectedCell}/>
        </div>
        <div id={'gridInner'}>
          <Axis orientation={'horizontal'} headerList={columnHeaderList} selectedCell={selectedCell}/>
          <div id={'gridData'}>
            {
              columnHeaderList.map((_, headColIndex) => <div key={headColIndex} className={'column'}>
                {
                  rowHeaderList.map((__, headRowIndex) => {
                  // Callback to get instrument(s) for this cell.
                  // false value = no instruments, so disabled
                    const foundInstrument = findCellInstrument(headRowIndex, headColIndex);

                    return (
                      <div key={`${headRowIndex}${headColIndex}`}
                        className={
                          `cell ${foundInstrument ? '' : 'disabled-cell'} ${
                            headRowIndex === selectedCell.row && headColIndex === selectedCell.col ? 'selected-cell' : ''}`
                        }
                        onClick={event => foundInstrument && handleCellClick({
                          row        : headRowIndex,
                          col        : headColIndex,
                          instrument : foundInstrument,
                          event
                        })}
                      >
                        {foundInstrument &&
                            <Cell
                              instrumentId={foundInstrument.instrumentId}
                              productType={foundInstrument.productType}
                              instrumentCount={foundInstrument.instrumentCount}
                              displayPrice={foundInstrument.displayPrice}
                            />
                        }
                      </div>
                    );
                  })
                }
              </div>)
            }
          </div>
        </div>
      </div>
    </>
  );
};

GridComponent.propTypes = {
  layout             : PropTypes.object,
  isUniversalGrid    : PropTypes.bool,
  handleCellClick    : PropTypes.func,
  findCellInstrument : PropTypes.func,
  selectedCell       : PropTypes.object
};

export default GridComponent;
