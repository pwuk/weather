import './footer.css';

const Footer = () => (
  <div id={'footer'}>
  </div>
);

export default Footer;
