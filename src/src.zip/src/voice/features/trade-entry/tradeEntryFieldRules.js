
export default {

  LM_MATRIX_VOICE_IRO_USD_STRANGLE : {
    tradeEntry : {
      shouldNotValidate : ['strike']
    }
  },

  LM_MATRIX_VOICE_IRO_USD_PAYER : {
    tradeEntry : {
      disableFields : ['premiumOne', 'premiumTwo']
    }
  },

  LM_MATRIX_VOICE_IRO_USD_RECEIVER : {
    tradeEntry : {
      disableFields : ['premiumOne', 'premiumTwo']
    }
  },

  LM_MATRIX_VOICE_IRO_USD_STRADDLE : {
    tradeEntry : {
      shouldNotValidate : ['strike'],
      copyStrike        : true,
      splitPremium      : true
    }
  }
};
