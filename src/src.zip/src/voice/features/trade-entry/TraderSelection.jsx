import React, {useEffect} from 'react';
import {useSelector} from 'react-redux';
import {get} from 'lodash';
import {
  TextField, Autocomplete, InputAdornment, Checkbox
} from '@mui/material';
import PropTypes from 'prop-types';
import './traderSelection.css';
import {Controller, useFormContext} from 'react-hook-form';
import {selectLogin} from '../../store/loginSlice';

const FIELD_MAX_WIDTH = '66%';
const TraderSelection = ({
  side, index, deleteTrader, isDelete, sideData
}) => {
  const allSites = useSelector(state => state.accounts.entities);
  const traderSites = Object.values(allSites).filter(entity => entity.users && entity.users.some(user => user.role === 'trader'));
  const getUsers = () => Object.values(allSites).filter(entity => entity.users)
    .map(obj => ({
      users : obj.users.filter(user => user.role === 'broker')
    })).flatMap(obj => obj.users)
    .filter(user => user && user.name)
    .map(user => ({name : user.name, role : user.role, login : user.login}));

  const brokers = getUsers('broker').filter((obj, idx, array) => array.findIndex(item => item.name === obj.name) === idx);
  const formMethods = useFormContext();
  const selectedFirm = formMethods.watch(`${sideData}.${index}.selectedFirm`);
  const traderWatch = formMethods.watch(`${sideData}.${index}.selectedTrader`);
  const isPrimaryBrokerWatch = formMethods.watch(`${sideData}.${index}.isPrimaryBroker`);
  const {desks: userDesks} = useSelector(selectLogin);

  // On Firm name change, clear trader and reset aggressor
  useEffect(() => {
    formMethods.setValue(`${sideData}.${index}.selectedTrader`, null, {
      shouldTouch : true,
      shouldDirty : true
    });
    formMethods.setValue(`${sideData}.${index}.isAggressor`, true, {
      shouldTouch : true,
      shouldDirty : true
    });

    if (selectedFirm) {
      formMethods.setValue(`${sideData}.${index}.selectedLegalName`,
        selectedFirm.defaultLegalEntity,
        {shouldTouch : true});
    } else {
      formMethods.setValue(`${sideData}.${index}.selectedLegalName`, null, {shouldTouch : true});
      formMethods.setValue(`${sideData}.${index}.isPrimaryBroker`, true, {shouldTouch : true});
    }
  }, [selectedFirm]);


  // clear broker selection when primary broker checked
  useEffect(() => {
    if (isPrimaryBrokerWatch) {
      formMethods.setValue(`${sideData}.${index}.selectedBroker`, null, {shouldTouch : true});
    }
  }, [isPrimaryBrokerWatch]);

  // On trader change select the default broker
  useEffect(() => {
    if (traderWatch) {
      const userDesk = traderWatch.desksInfo.find(({name}) => userDesks.includes(name));

      if (userDesk) {
        const broker = userDesk.defaultBroker;

        formMethods.setValue(`${sideData}.${index}.selectedBroker`, broker, {shouldTouch : true});
      }
    }
  }, [traderWatch]);

  return (
    <div className={`traderSelection ${side}`}>
      <label className='firm'>
        {isDelete && <button className='fa fa-trash-o' onClick={deleteTrader}/>}
        Firm
        <Controller
          control={formMethods.control}
          name={`${sideData}.${index}.selectedFirm`}
          rules={{required : true}}
          render={({field: {onChange, value}}) => (
            <Autocomplete
              id={`selectedFirm-${side}-${index}`}
              options={traderSites.sort((siteA, siteB) => -siteB.shortName.localeCompare(siteA.shortName))}
              isOptionEqualToValue={(option, optionValue) => get(option, 'shortName', '') === get(optionValue, 'shortName', '')}
              getOptionLabel={option => get(option, 'shortName', '')}
              value={value}
              onChange={(_, data) => {
                onChange(data);

                return data;
              }}
              renderInput={params => <TextField {...params}
                inputProps={{...params.inputProps}}
                error={Boolean(get(formMethods.formState.errors, [sideData, index, 'selectedFirm'], false)) }
              />}
              sx={{width : FIELD_MAX_WIDTH}}
            />
          )}
        />
      </label>
      <label className='trader'>
        Trader
        <Controller
          control={formMethods.control}
          name={`${sideData}.${index}.selectedTrader`}
          rules={{required : true}}
          render={({field: {onChange, value}}) => (
            <Autocomplete
              disabled={!selectedFirm}
              id={`selectedTrader-${side}-${index}`}
              options={get(selectedFirm, 'users', []).filter(({role}) => role === 'trader')}
              getOptionLabel={option => get(option, 'name', '')}
              isOptionEqualToValue={(option, optionValue) => get(option, 'name', '') === get(optionValue, 'name', '')}
              value={value}
              onChange={
                (_, data) => {
                  onChange(data);

                  return data;
                }
              }
              renderInput={params => <TextField {...params}
                inputProps={{...params.inputProps}}
                error={Boolean(get(formMethods.formState.errors, [sideData, index, 'selectedTrader'], false))}
              />}
              sx={{width : FIELD_MAX_WIDTH}}
            />
          )}
        />
      </label>
      <label className='legalName'>
        Legal Name
        <Controller
          control={formMethods.control}
          name={`${sideData}.${index}.selectedLegalName`}
          rules={{required : true}}
          render={({field: {onChange, value}}) => (
            <Autocomplete
              disabled={!selectedFirm}
              id={`selectedLegalName-${side}-${index}`}
              options={(selectedFirm ? [selectedFirm.defaultLegalEntity] : [])}
              getOptionLabel={option => get(option, 'name', '')}
              value={value}
              onChange={
                (_, data) => {
                  onChange(data);

                  return data;
                }
              }
              renderInput={params => <TextField {...params}
                inputProps={{...params.inputProps}}
                error={Boolean(get(formMethods.formState.errors, [sideData, index, 'selectedLegalName'], false))}
              />}
              sx={{width : FIELD_MAX_WIDTH}}
            />
          )}
        />
      </label>
      <label className='broker'>
        <span>Broker
          <Controller
            render={
              () => <Checkbox
                { ...formMethods.register(`${sideData}.${index}.isPrimaryBroker`)}
                disabled={!selectedFirm}
                defaultChecked={true}
              />
            }
            control={formMethods.control}
            name={`${sideData}.${index}.isPrimaryBroker`}
          /></span>
        <Controller
          control={formMethods.control}
          name={`${sideData}.${index}.selectedBroker`}
          render={({field: {onChange, value}}) => (
            <Autocomplete
              disabled={isPrimaryBrokerWatch}
              id={`selectedBroker-${side}-${index}`}
              options={brokers}
              getOptionLabel={option => get(option, 'name', '')}
              value={value}
              onChange={
                (_, data) => {
                  onChange(data);

                  return data;
                }
              }
              renderInput={params => <TextField {...params}
                inputProps={{...params.inputProps}}
                error={Boolean(get(formMethods.formState.errors, [sideData, index, 'selectedBroker'], false))}
                placeholder='Primary Broker'
              />}
              sx={{width : `calc(${FIELD_MAX_WIDTH} - 2.2rem)`}}
            />
          )}
        />
      </label>
      <label className='aggressor'>
        Aggressor
        <Controller
          render={
            () => <Checkbox
              { ...formMethods.register(`${sideData}.${index}.isAggressor`)}
              disabled={!selectedFirm}
              defaultChecked={true}
              sx={{width : '14px'}}
            />
          }
          control={formMethods.control}
          name={`${sideData}.${index}.isAggressor`}
        />
      </label>
      <label className='size'>
        Size
        <Controller
          render={
            () => <TextField {
              ...formMethods.register(`${sideData}.${index}.size`, {required : {value : true}})
            }
            type={'number'}
            error={Boolean(get(formMethods.formState.errors, [sideData, index, 'size'], false))}
            InputProps={{
              endAdornment : <InputAdornment position="end">MM</InputAdornment>
            }}
            sx={{maxWidth : 100}}
            disabled={!selectedFirm}
            />
          }
          control={formMethods.control}
          defaultValue=""
          name={`${sideData}.${index}.size`}
        />
      </label>
    </div>
  );
};

TraderSelection.propTypes = {
  side         : PropTypes.string,
  sideData     : PropTypes.string,
  index        : PropTypes.number,
  deleteTrader : PropTypes.func,
  isDelete     : PropTypes.bool
};

export default TraderSelection;
