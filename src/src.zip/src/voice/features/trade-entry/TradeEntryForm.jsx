/* eslint-disable no-restricted-globals */
import React, {useEffect, useState} from 'react';
import {useSelector} from 'react-redux';
import {get} from 'lodash';
import dayjs from 'dayjs';
import {useFieldArray, useForm, FormProvider } from 'react-hook-form';
import TradeDetails from './TradeDetails.jsx';
import TraderSelection from './TraderSelection.jsx';
import {getStore} from '../../store';
import {postTradeRequest} from '../../store/tradingSessionMiddleware';
import {voiceStatus, tradeResponseUpdated} from '../../store/voiceSlice';
import {selectInstrumentById} from '../../store/instrumentsSlice';
import {selectLogin} from '../../store/loginSlice';

import './tradeEntryForm.css';

const BUYER = 'buy';
const SELLER = 'sell';

const TRADER = {
  selectedFirm      : null,
  selectedTrader    : null,
  selectedLegalName : null,
  selectedBroker    : null,
  isPrimaryBroker   : true,
  isAggressor       : true,
  size              : null
};

const TRADE_DETAILS = {
  premium       : null,
  premiumOne    : null,
  premiumTwo    : null,
  strike        : null,
  strikeOne     : null,
  strikeTwo     : null,
  hedge         : false,
  hedgePremium  : null,
  hedgeStrike   : null,
  hedgeNOTL     : null,
  executionTime : null
};

function TradeEntryForm () {
  const {selectedInstrumentId: instrumentId, voiceTradeResponse} = useSelector(voiceStatus);
  const instrument = useSelector(state => selectInstrumentById(state, instrumentId));
  const {username : primaryBroker} = useSelector(selectLogin);
  const {shortName: instrumentShortName = ''} = instrument || {shortName : ''};
  const [validationMessage, setValidationMessage] = useState('');
  const formMethods = useForm({
    defaultValues : {
      sellers : [{...TRADER}],
      buyers  : [{...TRADER}],
      ...TRADE_DETAILS
    }
  });
  const {
    fields :buyerFields,
    append: buyerAppend,
    remove : buyerRemove
  } = useFieldArray({
    name    : 'buyers',
    control : formMethods.control
  });
  const {
    fields :sellerFields,
    append:  sellerAppend,
    remove : sellerRemove
  } = useFieldArray({
    name    : 'sellers',
    control : formMethods.control
  });

  const handleBuyerAppend = () => buyerAppend({...TRADER});
  const handleBuyerRemove = index => buyerRemove(index);
  const handleSellerAppend = () => sellerAppend({...TRADER});
  const handleSellerRemove = index => sellerRemove(index);
  const [tradeSubmissionStatusMessage, setTradeSubmissionStatusMessage] = React.useState('');
  const {dispatch} = getStore();
  const getTraderBySide = side => {
    const values = formMethods.getValues();

    return (side === BUYER ? {traders: values.buyers} : {traders: values.sellers});
  };

  const nowExecutionTime = () => {
    formMethods.setValue('executionTime', dayjs(new Date()), {shouldTouch : true});
  };
  const resetState = () => {
    formMethods.reset();
    nowExecutionTime();
    formMethods.clearErrors();
  };

  useEffect(() => {
    resetState()
  }, [instrumentId]);

  const transformTradersDetails = side => {
    const {traders} = getTraderBySide(side);

    return traders.map(trader => {
      return {
        traderId : {
          id   : get(trader.selectedTrader, 'login', ''),
          type : 'nativeLogin'
        },
        brokerId : {
          id   : Boolean(trader.isPrimaryBroker) ? primaryBroker : get(trader.selectedBroker, 'login', ''),
          type : 'nativeLogin'
        },
        legalEntityId    : get(trader.selectedLegalName, 'id', ''),
        isAggressor      : Boolean(trader.isAggressor),
        usePrimaryBroker : Boolean(trader.isPrimaryBroker),
        size             : Number(trader.size),
        side
      };
    });
  };

  /*
    Highlight error on trader selection fieldname.
    Currently used for size field to indicate mismatched size values
   */
  const setTraderError = (fieldName) => {
    const {buyers, sellers} = formMethods.getValues();

    buyers.forEach((_, index) => {
      formMethods.setError( `buyers.${index}.${fieldName}`, { shouldFocus: true} );
    })

    sellers.forEach((_, index) => {
      formMethods.setError( `sellers.${index}.${fieldName}`, {shouldFocus: true } );
    })
  }

  /*
      Highlight where (on opposite sides) the same firm is selected.
      It does not check the same side.
   */
  const validateOnSelfTrade = () => {
    const {buyers, sellers} = formMethods.getValues();

    const buyerIndices = buyers.reduce((accum, {selectedFirm: {shortName: buyShortName}}, index) => {
      const foundIndex = sellers.findIndex(({selectedFirm: {shortName: sellShortName}}) => buyShortName === sellShortName);
      if(foundIndex > -1) {
        accum.push(index)
      }

      return accum;
    }, []);

    const sellerIndices = sellers.reduce((accum, {selectedFirm: {shortName: sellShortName}}, index) => {
      const foundIndex = buyers.findIndex(({selectedFirm: {shortName: buyShortName}}) => buyShortName === sellShortName);
      if(foundIndex > -1) {
        accum.push(index)
      }

      return accum;
    }, []);

    buyers.forEach((_, index) => {
      if(buyerIndices.includes(index)) {
        formMethods.setError(`buyers.${index}.selectedFirm`, {shouldFocus: true});
      }
    })
    sellers.forEach((_, index) => {
      if(sellerIndices.includes(index)) {
        formMethods.setError(`sellers.${index}.selectedFirm`, {shouldFocus: true});
      }
    })

    return sellerIndices.length === 0 && buyerIndices.length === 0;
  }

  const validateOnSize = () => {
    const {buyers, sellers} = formMethods.getValues();
    const buyerSize = buyers.reduce((accum, {size}) => accum = accum + Number(size ), 0);
    const sellerSize = sellers.reduce((accum, {size}) => accum = accum + Number(size ), 0);

    return buyerSize === sellerSize;
  }

  const handleSubmit = () => {
    const tradeDetails = formMethods.getValues();
    const tradeCounterparties = transformTradersDetails(BUYER).concat(transformTradersDetails(SELLER));

    setValidationMessage('');

    if (!Boolean(instrumentId)) {
      setValidationMessage('Please select an instrument');

      return;
    }

    if(!validateOnSize()) {
      setValidationMessage('Buyer and seller sizes do not match');
      setTraderError('size')

      return
    }

    if(!validateOnSelfTrade()) {
      setValidationMessage('Self trading not valid');

      return;
    }

    const orderDetails = {
        instrumentId,
        tradeDetails : {
          executionTime    : tradeDetails.executionTime.toISOString(),
          premium          : Number(tradeDetails.premium),
          premium1         : Number(tradeDetails.premiumOne),
          premium2         : Number(tradeDetails.premiumTwo),
          strike           : Number(tradeDetails.strike),
          strike1Adj       : Number(tradeDetails.strikeOne),
          strike2Adj       : Number(tradeDetails.strikeTwo),
          isHedge          : tradeDetails.hedge,
          hedgePremium     : Number(tradeDetails.hedgePremium),
          hedgeStrike      : Number(tradeDetails.hedgeStrike),
          hedgeNOTL        : Number(tradeDetails.hedgeNOTL),
          isDropCopyBuyer  : false,
          isDropCopySeller : false
        },
        tradeCounterparties
    };

    console.log(orderDetails);

    dispatch(postTradeRequest(orderDetails));
  };

  useEffect(() => {
    nowExecutionTime();
  }, []);

  /*
    Accepted trade status displays a green 'tick' next to the submit button.
    This function / useEffect clears the status when a keyboard or click event is fired.
    Sets the body listener once per trade acceptance.
   */
  const handleClearAcceptedTradeStatus = () => {
    dispatch(tradeResponseUpdated(null));
  };

  React.useEffect(() => {
    if (voiceTradeResponse?.status === 'accepted') {
      document.addEventListener('keydown', handleClearAcceptedTradeStatus, true);
      document.addEventListener('click', handleClearAcceptedTradeStatus, true);
      resetState()

      return () => {
        document.removeEventListener('keydown', handleClearAcceptedTradeStatus, true);
        document.removeEventListener('click', handleClearAcceptedTradeStatus, true);
      };
    }
    else {
      setValidationMessage(voiceTradeResponse?.message);
    }

    return undefined;
  }, [voiceTradeResponse]);


  return (
    <>
      <div className='trade-entry-form__header'>
        <div>Trade Entry</div>
        <div>{instrumentShortName}</div>
      </div>
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(handleSubmit)}
              onKeyDown={(event)=>{

                // Prevent enter key from triggering submission
                if(event.key === 'Enter') {
                  event.preventDefault()
                }
              }}>
          <div className='trade-entry-form__body'>
            <TradeDetails reset={resetState} />
        <div className='trade-entry-form__row'>
          <div className='trade-entry-form__tradeSideHeader__buy'>Buyer</div>
          <div className='trade-entry-form__tradeSideHeader__sell'>Seller</div>
        </div>
        <div className='trade-entry-form__row traders'>
          <div className='trade-entry-form__buyers'>
            {buyerFields.map((buyer, index) => <TraderSelection
                  key={buyer.id}
                  trader={buyer}
                  side={BUYER}
                  sideData={'buyers'}
                  index={index}
                  deleteTrader={() => handleBuyerRemove(index)}
                  isDelete={buyerFields.length > 1}
                />)}
                <label className='addTraderLabel buyer'>
                  <button className='addTraderButton buyer' onClick={() => handleBuyerAppend()}>+</button>
                </label>
              </div>
              <div className='trade-entry-form__sellers'>
                {sellerFields.map((seller, index) => <TraderSelection key={index}
                  trader={seller}
                  side={SELLER}
                  sideData={'sellers'}
                  index={index}
                  deleteTrader={() => handleSellerRemove(index)}
                  isDelete={sellerFields.length > 1}
                />)}
                <label className='addTraderLabel seller'>
                  <button className='addTraderButton seller' onClick={() => handleSellerAppend()}>+</button>
                </label>
              </div>
            </div>
            {Object.keys(formMethods.formState?.errors).length > 0 &&
                <div className={'in-place-message in-place-message-error'}>Please enter marked fields</div>
            }
            {Boolean(validationMessage) &&
                <div className={'in-place-message in-place-message-error'}>{validationMessage}</div>
            }
            {
          Boolean(tradeSubmissionStatusMessage) &&
            <div className={'trade-submission-status'}>{tradeSubmissionStatusMessage}</div>
        }
        <div className='trade-entry-form__buttons'>
          <button id={'tradeSubmitButton'}
            onClick={()=>formMethods.handleSubmit(handleSubmit)} >
            Submit
            {
                Boolean(voiceTradeResponse?.status === 'accepted') &&
                <span className={'trade-submission-status-accepted fa fa-check'} />
            }
          </button>

        </div>
      </div></form>
      </FormProvider>
    </>
  );
}
export default TradeEntryForm;
