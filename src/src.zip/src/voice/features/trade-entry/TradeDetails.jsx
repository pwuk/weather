import React from 'react';
import PropTypes from 'prop-types';

import './tradeDetails.css';
import {DateTimePicker} from '@mui/x-date-pickers/DateTimePicker';
import {Checkbox, Input, TextField} from '@mui/material';
import {LocalizationProvider} from '@mui/x-date-pickers';
import {AdapterDayjs} from '@mui/x-date-pickers/AdapterDayjs';
import {Controller, useFormContext} from 'react-hook-form';
import {useSelector} from 'react-redux';
import {voiceStatus} from '../../store/voiceSlice';
import {useTradeDetailsController} from './tradeDetailsControlHook';

const FIELD_MAX_WIDTH = 100;

// Control the decimal places in premium and strike fields
const NUMBER_STEP = '0.00001';

function TradeDetails ({
  reset,
}) {
  const formMethods = useFormContext();
  const hedgeWatch = formMethods.watch('hedge');
  const {selectedInstrumentId} = useSelector(voiceStatus);

  const {
      premiumOneDisabled,
      premiumTwoDisabled,
      strikeRequired
  } = useTradeDetailsController(selectedInstrumentId);

  return (
    <div id='tradeDetails'>
      <div id='tradeDetails__header'>
        <div>Trade Details</div>
        <button id='tradeReset' className='fa fa-trash-o' onClick={reset} title="Reset all Fields"/>
      </div>
      <div id='tradeDetailsForm'>
        <div className='tradeDetails__row'>
          <label htmlFor='premium'>Premium</label>
          <Controller
            render={
              ({field}) => <TextField {
                ...formMethods.register('premium', {
                    required : {value : true},
                    min      : 0
                })}
                type={'number'}
                inputProps={{step: NUMBER_STEP}}
                error={Boolean(formMethods.formState.errors?.premium)}
              />
            }
            control={formMethods.control}
            defaultValue=""
            name={'premium'}
          />
          <label
              htmlFor='premiumOne'
              className={premiumOneDisabled ? 'disabled-field-label' : ''}
          >Premium 1
          </label>
          <Controller
              render={
                ({field}) => <TextField {
                  ...formMethods.register('premiumOne', {
                      required : {value : !premiumOneDisabled},
                      min      : 0
                  })}
                  type={'number'}
                  inputProps={{step: NUMBER_STEP}}
                  error={Boolean(!premiumOneDisabled && formMethods.formState.errors?.premiumOne)}
                  disabled={premiumOneDisabled}
                />
              }
              control={formMethods.control}
              defaultValue=""
              name={'premiumOne'}
          />
          <label
              htmlFor='premiumTwo'
              className={premiumTwoDisabled ? 'disabled-field-label' : ''}
          >Premium 2</label>
          <Controller
              render={
                ({field}) => <TextField {
                    ...formMethods.register('premiumTwo', {
                        required : {value : !premiumOneDisabled},
                        min      : 0
                    })}
                  type={'number'}
                  inputProps={{step: NUMBER_STEP}}
                  error={Boolean(!premiumOneDisabled && formMethods.formState.errors?.premiumTwo)}
                  disabled={premiumTwoDisabled}
                />
              }
              control={formMethods.control}
              defaultValue=""
              name={'premiumTwo'}
          />
        </div>
        <div className='tradeDetails__row'>
          <label htmlFor='strike'>Strike</label>
          <Controller
              render={
                ({field}) => <TextField {
                  ...formMethods.register('strike', {
                      required : {value : strikeRequired},
                      min      : 0,
                      max      : 100
                      })}
                  type={'number'}
                  inputProps={{step: NUMBER_STEP}}
                  error={Boolean(formMethods.formState.errors?.strike)}
                />
              }
              control={formMethods.control}
              defaultValue=""
              name={'strike'}
          />
          <label
              htmlFor='strikeOne'
              className={premiumOneDisabled ? 'disabled-field-label' : ''}
          >Strike 1</label>
          <Controller
              render={
                ({field}) => <TextField {
                    ...formMethods.register('strikeOne', {
                        required : {value : !premiumOneDisabled},
                        min      : 0,
                        max      : 100
                    })}
                  type={'number'}
                  inputProps={{step: NUMBER_STEP}}
                  error={Boolean(!premiumOneDisabled && formMethods.formState.errors?.strikeOne)}
                  disabled={premiumOneDisabled}
                />
              }
              control={formMethods.control}
              defaultValue=""
              name={'strikeOne'}
          />
          <label
              htmlFor='strikeTwo'
              className={premiumTwoDisabled ? 'disabled-field-label' : ''}
          >Strike 2</label>
          <Controller
              render={
                ({field}) => <TextField {
                  ...formMethods.register('strikeTwo', {
                      required : {value : !premiumTwoDisabled},
                      min      : 0,
                      max      : 100
                  })}
                  type={'number'}
                  inputProps={{step: NUMBER_STEP}}
                  error={Boolean(!premiumTwoDisabled && formMethods.formState.errors?.strikeTwo)}
                  disabled={premiumTwoDisabled}
                />
              }
              control={formMethods.control}
              defaultValue=""
              name={'strikeTwo'}
          />
        </div>
        <div className='tradeDetails__row'>
          <label htmlFor='executionTime'>Execution Time</label>
            <Controller
                render={
                    ({field: {onChange, value}}) =>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DateTimePicker {
                                ...formMethods.register('executionTime', {
                                    required : {value : true},
                                    valueAsDate: true
                                })}
                                onChange={(_, data) => {
                                    onChange(data);
                                    return data;
                                }}
                                value={value}
                                sx={{maxWidth : 145}}
                                ampm={false}
                                name={'executionTime'}
                                slotProps={{ textField: {
                                   error: Boolean(formMethods.formState.errors?.executionTime)
                                }}}
                            />
                        </LocalizationProvider>
                }
                control={formMethods.control}
                name={'executionTime'}
                rules={{ required: true }}
            />
        </div>
        <div className='tradeDetails__row'>
          <label htmlFor='hedge'>Hedge
              <Controller
                  render={
                      ({field : {onChange, value}}) =>
                        <Checkbox { ...formMethods.register('hedge')} defaultChecked={false} />
                  }
                  control={formMethods.control}
                  name={'hedge'}
              />
          </label>
        </div>
        <div className='tradeDetails__row'>
          {hedgeWatch && <>
            <label htmlFor='hedgePremium'>Premium</label>
              <Controller
                  render={({field}) =>
                      <TextField {
                          ...formMethods.register('hedgePremium', {
                              required : {value : true},
                              min      : 0,
                          })}
                          type={'number'}
                          inputProps={{step: NUMBER_STEP}}
                          error={Boolean(formMethods.formState.errors?.hedgePremium)}
                          sx={{maxWidth : FIELD_MAX_WIDTH}}
                      />}
                  control={formMethods.control}
                  defaultValue=""
                  name={'hedgePremium'}
              />
            <label htmlFor='hedgeStrike'>Strike</label>
            <Controller
              render={
                  ({field}) => <TextField {
                    ...formMethods.register('hedgeStrike', {
                        required : {value : true},
                        min      : 0,
                    })}
                    type={'number'}
                    inputProps={{step: NUMBER_STEP}}
                    error={Boolean(formMethods.formState.errors?.hedgeStrike)}
                    sx={{maxWidth : FIELD_MAX_WIDTH}}
                  />
              }
              control={formMethods.control}
              defaultValue=""
              name={'hedgeStrike'}
            />
            <label htmlFor='hedgeNOTL'>Hedge % NOTL</label>
              <Controller
                  render={
                      ({field}) => <TextField {
                        ...formMethods.register('hedgeNOTL', {
                            required : {value : true},
                            min      : 0,
                            max      : 100
                        })}
                        type={'number'}
                        error={Boolean(formMethods.formState.errors?.hedgeNOTL)}
                        sx={{maxWidth : FIELD_MAX_WIDTH}}
                        inputProps={{step: NUMBER_STEP}}
                      />
                  }
                  control={formMethods.control}
                  defaultValue=""
                  name={'hedgeNOTL'}
              />
          </>}
        </div>
      </div>
    </div>
  );
}

TradeDetails.propTypes = {
  reset                 : PropTypes.func,
};

export default TradeDetails;
