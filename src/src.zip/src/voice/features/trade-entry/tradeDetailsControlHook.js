import {useState, useEffect} from 'react';
import {useFormContext} from 'react-hook-form';
import {selectMatrixByInstrumentIds} from "../../store/layoutSlice";
import {getStore} from "../../store";
import fieldRules from './tradeEntryFieldRules';

/**
 * Controls which fields are required and or disabled depending on selected product type.
 *
 * @param selectedInstrumentId Derives the matrix id
 * @returns {{
 *              strikeRequired: boolean,
 *              premiumOneDisabled: boolean,
 *              premiumTwoDisabled: boolean
 *          }}
 */

export const useTradeDetailsController = selectedInstrumentId => {
  const formMethods = useFormContext();
  const premiumValue = formMethods.watch('premium');
  const strikeValue = formMethods.watch('strike');

    // Track previous values
    // For Straddles,  StrikeOne/Two and premiumOne/Two can be derived from the strike & premium fields
    // But, the user can override the values, so keep track of previous values and recalculate when changed.
    // Hedge checkbox click will also trigger this.
  const [prevPremium, setPrevPremium] = useState(formMethods.getFieldState().premium);
  const [prevStrike, setPrevStrike] = useState(formMethods.getFieldState().strike);

  let premiumOneDisabled = false;
  let premiumTwoDisabled = false;
  let strikeRequired = true;

  if(selectedInstrumentId) {
    const {voiceProps} = selectMatrixByInstrumentIds(getStore().getState(), [selectedInstrumentId])[0];
    const disableFields  = voiceProps?.tradeEntry?.disableFields ?? [];

    premiumOneDisabled = disableFields.includes('premiumOne');
    premiumTwoDisabled = disableFields.includes('premiumTwo');

    strikeRequired = voiceProps?.tradeEntry?.shouldNotValidate?.includes('strike') ?? true;

    if(voiceProps?.tradeEntry?.splitPremium) {
        if(premiumValue !== prevPremium) {
            formMethods.setValue('premiumOne', Number(premiumValue) / 2);
            formMethods.setValue('premiumTwo', Number(premiumValue) / 2);
            setPrevPremium(premiumValue)
        }
    }
    if(voiceProps?.tradeEntry?.copyStrike) {
        if(strikeValue !== prevStrike) {
            formMethods.setValue('strikeOne', strikeValue);
            formMethods.setValue('strikeTwo', strikeValue);
            setPrevStrike(strikeValue);
        }
    }
  }

  return {
      premiumOneDisabled,
      premiumTwoDisabled,
      strikeRequired
  };
};
