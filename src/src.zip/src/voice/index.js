/* eslint-disable no-magic-numbers, no-restricted-syntax */
import React from 'react';
import {createRoot} from 'react-dom/client';
import {Provider} from 'react-redux';
import {logger, TSAdapterTypes, createApp} from '@core-tech/web-api';
import createStore from './store';
import App from './app/App.jsx';
import {appStatusUpdated, AppStates} from './store/appSlice';
import {openTradingSession} from './store/loginSlice';
import {subscribeToAccounts} from './store/accountsSlice';
import {fetchDashboard, fetchDocument, selectUniqueDesks} from './store/layoutSlice';
import {subscribeInstruments, selectInstrumentsByContext} from './store/instrumentsSlice';
import {subscribeToTrades} from './store/tradesSlice';
import {msgProcessor} from './store/tradingSessionMiddleware';
import pkg from '../../package.json';

const root = createRoot(document.getElementById('voice-app'));

let appShell = null;

// eslint-disable-next-line max-statements
(async function createVoiceApp () {
  try {
    // Create application shell instance
    appShell = await createApp({
      appType       : 'App',
      appVersion    : pkg.version,
      isPrimary     : true,
      tsAdapterType : TSAdapterTypes.GTI_GBX_ADAPTER,
      venue         : 'voice'
    }, msgProcessor);

    // Create Redux store, injecting shell for thunks to make API calls
    const store = createStore(appShell);

    // Render React root application component
    root.render(
      <Provider store={store}>
        <App />
      </Provider>
    );

    // Dispatch thunk to open a trading-session and establish websocket connection to stream messages to the redux store
    await store.dispatch(openTradingSession(appShell.userId)).unwrap();

    // Dispatch thunk to fetch and load 'Dashboard' layout into the redux store
    const dashboard = await store.dispatch(fetchDashboard()).unwrap();

    // Dispatch thunk to subscribe trade capture reports
    store.dispatch(subscribeToTrades());

    // Dispatch thunk to subscribe site accounts, by desk
    store.dispatch(subscribeToAccounts({
      desks : selectUniqueDesks(store.getState())
    }));

    // Finally, build the dashboard's document layouts
    for await (const document of dashboard.pageList) {
      const {desk, subscriptionKey, linkName : context} = document;

      // Dispatch thunk to subscribe to the document's securities
      await store.dispatch(subscribeInstruments({
        context,
        subscriptionKey
      })).unwrap();

      // Dispatch thunk to build the document layout from the subscribed securities
      await store.dispatch(fetchDocument({
        desk,
        context,
        instruments : selectInstrumentsByContext(store.getState(), context)
      })).unwrap();
    }

    store.dispatch(appStatusUpdated({state : AppStates.APP_ONLINE}));
  } catch (err) {
    logger.error(`[createVoiceApp] Error initializing primary Dashboard application v${pkg.version}: error[${err}]`);

    logger.info(`[createVoiceApp] Forcing page reload: ${window.location}`);

    // Force page reload after 60 seconds
    setTimeout(() => window.location.reload(), 60000);
  }
}());

window.onbeforeunload = () => {
  logger.info('[createVoiceApp] Application is shutting down normally, flushing all log statements.');

  if (appShell) {
    appShell.close();
  }
};
