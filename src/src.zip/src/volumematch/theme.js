/* eslint-disable func-names, no-param-reassign, no-plusplus */
/* global BGC, _ */
/*
 * file theme.js
 * BGC Theme module implementation at the VolumematchView level.
 */

function uiThemes (context) {
  context.Volumematch = {
    // Themes supported by the application. We should add the new theme information here.
    // Theme id was stored as well as indexed in the mark up as 0 based for legacy reasons.
    themes : {
      2 : {name : window.BGC.resources.IDS_NVM_PEARL_THEME},
      3 : {name : window.BGC.resources.IDS_NVM_CHARCOAL_THEME},
      4 : {name : window.BGC.resources.IDS_NVM_ONYX_THEME}
    },

    // Themes supported by the brand - note some brands reuse the BGC theme set and
    // so are mapped to "BGC".
    brand : {
      BGCIRO : {
        defaultThemeId    : '2',
        supportedThemeIds : ['2', '3', '4']
      },
      GFI : {
        defaultThemeId    : '2',
        supportedThemeIds : ['2', '3', '4']
      }
    },

    /**
     * Notifies Volumematch application about changed theme.
     * Performs locally scoped logic since volumematch view doesn't follow overall
     * tables styling.
     *
     * @param {String} themeSuffix - is the theme to change to.
     * @function
     * @memberof ui.theme.Volumematch
     */
    setLocalTheme (themeSuffix) { // eslint-disable-line complexity, max-statements
      const htmlElement = document.querySelector('html');

      htmlElement.className = htmlElement.className.replace(
        /volumematch-\S+/,
        ''
      );
      htmlElement.classList.add(`volumematch${themeSuffix}`);
    },

    setFavIcon (brandId) {
      const favIconLinkElement = document.querySelector('link[rel="shortcut icon"]');

      if (favIconLinkElement) {
        const logoMap = {
          BGC       : 'bgc-favicon.ico',
          BGCIRO    : 'bgc-favicon.ico',
          GFI       : 'gfi.ico',
          GBX       : 'bgc-favicon.ico',
          'GFI-FXO' : 'gfi.ico'
        };

        favIconLinkElement.setAttribute('href', `assets/images/${logoMap[brandId]}`);
      }
    },

    // Returns the default theme. getBrandId ensures that a valid string will be returned.
    getDefaultTheme () {
      const brandId = BGC.ui.theme.getBrandId();
      const {defaultThemeId} = this.brand[brandId] || this.brand.BGCIRO;

      return {
        selectedTheme          : defaultThemeId,
        polymerComponentsTheme : `theme${defaultThemeId}`
      };
    },

    // Returns the supported themes for this brand. getBrandId ensures that a valid string will be returned.
    getSupportedThemes () {
      const brandId = BGC.ui.theme.getBrandId();
      const supportedThemes = (this.brand[brandId] || this.brand.BGCIRO)
        .supportedThemeIds;

      // filter out unsupported themes.
      return _.pick(this.themes, supportedThemes);
    }
  };

  // We want to disable the installation of the standard CSS theme files,
  // we don't use them in the Volume Match window.
  context.installAlternateCssFileLinks = function (caller, callback) {
    callback.call(caller);
  };
}

const context = window.BGC.ui.theme ? window.BGC.ui.theme : {};

uiThemes(context);

export default {};
