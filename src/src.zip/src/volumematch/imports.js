// Styles
import './less/common.less';
import './less/activeorders.less';
import './less/main.less';
import './less/matrix.less';
import './less/my-favorites-view.less';
import './less/portfolio.less';
import './less/orderentry.less';
import './less/tileview.less';
import './less/tradehistory.less';
import './less/instrumentsearch.less';
import './less/business-specific.less';
import './less/column-specific.less';
import './less/statusoverlay.less';
import './less/jquery-ui.theme.less';

// Common VM libraries
import 'axios';
import 'backbone';
import 'jquery';
import 'jquery-contextmenu';
import 'jquery-ui';
import 'jquery-ui/ui/widgets/dialog';
import 'jquery-ui/ui/widgets/sortable';
import 'jquery-ui/ui/widgets/autocomplete';
import 'underscore';
import 'tinycolor';

/* Fix for CEF dropdown offset issue */
import './legacy/fixcefselectoffset';

/* Legacy Application framework - intention is to deprecate over time by moving functions into VM framework */
import './legacy/bgc';
import './legacy/automation';
import './legacy/eventshandler';
import './legacy/datastore';
import './legacy/theme';

/* VMMatrix specific */
import './bgc';
import './eventshandler';
import './resources';
import './theme';

/* Utils */
import './utils/openfin_utils';
import './utils/utils';
import './utils/renderobject';
import './utils/loghandler';
import './utils/schemavalidator';
import './utils/validators';
import './utils/pricetypes';

/* Components */
import './views/tooltip';
import './views/jqueryui-customisation';
import './views/popupwidget';
import './views/order-entry-container-behavior';
import './views/quicksize-buttonset/quicksize-buttonset';

// import './components/nudgeable-price-input/nudgeable-price-input';
import './views/size-input-control/size-input-control';
import './views/inplace-order-entry/inplace-order-entry';
import './views/account-selection/account-button';
import './views/account-selection/accounts-bar';
import './views/editable-price-cell/editable-price-cell';
import './views/progress-bar/progress-bar';

// https://jira.cad.local:8443/browse/BGCVM-973

import './views/input-toggle';
import './views/drop-target';

/* Store */
import './store/datastore';
import './views/portfolio/config';
import './store/models/portfolio';
import './store/portfolio';
import './store/selection-manager';
import './store/models/account';
import './store/models/auction';
import './store/models/footprints';
import './store/models/instrument';
import './store/models/layout';
import './store/models/matrix';
import './store/models/order';
import './store/models/spread';
import './store/models/tile';
import './store/models/trade';

/* Views */
import './views/viewutils';
import './views/activeordersview';
import './views/docking';
import './views/globaltoolbar';
import './views/headerview';
import './views/instrumentsearchview';
import './views/layouteditor';
import './views/mainview';
import './views/orderentryviews';
import './views/settingsview';
import './views/stacklayoutview';
import './views/tabcontrol';
import './views/tradehistoryview';
import './views/verticallayoutview';
import './views/tile/notification-flash-behavior';

// import './views/auction/row';
// import './views/auction/group';
// import './views/auction/layout';
import './views/matrix/matrixview';
import './views/matrix/gridviewnav';
import './views/matrix/vm-cell-view';
import './views/favorites/fa-state-icon';
import './views/favorites/fa-icon';
import './views/favorites/filter-menu';
import './views/favorites/fa-count-button';
import './views/favorites/my-favorites-view';
import './views/portfolio/row';
import './views/portfolio/grid';
import './views/portfolio/view';
import './views/tile/vm-header-row';
import './views/tile/vm-tilerow-behavior';
import './views/tile/vm-instrumentrow';
import './views/tile/vm-tile-behavior';
import './views/tile/vm-instrumenttile';
import './views/tile/vm-midprice-cell';

// import './views/tile/vm-ordersize-cell';
import './views/tile/vm-spread-instrumentrow';
import './views/tile/vm-spreadtile';
import './views/toolbar/toolbar';
