/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false, console: false */
///////////////////////////////////////////////////////////////////////////////
// file theme.js
// BGC Theme module implementation.
///////////////////////////////////////////////////////////////////////////////

import getApp from '../index';

(function (context, undefined) {
    "use strict";

    // CSS files to use, in the order they should be applied
    // - base file names, no theme Id suffix, no ".css" extension
    // Lower level theme.js files that extend this context may add more files to the array
    context.cssFiles = [];
    context.cssFiles.push("style");

    var numberOfSupportedThemes = 14, // old-style BGC themes
        selectedComponentTheme = "theme1";

    context.setCssTheme = function (themeId) {
        var i, defaultCssFileName, enableCssFileName, selectCssFilesStartingWith, cssPath = "../css/", cssStyles, found;

        if (typeof themeId !== "string") {
            themeId = "";
        }

        // Utility function for use in the below loop
        function enableDisable() {
            var cssStyle = $(this);
            if (cssStyle.attr("href") === enableCssFileName) {
                cssStyle.prop("disabled", false);
                found = true;
            } else {
                cssStyle.prop("disabled", true);
            }
        }

        for (i = 0; i < context.cssFiles.length; ++i) {
            found = false;
            defaultCssFileName = context.cssFiles[i];
            enableCssFileName = cssPath + defaultCssFileName + themeId + ".css";

            selectCssFilesStartingWith = cssPath + defaultCssFileName;
            cssStyles = $("link[rel='stylesheet'][href^='" + selectCssFilesStartingWith + "']");

            // For this particular CSS file flavour (e.g. "datatables"),
            // enable the one with the required theme suffix (e.g. "../css/datatables-theme1.css")
            // and disable the rest. If themed version not found, enable the default (e.g. "../css/datatables.css")
            $.each(cssStyles, enableDisable);
            if (!found) {
                // Ensure the default CSS is enabled
                $("style[href='" + defaultCssFileName + ".css" + "']").prop("disabled", false);
            }
        }

    };

    context.installAlternateCssFileLinks = function (caller, callback) {
        var i, defaultCssFileName, fullCssFileName, cssPath = "../css/", themeNumber, themeId, loadArray = [];

        for (i = 0; i < context.cssFiles.length; ++i) {
            defaultCssFileName = context.cssFiles[i];
            for (themeNumber = 1; themeNumber <= numberOfSupportedThemes; ++themeNumber) {
                themeId = "-theme" + themeNumber;
                fullCssFileName = cssPath + defaultCssFileName + themeId + ".css";
                loadArray.push(fullCssFileName);
            }
        }
        BGC.utils.loadCss(loadArray, caller, callback);
    };

    context.getBrandId = function () {
        // GBX Rates - Set single BGCIRO brand
        return getApp().brand || 'BGCIRO';
    };

    context.getBrandCompanyName = function () {
        var companyNameMap = {
            "BGC": "BGC Technology Markets, L.P.",
            "BGCIRO": "BGC Technology Markets, L.P.",
            "GFI": "GFI Group Inc.",
            "GFI-FXO": "GFI Group Inc."
        };

        return companyNameMap[context.getBrandId()] || companyNameMap["BGC"];
    };

    context.getBrandShortCompanyName = function () {
        var shortCompanyNameMap = {
            "BGC": "BGC",
            "BGCIRO": "BGC",
            "GFI": "GFI",
            "GFI-FXO": "GFI"
        };

        return shortCompanyNameMap[context.getBrandId()] || shortCompanyNameMap["BGC"];
    };

    context.getBrandCompanyWebsiteURL = function () {
        var companyWebsiteURLMap = {
            "BGC": "http://www.bgcpartners.com/",
            "BGCIRO": "http://www.bgcpartners.com/",
            "GFI": "http://www.gfigroup.com/",
            "GFI-FXO": "http://www.gfigroup.com/",
            "CANTOR": "https://www.cantor.com/"
        };

        return companyWebsiteURLMap[context.getBrandId()] || companyWebsiteURLMap["BGC"];
    };

    context.getBrandLogoImagePath = function () {
        var logoMap = {
            "BGC": "/images/shared/taskbaricon.ico",
            "BGCIRO": "/images/shared/taskbaricon.ico",
            "GFI": "/images/shared/gfi-taskbaricon.ico",
            "GFI-FXO": "/images/shared/gfi-taskbaricon.ico"
        };

        return window.location.origin + (logoMap[context.getBrandId()] || logoMap["BGC"]);
    };

    context.getBrandWindowIconPath = function () {
        var logoMap = {
            "BGC": "/images/shared/favicon.ico",
            "BGCIRO": "/images/shared/favicon.ico",
            "GFI": "/images/shared/gfi-taskbaricon.ico",
            "GFI-FXO": "/images/shared/gfi-taskbaricon.ico"
        };

        return window.location.origin + (logoMap[context.getBrandId()] || logoMap["BGC"]);
    };

    context.getBrandTaskbarIconPath = function () {
        var logoMap = {
            "BGC": "/images/shared/taskbaricon.ico",
            "BGCIRO": "/images/shared/taskbaricon.ico",
            "GFI": "/images/shared/gfi-taskbaricon.ico",
            "GFI-FXO": "/images/shared/gfi-taskbaricon.ico"
        };

        return window.location.origin + (logoMap[context.getBrandId()] || logoMap["BGC"]);
    };

    context.getBrandLogo = function () {
        const logoMap = {
            // "BGC": "/assets/images/bgc-logo-black.svg",
            "BGC": "--bgc-logo-url",
            // "BGCIRO": "/assets/images/bgc-logo-black.svg",
            "BGCIRO": "--bgc-logo-url",
            "GFI": "/assets/images/GFI-Logo.png",
            "GFI-FXO": "/assets/images/GFI-Logo.png",
            "GBX": "/assets/images/gbx-logo-black.png",
            "CAVENTOR": "/assets/images/caventor-logo-color.png"
        }

        // Window Pathnamme -> /volumematch/volumematch.htm
        // Do not need the last path /volumematch.htm
        const orgPath = window.location.pathname;
        const path = orgPath.slice(0, orgPath.lastIndexOf('/'));

        const logo = logoMap[context.getBrandId()] || logoMap['BGCIRO'];
        const isCSSVar = logo.slice(0,2) === "--";

        if(isCSSVar) {
            return `var(${logo})`;
        }

        return window.location.origin + path + (logoMap[context.getBrandId()] || logoMap["BGCIRO"]);
    };
}(window.BGC.ui.theme));
