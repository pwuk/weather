/* eslint-disable func-names, no-param-reassign, max-lines, max-statements, no-inline-comments, line-comment-position, max-len, no-plusplus */
/* global BGC: false, $: false, _:false, Backbone: false, tv4: false */

// /////////////////////////////////////////////////////////////////////////////
// file datastore.js
// BGC Data store module implementation for backbone-based models.
// Derive specialised behaviours from this class and include the code
// context.dataStore = new <MyDataStoreClassName>;
// at the end of the self-executing function that contains the derived class definition
// /////////////////////////////////////////////////////////////////////////////

import {getUserSettingsStore, getUserSettingCollection, restoreSettings} from '@core-tech/web-api/user-settings';

(function (context) {
  context.BackboneDataStore = function () {
    if (!(this instanceof context.BackboneDataStore)) {
      throw new Error('Constructor called as a function.');
    }

    _.extend(this, Backbone.Events);

    this.defaultLogContext = '';

    // Any view may have to wait on a number of different kinds of resource to load before it's fully initialized
    this.resourceSynchronizer = new BGC.utils.AsyncEventSynchronizer(this, this.finalizeInitialize);

    // Can't be initialized until the C++ tells us it has sent everything we need, either
    this.resourceSynchronizer.addEvent(this, 'waitingForInitializePage');

    // Any view must support theme selection (selection of alternate CSS files).
    this.currentThemeCssFileSuffix = '';

    // These are downloaded asynchronously so we don't want to finalize initialization of the view until ready.
    this.resourceSynchronizer.addEvent(this, 'waitingForAlternateCssFiles');

    // Any view may need some general settings from the app
    this.generalSettingsCollection = {};

    // Any view will need supporting data stored in one or more Backbone collections/models
    // We need to store definitions for both, and instances of collections
    // These will be dynamically driven from the business logic in the host
    this.collectionDefinitions = {};
    this.modelDefinitions = {};
    this.collections = {};

    // Initialise the user settings store
    this.initUserSettings();

    // All datastores must provide a schema for validating data received from the outside world.
    // This may be extended in derived classes by calling this.augmentSchema()
    // AT THE VERY LEAST, each derived datastore class must add an "initializePage" schema and an initializePage(message) function
    // This is the message that the marshal should send when the page has loaded and the data collection and table definitions have been sent.
    // The initializePage(message) function should do any other necessary initialization and then create the Backbone view objects in BGC.ui.view
    const schema = {
      $schema : 'http://json-schema.org/draft-04/schema',

      type       : 'object',
      properties : {
        messages : {
          type  : 'array',
          items : {
            oneOf : [
              {$ref : '#/definitions/generalSettingsSchema'},
              {$ref : '#/definitions/userSettingsSchema'},
              {$ref : '#/definitions/debugActivationSchema'},
              {$ref : '#/definitions/reloadPageSchema'}
            ]
          }
        }
      },

      definitions : {
        generalSettingsSchema : {
          required   : ['messageName', 'settings'],
          properties : {
            messageName : {enum : ['generalSettings']},
            settings    : {
              type : 'array',

              // "items" represents the items in the "settings" array
              items : {
                type       : 'object',
                required   : ['name', 'value'],
                properties : {
                  name  : {type : 'string'},
                  value : {type : 'string'}
                }
              }
            }
          },
          additionalProperties : false
        },

        userSettingsSchema : {
          required   : ['messageName', 'settings'],
          properties : {
            messageName : {enum : ['userSettings']},
            settings    : {
              type : 'string'
            }
          },
          additionalProperties : false
        },

        debugActivationSchema : {
          required   : ['messageName'],
          properties : {
            messageName : {enum : ['debugActivation']},
            debugLevel  : {type : 'number'}
          },
          additionalProperties : false
        },

        reloadPageSchema : {
          required   : ['messageName'],
          properties : {
            messageName : {enum : ['reloadPage']}
          },
          additionalProperties : false
        }
      }

    };

    // Public functions accessing private schema

    this.validateMessage = function (message, validationError) {
      const isValid = tv4.validate(message, schema);

      if (!isValid && validationError) {
        validationError.code = tv4.error.code;
        validationError.message = tv4.error.message;
      }

      return isValid;
    };

    // Adds a message definition to the schema
    this.augmentSchema = function (messageName, schemaDefinition) {
      const schemaName = messageName.endsWith('Schema') ? messageName : `${messageName}Schema`;
      const schemaRef = `#/definitions/${schemaName}`;

      schema.properties.messages.items.oneOf.push({$ref : schemaRef});
      schema.definitions[schemaName] = schemaDefinition;
    };

    // Adds a reuseable data definition to the schema that may be used in message definitions
    this.addSchemaDataDefinition = function (dataName, schemaDefinition) {
      const schemaName = dataName.endsWith('Schema') ? dataName : `${dataName}Schema`;

      schema.definitions[schemaName] = schemaDefinition;
    };

    this.logSchema = function () {
      // eslint-disable-next-line no-console
      console.log(JSON.stringify(schema));
    };
  };

  context.BackboneDataStore.prototype.constructor = context.BackboneDataStore;

  context.BackboneDataStore.prototype.update = function (messageData) {
    // Accept a raw JSON string or its object equivalent.
    const jsonMessageData = typeof messageData === 'string' ? (JSON && JSON.parse(messageData)) || $.parseJSON(messageData) : messageData;
    const messageCount = jsonMessageData.messages.length;
    let valid = false;

    try {
      if (this.isJsonMessageValidationRequired) {
        // Validate against the schema using Tiny Validator (supports v4 draft of JSON Schema)
        valid = this.isJsonMessageValidationRequired ? this.validateMessage(jsonMessageData) : true;
      }
    } catch (error) {
      BGC.logger.logError('', `${error.name}: ${error.message}\n\n${JSON.stringify(jsonMessageData)}`);
      throw new Error(`${error.name}: ${error.message}\n\n${JSON.stringify(jsonMessageData)}`);
    }

    // Report standard validation errors that didn't already throw an exception from the validator
    if (this.isJsonMessageValidationRequired && !valid) {
      BGC.logger.logError('', `${tv4.error.message}  [Code = ${tv4.error.code}]\n\n${JSON.stringify(jsonMessageData)}`);
      throw new Error(`${tv4.error.message}  [Code = ${tv4.error.code}]\n\n${JSON.stringify(jsonMessageData)}`);
    }

    // Fields are valid or exception would have been thrown and we wouldn't be here.
    for (let index = 0; index < messageCount; ++index) {
      const message = jsonMessageData.messages[index];

      this.processMessage(message);
    }
  };

  context.BackboneDataStore.prototype.initUserSettings = function () {
    this.userSettingsStore = getUserSettingsStore();
    this.userSettingsCollection = getUserSettingCollection();
  };

  // eslint-disable-next-line complexity
  context.BackboneDataStore.prototype.processMessage = function (message) {
    if (message.messageName === 'debugActivation') {
      BGC.utils.debug.debugTrace = true;
      BGC.utils.debug.debugLevel = message.debugLevel;

      // Only invoke message validation if this is a debug build
      this.isJsonMessageValidationRequired = !message.debugLevel || message.debugLevel === 1;
      if (this.isJsonMessageValidationRequired) {
        this.logSchema();
      }
    } else if (message.messageName === 'reloadPage') {
      window.location.reload();
    } else if (message.messageName === 'initializePage' || message.messageName === 'page') {
      this.initializePage(message);
    } else if (message.messageName === 'generalSettings') {
      for (let settingIndex = 0; settingIndex < message.settings.length; ++settingIndex) {
        this.generalSettingsCollection[message.settings[settingIndex].name] = message.settings[settingIndex].value;
        this.onGeneralSettingChanged({name : message.settings[settingIndex].name, value : message.settings[settingIndex].value});
      }
    }
  };

  context.BackboneDataStore.prototype.onAlternateCssFilesLoaded = function () {
    BGC.ui.theme.setCssTheme(this.currentThemeCssFileSuffix);
    this.trigger('waitingForAlternateCssFiles');
  };

  // eslint-disable-next-line no-shadow
  context.BackboneDataStore.prototype.onLoadUserSettings = function (settings, appContext) {
    restoreSettings(settings, appContext);
  };

  // Called after setting has been stored by the message handler.
  // This function may be overridden to allow any specialized behaviour to be triggered for specific setting changes
  context.BackboneDataStore.prototype.onGeneralSettingChanged = function (setting) {
    let value = null;

    if (setting.value === 'Y') {
      value = 1;
    } else if (setting.value === 'N') {
      value = 0;
    } else {
      value = setting.value;
    }
    this.userSettingsCollection.defaults.set(setting.name, value, true);
  };

  context.BackboneDataStore.prototype.setupEnumerations = function () {
    // Set up any global enumerations required for code clarity
    BGC.enums = BGC.enums || {};

    // Nomenclure enumerants mimic the values defined in OMS\Instrument.h
    BGC.utils.createEnumeration(BGC.enums, 'ENomenclature', ['bidOffer', 'payRec', 'paidGiven', 'traded']);
  };

  // This function may be overridden to allow any specialized page initialization message to be handled
  // If it IS overridden then the base class must also be called.
  // e.g.  context.MyDataStore.prototype.initializePage = function (message) {
  //           ...
  //           context.BackboneDataStore.prototype.initializePage.call(this);
  //       };
  context.BackboneDataStore.prototype.initializePage = function () {
    if (!this.defaultLogContext) {
      this.defaultLogContext = document.title || '';
    }

    BGC.ui.theme.installAlternateCssFileLinks(this, this.onAlternateCssFilesLoaded);
    this.trigger('waitingForInitializePage');
  };

  // MUST override this to trigger creation of Backbone view(s) when all initialization is complete
  // Override MUST call the base class so that UIA can be initialized if necessary
  context.BackboneDataStore.prototype.finalizeInitialize = function () {
    if (BGC.ui.automation.enabled) {
      BGC.ui.view.initializeUIA();
    }
  };

  context.BackboneDataStore.prototype.setCurrentThemeCssFileSuffix = function (themeSuffix, initOnly) {
    this.currentThemeCssFileSuffix = themeSuffix;
    if (!initOnly) {
      BGC.ui.theme.setCssTheme(this.currentThemeCssFileSuffix);
    }
  };

  context.BackboneDataStore.prototype.getGeneralSetting = function (settingId) {
    let setting = this.generalSettingsCollection[settingId];

    if (setting === undefined) {
      setting = this.userSettingsCollection.global.get(settingId);
    }

    return setting;
  };

  // Required for logging, which is designed to allow a log context
  // specific to an individual viewId (a part of the greater view) to be retrieved.
  // This was originally designed this way for the Pod GUI, where each Pod has its own logContext (its Id) but isn't really relevant for much else
  // This function may be overridden as desired.
  context.BackboneDataStore.prototype.getField = function () {
    return '';
  };
}(window.BGC, window.BGC.Settings));
