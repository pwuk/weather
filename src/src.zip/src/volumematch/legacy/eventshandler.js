import {UserSettings} from '@core-tech/web-api/user-settings';
import getApp from '../index';
import axios from 'axios';

(function (context, undefined) {
  const {BGCAPP} = window;
  const {logger} = window.BGC;

  // eslint-disable-next-line max-params
  context.onClick = (id, fieldName, fieldValue, options) => {
    getApp().sendTradingSessionCmd(id, fieldName, fieldValue, options);
  };

  context.onMouseDown = () => {
    if (BGCAPP) {
      BGCAPP.onMouseDown();
    }
  };

  context.onKeyDown = keyEvent => {
    if (BGCAPP) {
      BGCAPP.onKey('keyDownEvent', JSON.stringify({
        which    : keyEvent.which,
        altKey   : keyEvent.altKey,
        shiftKey : keyEvent.shiftKey,
        ctrlKey  : keyEvent.ctrlKey
      }));
    }
  };

  context.onKeyUp = keyEvent => {
    if (BGCAPP) {
      BGCAPP.onKey('keyUpEvent', JSON.stringify({
        which    : keyEvent.which,
        altKey   : keyEvent.altKey,
        shiftKey : keyEvent.shiftKey,
        ctrlKey  : keyEvent.ctrlKey
      }));
    }
  };

  context.onKeyPress = keyEvent => {
    if (BGCAPP) {
      BGCAPP.onKey('keyPressEvent', JSON.stringify({
        which    : keyEvent.which,
        altKey   : keyEvent.altKey,
        shiftKey : keyEvent.shiftKey,
        ctrlKey  : keyEvent.ctrlKey
      }));
    }
  };

  context.onLayoutResize = size => {
    const {mainWindow} = getApp();

    const newClientWidth = Math.max(size.x, size.minX);
    const newClientHeight = Math.max(size.y, size.minY);

    mainWindow.resize(newClientWidth, newClientHeight);
  };

  context.onUpdateGeneralSetting = (viewId, fieldName, fieldValue) => {
    const {tradingSession} = getApp();

    if (BGCAPP) {
      BGCAPP.onClick(viewId, fieldName, fieldValue);
    } else if (tradingSession) {
      let name = '';
      let value = '';

      switch (fieldName) {
        case 'vmChangeUpsizingMode':
          name = 'incrementalUpsizing';
          value = Number(JSON.parse(fieldValue).upsizingMode) === 0 ? 'Y' : 'N';
          break;
        case 'vmChangeMaximumQuantity':
          name = 'maximumQuantity';
          value = JSON.parse(fieldValue).maximumQuantity;
          break;
        default:
          logger.logWarning('onUpdateGeneralSetting', `Unknown setting received: ${fieldName}`);
          break;
      }

      tradingSession.send({
        commandName   : 'updateGeneralSetting',
        commandSource : viewId,
        commandParams : {name, value}
      });
    }
  };
}(window.BGC.eventsHandler));
