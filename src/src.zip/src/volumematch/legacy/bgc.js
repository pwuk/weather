/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */
///////////////////////////////////////////////////////////////////////////////
// file bgc.js
// BGC namespace.
///////////////////////////////////////////////////////////////////////////////

(function () {
    "use strict";

    // ECMAScript6 Polyfills...

    if (!String.prototype.includes) {
        String.prototype.includes = function (search, start) {
            if (typeof start !== 'number') {
                start = 0;
            }

            if (start + search.length > this.length) {
                return false;
            }

            return this.indexOf(search, start) !== -1;
        };
    }

    if (!String.prototype.supplant) {
        String.prototype.supplant = function (obj) {
            return this.replace(
                /{([^{}]*)}/g,
                function (a, b) {
                    var r = obj[b];
                    return typeof r === 'string' || typeof r === 'number' ? r : a;
                }
            );
        };
    }

    // Give array methods to NodeList, for ease of iterating results of Element.querySelectorAll()

    var arrayMethods = Object.getOwnPropertyNames(Array.prototype);

    arrayMethods.forEach(attachArrayMethodsToNodeList);

    function attachArrayMethodsToNodeList(methodName) {
        if (methodName !== "length") {
            NodeList.prototype[methodName] = Array.prototype[methodName];
        }
    };
}());

// Helper function to retrieve the appropriate requestAnimationFrame implementation based on browser version.
// Moved on top of every other modules as browsers may bind this function early regardless of the order of inclusion.
window.requestAnimationFrame = (function () {
    "use strict";
    return  window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame ||
            function (callback) {
                window.setTimeout(callback, 1000 / 60);
            };
}());

/**
 * @namespace BGC
 */
window.BGC = {
    /**
     * @property {Object} BGC.ui
     * @property {Object} BGC.ui.automation
     * @property {Object} BGC.ui.theme
     * @property {Object} BGC.ui.view
     * @property {Object} BGC.ui.viewUtils UI View utilities module.
     */
    ui: {
        automation: {},
        theme: {},
        view: {},
        viewUtils: {}
    },

    /**
     * @property {Object} BGC.dataStore
     */
    dataStore: {},

    /**
     * @property {Object} BGC.utils
     */
    utils: { trace: function () { } }, // dummy function until debug logging activated

    /**
     * @property {Object} BGC.logger
     */
    logger: {},

    /**
     * @property {Object} BGC.eventsHandler
     */
    eventsHandler: {},

    /**
     * @property {Object} BGC.openfin
     */
    openfin: {},

    /**
     * @property {Object} BGC.Settings
     */
    Settings: {},

    /**
     * Preserve vuex bridging methods
     */
    ...window.BGC
};

// Document has loaded and is ready.
$(document).ready(function () {
    "use strict";

    // Display the loading message
    $("#loadingMessage").css("opacity", 1);

    // Enable automation if URL query parameter specified
    if (window.location.href.indexOf("qaaEnabled=true") !== -1) {
        BGC.ui.automation.enabled = true;
    }

    // Inject the Thomson Reuters Eikon JET API if Thomson Reuters Eikon is detected.
    if (window.EikonData) {
        $('head').append('<link rel="import" type="text/html" href="../script/third/jet-app/jet-app.html"/>');
    }
});

 //Disable drag operations at document level - we handle them.
$(document).mousedown(function (event) {
    "use strict";

    // Call back into the C++ in order to allow it to dismiss any active popup menus... Particularly ribbon bar popup menus.
    BGC.eventsHandler.onMouseDown();

    // Make exception for in-place edit, to allow text selection etc. to work
    var target = $(event.target);
    if (target.is("input") || target.is("select")) {
        return true;
    }
    return false;
});

// Disable standard web page context menu unless we are web deployed - we create our own from
// mouse click handlers instead
$(document).contextmenu(function () {
    "use strict";
  return !Reflect.has(window, 'BGCAPP');
});

$(document).keydown(function (keydownEvent) {
    "use strict";

  const isWebDeployed = !Reflect.has(window, 'BGCAPP');

    if (keydownEvent.which === BGC.utils.KeyCodes.F5) { // F5
        // Pass this out of JavaScript world to be dealt with elsewhere and prevent default
        // processing unless we are web deployed
        BGC.eventsHandler.onKeyDown(keydownEvent);
        return isWebDeployed;
    }
    // Pass this out of JavaScript world to be dealt with elsewhere
    BGC.eventsHandler.onKeyDown(keydownEvent);
    // but also allow default processing by the browser
    return true;
});
