/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */
///////////////////////////////////////////////////////////////////////////////
// file automation.js
// BGC Automation module implementation.
///////////////////////////////////////////////////////////////////////////////

(function (context, undefined) {
    "use strict";

    var isSerializationLocked = false, scrollingElementPositions = {}, autoScrollingParentId = "", lastOutput = "";

    context.enabled = false;
    context.rootAutomationElement = {};

    // Need a way for the UIA proxy to execute commands on the UI
    context.uiaExecute = function (messageData) {
        // Accept a raw JSON string or its object equivalent.
        var jsonMessageData = (typeof messageData === "string") ? ((JSON && JSON.parse(messageData)) || $.parseJSON(messageData)) : messageData,
            i, message, messageCount = jsonMessageData.messages.length,
            uiaExecuteSchema = {
            "$schema": "http://json-schema.org/draft-04/schema",

            "type": "object",
            "properties": {
                "messages": {
                    "type": "array",
                    "items": {
                        "oneOf": [
                            { "$ref": "#/definitions/scrollItemSchema" }
                        ]
                    }
                }
            },

            "definitions": {
                "scrollItemSchema": {
                    "required": ["messageName", "parent", "child"],
                    "properties": {
                        "messageName": { "enum": ["scrollItemIntoView"] },
                        "parent": { "type": "string" },
                        "child": { "type": "string" }
                    },
                    "additionalProperties": false
                }
            }

        },
        // Validate against the schema using Tiny Validator (supports v4 draft of JSON Schema)
        valid = tv4.validate(jsonMessageData, uiaExecuteSchema);

        if (!valid) {
            BGC.logger.logError("", tv4.error.message + "  [Code = " + tv4.error.code + "]\n\n" + JSON.stringify(jsonMessageData));
            throw new Error(tv4.error.message);
        }

        // Fields are valid or exception would have been thrown and we wouldn't be here.
        for (i = 0; i < messageCount; ++i) {
            message = jsonMessageData.messages[i];

            if (message.messageName === "scrollItemIntoView") {
                context.startAutoScroll(message.parent, message.child, 0);
            }
        }
    };

    context.startAutoScroll = function (parentId, childId, milliSecsDuration) {
        context.lockSerialization(true);
        var scrolledChild = $("[data-uiaId='" + childId + "']"),
            scrollableParent = $("[data-uiaId='" + parentId + "']");

        autoScrollingParentId = parentId;
        scrollableParent.scrollTo(scrolledChild, milliSecsDuration, { onAfter: context.endAutoScroll });
    };

    context.endAutoScroll = function () {
        // Update the scrolling element's last scroll pos, to prevent scroll handler from kicking in
        var autoScrollingParent = $("[data-uiaId='" + autoScrollingParentId + "']");
        scrollingElementPositions[autoScrollingParentId] = autoScrollingParent.scrollTop();
        context.lockSerialization(false);
        // Need to re-serialise UIA elements as we have just changed their position
        context.serialize();
    };

    // A quick way to optimize DOM access is to keep track of the old content
    // to prevent redundant updates.
    context.serialize = function () {
        if (!context.enabled) {
            return;
        }
        // stringify() calls toJSON() on the supplied object.
        // Tab-indented for readability only (not strictly necessary).
        BGC.logger.logInformation("", "Starting UIA object model serialization...");
        if (!isSerializationLocked) {
            var output = JSON.stringify(context.rootAutomationElement, null, "\t");
            BGC.logger.logInformation("", "Finished UIA object model serialization.");

            // Update the DOM.
            if (lastOutput !== output) {
                lastOutput = output;

                // Send JSON string to host.
                BGC.eventsHandler.onUiaStructureChanged(output);
                BGC.logger.logInformation("", "Serialized UIA model sent to host.");
            } else {
                BGC.logger.logInformation("", "Serialized UIA model hasn't changed. Nothing sent to host.");
            }
        } else {
            BGC.logger.logInformation("", "Serialization locked: Aborting UIA object model serialization.");
        }
    };

    // Need to be able to protect against too many serialization calls.
    // For instance, when inserting rows into a scrollable table, the scroll handler gets called several times.
    // The scroll handler for any scrollable element (as set by view.buildUIA()) serializes the UIA elements,
    // as they may have changed position. However when a new DOM element is added within the scrollable parent,
    // all UIA serialization needs to be deferred until the UIA elements have been re-created (so they include
    // the new DOM element)
    context.lockSerialization = function (lock) {
        isSerializationLocked = lock;
    };

    // A separate tree of AutomationElement instances is maintained by the automation module.
    // This allows a custom hierarchical representation of the underlying automation objects
    // that is not necessarily represented by the automation objects themselves. Also provides
    // storage for control types and patterns, so that we are not forced to store this on the
    // underlying objects.
    context.AutomationElement = function (automationId, automationObject, parentAutomationId) {
        if (!(this instanceof context.AutomationElement)) {
            throw new Error("Constructor should be called with new.");
        }

        this.automationId = automationId;
        this.automationObject = automationObject || {};
        this.automationControlType = "custom"; // Mapping to UIA types in CChromiumDOMElementUIAProxy::ControlTypeStringToId().
        // Use the parent Id to build unique DOM element identifier for jQuery
        this.uniqueId = parentAutomationId || automationId;
        if (parentAutomationId) {
            this.uniqueId += "." + automationId;
        }
        this.automationChildren = []; // Child AutomationElement instances
        this.automationPatterns = {};
        this.isOffscreen = false;
    };

    // Called to unhook any jQuery handlers and release objects for garbage collection
    context.AutomationElement.prototype.releaseContents = function () {
        var i, jObj = {};
        for (i = 0; i < this.automationChildren.length; i++) {
            this.automationChildren[i].releaseContents();
        }
        if (this.automationObject instanceof jQuery) {
            jObj = this.automationObject;
        } else {
            jObj = $(this.automationObject);
        }
        jObj.off("scroll.uia");
        this.automationObject = {};
        this.automationPatterns = {};
        this.automationChildren = [];
    };

    context.AutomationElement.prototype.setScrollable = function () {
        scrollingElementPositions[this.uniqueId] = 0;

        var that = this, jObj = {};
        if (this.automationObject instanceof jQuery) {
            jObj = this.automationObject;
        } else {
            jObj = $(this.automationObject);
        }
        jObj.on("scroll.uia", function () {
            if (scrollingElementPositions[that.uniqueId] !== jObj.scrollTop()) {
                scrollingElementPositions[that.uniqueId] = jObj.scrollTop();
                BGC.ui.automation.serialize();
            }
        });
    };

    // Called when JSON.stringify() is called on AutomationElement. Allows full customisation
    // of the serialised output: we do not want to serialise the entire underlying automation
    // object.
    context.AutomationElement.prototype.toJSON = function () {

        // Allow the automation object to perform processing before serialisation itself
        if (this.automationObject.preSerialize) {
            this.automationObject.preSerialize();
        }

        // This is the actual object that is serialised
        var json = {
            id: this.automationId,
            controlType: this.automationObject.controlType || this.automationControlType // Use automation object's control type preferentially, if specified
        };

        // Only serialise children and patterns if they are non-empty
        if (this.automationChildren.length > 0) {
            json.children = this.automationChildren; // Calls toJSON() recursively
        }

        if (!$.isEmptyObject(this.automationPatterns)) { // "this.automationPatterns !== {}" always returns true
            json.patterns = this.automationPatterns;
        }

        // Call automation object's serialize function if defined,
        // to allow decoration of the above json object. DOM elements
        // have a special serialisation method that accesses the jQuery
        // object for serialisation data.
        if (this.automationObject instanceof jQuery) {
            this.serializeJQuery(json);
        } else if (this.automationObject.serialize) { // N.B. jQuery objects have a serialize() function, so avoid this check on DOM elements
            this.automationObject.serialize(json);
        }

        if (this.isOffscreen) {
            json.isOffscreen = true;
        }

        return json;
    };

    context.AutomationElement.prototype.serializeJQuery = function (json) {
        if (!(this.automationObject instanceof jQuery)) {
            throw new Error("serializeJQuery() called when underlying automation object is not jQuery.");
        }

        // Access jQuery object
        var offset = this.automationObject.offset(),
            height = this.automationObject.outerHeight(),
            width = this.automationObject.outerWidth();

        json.rect = {
            left: Math.floor(offset.left),
            top: Math.floor(offset.top),
            width: Math.floor(width),
            height: Math.floor(height)
        };

        // If the DOM object's text is anything other than that returned by
        // jQuery's text() method, then this serializeJQuery method will need to be
        // overridden in the AutomationElement instance.
        json.value = this.automationObject.text();

        // Visibility test is sufficient; host will determine if object is outside client area
        if (this.isOffscreen || !(this.automationObject.is(":visible")) || (this.automationObject.css("opacity") === "0")) { // .css() returns String
            json.isOffscreen = true;
        }
    };

    // Hook for mixin() function. Parent automation element is first parameter;
    // remaining parameters are objects with single property: the child
    // automation elements. Create child automation elements as children of parent
    // automation element. Return mixin object as per regular mixin() function.
    context.mixinChildAutomationElements = function (parentAutomationElement) {
        var childAutomationElements = Array.prototype.slice.call(arguments, 1),
            mixinObject = BGC.utils.mixin.apply(this, childAutomationElements),
            i, len, prop, newAutomationElement;

        if (context.enabled) {
            for (i = 0, len = childAutomationElements.length; i < len; ++i) {
                // Ignore child automation elements with > 1 property
                if (Object.keys(childAutomationElements[i]).length === 1) {
                    for (prop in childAutomationElements[i]) {
                        if (childAutomationElements[i].hasOwnProperty(prop)) {
                            newAutomationElement = new BGC.ui.automation.AutomationElement(prop);
                            parentAutomationElement.automationChildren.push(newAutomationElement);
                            break;
                        }
                    }
                }
            }
        }

        return mixinObject;
    };

    // Hook for mixin() function. Create new grid automation element for supplied
    // grid. Create new automation element for each grid element, and add as child
    // of the grid automation element. Finally, add grid automation element as child
    // of parent automation element. Return mixin object as per regular mixin() function.
    // Can be made more generic, passing in automation control types, if required.
    context.mixinGrid = function (parentAutomationElement, gridAutomationId, grid) {
        var mixinObject = BGC.utils.mixin(grid), gridAutomationElement, cell, cellAutomationElement;

        if (context.enabled) {
            gridAutomationElement = new BGC.ui.automation.AutomationElement(gridAutomationId);
            gridAutomationElement.automationControlType = "grid";

            // There is no physical grid object, so we have to fabricate one here.
            // Determine bounding rectangle of all grid cells.
            gridAutomationElement.automationObject = {
                serialize: function (json) {
                    var i, len, cellAutomationObject, cellRect, screenRect,
                        gridRect = { left: null, top: null, right: null, bottom: null, width: 0, height: 0 };

                    for (i = 0, len = gridAutomationElement.automationChildren.length; i < len; ++i) {
                        cellAutomationObject = gridAutomationElement.automationChildren[i].automationObject;
                        if (cellAutomationObject.isVisible) { // Empty rectangle would be reported for invisible cells
                            cellRect = cellAutomationObject.getRect();
                            gridRect.left = gridRect.left ? Math.min(gridRect.left, cellRect.left) : cellRect.left;
                            gridRect.top = gridRect.top ? Math.min(gridRect.top, cellRect.top) : cellRect.top;
                            gridRect.right = gridRect.right ? Math.max(gridRect.right, cellRect.left + cellRect.width) : cellRect.left + cellRect.width;
                            gridRect.bottom = gridRect.bottom ? Math.max(gridRect.bottom, cellRect.top + cellRect.height) : cellRect.top + cellRect.height;
                        }
                    }
                    gridRect.width = gridRect.right - gridRect.left;
                    gridRect.height = gridRect.bottom - gridRect.top;

                    screenRect = BGC.ui.view.renderer.viewToScreen(gridRect); // right and bottom properties ignored by viewToScreen
                    json.rect = {
                        left: Math.floor(screenRect.left),
                        top: Math.floor(screenRect.top),
                        width: Math.floor(screenRect.width),
                        height: Math.floor(screenRect.height)
                    };
                }
            };

            for (cell in grid) {
                if (grid.hasOwnProperty(cell)) {
                    cellAutomationElement = new BGC.ui.automation.AutomationElement(cell);
                    cellAutomationElement.automationControlType = "gridItem";
                    gridAutomationElement.automationChildren.push(cellAutomationElement);
                }
            }

            parentAutomationElement.automationChildren.push(gridAutomationElement);
        }

        return mixinObject;
    };

    // Walk automation element tree, setting up named object references from object source.
    // Can't do this when setting up automation element hierarchy, as mixin() function copies
    // individual properties rather than the objects themselves, and the canvas framework only
    // modifies the properties (layout, etc.) of the final top-level mixin object.
    context.setupAutomationObjectReferences = function (parentAutomationElement, objectSource) {
        var i, len;

        if (objectSource.hasOwnProperty(parentAutomationElement.automationId)) {
            parentAutomationElement.automationObject = objectSource[parentAutomationElement.automationId];
        }

        for (i = 0, len = parentAutomationElement.automationChildren.length; i < len; ++i) {
            context.setupAutomationObjectReferences(parentAutomationElement.automationChildren[i], objectSource);
        }
    };
}(window.BGC.ui.automation));
