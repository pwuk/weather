/* global BGC, $ */
import {logger} from '@core-tech/web-api';
import './imports';
import StatusOverlayView from './views/statusoverlayview';

// Create a splash screen overlay to display status updates while the app is initializing
const getSplash = (function createSplash () {
  const splashView = new StatusOverlayView({
    el          : $('.status-overlay')[0],
    message     : 'Application Loading ...',
    displayLogo : true,
    autoOpen    : true
  });

  return () => splashView;
}());

// Get the (legacy) backbone datastore
const getDataStore = () => BGC.dataStore;

const msgProcessor = appMsg => {
  const dataStore = getDataStore();
  const {messages} = appMsg;

  if (messages.length === 1 && messages[0].messageName === 'TransportStatus') {
    getSplash().updateMessage(messages[0].statusText, true);
  } else if (dataStore) {
    dataStore.update(appMsg);
  } else {
    const messageNames = messages.reduce((acc, msg) => (acc ? `${acc}, ${msg.messageName}` : `${msg.messageName}`), '');

    logger.warn(`[msgProcessor] Dropping ${messageNames} message(s), the dataStore has not been initialized.`);
  }
};

function renderPage (app) {
  const {layout, userSettings} = app;
  const dataStore = getDataStore();

  try {
    logger.info(`[renderPage] Rendering ${app.id} Page`);

    getSplash().updateMessage(`Rendering ${layout.displayName} Page`);

    dataStore.processUserLogin(app.login, layout);

    dataStore.initializePage(layout);

    // Restore the user settings store
    dataStore.onLoadUserSettings(userSettings, {
      path   : app.path,
      userId : app.userId
    });

    // When the application is launched whilst an auction is running, we may receive auction message before the
    // page layout request has completed - process any cached messages here
    dataStore.preInitAuctionMsgCache.forEach(message => {
      dataStore.processMessage(message);
    });

    dataStore.preInitAuctionMsgCache = [];

    getSplash().close();
  } catch (err) {
    logger.error(`[renderPage] Error rendering ${app.id} page: ${err}`);
    
    throw err;
  }
}

export {
  renderPage,
  getDataStore,
  getSplash,
  msgProcessor
};
