/* eslint-disable func-names */
/* global BGC:false, $:false */

// /////////////////////////////////////////////////////////////////////////////
// file eventshandler.js
// BGC Events handler module implementation.
// /////////////////////////////////////////////////////////////////////////////

(function () {
  BGC.onKillFocus = function () {
    BGC.hasFocus = false;
    $(':focus').blur();
  };

  BGC.onfocus = function () {
    BGC.hasFocus = true;
  };

  BGC.onblur = function (event) {
    if (event.target === window) {
      BGC.hasFocus = false;
      $(':focus').blur();
    }
  };

  window.addEventListener('focus', BGC.onfocus, true);
  window.addEventListener('blur', BGC.onblur, true);
}(window.BGC.eventsHandler));
