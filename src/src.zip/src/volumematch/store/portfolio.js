/*global BGC: false, Backbone: false*/

(function (context, utils, logger) {
    "use strict";

    // Instrument lookup options
    const instrumentLookup = {
        cusip: function () {
            // For CUSIP searches the user typically types in the first leg of the structure as the second leg is locked.
            // By doing an initial grouping (on the first leg) we avoid an O(n2) duplicate search.
            const lookup = _.groupBy(context.instruments.filter(instrument => instrument.get('cusip')),
                instrument => instrument.get('cusip').split('/')[0]);

            const locks = context.instruments.filter(instrument => instrument.get('isLockInstrument'));

            // The identifier may be a single leg or multiple legs separated by '/'
            return id => {
                let instrument;
                const matches = lookup[id.split('/')[0]] || [];

                if (matches.length === 1) {
                    instrument = matches[0];
                } else {
                    // If we have multiple 'CUSIP' matches - try a specific against the 'id'
                    instrument = matches.find(item => item.get('cusip') === id);
                }

                return {
                    instrument,
                    matches,
                    locks
                };
            }
        },
        isin: function () {
            return id => ({
                instrument: context.instruments.find(item => item.get('isin') === id)
            })
        },
        linkedMatrix : function () {
            const {matrices} = context.pageLayout.attributes;    
            // Currently this will support layout with 1-Outright + 1-Linked triangle matrix        
            // Outright matrix is mapped with ColName-RowName whereas Triangle matrix is mapped with RowName-ColName
           
            // lookUp(Param1, Param2) : Param1 :- true : map by row-col ,  false: map  by col-row
            //                          Param2 :- Index of linked matrix whose instruments are needed

            // Master look up object which includes all the parent matrix instrument  + linked matrix instruments
            let masterLookup = {};

            matrices.models.forEach(model => {
                // Get parent matrix instruments for look up 
                const outrightLookUp = model.lookUp(false);

                // Get linked matrix instruments if its available
                const linkedMatrixCount =  model.get('linkedMatrices').models.length;  
                const linkedMatrixLookUp = linkedMatrixCount >= 1 ? model.lookUp(true, 1) : {};

                masterLookup =  _.extend(masterLookup, outrightLookUp, linkedMatrixLookUp);
            });

            return id => ({
                instrument: (masterLookup[id])
            })          
        },       
        matrix: function () {
            // For matrices (currently we only support single matrix layouts), map the RowCol name to the instrument
            const {matrices} = context.pageLayout.attributes;
            const lookup = matrices.models.length === 1 ? matrices.models[0].lookUp() : {};
            const spreads = context.instruments.filter(model => model.get('spread') && model.isInAuction());

            // The identifier may be a single leg or multiple legs separated by 'vs' or 'v'
            return id => {
                let instrument, structure, isHigherVegaFirst = true;
                const legs = id.split(/vs|v/i).map(leg => lookup[leg.toUpperCase()]);

                if (legs.length === 1) {
                    instrument = legs[0];
                } else if (legs.length === 2) {
                    instrument = spreads.find(model => model.matchStructure(legs));

                    // If a spread already exists, set the spread instrument and compare the vegas on the legs to
                    // see whether we have entered the instrument higher vega first, otherwise just set the structure
                    if (instrument) {
                        isHigherVegaFirst = utils.compareFPNumGTEQ(legs[0].get('vega'), legs[1].get('vega'));
                    } else if (!instrument && legs.every(item => item)) {
                        structure = legs;
                    }
                }

                return {
                    instrument,
                    structure,
                    isHigherVegaFirst
                }
            }
        },
        name: function () {
            return id => ({
                instrument: context.instruments.find(item => item.get('name') === id)
            })
        }
    };

    context.collectionDefinitions.Portfolio = Backbone.Collection.extend({
        model: context.modelDefinitions.PortfolioItem,

        initialize: function (models, options) {
            const {columns, lookupType} = options;

            // Set the business specific import columns and instrument lookup
            this.columns = columns;
            this.lookup = instrumentLookup[lookupType];

            // Portfolio is single-shot by default
            this.isSingleShot = true;
        },

        processInstrumentMsg: function (instrument, message, msgState) {
            const {spread} = instrument.attributes;

            // If a spread is entering VM, check whether it matches any structures in the portfolio
            if (spread && msgState.isEnteringVM) {
                const structure = this.find(model => {
                    const {structure} = model.attributes;

                    return structure && instrument.matchStructure(structure.get('instruments'));
                });

                if (structure) {
                    // Upgrade the structure to a full (spread) instrument
                    structure.upgradeStructure(instrument);
                }
            }
        },

        import: function (data) {
            const {columns} = this;
            const lookup = this.lookup && this.lookup();

            if (!columns || !lookup) {
                return;
            }

            // Parse records
            const records = data.trim().split(/\r\n|\n/).map(record => {
                const fields = record.trim().split(/\s+|','/);

                return this.columns.reduce((accumulator, column, index) => {
                    const field = fields[column.calculated || index];

                    // Add processed field value - basic input validation
                    accumulator[column.id] = field ? column.get(field) : undefined;

                    // Add raw input field
                    if (!column.calculated) {
                        accumulator.fields.push({
                            name  : column.id,
                            value : field
                        });
                    }

                    return accumulator;
                }, {
                    fields: []
                });
            });

            // Filter new records
            const newItems = records.filter( (record, index) => {
                let {id} =  record;

                return id && !this.get(id) && records.findIndex(item => item.id === id) === index
            });

            logger.logInformation('Portfolio::import', `Attempting to import ${newItems.length} item(s)`, true);

            // Import new items
            this.add(newItems.map(newItem => new context.modelDefinitions.PortfolioItem(newItem, lookup(newItem.id))));
        },

        // Submit all valid orders
        submitAll: function () {
            const {PENDING, HELD, LOADED} = context.PortfolioStates;

            // First filter all loaded orders
            this.filter(item => item.get('state') === LOADED).forEach(order => {
                const {structure, instrument, state, limit, limitB} = order.attributes;

                if ((structure && !structure.areUnderlyingsInAuction()) || (instrument && !instrument.isInAuction())) {
                    // Mark order 'pending' submission for next session
                    logger.logInformation('Portfolio::submitAll', `[${order.getDescription()}] Set order 'Pending' submission to next session`, true);

                    order.set('state', PENDING);
                } else if (!order.isHeldByLimit()) {
                    // Submit order if the session price is within the limit price
                    logger.logInformation('Portfolio::submitAll', `[${order.getDescription()}] Submitting order into live session`, true);

                    order.submit();
                } else {
                    // Hold order for next session
                    logger.logInformation('Portfolio::submitAll', `[${order.getDescription()}] Order 'Held' by limit in active session [${limit.text}, ${limitB.text}]`, true);

                    order.set('state', HELD);
                }
            });
        },

        // Cancel all live orders
        cancelAll: function () {
            this.filter(item => item.hasLiveOrder()).forEach(item => {
                logger.logInformation('Portfolio::cancelAll', `[${item.getDescription()}] Cancelling live order`, true);

                item.cancelOrder();
            });
        },

        // Clears the portfolio
        clear: function () {
            logger.logInformation('Portfolio::clear', `Clearing Portfolio`, true);

            this.cancelAll();

            this.filter(item => item.clean());

            this.reset();
        }
    });

    // Create collection
    context.portfolio = new context.collectionDefinitions.Portfolio([], {
      lookupType : context.getPortfolioLookupType('IRO'),
      columns    : context.getPortfolioColumns('IRO')
    });

}(window.BGC.dataStore, window.BGC.utils, window.BGC.logger));
