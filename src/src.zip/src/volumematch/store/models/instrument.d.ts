/// <reference path='order.d.ts'/>

interface InstrumentObject {
    isSubscribed: boolean;
    name: string;
    instrumentId: string;
    priceDisplay: string;
    midPrice: number;
    minBidPrice: number;
    maxBidPrice: number;
    minOfferPrice: number;
    maxOfferPrice: number;
    priceIncrement: number;
    priceDirection: string;
    allowsNegativeOrZeroPrice: boolean;
    isHigherBidBetter: boolean;
    isLowerOfferBetter: boolean;
    strikenumberDisplay: string;
    strike2Display: string;
    crossDisplay: string;
    volume: string;
    minSize: number;
    baseSize: number;
    classification: number;
    vega: number;
    thirdPartyInterest: string;
    haSameLeBuyInterest: boolean;
    haSameLeSellInterest: boolean;
    hasTradedAtMidPrice: boolean;
    hasTradedInAuction: boolean;
    isShowGlowAlwaysEnabled: boolean;
    inactive: boolean;
    auctionId: string;
    auction: Object;
    isMidPriceIndicative: boolean;
    tileId: string;
    canUserEnterOrders: boolean;
    supportTradeConfirmRequest: boolean;
    index: number;
    isExcelLiveModeEnabled: boolean;
    spread: Object;
    nomenclature: string;
    minDecimalPlaces: number;
    quickSizes: QuickSizes;
    ownOrder: ActiveOrderObject;
    isPickGivePriced: boolean;
    buyLegRatio: number;
}

interface ValidatedNumber {
    /** is value is valid or not */
    valid: boolean;
    /** value converted to numeric type */
    numericValue: number;
    stringValue: string;
}

interface QuickSizes {
    buy: number[];
    sell: number[];
}
