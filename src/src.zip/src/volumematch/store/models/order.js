/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, BGCAPP: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */

import {postEventMetric} from '@core-tech/web-api';
import getApp from '../../index';

(function (context, utils, undefined) {
    "use strict";

    // Private static functions
    function filterOrdersBySide (orders, side) {
        return _.filter(orders, function (orderModel) {
            return orderModel.hasFilledSize(side) || orderModel.hasUnfilledSize(side);
        });
    }

    /*
     *   Attributes:
     *   - instrument: reference to an Instrument Model
     *   - priceDisplay: String :formatted display price of order
     *   - priceDisplayD2: String: formatted display price of D2 underlying. Only applicable for spread instrument orders.
     *   - price: Number  :actual order price which should be used for cancelling
     *   - accountId: String: For Sales Traders
     *   - userId: String: owner of the order
	 *	 - strike1Display: String
	 *	 - strike2Display: String
     *   - buySize: Number
     *   - sellSize: Number
     *   - boughtSize: Number
     *   - soldSize: Number
	 *   - isLiveBuy: Boolean: is a live buy-side order or was a live buy-side order prior to auction end
	 *   - isLiveSell: Boolean: is a live sell-side order or was a live sell-side order prior to auction end
	 *   - isBuyFootprint: Boolean: is a buy-side footprint of a live order after auction end if isLiveBuy is true or is an Excel footprint if isLiveBuy is false
	 *   - isSellFootprint: Boolean: is a sell-side footprint of a live order after auction end if isLiveSell is true or is an Excel footprint if isLiveSell is false
     *   - buyCanBeCancelled: Boolean: Order representation in a view should present a cancel option on the buy side
     *   - sellCanBeCancelled: Boolean: Order representation in a view should present a cancel option on the sell side
     *   - wasBuyPublishedByExcel: Boolean
     *   - wasSellPublishedByExcel: Boolean
     *   - executions: Collection of order executions
     *   - orderType: String - generalized order flavour for presentation styling (mine, sameLE, Sales Trader group)
     *   - creationTime: Number
     */
    context.dataStore.modelDefinitions.Order = Backbone.Model.extend({
        defaults: {
            instrument: undefined,

            // Added to support clOrderId for GTI
            // An orderId is required for each side
            sellOrderId: "",
            buyOrderId: "",
            priceDisplay: "",
            priceDisplayD2: "",
            price: 0,
            accountId: "",
            userId: "",
            boughtSize: 0,
            soldSize: 0,
            buySize: 0,
            sellSize: 0,
            isLiveBuy: true,
            isLiveSell: true,
            buyCanBeCancelled: false,
            sellCanBeCancelled: false,
            isBuyFootprint: false,
            isSellFootprint: false,
            isAuctionEndFootprint: false,
            wasBuyPublishedByExcel: false,
            wasSellPublishedByExcel: false,
            hasInstrumentTradedAtOrderPrice: false,
            executions: undefined,
            orderType: "own",
            creationTime: 0,
            repostCheck: false
        },

        initialize: function () {
          this.set("executions", new context.dataStore.collectionDefinitions.Trades([]));
        },

        serialize: function () {
            var model = this.toJSON();

            model.isOwnOrder = this.isOwnOrder();
            model.hasBuySize = model.buySize > 0;
            model.hasSellSize = model.sellSize > 0;
            model.hasCancellableBuySize = this.hasCancellableSize("buy");
            model.hasCancellableSellSize = this.hasCancellableSize("sell");
            model.hasBoughtSize = model.boughtSize > 0;
            model.hasSoldSize = model.soldSize > 0;
            model.totals = { bought: this.getTotalSize("buy"), sold: this.getTotalSize("sell") };
            model.executions = this.get("executions").toJSON();

            return model;
        },

        addExecution: function (tradeExecution) {
            this.get("executions").add(tradeExecution);

            this.trigger(tradeExecution.get("tradeSide") === BGC.schemaValidator.BUY_SIDE ? "buyExecution" : "sellExecution");
        },

        addOrderId: function (orderId, side) {
          if (side === "buy") {
            this.set("buyOrderId", orderId);
          } else {
            this.set("sellOrderId", orderId);
          }
        },

        getOrderId: function (side) {
          return (side === "buy" ? this.get("buyOrderId") : this.get("sellOrderId"));
        },

        isUnfilled: function() {
        	return this.hasUnfilledSize("buy") || this.hasUnfilledSize("sell");
        },

        hasExecuted: function() {
            return (this.get("boughtSize") > 0 || this.get("soldSize") > 0);
        },

        getFilledSize: function (side) {
            return (side === "buy" ? this.get("boughtSize") : this.get("soldSize"));
        },

        // This function only returns unfilled size entered directly by the user
        // or live orders from a linked Excel document (blue chain icon ACTIVATED).
        getUnfilledSize: function (side) {
      		return this.isLive(side) ? this.getSize(side) : 0;
        },

        // This function returns unfilled size even if it is Excel footprint size that can't be executed
        getSize: function(side) {
        	return side === "buy" ? this.get("buySize") : this.get("sellSize");
        },

        // This function is used to get the current total size so that the size for new orders in total mode
        // can be calculated. As such, it only includes "live" unfilled size (see comments above)
        getTotalSize: function (side) {
            // Avoid FP addition errors
            return parseFloat((this.getFilledSize(side) + this.getUnfilledSize(side)).toFixed(10));
        },

        hasFilledSize: function (side) {
            return this.getFilledSize(side) > 0;
        },

        hasUnfilledSize: function (side) {
            return this.getUnfilledSize(side) > 0;
        },

        hasSize: function (side) {
            return this.getSize(side) > 0;
        },

        isLive: function (side) {
        	return side === "buy" ? this.get("isLiveBuy") : this.get("isLiveSell");
        },

        sendCancelOrder: function (viewId, cancelSide) {
            var instrument = this.get("instrument");

            // OrderId is uuid required by GTI
            // originalOrderId is the orderId of the initial order - only required for GTI
            BGC.dataStore.sendCancelOrder(viewId, {
                instrumentId: instrument.get("instrumentId"),
                orderId: BGC.utils.createUuid().substr(0, 20),
                originalOrderId: this.getOrderId(cancelSide),
                price: this.get("price"),
                size: this.get((cancelSide === "buy") ? "buySize" : "sellSize"),
                side: cancelSide,
                accountId: this.get("accountId"),
                userId: this.get("userId"),
                isBuddyCancel: !this.isOwnOrder() && !this.isSalesTraderGroupOrder(),
                sourceSystem: instrument.get("sourceSystem"),
                symbolType: instrument.get("symbolType"),
                venueType: instrument.get("venueType"),
                regulatoryRegime: instrument.get("regulatoryRegime")
            });
        },

        isOwnOrder: function () {
            return (this.get("orderType") === BGC.schemaValidator.OWNERSHIP_MINE);
        },

        isSameLEOrder: function () {
            return (this.get("orderType") === BGC.schemaValidator.OWNERSHIP_MY_FIRM);
        },

        isCancellationBuddyOrder: function (side) {
            var isBuddy = false;

            if (!this.isOwnOrder() && !this.isSalesTraderGroupOrder()) {
                if (side === undefined) {
                    isBuddy = (this.get("buyCanBeCancelled") === true || this.get("sellCanBeCancelled") === true);
                } else if (side === "buy") {
                    isBuddy = (this.get("buyCanBeCancelled") === true);
                } else if (side === "sell") {
                    isBuddy = (this.get("sellCanBeCancelled") === true);
                }
            }

            return isBuddy;
        },

        isSalesTraderGroupOrder: function () {
            return (this.get("orderType") === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT);
        },

        hasCancellableSize: function (side) {
            if (side === undefined) {
                return this.hasCancellableSize("buy") || this.hasCancellableSize("sell");
            }
            return (this.hasUnfilledSize(side) && (this.get(side === "buy" ? "buyCanBeCancelled" : "sellCanBeCancelled") === true));
        },

        buildStatusString: function (side, includePrice) {
            var orderStatus = "",
                instrument = this.get("instrument"),
                totalSize = this.getTotalSize(side);

            // status string i.e. 50 of 100 Bought
            if (totalSize > 0) {
                orderStatus = this.getFilledSize(side);

                if (this.hasUnfilledSize(side)) {
                    orderStatus += BGC.resources.IDS_OF_SEPARATOR + totalSize;
                }
                orderStatus += " " + (side === "buy" ? instrument.getAdjustedNomenclature("IDS_BOUGHT") : instrument.getAdjustedNomenclature("IDS_SOLD"));
            }

            if (includePrice && orderStatus && instrument.isMoveableMidEnabled()) {
                orderStatus += " @ " + this.get("priceDisplay");
            }

            return orderStatus;
        }
    },
    {
        repostAllCheck : false,

        setRepostAllState : function (val) {
            this.repostAllCheck = val;
        },

        getRepostAllState : function () {
            return this.repostAllCheck;
        }
    });

    /*
     * ActiveOrder - the data attached to an instrument that is used to show in-place order status
     * Not used for the Your Orders view
     * Note that this ActiveOrder model presents to external clients the majority of the methods of the Order model,
     * but internally actually consists chiefly of references to two Orders that it gets its data from.
     * For most VMs, the order on the buy side will be the same as the order on the sell side,
     * because they will be at the same price (even in most VM+ scenarios).
     * However, where VM+ and Locked Down Orders are in play together, the buy-side and sell-side active orders may
     * be at different price levels and will therefore be represented by different Order objects.
     * Hence the need for this model and its usage by the Instrument model.
     */
    context.dataStore.modelDefinitions.ActiveOrder = Backbone.Model.extend({
        defaults: {
            buy: undefined,
            sell: undefined
        },

        initialize: function () {
            this.orders = {};
            this.serializedObject = {};
            this.isSerializedObjectDirty = true;

            this._setInternals();
            // Whenever the buy order or the sell order is swapped out for something different
            // then we need to adjust our internal view of the world and do some eventing set-up.
            this.listenTo(this, "change:buy change:sell", this._setInternals);

            this.listenTo(context.dataStore.orderStore, "reset", function () {
                this.isSerializedObjectDirty = true;
                this.trigger("remove", this);
                this.unset("buy");
                this.unset("sell");
            });
        },

        /** Overidden set function allows us to set serializedObjectDirty before any change events fire */
        set: function (key, val, options) {
            this.isSerializedObjectDirty = true;

            Backbone.Model.prototype.set.call(this, key, val, options);
        },

        _setInternals: function () {
            this.isSerializedObjectDirty = true;

            if (this.orders.buy) {
                this.stopListening(this.orders.buy, null, null);
            }
            if (this.orders.sell) {
                this.stopListening(this.orders.sell, null, null);
            }

            this.orders = { buy: this.get("buy"), sell: this.get("sell") };

            // Whenever the buy order or sell order internals change, then this active order model
            // needs to signal its observer(s) so that any view showing active order status can be refreshed
			// When there is only one order it will be installed on both sides of the active order object.
            if (this.orders.buy) {
                this.listenTo(this.orders.buy, "change", function () {
                    this.isSerializedObjectDirty = true;
                    this.trigger("change", this);
                });
                this.listenTo(this.orders.buy, "buyExecution", function () { this.trigger("buyExecution", this); });
                this.listenTo(this.orders.buy, "remove", this._onOrderRemoved);
            }

            if (this.orders.sell) {
                this.listenTo(this.orders.sell, "sellExecution", function () { this.trigger("sellExecution", this); });
            }

            if (this.orders.sell && (this.orders.sell !== this.orders.buy)) {
                this.listenTo(this.orders.sell, "change", function () {
                    this.isSerializedObjectDirty = true;
                    this.trigger("change", this);
                });
                this.listenTo(this.orders.sell, "remove", this._onOrderRemoved);
            }
        },

        _onOrderRemoved: function (order) {
            this.isSerializedObjectDirty = true;

            if (order === this.orders.buy && order !== this.orders.sell) {
                // The buy-side order has gone, but a different sell-side order remains,
                // so set the active buy side order the same as the active sell side order
                // This will trigger a call to _setInternals()
                this.set("buy", this.get("sell"));
            } else if (order === this.orders.sell && order !== this.orders.buy) {
                // Vice-versa...
                this.set("sell", this.get("buy"));
            } else if (order === this.orders.buy) {
                // Buy and sell side orders are the same and the one order has been removed
                // Therefore there is no longer an active order that any observers should worry about
                this.trigger("remove", this);
                // This will trigger a call to _setInternals()
                this.unset("buy");
                this.unset("sell");
            }
        },

        setOrder: function (order, side) {
            if (side) {
                var otherSide = (side === "buy" ? "sell" : "buy");
                this.set(side, order);
                if (!this.get(otherSide)) {
                    // Nothing set on the other side, so set it the same
                    this.set(otherSide, order);
                }
            } else {
                this.set("buy", order);
                this.set("sell", order);
            }
        },

        serialize: function () {
            if (this.isSerializedObjectDirty) {
                this.serializedObject.buyOrder = this.orders.buy ? this.orders.buy.serialize() : (this.orders.sell ? this.orders.sell.serialize() : undefined);
                this.serializedObject.sellOrder = this.orders.sell ? this.orders.sell.serialize() : (this.orders.buy ? this.orders.buy.serialize() : undefined);

                this.serializedObject.buySize = this.serializedObject.buyOrder ? this.serializedObject.buyOrder.buySize : 0;
                this.serializedObject.hasBuySize = this.serializedObject.buySize > 0;
                this.serializedObject.hasCancellableBuySize = this.hasCancellableSize("buy");
                this.serializedObject.boughtSize = this.serializedObject.buyOrder ? this.serializedObject.buyOrder.boughtSize : 0;
                this.serializedObject.hasBoughtSize = this.serializedObject.boughtSize > 0;
                this.serializedObject.wasBuyPublishedByExcel = this.serializedObject.buyOrder ? this.serializedObject.buyOrder.wasBuyPublishedByExcel : false;

                this.serializedObject.sellSize = this.serializedObject.sellOrder ? this.serializedObject.sellOrder.sellSize : 0;
                this.serializedObject.hasSellSize = this.serializedObject.sellSize > 0;
                this.serializedObject.hasCancellableSellSize = this.hasCancellableSize("sell");
                this.serializedObject.soldSize = this.serializedObject.sellOrder ? this.serializedObject.sellOrder.soldSize : 0;
                this.serializedObject.hasSoldSize = this.serializedObject.soldSize > 0;
                this.serializedObject.wasSellPublishedByExcel = this.serializedObject.sellOrder ? this.serializedObject.sellOrder.wasSellPublishedByExcel : false;

                this.isSerializedObjectDirty = false;
            }

            return this.serializedObject;
        },

        getPrice: function (side) {
            return this.orders[side] ? this.orders[side].get("price"): NaN;
        },

        getDisplayPrice: function (side) {
            return this.orders[side] ? this.orders[side].get("priceDisplay") : "";
        },

        getOrderId: function (side) {
            return this.orders[side] ? this.orders[side].get("orderId") : "";
        },

        getAccountId: function () {
            // Even if buy/sell orders are different objects, they will always be for the same account
            return this.orders.buy ? this.orders.buy.get("accountId") : (this.orders.sell ? this.orders.sell.get("accountId") : "");
        },

        hasUnfilledSize: function (side) {
            return this.getUnfilledSize(side) > 0;
        },

        hasFilledSize: function (side) {
            return this.getFilledSize(side) > 0;
        },

        getFilledSize: function (side) {
            return (this.orders[side] ? this.orders[side].getFilledSize(side) : 0);
        },

        getUnfilledSize: function (side) {
            return this.isLive(side) ? this.getSize(side) : 0;
        },

        getSize: function (side) {
            return (this.orders[side] ? this.orders[side].getSize(side): 0);
        },

        getTotalSize: function (side) {
            // Avoid FP addition errors
            return parseFloat((this.getFilledSize(side) + this.getUnfilledSize(side)).toFixed(10));
        },

        isLive: function (side) {
            return (this.orders[side] ? this.orders[side].isLive(side) : false);
        },

        hasCancellableSize: function (side) {
            return (this.orders[side] ? this.orders[side].hasCancellableSize(side) : false);
        },

        buildStatusString: function (side, includePrice) {
            return (this.orders[side] ? this.orders[side].buildStatusString(side, includePrice) : "");
        },

        buildTipText: function () {
            var tipText = "";

            if (this.hasUnfilledSize("buy")) {
                tipText = "<span>" + this.buildStatusString("buy", true) + "</span>";
            }

            if (this.hasUnfilledSize("sell")) {
                if (tipText !== "") {
                    tipText += "<br/>";
                }
                tipText += "<span>" + this.buildStatusString("sell", true) + "</span>";
            }

            return tipText;
        }
    });

    const ownershipEnum = {"own":1, "myFirm":2, "sharedAccount":3};
    /*
     *  Orders - collection of orders, used by the Orders view
     */
    context.dataStore.collectionDefinitions.Orders = Backbone.Collection.extend({
        model: context.dataStore.modelDefinitions.Order,
        comparator: function (order1, order2) {
            var compare = 0;
            if (ownershipEnum[order1.get("orderType")] > ownershipEnum[order2.get("orderType")]) {
              compare = 1;
            } else if (ownershipEnum[order1.get("orderType")] < ownershipEnum[order2.get("orderType")]) {
              compare = -1;
            }
            else {
              if (order1.get("creationTime") < order2.get("creationTime")) {
                compare = 1;
              } else if (order1.get("creationTime") > order2.get("creationTime")) {
                compare = -1;
              }
            }
            return compare;
        },

        hasCancellableOrders: false,

        alertOrdersCanBeCancelled: function () {
            var hasCancellable = !!this.find(function (order) { return order.hasCancellableSize(); });

            if (hasCancellable !== this.hasCancellableOrders) {
                this.hasCancellableOrders = hasCancellable;
                this.trigger("ordersCanBeCancelled", { state: this.hasCancellableOrders });
            }
        },

        getOrdersForInstrument: function (instrumentModel) {
            return this.filter(function (order) { return order.get("instrument") === instrumentModel; });
        },

        findOrders: function (matchAttributes, price, side) {
            var matchedWithoutPrice = matchAttributes ? this.where(matchAttributes) : this.models,
                matchedWithPrice = [];

            if (price !== undefined) {
                // Price matching needs to be done using utility functions that account for FP inaccuracies
                matchedWithPrice = _.filter(matchedWithoutPrice, function (orderModel) {
                    return BGC.utils.compareFPNumEQ(orderModel.get("price"), price);
                });

                return side ? filterOrdersBySide(matchedWithPrice, side) : matchedWithPrice;
            }

            return side ? filterOrdersBySide(matchedWithoutPrice, side) : matchedWithoutPrice;
        },

        findOrderById: function (orderId, side) {
          return _.filter(this.models, function (orderModel) {
            return orderModel.getOrderId(side) === orderId;
        });
        },

        findUnfilledOrders: function (matchAttributes, price) {
            var matched = this.findOrders(matchAttributes, price);

            return _.filter(matched, function (order) {
                return order.isUnfilled();
            });
        },

        findFirstMatchingOrder: function (matchAttributes, price, side) {
            var matched = this.findOrders(matchAttributes, price, side);
            if (matched.length) {
                return matched[0];
            }
            return undefined;
        },

        processInstrumentMsg : function (instrument, message, msgState) {
            if (msgState.isEnteringVM) {
                this.onInstrumentEnteringVmState(instrument);
            } else if (msgState.isLeavingVM) {
                this.onInstrumentLeavingVmState(instrument);
            }
        },

    hasInstrumentExecuted : function (order, previousFilledSizes) {
      let hasExecuted = false;

      if (BGC.utils.compareFPNumGT(order.getFilledSize('buy'), previousFilledSizes.boughtSize) ||
            BGC.utils.compareFPNumGT(order.getFilledSize('sell'), previousFilledSizes.soldSize)) {
        hasExecuted = true;
      }

      return hasExecuted;
    },

        onInstrumentEnteringVmState: function (instrument) {
            // if the instrument is entering auction, first remove any order footprint from the previous auction
            var ordersForInstrument = this.getOrdersForInstrument(instrument);
            // Will generate remove event for each order...
            this.remove(ordersForInstrument);
        },

        onInstrumentLeavingVmState: function (instrument) {
            // If 'Favorite' footprints are disabled and the instrument is leaving auction,
            // set any filled orders as footprints instead
            if (!context.dataStore.userSettingsStore.get('displayFavorites')) {
                var ordersForInstrument = this.getOrdersForInstrument(instrument);
                _.each(ordersForInstrument, function (order) {
                    if (order.hasExecuted()) {
                        // Just set footprint flag on object, not in model
                        // - don't want to generate change event until after corresponding order update
                        order.isBuyFootprint = order.get("boughtSize") > 0;
                        order.isSellFootprint = order.get("soldSize") > 0;

                        // Clear any Excel footprint size or attributes.
                        order.buySize = 0;
                        order.sellSize = 0;
                        order.wasBuyPublishedByExcel = false;
                        order.wasSellPublishedByExcel = false;
                    }
                });
            }
        },

        // calculate latency for order/cancel submits and spread creation timed in the JavaScript GUI layer
        reportQoSMetrics: function (instrument, endTimeUtc, user) {
            var now, platform, theOrderSubmitTime, wasAnOrder, requestType /* order or cancel */, qosDatabaseKey, instType, isSpreadCreation = false,
                spreadModel = instrument.get("spread"), logText; // QoS metrics

            // custom spread or outright/standard spread
            if (spreadModel && context.dataStore.modelDefinitions.Spread.getQOSRequestTime(spreadModel.getSpreadID())) {
                theOrderSubmitTime = context.dataStore.modelDefinitions.Spread.getQOSRequestTime(spreadModel.getSpreadID());
                context.dataStore.modelDefinitions.Spread.completeQOSRecord(spreadModel.getSpreadID());
                isSpreadCreation = true;
                requestType = "createSpread";
            } else {
                theOrderSubmitTime = instrument.orderSubmitTime;
                wasAnOrder = instrument.isQoSOpAnOrder;
                requestType = wasAnOrder ? "postOrder" : "cancelOrder";
            }

            // don't output QoS metrics for cases when an initial timestamp was not captured in sendOrder() or sendCancelOrder()
            if (theOrderSubmitTime !== 0) {
                const {path: appPath, id : appId, desk} = getApp();

                instType = spreadModel ? "Spread" : "Outright";
                logText = "InstrumentType[" + instType + "], Instrument[" + instrument.getLogDescStr() + "]";

                BGC.logger.sendQoSEvent({
                    type: requestType,
                    databaseKeyName: "HTML_VM_OP",
                    startTimeUtc: theOrderSubmitTime,
                    message: logText,
                    alertThresholdMilliSecs: 5000
                });

                // Sending QoSEvent post order, cancel order and createSpread to web-session
                postEventMetric(appPath, requestType, {
                    appId,
                    rtt   : endTimeUtc - theOrderSubmitTime,
                    user,
                    desk,
                    clientTime: new Date().toISOString()
                });

                if (!isSpreadCreation) {
                    // DON'T use Backbone model's "set" function as it triggers updates of all observing views.
                    // Simply store the value as a normal object attribute instead.
                    instrument.orderSubmitTime = 0;
                }
            }
        },

        processOrderMsg: function (instrument, message) {
            var updateAttributes = {},
                updateInstrumentActiveOrder = false,
                isCreatedFromExecution = false,
                pickGivePrefix = '',
                order,
                spread,
                endTimeUtc = Date.now(),
                user = message.userId;

            // calculate the time from order submission (including cancels) and spread creation to now and output to log for QoS metrics
            this.reportQoSMetrics(instrument, endTimeUtc, user);
            // Set the orderId from GTI as this will be required to cancel / update orders
            if(message.side === 'buy'){
              updateAttributes.buyOrderId = message.orderId;
            } else {
              updateAttributes.sellOrderId = message.orderId;
            }

            // process unfilled order attributes
            if (!message.singleSide || message.singleSide === 'buy') {
                updateAttributes.buySize = message.buySize;
                updateAttributes.buyCanBeCancelled = message.buyCanBeCancelled;
            }
            if (!message.singleSide || message.singleSide === 'sell') {
                updateAttributes.sellSize = message.sellSize;
                updateAttributes.sellCanBeCancelled = message.sellCanBeCancelled;
            }

            updateAttributes.orderType = message.orderType;

            // Set the check state if order ownership is "MINE"
            if (message.orderType === BGC.schemaValidator.OWNERSHIP_MINE) {
                updateAttributes.repostCheck = message.shouldRepost;
            }

            // Don't process execution totals unless the auction is running:
            // we want to retain the order footprint post auction, so don't want it zeroed out at that point.
            if (instrument.isInAuction()) {
                if (!message.singleSide || message.singleSide === 'buy') {
                    updateAttributes.boughtSize = message.boughtSize;
                    updateAttributes.isLiveBuy = message.isLiveBuy;
                    updateAttributes.isBuyFootprint = message.isBuyFootprint;
                    updateAttributes.wasBuyPublishedByExcel = message.wasBuyPublishedByExcel;
                }
                if (!message.singleSide || message.singleSide === 'sell') {
                    updateAttributes.soldSize = message.soldSize;
                    updateAttributes.isLiveSell = message.isLiveSell;
                    updateAttributes.isSellFootprint = message.isSellFootprint;
                    updateAttributes.wasSellPublishedByExcel = message.wasSellPublishedByExcel;
                    updateAttributes.hasInstrumentTradedAtOrderPrice = message.hasInstrumentTradedAtOrderPrice;
                }
            }

            BGC.utils.trace("Processing an order update for an order at price " + message.orderPrice);

            // First look up the order to determine whether this is an update for an existing order in the store
            order = this.findOrder(instrument, message);

            if (!order) {
                if (!(utils.compareFPNumGT(message.buySize, 0) || utils.compareFPNumGT(message.sellSize, 0) ||
                    utils.compareFPNumGT(message.boughtSize, 0) || utils.compareFPNumGT(message.soldSize, 0))) {
                    utils.trace("No corresponding order found in the order store, but incoming order has zero size - discarding");
                    return undefined;
                }

                BGC.utils.trace("No corresponding order found in the order store, creating a new one");

                // create new order - at the (fixed) auction mid and strike/cross price
                spread = instrument.get("spread");
                updateAttributes.priceDisplay = spread && spread.get("displayUnderlyingPrices") ? spread.getInstrument(0).get("priceDisplay") : instrument.formatPrice(message.orderPrice);
                updateAttributes.priceDisplayD2 = spread ? spread.getInstrument(1).get("priceDisplay") : "";
                updateAttributes.price = message.orderPrice;
                updateAttributes.accountId = message.accountId || "";
                updateAttributes.userId = message.userId;
                updateAttributes.strike1Display = instrument.get("strike1Display");
                updateAttributes.strike2Display = instrument.get("strike2Display");
                updateAttributes.crossDisplay = instrument.get("crossDisplay");
                updateAttributes.priceBDisplay = instrument.get("priceBDisplay");
                updateAttributes.creationTime = new Date().getTime();
                if (!message.singleSide || message.singleSide === 'buy') {
                    updateAttributes.isLiveBuy = message.isLiveBuy;
                    updateAttributes.isBuyFootprint = message.isBuyFootprint;
                }
                if (!message.singleSide || message.singleSide === 'sell') {
                    updateAttributes.isLiveSell = message.isLiveSell;
                    updateAttributes.isSellFootprint = message.isSellFootprint;
                }
                updateAttributes.instrument = instrument;

                order = new context.dataStore.modelDefinitions.Order(_.extend(updateAttributes, {
                    collection: this,
                    executions: new context.dataStore.collectionDefinitions.Trades([])
                }));

                // If it's ours, add a reference to it in the instrument
                if (order.get("orderType") === BGC.schemaValidator.OWNERSHIP_MINE) {
                    updateInstrumentActiveOrder = true;

                    // Also need to tell the instrument if this is
                    // a newly created order which already contains executed size
                    if (order.hasFilledSize("buy") || order.hasFilledSize("sell")) {
                        isCreatedFromExecution = true;
                    }
                }

                // Add new order to the store
                this.add(order);
            } else {
                // Don't update data for orders after they have become footprints from live orders,
                // but the first update received after the instrument update (the order cancel)
                // should be used to clear any unfilled size and trigger a redraw of instrument and its orders,
                // or indeed remove the order altogether if there is no filled size.
                if (((order.isBuyFootprint === true) || (order.isSellFootprint === true)) && !order.get("isAuctionEndFootprint")) {
                    if (!order.hasExecuted()) {
                        if (order.get("orderType") === BGC.schemaValidator.OWNERSHIP_MINE) {
                            instrument.removeOrder(order);
                        }
                        context.dataStore.orderStore.remove(order);
                    } else {
                    	order.set({ isBuyFootprint: true, isSellFootprint: true, isAuctionEndFootprint: true, buySize: 0, sellSize: 0 }); // generate change event to trigger redraw
                    }
                    return order;
                }

                if (!(utils.compareFPNumGT(updateAttributes.boughtSize, 0) ||
                    utils.compareFPNumGT(updateAttributes.soldSize, 0) ||
                    utils.compareFPNumGT(updateAttributes.buySize, 0) ||
                    utils.compareFPNumGT(updateAttributes.sellSize, 0))) {
                    // if the incoming existing order update hasn't executed and has no unfilled or footprint size,
                    // then it must be a cancellation notification so remove the order
            	    context.dataStore.orderStore.remove(order);
            	} else {
            		// update the order model and generate change event
            		order.set(updateAttributes);
                }

                // Make sure that any update to one of MY orders results in any necessary
                // re-selection of what should be the "active" order(s) on the instrument
                // (for in-place order display)
                if (order.get("orderType") === BGC.schemaValidator.OWNERSHIP_MINE) {
            	    updateInstrumentActiveOrder = true;
            	}
            }

            if (updateInstrumentActiveOrder) {
                instrument.onMyVMOrderUpdate(order, isCreatedFromExecution);
            }

            return order;
        },

        findOrder: function (instrument, filterCriteria) {
            let order;
            if (filterCriteria.orderType === BGC.schemaValidator.OWNERSHIP_MINE) {
                order = context.dataStore.orderStore.findFirstMatchingOrder({
                    "instrument": instrument,
                    "orderType": filterCriteria.orderType,
                    "accountId": filterCriteria.accountId
                }, filterCriteria.orderPrice);
            } else if (filterCriteria.orderType === BGC.schemaValidator.OWNERSHIP_MY_FIRM) {
                order = context.dataStore.orderStore.findFirstMatchingOrder({
                    "instrument": instrument,
                    "orderType": filterCriteria.orderType
                }, filterCriteria.orderPrice);
            } else if (filterCriteria.orderType === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT) {
                order = context.dataStore.orderStore.findFirstMatchingOrder({
                    "instrument": instrument,
                    "orderType": filterCriteria.orderType,
                    "accountId": filterCriteria.accountId,
                    "userId": filterCriteria.userId
                }, filterCriteria.orderPrice);
            }
            return order;
        },

        onOrderExecutionUpdate: function (tradeModel) {
            var instrument = context.dataStore.getInstrumentById(tradeModel.get("instrumentId")),
                order, orderType = tradeModel.get("tradeType"),
                accountId = tradeModel.get("accountId"), userId = tradeModel.get("userId");

            BGC.utils.trace("Processing an order execution update for a trade at price " + tradeModel.get("tradePrice"));

            // Does the execution match an order in the store?
            if (orderType === BGC.schemaValidator.OWNERSHIP_MINE) {
                order = this.findFirstMatchingOrder({ "instrument": instrument, "orderType": orderType, "accountId": accountId }, tradeModel.get("tradePrice"));
            } else if (orderType === BGC.schemaValidator.OWNERSHIP_MY_FIRM) {
                order = this.findFirstMatchingOrder({ "instrument": instrument, "orderType": orderType }, tradeModel.get("tradePrice"));
            } else if (orderType === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT) {
                order = this.findFirstMatchingOrder({ "instrument": instrument, "orderType": orderType, "accountId": accountId, "userId": userId }, tradeModel.get("tradePrice"));
            }

            if (order === undefined) {
                BGC.utils.trace("No corresponding order found in the order store, creating a new one");

                // the execution message has arrived before the order message,
                // create an empty order silently to hold the execution
                order = new context.dataStore.modelDefinitions.Order({
                    instrument: instrument,
                    priceDisplay: (instrument.get("spread") && instrument.get("spread").get("displayUnderlyingPrices")) ? instrument.get("spread").getInstrument(0).get("priceDisplay") : tradeModel.get("tradeDisplayPrice"),
                    priceDisplayD2: instrument.get("spread") ? instrument.get("spread").getInstrument(1).get("priceDisplay") : "",
                    price: tradeModel.get("tradePrice"),
                    hasInstrumentTradedAtOrderPrice: true,
                    strike1Display: instrument.get("strike1Display"),
                    strike2Display: instrument.get("strike2Display"),
                    priceBDisplay: instrument.get("priceBDisplay"),
                    crossDisplay: instrument.get("crossDisplay"),
                    orderType: tradeModel.get("tradeType"),
                    boughtSize: tradeModel.get("tradeSide") === BGC.schemaValidator.BUY_SIDE ? tradeModel.get("tradeSize") : 0,
                    soldSize: tradeModel.get("tradeSide") === BGC.schemaValidator.SELL_SIDE ? tradeModel.get("tradeSize") : 0,
                    accountId: accountId,
                    userId:  userId,
                    creationTime: new Date().getTime()
                });

                context.dataStore.orderStore.add(order);
                if (tradeModel.isOwnTrade()) {
                    instrument.onMyVMOrderUpdate(order, true);
                }
            } else {
                BGC.utils.trace("Found a corresponding order in the store");
            }

            order.addExecution(tradeModel);
        }
    });

    context.dataStore.orderStore = new context.dataStore.collectionDefinitions.Orders([]);

    context.dataStore.orderStore.listenTo(context.dataStore.orderStore, 'add remove change reset', context.dataStore.orderStore.alertOrdersCanBeCancelled);

}(window.BGC, window.BGC.utils));
