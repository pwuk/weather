/* eslint-disable func-names, max-lines, no-param-reassign, no-plusplus, complexity, max-statements, no-magic-numbers */
/* global BGC: false, _:false, Backbone: false */

(function (context) {
  /**
   * Tile Model:represents a standard tile
   *  Attributes:
   *  - tileId:               String:           unique tile identifier
   *  - tileName:             String:           tile display name
   *  - excludeFromFavorites  Boolean:          whether or not instruments on this tile should be excluded from the favorites list
   *  - layoutType:           Enum:             outright or spread layout
   *  - auction:              Model:            the auction that this tile is a part of
   *  - pageLayout:           Model:            the page layout that contains this tile
   *  - instruments:          Instrument Array: list of instruments on tile
   */
  context.modelDefinitions.Tile = Backbone.Model.extend({

    defaults : {
      tileId               : '',
      tileName             : '',
      excludeFromFavorites : false,
      layoutType           : 'outright',
      pageLayout           : null,
      auction              : null,
      active               : false
    },

    idAttribute : 'tileId',

    initialize () {
      if (!this.get('tileId')) {
        throw new TypeError('Tile model created without ID');
      }

      this.set('instruments', new context.collectionDefinitions.TileInstruments());

      // Create an internal pseudo-Auction object to embrace the characteristics
      // of all auctions running in this tile
      this.auction = this.get('pageLayout').getOrAddAuction(this.get('tileId'), true);
      this.activeInstrumentCount = {inAuction : 0, indicativeMid : 0};
      this.auctionInstrumentCounts = {indicative : 0, dormant : 0};

      this.on('remove', this.onDestroy);

      // Ensure that sortInstruments() is always called in the right context,
      // even when it is provided as a callback argument to _.debounce()
      this.sortInstruments = this.sortInstruments.bind(this);

      // Sorting may be triggered many times in quick succession (e.g. when VMs start),
      // so it will speed things up to coalesce these requests into one actual sort.
      this.coalesceSortRequests = _.debounce(this.sortInstruments, 100);
    },

    onDestroy () {
      this.get('instruments').each(function (instrument) {
        instrument.off(null, null, this);
      });
    },

    areAnyInstrumentsInAuction () {
      return this.activeInstrumentCount.inAuction > 0;
    },

    doAnyInstrumentsHaveIndicativeMids () {
      return this.activeInstrumentCount.indicativeMid > 0;
    },

    // eslint-disable-next-line max-statements
    _addInstrument (instrument) {
      this.get('instruments').add(instrument, {sort : false});

      instrument.on('change:thirdPartyInterest', this.instrumentInterestUpdated, this);
      instrument.on('change:hasTradedInAuction', this.onInstrumentTraded, this);
      instrument.on('change:auction', this.onInstrumentAuctionChanged, this);
      instrument.on('change:index', this.onInstrumentSortIndexChanged, this);
      if (this.get('layoutType') === 'spread') {
        instrument.on('change:spread', this.coalesceSortRequests, this);

        // We need to call the following functions when the spread is created to log rendering of tradeed gavel and interest glow.
        this.instrumentInterestUpdated(instrument, instrument.attributes.thirdPartyInterest);
        this.onInstrumentTraded(instrument, instrument.attributes.hasTradedInAuction);
      }

      // Cache the tile index with other tile info - we may need this for sorting instruments within non-tile views
      const tileInfo = {tileIndex : this.collection.indexOf(this), tile : this, tileId : this.get('tileId')};

      instrument.set(tileInfo);

      const instAuction = instrument.get('auction');
      const instAuctionId = instAuction.get('auctionId');

      if (instAuction.get('runningState')) {
        // Adding instrument to already running auction
        this.onInstrumentAuctionChanged(instrument);
      } else if (instAuctionId !== 'dormant') {
        if (instAuctionId === 'indicative') {
          this.activeInstrumentCount.indicativeMid++;
        } else {
          this.activeInstrumentCount.inAuction++;
        }

        if (this.auctionInstrumentCounts[instAuctionId] === undefined || this.auctionInstrumentCounts[instAuctionId] === 0) {
          this.auctionInstrumentCounts[instAuctionId] = 1;
          this.handleAuctionActivated(instAuction);
        } else {
          this.auctionInstrumentCounts[instAuctionId] += 1;
        }
      }

      // Don't throw an event at this point, sorting function will throw one when it finishes
      // and this will save us from rebuilding views of this tile more than once
    },

    // Remove an instrument from the tile and clean up listeners, trigger a change event
    removeInstrument (instrumentId) {
      const logContext = `VM: ${document.title}`;
      const instrument = this.get('instruments').findWhere({instrumentId});

      if (instrument) {
        if (instrument.get('auction').get('runningState')) {
          instrument.set('auction', this.get('pageLayout').getOrAddAuction('dormant'));
        }

        instrument.set('tile', null);
        instrument.off(null, null, this);
        instrument.trigger('remove', instrument);

        BGC.logger.logInformation(logContext, `Removed instrument [${instrument.getLogDescStr()}] from tile [${this.get('tileName')}]`);

        this.get('instruments').remove(instrument);
        BGC.logger.logInformation(logContext, `Number of instruments remaining in tile [${this.get('tileName')}] is ${this.get('instruments').length}`);

        this.trigger('change:instrumentRemoved');

        return true;
      }

      return false;
    },

    createContentFromInstrumentList (instrumentList) {
      BGC.logger.logInformation(this.get('tileId'), 'Creating content from instrument list');

      instrumentList.forEach(function (instDetail) {
        let instModel = context.getInstrumentById(instDetail.instrumentId);

        if (!instModel) {
          instModel = context.modelDefinitions.Instrument.createStubInstrument(
            instDetail.instrumentId,
            this.get('tileId'),
            !context.isBrokerMode(),
            context,
            instDetail.sortOrdinal
          );
        }

        if (!instModel.get('auction')) {
          instModel.set('auction', this.get('pageLayout').getOrAddAuction('dormant'));
        }

        this._addInstrument(instModel);
      }, this);

      this.sortInstruments();
    },

    updateContentFromInstrumentList (instrumentList) {
      if (this.get('instruments').length === 0) {
        this.createContentFromInstrumentList(instrumentList);

        return;
      }

      BGC.logger.logInformation(this.get('tileId'), 'Updating content from instrument list');

      instrumentList.forEach(function (instDetail) {
        let instModel = this.findInstrumentById(instDetail.instrumentId);

        if (instModel) {
          if (instDetail.sortOrdinal !== undefined && instModel.get('index') !== instDetail.sortOrdinal) {
            instModel.set('index', instDetail.sortOrdinal);
          }
        } else {
          instModel = context.getInstrumentById(instDetail.instrumentId);
          if (!instModel) {
            instModel = context.modelDefinitions.Instrument.createStubInstrument(
              instDetail.instrumentId,
              this.get('tileId'),
              !context.isBrokerMode(),
              context,
              instDetail.sortOrdinal
            );

            context.instruments.add(instModel);
          }
          this._addInstrument(instModel);
        }
      }, this);

      // Now we need to remove from the tile any instruments that are not in the new instrument list

      const newInstIdList = _.indexBy(instrumentList, 'instrumentId');
      const instRemovalList = [];

      this.get('instruments').forEach(instrument => {
        if (newInstIdList[instrument.get('instrumentId')] === undefined) {
          instRemovalList.push(instrument.get('instrumentId'));
        }
      });

      instRemovalList.forEach(function (instId) {
        this.removeInstrument(instId);
      }, this);

      // Then sort what's left
      this.sortInstruments();
    },

    instrumentInterestUpdated (instrument, interest) {
      const instruments = this.get('instruments');

      if (interest) {
        const {name} = instrument.attributes;

        switch (interest) {
          case 'none':
            BGC.logger.logInformation('tile:instrumentInterestUpdated', `${name} - Cleared third party interest glow`);
            break;
          case 'atMid':
            BGC.logger.logInformation('tile:instrumentInterestUpdated', `${name} - Rendered full third party interest glow`);
            break;
          case 'atMidBelowMarketSize':
            BGC.logger.logInformation('tile:instrumentInterestUpdated', `${name} - Rendered below market size third party interest glow`);
            break;
          default:
            BGC.logger.logWarning('tile:instrumentInterestUpdated', `${name} - Received unknown third party interest glow: ${interest}`);
        }
      }

      this.trigger('tileHasInterest', instruments.filter(item => item.get('thirdPartyInterest') !== 'none').length);
    },

    onInstrumentTraded (instrument, hasTraded = false) {
      const instruments = this.get('instruments');

      if (hasTraded) {
        const {name} = instrument.attributes;

        BGC.logger.logInformation('tile:onInstrumentTraded', `${name} - Rendered traded gavel`);
      }
      this.trigger('instrumentTraded', instruments.filter(item => item.get('hasTradedInAuction')).length);
    },

    hasActiveIndicativePrices () {
      return !this.areAnyInstrumentsInAuction() && this.doAnyInstrumentsHaveIndicativeMids();
    },

    onInstrumentAuctionChanged (instrument) {
      const instAuction = instrument.get('auction');
      const instAuctionId = instAuction.get('auctionId');
      const prevInstAuction = instrument.previousAttributes() && instrument.previousAttributes().auction;
      const prevInstAuctionId = prevInstAuction && prevInstAuction.get('auctionId');
      const isEnteringAuctionState = instAuctionId && (instAuctionId !== 'dormant') && (instAuctionId !== 'indicative');
      const isLeavingAuctionState = !isEnteringAuctionState && prevInstAuctionId &&
        (prevInstAuctionId !== 'dormant') && (prevInstAuctionId !== 'indicative') && (prevInstAuctionId !== instAuctionId);
      const isEnteringIndicativeState = instAuctionId === 'indicative';
      const isLeavingIndicativeState = !isEnteringIndicativeState && prevInstAuctionId && prevInstAuctionId === 'indicative';
      const isLeavingDormantState = !prevInstAuctionId || prevInstAuctionId === 'dormant';
      const tileHadIndicatives = this.doAnyInstrumentsHaveIndicativeMids();
      const tileWasInAuctionState = this.areAnyInstrumentsInAuction();

      if (isEnteringAuctionState) {
        this.activeInstrumentCount.inAuction++;
        this.trigger('activeInstrumentCountChanged');
      } else if (isLeavingAuctionState) {
        this.activeInstrumentCount.inAuction--;
        this.trigger('activeInstrumentCountChanged');
      }

      if (isEnteringIndicativeState) {
        this.activeInstrumentCount.indicativeMid++;
      } else if (isLeavingIndicativeState) {
        this.activeInstrumentCount.indicativeMid--;
      }

      // Now deal with individual auction counts and updating tile auction attributes
      if (instAuctionId !== 'dormant') {
        if (this.auctionInstrumentCounts[instAuctionId] === undefined || this.auctionInstrumentCounts[instAuctionId] === 0) {
          this.auctionInstrumentCounts[instAuctionId] = 1;

          BGC.logger.logInformation(`VM: ${document.title}`, `First instrument activated in VM [${instAuctionId}] on Tile [${this.get('tileName')}]`);

          this.handleAuctionActivated(instAuction);
        } else {
          this.auctionInstrumentCounts[instAuctionId] += 1;
        }

        if (isEnteringIndicativeState && isLeavingDormantState) {
          this.trigger('indicativeInstrumentActivated', instrument.get('instrumentId'));
        }
      }

      if (prevInstAuctionId && prevInstAuctionId !== 'dormant' && prevInstAuctionId !== instAuctionId) {
        this.auctionInstrumentCounts[prevInstAuctionId] -= 1;

        if (this.auctionInstrumentCounts[prevInstAuctionId] === 0 && prevInstAuctionId !== 'indicative') {
          this.stopListening(prevInstAuction);

          this.handleAuctionDeactivated(prevInstAuction);
        }
      }

      // If there's nothing in auction, and we've gone from having no indicatives to having indicatives,
      // OR if we were in auction, but now we aren't, and there are indicatives in the tile,
      // then set the tile auction attributes for indicatives display
      if ((!tileHadIndicatives && this.activeInstrumentCount.indicativeMid > 0 && this.activeInstrumentCount.inAuction === 0) ||
        (this.activeInstrumentCount.indicativeMid > 0 && tileWasInAuctionState && this.activeInstrumentCount.inAuction === 0)) {
        this.updateAuctionAttributes();
      }

      BGC.utils.trace(`Tile.onInstrumentAuctionChanged: ${this.get('tileId')}: Instruments in auction = ${this.activeInstrumentCount.inAuction}, 
      Instruments with indicative = ${this.activeInstrumentCount.indicativeMid}`);
      BGC.utils.trace(`Tile.onInstrumentAuctionChanged: ${this.get('tileId')} ${JSON.stringify(this.auctionInstrumentCounts)}`);
    },

    onInstrumentSortIndexChanged () {
      // We might get many of these happen in quick succession,
      // so put a coalescence timer on our reaction to it
      this.coalesceSortRequests();
    },

    handleAuctionActivated (auction) {
      // Auction activated in response to first instrument (in this tile at least) going into VM state.

      BGC.utils.trace(`Tile.handleAuctionActivated: Tile: ${this.get('tileId')}, 
      Auction: ${auction.get('auctionId')}Auction Inst Count: ${this.auctionInstrumentCounts[auction.get('auctionId')]}`);

      this.listenTo(auction, 'change:endTime change:auctionPhase change:phaseoneEndtime', this.updateAuctionEndTime);
      this.listenTo(auction, 'change:runningState', this.handleAuctionRunningStateChanged);
      this.listenTo(auction, 'change:hiddenColumns', this.updateAuctionAttributes);
      this.listenTo(auction, 'change:showInterestAndTradeCount', this.updateAuctionAttributes);
      this.listenTo(auction, 'change:showThirdPartyInterestGlows', this.updateAuctionAttributes);

      this.updateAuctionEndTime();

      this.auction.set('orderPhaseText', auction.get('orderPhaseText'));

      // If we have just added the first instrument (in this tile at least) to an already running auction
      // then we won't be getting a subsequent auction start message so initialize from auction attributes now.
      if (auction.get('runningState') === auction.EContentState.eVMOnly) {
        this.handleAuctionRunningStateChanged(auction);
      }
    },

    handleAuctionRunningStateChanged (auction) {
      if (auction.get('runningState')) {
        if (auction.get('auctionId') !== 'indicative') {
          // It just got it's auction start message, complete with any hidden column info
          BGC.logger.logInformation('Tile Model', `'${this.get('tileName')}' handling start event for auction '${auction.get('auctionId')}'`);
        }

        // When we update the 'tile auction' attributes, we'll need to force out a 'change:runningState' event
        // if this is a new auction starting on tile with an already running auction, even though
        // the running state of the tile as a whole hasn't changed
        this.updateAuctionAttributes(true);
      } else {
        // Running state of indicative auction may throw a change event triggered by the layout
        // (even though its state hasn't changed) to alert us if instruments in other tiles
        // enter VM state, in which case this tile needs to hide itself if it only contains indicatives
        this.updateAuctionAttributes();
      }
    },

    handleAuctionDeactivated (auction) {
      BGC.utils.trace(`Tile.handleAuctionDeactivated: Tile: ${this.get('tileId')}, 
      Auction: ${auction.get('auctionId')}Auction Inst Count: ${this.auctionInstrumentCounts[auction.get('auctionId')]}`);

      this.auction.set('orderPhaseText', '');
      this.stopListening(auction);
      this.updateAuctionEndTime();
      this.updateAuctionAttributes();
    },

    updateAuctionEndTime () {
      let endTime = 0;
      const pageLayout = this.get('pageLayout');

      if (this.areAnyInstrumentsInAuction()) {
        let longestAuction = null;

        // Get the end time and time offset of the latest ending auction on the tile
        _.each(this.auctionInstrumentCounts, function (value, key) {
          const instAuction = pageLayout.getOrAddAuction(key);

          if (value > 0 && instAuction.get('runningState')) {
            if (instAuction.get('endTime') > endTime) {
              longestAuction = instAuction;
              endTime = longestAuction.get('endTime');
            }

            this.auction.set({
              auctionPhase    : instAuction.get('auctionPhase'),
              phaseoneEndtime : instAuction.get('phaseoneEndtime')
            });
          }
        }, this);

        if (longestAuction) {
          this.auction.set({
            endTime,
            timeOffset : longestAuction.get('timeOffset'),
            startTime  : this.auction.get('startTime') || longestAuction.get('startTime')
          });
        }
      } else {
        this.auction.set({
          startTime       : 0,
          endTime         : 0,
          timeOffset      : 0,
          auctionPhase    : '',
          phaseoneEndtime : 0
        });
      }
    },

    updateAuctionAttributes (forceRunningStateNotification) {
      let showInterestAndTradeCount = false;
      let showThirdPartyInterestGlows = false;
      let hiddenColumns = [];
      let areHiddenColumnsSetYet = false;
      const pageLayout = this.get('pageLayout');
      let auctionAttributes = {};
      let nextRunningState = -1;

      if (this.areAnyInstrumentsInAuction()) {
        const numInstrumentsInAuction = _.reduce(this.auctionInstrumentCounts,
          (memo, count, key) => (key === 'indicative' || key === 'dormant' ? memo : memo + count), 0);

        BGC.logger.logInformation('Tile.updateAuctionAttributes',
          BGC.utils.format('Tile {0}: Tile has {1} instruments in auction', [this.get('tileId'), numInstrumentsInAuction]));

        _.each(this.auctionInstrumentCounts, function (value, key) {
          const instAuction = pageLayout.getOrAddAuction(key);

          if (value > 0 && instAuction.get('runningState') === this.auction.EContentState.eVMOnly) {
            BGC.logger.logInformation('Tile.updateAuctionAttributes',
              BGC.utils.format('Tile {0} has {1} instruments in running Auction {2}, which has hidden columns set to {3}.',
                [this.get('tileId'), value, instAuction.get('auctionId'), JSON.stringify(instAuction.get('hiddenColumns'))]));

            if (areHiddenColumnsSetYet) {
              // Don't hide columns that are not hidden by ALL active auctions in the tile
              hiddenColumns = _.intersection(hiddenColumns, instAuction.get('hiddenColumns'));
            } else {
              // No hidden columns yet, so just set them from this auction
              hiddenColumns = instAuction.get('hiddenColumns');
              areHiddenColumnsSetYet = true;
            }
            showInterestAndTradeCount = showInterestAndTradeCount || instAuction.get('showInterestAndTradeCount');
            showThirdPartyInterestGlows = showThirdPartyInterestGlows || instAuction.get('showThirdPartyInterestGlows');
          }
        }, this);

        nextRunningState = this.doAnyInstrumentsHaveIndicativeMids() ? this.auction.EContentState.eMixed : this.auction.EContentState.eVMOnly;

        // Only cause an event to be thrown for hidden columns if they have really changed
        if ((hiddenColumns.length !== this.auction.get('hiddenColumns').length) ||
          _.difference(hiddenColumns, this.auction.get('hiddenColumns')).length) {
          this.auction.set('hiddenColumns', hiddenColumns);
        }
      } else if (this.doAnyInstrumentsHaveIndicativeMids()) {
        nextRunningState = pageLayout.areAnyInstrumentsInAuction() ? this.auction.EContentState.eNone : this.auction.EContentState.eIndicativeOnly;

        if (nextRunningState === this.auction.EContentState.eIndicativeOnly) {
          // Hide all generic columns
          hiddenColumns = pageLayout.getGenericColumnIdentifiers();

          // Only cause an event to be thrown for hidden columns if they have really changed
          if ((hiddenColumns.length !== this.auction.get('hiddenColumns').length) ||
            _.difference(hiddenColumns, this.auction.get('hiddenColumns')).length) {
            this.auction.set('hiddenColumns', hiddenColumns);
          }
        }
      } else {
        BGC.utils.trace(`updateAuctionAttributes: Tile ${this.get('tileId')}: Tile has NO instruments in auction or indicative state`);
        nextRunningState = this.auction.EContentState.eNone;
      }
      BGC.utils.trace(`updateAuctionAttributes: Tile ${this.get('tileId')} hidden columns are currently ${JSON.stringify(this.auction.get('hiddenColumns'))}`);

      if (nextRunningState === this.auction.get('prevRunningState')) {
        auctionAttributes = {
          showInterestAndTradeCount,
          showThirdPartyInterestGlows
        };
      } else {
        auctionAttributes = {
          prevRunningState : this.auction.get('runningState'),
          runningState     : nextRunningState,
          showInterestAndTradeCount,
          showThirdPartyInterestGlows
        };
      }

      this.auction.set(auctionAttributes);

      if (forceRunningStateNotification && !auctionAttributes.runningState) {
        this.auction.trigger('change:runningState');
      }

      // Now it has been used to indicate any state transition to consider during eventing,
      // update the tile's prevRunningState to the current runningState
      this.auction.set('prevRunningState', this.auction.get('runningState'));
    },

    sortInstruments () {
      this.get('instruments').sort();

      BGC.logger.logInformation(`VM: ${document.title}`,
        `Tile [${this.get('tileName')}|${this.get('tileId')}] sorted, now contains ${this.get('instruments').length} instruments`);

      this.trigger('change:sortOrder');
    },

    getInstrumentCount () {
      return this.get('instruments').length;
    },

    getActiveInstrumentCount () {
      return this.activeInstrumentCount.inAuction;
    },

    getInterestCount () {
      return context.modelDefinitions.Instrument.getThirdPartyInterestForInstruments(this.getInstruments());
    },

    getTradeCount () {
      return context.modelDefinitions.Instrument.getTradedCountForInstruments(this.getInstruments());
    },

    findInstrumentById (instrumentId) {
      return this.get('instruments').get(instrumentId);
    },

    getAdjustedNomenclature (stringId) {
      // Currently the same for all tiles
      return BGC.resources.getAdjustedNomenclature(stringId, this.get('pageLayout').get('nomenclature'));
    },

    getInstruments () {
      return this.get('instruments').models;
    },

    getSortedInstrumentCollection () {
      return this.get('instruments');
    },

    getName () {
      return this.get('tileName');
    }
  });

  /**
   *  Tile Collection
   */
  context.collectionDefinitions.Tiles = Backbone.Collection.extend({
    model : context.modelDefinitions.Tile,
    getInstrumentCount () {
      let count = 0;

      this.each(tile => {
        count += tile.get('instruments').length;
      });

      return count;
    }
  });

  /**
   * Tile instrument collection
   */
  context.collectionDefinitions.TileInstruments = Backbone.Collection.extend({
    model : context.modelDefinitions.Instrument,
    comparator (instrument1, instrument2) {
      const spread1 = instrument1.get('spread');
      const spread2 = instrument2.get('spread');

      if (spread1 && spread1.validateUnderlyings() && spread2 && spread2.validateUnderlyings()) {
        return context.modelDefinitions.Spread.compareSpreads(instrument1, instrument2);
      }

      return instrument1.get('index') - instrument2.get('index');
    }
  });
}(window.BGC.dataStore));
