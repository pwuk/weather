interface OrderObject {
    priceDisplay: string;
    priceDisplayD2: string;
    price: number;
    accountId: string;
    userId: string;
    boughtSize: number;
    soldSize: number;
    buySize: number;
    sellSize: number;
    isLiveBuy: boolean;
    isLiveSell: boolean;
    buyCanBeCancelled: boolean;
    sellCanBeCancelled: boolean;
    isBuyFootprint: boolean;
    isSellFootprint: boolean;
    isAuctionEndFootprint: boolean;
    wasBuyPublishedByExcel: boolean;
    wasSellPublishedByExcel: boolean;
    orderType: string;
    creationTime: number;
    isOwnOrder: boolean;
    hasBuySize: boolean;
    hasSellSize: boolean;
    hasCancellableBuySize: boolean;
    hasCancellableSellSize: boolean;
    hasBoughtSize: boolean;
    hasSoldSize: boolean;
}

interface ActiveOrderObject {
    buyOrder: OrderObject;
    sellOrder: OrderObject;
    buySize: number;
    sellSize: number;
    boughtSize: number;
    soldSize: number;
    hasCancellableBuySize: boolean;
    hasCancellableSellSize: boolean;
}