/* eslint-disable max-lines, func-names, no-param-reassign */
/* global BGC: false, _:false, Backbone: false*/

/**
 * Created by glwilliams on 12/10/2016.
 */
(function (context, utils) {
  let PendingPlugin = null;
  let InstrumentPlugin = null;
  let StructuredPlugin = null;
  const LABEL_TBD = 'TBD';

  /*
     *  Footprint model *
     *  Maintains unfilled size footprint across auction sessions
     *  States:

        'pending'       - the instrument or the underlying structure has not subscribed
        'inactive'      - the instrument or the underlying structure has subscribed but it is not active in an auction
        'indicative'    - the instrument is active in an indicative auction
        'active'        - the instrument or the underlying structure is active in a live auction

     *  Plugin behaviours:

        'Pending'       - the full instrument or the underlying structure is pending subscription
        'Instrument'    - the full instrument or underlying structure has subscribed and the underlying structure is in auction
                        - the full instrument plugin maintains a 1:1 relationship between its footprint and the instrument
        'Structured'    - the full instrument is not in auction but its underlying structure has subscribed

     *  Persisted to local storage and application server via user settings architecture
     *
     */
  context.modelDefinitions.Footprint = Backbone.Model.extend({
    defaults : {
      side         : '',
      unfilledSize : 0,
      state        : 'pending'
    },

    initialize (attributes, options) {
      this.setPlugin(options);
    },

    updateInstrument (instrument) {
      if (instrument) {
        instrument.set('footprint', this);
      } else if (this.instrument) {
        this.instrument.set('footprint', null);
      }

      this.instrument = instrument || null;
    },

    processOrderUpdate (instrument, orderSize, orderSide) {
      if (instrument === this.instrument) {
        // Update the footprint size
        this.setSize(orderSize, orderSide);

        // Downgrade to a pending footprint as the instrument now has full order
        if (this.plugin instanceof InstrumentPlugin) {
          BGC.logger.logInformation('Footprints', `Downgrading to pending footprint as order has been entered: ${instrument.getLogDescStr()}`);

          // Downgrade the instrument footprint to pending footprint
          this.setPlugin({
            id : instrument.get('instrumentId'),
            instrument
          });
        }
      } else {
        BGC.logger.logWarning('Footprints', `Ignoring order update from non-matching instrument: ${instrument.getLogDescStr()}`);
      }
    },

    processOrderCancel (instrument) {
      if (instrument === this.instrument) {
        BGC.logger.logInformation('Footprints', `Upgrading to full instrument footprint as order has been cancelled: ${instrument.getLogDescStr()}`);

        // Upgrade the pending footprint to a full instrument footprint
        this.setPlugin({
          instrument
        });
      } else {
        BGC.logger.logWarning('Footprints', `Ignoring order update from non-matching instrument: ${instrument.getLogDescStr()}`);
      }
    },

    setPlugin (options) {
      // Update the instrument relationship as the plugin strategy changes
      this.updateInstrument(options.instrument);

      // Update the plugin strategy
      if (options.id || options.underlyingIds) {
        this.plugin = new PendingPlugin(options);
      } else if (options.instrument && options.instrument.get('isSubscribed')) {
        this.plugin = new InstrumentPlugin(options);
      } else if (options.instruments && options.instruments.every(instrument => instrument && instrument.get('isSubscribed'))) {
        this.plugin = new StructuredPlugin(options);
      }

      // A footprint should always have a plugin
      if (this.plugin) {
        // Let the plugin reference its parent
        this.plugin.footprint = this;

        // Update the footprint state
        this.updatedAt = Date.now();
        this.updateState();
      } else {
        BGC.logger.logError('Footprints:', 'Error initializing footprint - failed to create plugin');
      }
    },

    isReady () {
      // An active footprint is ready (for submission) if it has (order) size
      return this.get('side') && this.get('state') === 'active';
    },

    setSize (newSize, side, validate) {
      const validated = !validate || newSize === 0 || this.plugin.validateSize(newSize);

      if (validated) {
        this.set({
          side         : newSize === 0 ? '' : side,
          unfilledSize : newSize
        });

        // If the size as been updated and the model is in a collection, persist updated collection to the server
        if (this.collection) {
          this.collection.save();
        }
      }

      return validated;
    },

    toJSON () {
      const {instrument} = this;
      const json = {
        side         : this.get('side'),
        unfilledSize : this.get('unfilledSize')
      };

      // If we have a valid instrument persist the instrument structure,
      // otherwise the footprint is pending subscription so persist the pending plugin structure
      if (instrument && instrument.isCustomSpread()) {
        const spread = instrument && instrument.get('spread');

        json.underlyingIds = spread.get('underlyings').map(underlying => underlying.instrument.get('instrumentId'));
      } else if (instrument) {
        json.id = instrument.get('instrumentId');
      } else if (this.plugin.id) {
        json.id = this.plugin.id;
      } else if (this.plugin.underlyingIds) {
        json.underlyingIds = this.plugin.underlyingIds;
      }

      return json;
    },

    matchSpread (instrument) {
      return this.plugin instanceof StructuredPlugin && instrument.matchSpread(this.plugin.spread);
    }
  });

  _.extend(context.modelDefinitions.Footprint.prototype, {
    processInstrumentMsg (instrument, msgState) {
      this.plugin.processInstrumentMsg(instrument, msgState);
    },

    updateState () {
      return this.plugin.updateState();
    },

    getId () {
      return this.plugin.getId();
    },

    getDisplayName () {
      return this.plugin.getDisplayName();
    },

    getDisplayPrice () {
      return this.plugin.getDisplayPrice();
    },

    getLastAuctionMidPriceDirection () {
      return this.plugin.getLastAuctionMidPriceDirection();
    },

    getGenericFieldValues (fields) {
      return this.plugin.getGenericFieldValues(fields);
    },

    getStandardSizes () {
      return this.plugin.getStandardSizes();
    },

    getTileInfo () {
      return this.plugin.getTileInfo();
    },

    getSortCriteria () {
      return this.plugin.getSortCriteria();
    },

    validateSize () {
      return this.plugin.validateSize();
    },

    sendOrder (viewName) {
      return this.plugin.sendOrder(viewName);
    },

    clean () {
      this.plugin.clean();
    }
  });

  // A footprint has an instrument plugin when its instrument has subscribed and if it's a structured instrument, the
  // instrument is active in an auction
  InstrumentPlugin = function (options) {
    if (!(this instanceof InstrumentPlugin)) {
      throw new Error('Constructor invoked as a function');
    }

    BGC.logger.logInformation('Footprints:', utils.format('Creating full instrument plugin: {0}', [options.instrument.getLogDescStr()]));

    // Set the instrument and bind the instrument state handlers
    this.instrument = options.instrument;
    this.instrument.on('change:state', this.updateState, this);
    this.instrument.on('change:priceDisplay', this.updatePrice, this);
  };

  _.extend(InstrumentPlugin.prototype, {
    updateState () {
      this.footprint.set('state', this.instrument.get('state'));
      this.footprint.trigger('change:state', this.footprint);
    },

    updatePrice () {
      this.footprint.trigger('change:state', this.footprint);
    },

    processInstrumentMsg (instrument, msgState) {
      if (this.instrument !== instrument) {
        BGC.logger.logWarning('Footprints', `InstrumentPlugin - ignoring instrument update from non-matching instrument: ${instrument.getLogDescStr()}`);
      } else if (instrument.isCustomSpread() && msgState.isLeavingVM) {
        const spread = instrument.get('spread');

        // If a spread instrument is leaving VM, downgrade the instrument footprint to a structured footprint
        BGC.logger.logInformation('Footprints', `Downgrading instrument footprint as spread leaves auction: ${instrument.getLogDescStr()}`);
        this.footprint.setPlugin({
          instruments : [spread.getInstrument(0), spread.getInstrument(1)],
          spreadTile  : context.pageLayout.getCustomSpreadTile()
        });
      }
    },

    getId () {
      return this.instrument.get('instrumentId');
    },

    getDisplayName () {
      let displayName = this.instrument.get('name');

      if (this.instrument.isCustomSpread()) {
        const spread = this.instrument.get('spread');

        displayName += spread.getDisplayPriceString();
      }

      return displayName;
    },

    getDisplayPrice () {
      return this.footprint.get('state') === 'inactive' ? LABEL_TBD : this.instrument.get('priceDisplay');
    },

    getLastAuctionMidPriceDirection () {
      return this.instrument.get('lastAuctionMidPriceDirection');
    },

    getGenericFieldValues (fields) {
      return fields.map(function (fld) {
        return {
          id    : fld.columnId,
          value : this.footprint.get('state') === 'inactive' ? LABEL_TBD : this.instrument.get(fld.columnId)
        };
      }, this);
    },

    getStandardSizes () {
      return this.instrument.getStandardSizes();
    },

    getTileInfo () {
      return this.instrument.getTileInfo();
    },

    getSortCriteria () {
      return {
        layoutPos     : this.getTileInfo().layoutPos,
        tilePos       : this.instrument.get('tileIndex'),
        instrumentPos : this.instrument.get('index')
      };
    },

    validateSize (size) {
      return this.instrument.validateSizeIgnoringOrder(size).valid;
    },

    sendOrder (viewName) {
      let orderPrice = this.instrument.get('midPrice');
      const pickGivePrefix = this.instrument.getPickGiveIndicator(this.footprint.get('side'));

      if (pickGivePrefix === '+') {
        // Ensure price is positive
        orderPrice = Math.abs(orderPrice);
      } else if (pickGivePrefix === '-') {
        // Ensure price is negative
        orderPrice = -Math.abs(orderPrice);
      }

      this.instrument.sendOrder({
        side         : this.footprint.get('side'),
        size         : this.footprint.get('unfilledSize').toString(),
        priceDisplay : this.getDisplayPrice(),
        price        : orderPrice
      }, viewName);
    },

    clean () {
      this.instrument.off('change:state', this.updateState);
      this.instrument.off('change:priceDisplay', this.updatePrice);
      this.instrument.set('footprint', null);
    }
  });

  // A footprint has a structured plugin if its underlying instrument structure is subscribed but the instrument itself
  // is not active (in a live auction)
  StructuredPlugin = function (options) {
    if (!(this instanceof StructuredPlugin)) {
      throw new Error('Constructor being invoked as a function');
    }

    BGC.logger.logInformation('Footprints:', utils.format('Creating structured plugin: {0}, {1}',
      [options.instruments[0].getLogDescStr(), options.instruments[1].getLogDescStr()]));

    this.spreadTile = options.spreadTile;

    // Do not sort underlyings if instrument(s) is inactive
    const shouldNotSortUnderlyings = options.instruments.some(instrument => instrument.get('inactive'));

    // Crete the spread from the underlying instrument structure
    this.spread = new context.modelDefinitions.Spread({
      instruments             : options.instruments,
      displayUnderlyingPrices : true,
      shouldNotSort           : shouldNotSortUnderlyings
    });

    // Bind instrument state change handlers
    this.spread.getInstrument(0).on('change:state', this.updateState, this);
    this.spread.getInstrument(1).on('change:state', this.updateState, this);
  };

  _.extend(StructuredPlugin.prototype, {
    updateState () {
      if (this.spread.areUnderlyingsInAuction()) {
        this.spread.set('weighting', this.spread.calcNormalVegaWeighting());
        this.footprint.set('state', 'active', {silent : true});
      } else {
        this.spread.set('weighting', 0);
        this.footprint.set('state', 'inactive', {silent : true});
      }
      this.footprint.trigger('change:state', this.footprint);
    },

    processInstrumentMsg (instrument, msgState) {
      const spread = instrument.get('spread');

      // If a new spread instrument is entering VM, check to see whether it matches this plugin structure,
      // and if it does upgrade the structured footprint tpo a full instrument footprint (now the spread is available)
      if (spread && msgState.isEnteringVM && this.footprint.matchSpread(instrument)) {
        BGC.logger.logInformation('Footprints', `Upgrading structured footprint as spread enters auction: ${instrument.getLogDescStr()}`);

        this.footprint.setPlugin({
          instrument
        });
      }
    },

    getId () {
      return this.spread.getInstrument(0).get('instrumentId') + this.spread.getInstrument(1).get('instrumentId');
    },

    getDisplayName () {
      let displayName = this.spread.buildSpreadDisplayName();

      if (this.footprint.get('state') === 'active') {
        displayName += this.spread.getDisplayPriceString();
      }

      return displayName;
    },

    getDisplayPrice () {
      return this.footprint.get('state') === 'inactive' ? LABEL_TBD : this.spread.getInstrument(0).get('priceDisplay');
    },

    getLastAuctionMidPriceDirection () {
      return this.spread.getInstrument(0).get('lastAuctionMidPriceDirection');
    },

    getGenericFieldValues (fields) {
      return fields.map(function (fld) {
        let value = '';

        switch (fld.columnId) {
          case 'strike1Display':
            value = this.spread.getInstrument(0).get('strike2Display');
            break;
          case 'strike2Display':
            value = this.spread.getInstrument(1).get(fld.columnId);
            break;
          default:
        }

        return {
          id    : fld.columnId,
          value : this.footprint.get('state') === 'inactive' ? LABEL_TBD : value
        };
      }, this);
    },

    getStandardSizes () {
      return this.spread.getInstrument(0).getStandardSizes();
    },

    getTileInfo () {
      return {
        layoutPos : this.spreadTile.get('layoutPos'),
        id        : this.spreadTile.get('tileId'),
        name      : this.spreadTile.get('tileName')
      };
    },

    getSortCriteria () {
      return {
        layoutPos     : this.spreadTile.get('layoutPos'),
        tilePos       : this.spreadTile.get('tileIndex'),
        instrumentPos : this.spread.getInstrument(0).get('index')
      };
    },

    validateSize (size) {
      return this.spread.validateSize(0, size).valid;
    },

    sendOrder () {
      this.spread.setOrder(0, this.footprint.get('side'), this.footprint.get('unfilledSize'));

      this.spread.createSpread(true, true);
    },

    clean () {
      this.spread.getInstrument(0).off('change:state', this.updateState);
      this.spread.getInstrument(1).off('change:state', this.updateState);
    }
  });

  // A footprint maintains a pending plugin until its instrument or the instruments that comprise the underlying
  // structure have subscribed.
  PendingPlugin = function (options) {
    if (!(this instanceof PendingPlugin)) {
      throw new Error('Constructor being invoked as a function');
    }

    this.id = options.id || null;
    this.underlyingIds = options.underlyingIds || null;
  };

  _.extend(PendingPlugin.prototype, {
    updateState () {
      this.footprint.set('state', 'pending');
    },

    processInstrumentMsg (instrument, msgState) {
      if (msgState.isLeavingVM && instrument.isCustomSpread() && this.footprint.instrument === instrument) {
        const spread = instrument.get('spread');

        // If this is a custom spread footprint and its instrument is leaving VM,
        // upgrade to a structured footprint to persist the underlying structure
        BGC.logger.logInformation('Footprints', `Upgrading from pending to structured footprint as spread leaves auction: ${instrument.getLogDescStr()}`);

        this.footprint.setPlugin({
          instruments : [spread.getInstrument(0), spread.getInstrument(1)],
          spreadTile  : context.pageLayout.getCustomSpreadTile()
        });
      } else if (!this.footprint.instrument) {
        const id = instrument.get('instrumentId');

        // Otherwise, if the footprint is pending subscription, attempt to match against the new instrument
        if (this.id === id) {
          this.footprint.setPlugin({
            instrument
          });
        } else if (this.underlyingIds) {
          const underlyingIndex = this.underlyingIds.indexOf(id);

          if (underlyingIndex === 0) {
            this.footprint.setPlugin({
              instruments : [instrument, context.getInstrumentById(this.underlyingIds[1])],
              spreadTile  : context.pageLayout.getCustomSpreadTile()
            });
          } else if (underlyingIndex === 1) {
            this.footprint.setPlugin({
              instruments : [context.getInstrumentById(this.underlyingIds[0]), instrument],
              spreadTile  : context.pageLayout.getCustomSpreadTile()
            });
          }
        }
      }
    },

    getId () {
      return this.id || (this.underlyingIds[0] + this.underlyingIds[1]);
    },

    getDisplayName () {
      return 'pending';
    },

    getDisplayPrice () {
      return LABEL_TBD;
    },

    getLastAuctionMidPriceDirection () {
      return 'none';
    },

    getGenericFieldValues () {
      // stub
    },

    getStandardSizes () {
      return [0, 0, 0];
    },

    getSortCriteria () {
      return {
        layoutPos     : 0,
        tilePos       : 0,
        instrumentPos : 0
      };
    },

    validateSize () {
      return false;
    },

    clean () {
      if (this.footprint.instrument) {
        this.footprint.instrument.set('footprint', null);
      }
    }
  });

  context.collectionDefinitions.Footprints = Backbone.Collection.extend({
    model                    : context.modelDefinitions.Footprint,
    maxFootprintInactiveTime : context.userSettingsStore.get('maxFootprintInactiveTime'),

    // Override Backbone method to associate the footprint with its instrument and to persist updated collection to the server
    add (models, options) {
      const modelList = Array.isArray(models) ? models : [models];

      // If it's a spread and spread's instrument is not in auction set plugin type to Structured
      if (options && options.restore) {
        modelList.filter(model => {
          if (model.plugin instanceof InstrumentPlugin) {
            return model.instrument.isCustomSpread() && !model.instrument.isInAuction();
          }

          return false;
        }).forEach(model => {
          model.plugin.processInstrumentMsg(model.instrument, {isLeavingVM : true});
        });
      }

      // Associate each new footprint with its instrument
      modelList.filter(model => model.plugin instanceof InstrumentPlugin).forEach(model => {
        model.instrument.set('footprint', model);
      });

      // Invoke the base class implementation to add models to the collection
      const addedModels = Backbone.Collection.prototype.add.apply(this, [modelList, options]);

      // Persist updated collection to the server
      if (modelList.length > 0 && (!options || !options.shouldNotPersist)) {
        this.save();
      }

      return addedModels;
    },

    // Override Backbone method to remove footprint from instrument and to persist updated collection to the server
    remove (models, options) {
      if (!models) {
        return;
      }

      const modelList = Array.isArray(models) ? models : [models];

      // Remove event handlers and footprint
      modelList.forEach(model => {
        model.clean();
      });

      // Invoke the base class implementation to remove the models
      Backbone.Collection.prototype.remove.call(this, models, options);

      // Persist updated collection to the server
      this.save();

      // eslint-disable-next-line consistent-return
      return models;
    },

    // Override Backbone method to (optionally) persist collection to the server
    reset (models, options) {
      // Clear all event handlers and footprint - instrument associations
      this.forEach(model => {
        model.clean();
      });

      // Invoke the base class implementation to reset the collection
      Backbone.Collection.prototype.reset.call(this, models, options);

      if (!options || !options.shouldNotPersist) {
        this.save();
      }
    },

    // Persist footprint collection to user settings store
    save () {
      context.userSettingsStore.set('persistedFootprints', this.length > 0 ? this.toJSON() : []);
    },

    // Restore the footprint collection from the user settings store
    restore (settings) {
      const footprints = [];

      BGC.logger.logInformation('Footprints', utils.format('Restoring {0} pending footprints from user settings ...', [settings.length]));

      // Restore all settings as footprints
      settings.forEach(value => {
        if (value.id || value.underlyingIds) {
          footprints.push(new context.modelDefinitions.Footprint({
            unfilledSize : value.unfilledSize,
            side         : value.side
          }, {
            id            : value.id,
            underlyingIds : value.underlyingIds
          }));
        } else {
          BGC.logger.logError('Footprints', 'Removing invalid footprint');
        }
      }, this);

      this.reset(footprints, {shouldNotPersist : true});
    },

    // Processes 'instrument' message updates
    processInstrumentMsg (instrument, message, msgState) {
      const footprint = instrument.get('footprint');

      // If the instrument has a footprint process the update directly
      if (footprint) {
        footprint.processInstrumentMsg(instrument, msgState);
      } else if (!msgState.isLeavingVM) {
        // Otherwise allow any footprints that are still pending instrument subscription to process this update
        this.filter(item => !item.instrument).forEach(footprintModel => {
          footprintModel.processInstrumentMsg(instrument, msgState);
        });
      }
    },

    // Processes 'order' message updates
    // eslint-disable-next-line max-statements
    processOrderMsg (instrument, order, msg) {
      const footprint = instrument.get('footprint');
      const hasZeroSize = utils.compareFPNumEQ([msg.boughtSize, msg.soldSize, msg.buySize, msg.sellSize]
        .reduce((acc, val) => acc + val, 0), 0);
      const isOrderCancel = !!(hasZeroSize && order);
      let orderSide = '';
      let unfilledSize = 0;

      // Calculate the unfilled size and order side
      if (msg.isLiveBuy) {
        unfilledSize = msg.buySize;
        orderSide = 'buy';
      } else if (msg.isLiveSell) {
        unfilledSize = msg.sellSize;
        orderSide = 'sell';
      }

      // If the instrument has a footprint process the order directly
      if (footprint) {
        if (isOrderCancel) {
          footprint.processOrderCancel(instrument);
        } else if (!hasZeroSize) {
          footprint.processOrderUpdate(instrument, unfilledSize, orderSide);
        }
      } else if (!hasZeroSize) {
        BGC.logger.logInformation('Footprints', `Creating pending footprint for new order: ${instrument.getLogDescStr()}`);

        // Otherwise this is a new order submission, so create a pending footprint
        this.add(new context.modelDefinitions.Footprint({
          side : orderSide,
          unfilledSize
        }, {
          id : instrument.get('instrumentId'),
          instrument
        }));
      }
    },

    // Empties the pending footprint collection.
    clearPendingFootprints () {
      const inactiveFootprints = this.models.filter(function (fp) {
        return fp.get('state') === 'pending' &&
                Date.now() - fp.updatedAt > this.maxFootprintInactiveTime;
      }, this);

      if (inactiveFootprints && inactiveFootprints.length > 0) {
        BGC.logger.logInformation(
          'Footprints:',
          utils.format('Removing {0} inactive pending footprint(s)', [inactiveFootprints.length])
        );

        inactiveFootprints.forEach(function (fp) {
          this.remove(fp);
        }, this);
      }
    }
  });

  // Create the 'footprint' collection
  context.footprints = new context.collectionDefinitions.Footprints();
}(window.BGC.dataStore, window.BGC.utils));
