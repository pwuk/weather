/* eslint-disable max-lines, func-names, no-param-reassign, id-length, no-plusplus */
/* global BGC: false, _:false, Backbone: false  */

(function (context) {
  /*
     *   Attributes:
     *   x                        : Array of column header strings
     *   y                        : Array of row header strings
     *   cells                    : 2D Array of Instrument models
     *   linkedMatrices           : (Optional) Collection of linked Matrix models
     *   defaultLinkedMatrixIndex : Default Linked Matrix Index selected when page is first opened
     *   columnLinkIndex          : Index of linked column in main matrix
     *   matrixName               : matrix display name string
     */
  context.dataStore.modelDefinitions.Matrix = Backbone.Model.extend({

    defaults : {
      x          : [],
      y          : [],
      cells      : [[]],
      active     : false,
      auction    : null,
      matrixName : '',
      matrixId   : '',
      currencyId : ''
    },

    initialize () {
      if (!this.get('matrixId')) {
        throw new TypeError('Matrix model created without ID');
      }

      // Create an Auction object to embrace the characteristics of all auctions running in this matrix
      this.auction = this.get('pageLayout').getOrAddAuction(this.get('matrixId'), true);
      this.activeInstrumentCount = {inAuction : 0, indicativeMid : 0};
      this.auctionInstrumentCounts = {indicative : 0, dormant : 0};

      // listen to linked matrices interest change
      this.get('linkedMatrices').forEach(function (linkedMatrix) {
        this.listenTo(linkedMatrix, 'matrixHasInterest', this.instrumentInterestUpdated);
        this.listenTo(linkedMatrix, 'matrixInstrumentTraded', this.onInstrumentTraded);
        this.listenTo(linkedMatrix, 'orderExecutedOnMatrixInstrument', this.onOrderExecuted);
      }, this);

      // label each instrument's position (x, y) within the grid
      this.get('cells').forEach(function (column) {
        column.forEach(function (instrument) {
          instrument.on('change:thirdPartyInterest', this.instrumentInterestUpdated, this);
          instrument.on('change:auction', this.onInstrumentAuctionChanged, this);
          instrument.on('change:hasTradedInAuction', this.onInstrumentTraded, this);
          instrument.on('change', this.onOrderExecuted, this);

          const instAuction = instrument.get('auction');
          const instAuctionId = instAuction.get('auctionId');

          if (instAuction.get('runningState')) {
            // Adding instrument to already running auction
            this.onInstrumentAuctionChanged(instrument);
          } else if (instAuctionId !== 'dormant') {
            if (instAuctionId === 'indicative') {
              this.activeInstrumentCount.indicativeMid++;
            } else {
              this.activeInstrumentCount.inAuction++;
            }

            if (this.auctionInstrumentCounts[instAuctionId] === undefined || this.auctionInstrumentCounts[instAuctionId] === 0) {
              this.auctionInstrumentCounts[instAuctionId] = 1;
              this.handleAuctionActivated(instAuction);
            } else {
              this.auctionInstrumentCounts[instAuctionId] += 1;
            }
          }
        }, this);
      }, this);
    },

    // Returns the matrix instruments mapped by row/col identifier
    lookUp (isMapByRowCol = true, linkedMatrixIndex = undefined) {
      const instruments = {};
      const {currencyId} = this.attributes;
      let {y, x, cells} = this.attributes;

      if (linkedMatrixIndex) {
        y = this.get('linkedMatrices').models[linkedMatrixIndex - 1].attributes.y;
        x = this.get('linkedMatrices').models[linkedMatrixIndex - 1].attributes.x;
        cells = this.get('linkedMatrices').models[linkedMatrixIndex - 1].attributes.cells;
      }

      cells.forEach((col, colIndex) => {
        col.forEach((instrument, rowIndex) => {
          if (colIndex < x.length && rowIndex < y.length) {
            if (isMapByRowCol) {
              instruments[`${currencyId}${y[rowIndex]}${x[colIndex]}`] = instrument;
            } else {
              instruments[`${currencyId}${x[colIndex]}${y[rowIndex]}`] = instrument;
            }
          }
        });
      });

      return instruments;
    },

    // Returns whether the single linked triangle matrix is an inverted layout
    isInvertedTriangleLayout () {
      const linkedMatrices = this.get('linkedMatrices') || [];

      return linkedMatrices.length === 1 ? linkedMatrices.models[0].get('layoutType') === 'triangle-inverted' : false;
    },

    areAnyInstrumentsInAuction () {
      return this.activeInstrumentCount.inAuction > 0;
    },

    doAnyInstrumentsHaveIndicativeMids () {
      return this.activeInstrumentCount.indicativeMid > 0;
    },

    hasActiveIndicativePrices () {
      return !this.areAnyInstrumentsInAuction() && this.doAnyInstrumentsHaveIndicativeMids();
    },

    // eslint-disable-next-line complexity,max-statements
    onInstrumentAuctionChanged (instrument) {
      const instAuction = instrument.get('auction');
      const instAuctionId = instAuction.get('auctionId');
      const prevInstAuction = instrument.previousAttributes() && instrument.previousAttributes().auction;
      const prevInstAuctionId = prevInstAuction && prevInstAuction.get('auctionId');
      const isEnteringAuctionState = instAuctionId && (instAuctionId !== 'dormant') && (instAuctionId !== 'indicative');
      const isLeavingAuctionState = !isEnteringAuctionState && prevInstAuctionId && (prevInstAuctionId !== 'dormant') &&
        (prevInstAuctionId !== 'indicative') && (prevInstAuctionId !== instAuctionId);
      const isEnteringIndicativeState = instAuctionId === 'indicative';
      const isLeavingIndicativeState = !isEnteringIndicativeState && prevInstAuctionId && prevInstAuctionId === 'indicative';
      const matrixHadIndicatives = this.doAnyInstrumentsHaveIndicativeMids();
      const matrixWasInAuctionState = this.areAnyInstrumentsInAuction();

      if (isEnteringAuctionState) {
        this.activeInstrumentCount.inAuction++;
      } else if (isLeavingAuctionState) {
        this.activeInstrumentCount.inAuction--;
      }

      if (isEnteringIndicativeState) {
        this.activeInstrumentCount.indicativeMid++;
      } else if (isLeavingIndicativeState) {
        this.activeInstrumentCount.indicativeMid--;
      }

      // Now deal with individual auction counts and updating matrix auction attributes
      if (instAuctionId !== 'dormant') {
        if (this.auctionInstrumentCounts[instAuctionId] === undefined || this.auctionInstrumentCounts[instAuctionId] === 0) {
          this.auctionInstrumentCounts[instAuctionId] = 1;

          BGC.logger.logInformation(`VM: ${document.title}`, `First instrument activated in VM [${instAuctionId}] on Matrix [${this.get('matrixId')}]`);

          this.handleAuctionActivated(instAuction);
        } else {
          this.auctionInstrumentCounts[instAuctionId] += 1;
        }
      }

      if (prevInstAuctionId && prevInstAuctionId !== 'dormant' && prevInstAuctionId !== instAuctionId) {
        this.auctionInstrumentCounts[prevInstAuctionId] -= 1;

        if (this.auctionInstrumentCounts[prevInstAuctionId] === 0 && prevInstAuctionId !== 'indicative') {
          this.stopListening(prevInstAuction);

          this.handleAuctionDeactivated(prevInstAuction);
        }
      }

      // If there's nothing in auction, and we've gone from having no indicatives to having indicatives,
      // OR if we were in auction, but now we aren't, and there are indicatives in the Matrix,
      // then set the Matrix auction attributes for indicatives display
      if ((!matrixHadIndicatives && this.activeInstrumentCount.indicativeMid > 0 && this.activeInstrumentCount.inAuction === 0) ||
        (this.activeInstrumentCount.indicativeMid > 0 && matrixWasInAuctionState && this.activeInstrumentCount.inAuction === 0)) {
        this.updateAuctionAttributes();
      }

      BGC.utils.trace(`Matrix.onInstrumentAuctionChanged: ${this.get('matrixId')}: 
      Instruments in auction = ${this.activeInstrumentCount.inAuction}, Instruments with indicative = ${this.activeInstrumentCount.indicativeMid}`);
    },

    handleAuctionActivated (auction) {
      this.listenTo(auction, 'change:endTime change:auctionPhase change:phaseoneEndtime', this.updateAuctionEndTime);
      this.listenTo(auction, 'change:showInterestAndTradeCount', this.updateAuctionAttributes);
      this.listenTo(auction, 'change:runningState', this.handleAuctionRunningStateChanged);
      this.listenTo(auction, 'change:endTime', this.updateAuctionEndTime);

      this.auction.set('orderPhaseText', auction.get('orderPhaseText'));

      this.updateAuctionEndTime();

      // If we have just added the first instrument (in this matrix at least) to an already running auction
      // then we won't be getting a subsequent auction start message so initialize from auction attributes now.
      if (auction.get('runningState') === auction.EContentState.eVMOnly) {
        this.handleAuctionRunningStateChanged(auction);
      }
    },

    handleAuctionDeactivated (auction) {
      this.auction.set('orderPhaseText', '');

      this.stopListening(auction);
      this.updateAuctionEndTime();
      this.updateAuctionAttributes();
    },

    handleAuctionRunningStateChanged (auction) {
      if (auction.get('runningState')) {
        if (auction.get('auctionId') !== 'indicative') {
          // It just got it's auction start message, complete with any hidden column info
          BGC.logger.logInformation('Matrix Model', `'${this.get('matrixId')}' handling start event for auction '${auction.get('auctionId')}'`);
        }

        // When we update the 'matrix auction' attributes, we'll need to force out a 'change:runningState' event
        // if this is a new auction starting on matrix with an already running auction, even though
        // the running state of the matrix as a whole hasn't changed
        this.updateAuctionAttributes(true);
      } else {
        // Running state of indicative auction may throw a change event triggered by the layout
        // (even though its state hasn't changed) to alert us if instruments in other tiles
        // enter VM state, in which case this tile needs to hide itself if it only contains indicatives
        this.updateAuctionAttributes();
      }
    },

    updateAuctionEndTime () {
      let endTime = 0;
      const pageLayout = this.get('pageLayout');

      if (this.areAnyInstrumentsInAuction()) {
        let longestAuction = null;

        // Get the end time and time offset of the latest ending auction on the matrix
        _.each(this.auctionInstrumentCounts, function (value, key) {
          const instAuction = pageLayout.getOrAddAuction(key);

          if (value > 0 && instAuction.get('runningState')) {
            if (instAuction.get('endTime') > endTime) {
              longestAuction = instAuction;
              endTime = longestAuction.get('endTime');
            }

            this.auction.set({
              auctionPhase    : instAuction.get('auctionPhase'),
              phaseoneEndtime : instAuction.get('phaseoneEndtime')
            });
          }
        }, this);

        if (longestAuction) {
          this.auction.set({
            endTime,
            timeOffset : longestAuction.get('timeOffset'),
            startTime  : this.auction.get('startTime') || longestAuction.get('startTime')
          });
        }
      } else {
        this.auction.set({
          startTime       : 0,
          endTime         : 0,
          timeOffset      : 0,
          auctionPhase    : '',
          phaseoneEndtime : 0
        });
      }
    },

    // eslint-disable-next-line max-statements
    updateAuctionAttributes (forceRunningStateNotification) {
      let showInterestAndTradeCount = false;
      const pageLayout = this.get('pageLayout');
      let auctionAttributes = {};
      let nextRunningState = -1;

      if (this.areAnyInstrumentsInAuction()) {
        _.each(this.auctionInstrumentCounts, (value, key) => {
          let instAuction = pageLayout.getOrAddAuction(key);

          if (value > 0 && instAuction.get('runningState')) {
            instAuction = pageLayout.getOrAddAuction(key);
            showInterestAndTradeCount = showInterestAndTradeCount || instAuction.get('showInterestAndTradeCount');
          }
        }, this);

        nextRunningState = this.doAnyInstrumentsHaveIndicativeMids() ? this.auction.EContentState.eMixed : this.auction.EContentState.eVMOnly;
      } else if (this.doAnyInstrumentsHaveIndicativeMids()) {
        nextRunningState = pageLayout.areAnyInstrumentsInAuction() ? this.auction.EContentState.eNone : this.auction.EContentState.eIndicativeOnly;
      } else {
        BGC.utils.trace(`updateAuctionAttributes: Matrix ${this.get('matrixId')}: Matrix has NO instruments in auction or indicative state`);
        nextRunningState = this.auction.EContentState.eNone;
      }

      if (nextRunningState === this.auction.get('prevRunningState')) {
        auctionAttributes = {
          showInterestAndTradeCount
        };
      } else {
        auctionAttributes = {
          prevRunningState : this.auction.get('runningState'),
          runningState     : nextRunningState,
          showInterestAndTradeCount
        };
      }

      this.auction.set(auctionAttributes);

      if (forceRunningStateNotification && !auctionAttributes.runningState) {
        this.auction.trigger('change:runningState');
      }

      // Now it has been used to indicate any state transition to consider during eventing,
      // update the tile's prevRunningState to the current runningState
      this.auction.set('prevRunningState', this.auction.get('runningState'));
    },

    getCells () {
      let columns = this.get('cells');

      this.get('linkedMatrices').each(linkedMatrix => {
        columns = columns.concat(linkedMatrix.get('cells'));
      });

      return columns;
    },

    instrumentInterestUpdated (instrument, interest) {
      if (interest) {
        const {name} = instrument.attributes;

        switch (interest) {
          case 'none':
            BGC.logger.logInformation('matrix:instrumentInterestUpdated', `${name} - Cleared third party interest glow`);
            break;
          case 'atMid':
            BGC.logger.logInformation('matrix:instrumentInterestUpdated', `${name} - Rendered full third party interest glow`);
            break;
          case 'atMidBelowMarketSize':
            BGC.logger.logInformation('matrix:instrumentInterestUpdated', `${name} - Rendered below market size third party interest glow`);
            break;
          default:
            BGC.logger.logWarning('matrix:instrumentInterestUpdated', `${name} - Received unknown third party interest glow: ${interest}`);
        }
      }

      this.trigger('matrixHasInterest', this.getInterestCountForLinkedMatrices());
    },

    onOrderExecuted (instrument) {
      this.trigger('orderExecutedOnMatrixInstrument', instrument);
    },

    onInstrumentTraded (instrument, hasTraded = false) {
      if (hasTraded) {
        const {name} = instrument.attributes;

        BGC.logger.logInformation('matrix:onInstrumentTraded', `${name} - Rendered traded gavel`);
      }

      this.trigger('matrixInstrumentTraded', this.getTradedCountForLinkedMatrices());
    },

    getInterestCount () {
      return context.dataStore.modelDefinitions.Instrument.getThirdPartyInterestForInstruments(_.flatten(this.getCells()));
    },

    getTradedCount () {
      return context.dataStore.modelDefinitions.Instrument.getTradedCountForInstruments(_.flatten(this.getCells()));
    },

    getInterestCountForLinkedMatrices () {
      const matrixInterest = [];

      this.get('linkedMatrices').each(linkedMatrix => {
        const thirdPartyInterest = context.dataStore.modelDefinitions.Instrument.getThirdPartyInterestForInstruments(_.flatten(linkedMatrix.get('cells')));

        matrixInterest.push({matrixId : linkedMatrix.get('matrixId'), thirdPartyInterest});
      });

      return matrixInterest;
    },

    getTradedCountForLinkedMatrices () {
      const matrixTradedCount = [];

      this.get('linkedMatrices').each(linkedMatrix => {
        const tradedCount = context.dataStore.modelDefinitions.Instrument.getTradedCountForInstruments(_.flatten(linkedMatrix.get('cells')));

        matrixTradedCount.push({matrixId : linkedMatrix.get('matrixId'), tradedCount});
      });

      return matrixTradedCount;
    },

    getInstruments () {
      let currentMatrixInstruments = [];
      const linkedMatricesInstruments = _.flatten(this.get('linkedMatrices').invoke('getInstruments'));

      currentMatrixInstruments = _.chain(this.get('cells'))
        .flatten()
        .filter(instrument => !_.isUndefined(instrument.get('instrumentId')))
        .value();

      return currentMatrixInstruments.concat(linkedMatricesInstruments);
    },

    findInstrumentById (instrumentId) {
      return _.find(this.getInstruments(), instrument => instrument.get('instrumentId') === instrumentId);
    },

    getName () {
      return this.get('matrixName');
    }
  });

  /**
   * Creation method that builds a matrix model
   * from the provided data. Gets recursively called
   * for all linked matrices
   *
   * @param {Object} matrixData - is the data to populate matrix with
   * @param {Object} dataStore - the central data store which receives all data from the server
   * @returns {context.dataStore.modelDefinitions.Matrix} - created matrix model
   * @memberof context.dataStore.modelDefinitions.Matrix
   * @static
   */
  context.dataStore.modelDefinitions.Matrix.build = function (matrixData, pageLayout, dataStore) {
    let linkedMatrices = [];

    if (matrixData.linkedMatrices) {
      linkedMatrices = matrixData.linkedMatrices.map(linkedMatrix => context.dataStore.modelDefinitions.Matrix.build(linkedMatrix, pageLayout, dataStore));
    }

    // create Instrument models
    const instrumentList = matrixData.instrumentList.map(instrument => {
      const instrumentModel = dataStore.getInstrumentById(instrument.instrumentId);

      if (instrumentModel) {
        instrumentModel.set({
          xIndex             : instrument.columnIndex,
          yIndex             : instrument.rowIndex,
          canUserEnterOrders : !dataStore.isBrokerMode(),
          auction            : pageLayout.getOrAddAuction('dormant'),
          tileId             : matrixData.matrixId,
          dataStore
        });

        return instrumentModel;
      }

      return new context.dataStore.modelDefinitions.Instrument({
        instrumentId       : instrument.instrumentId,
        name               : instrument.instrumentName,
        shortName          : instrument.instrumentShortName,
        xIndex             : instrument.columnIndex,
        yIndex             : instrument.rowIndex,
        canUserEnterOrders : !dataStore.isBrokerMode(),
        auction            : pageLayout.getOrAddAuction('dormant'),
        dataStore
      });
    }, this);

    // create an object for quick lookup when creating the matrix
    const instruments = BGC.utils.groupBy(instrumentList, [
      function (instrument) {
        return instrument.get('xIndex');
      },
      function (instrument) {
        return instrument.get('yIndex');
      }
    ]);

    // create instrument matrix
    const instrumentMatrix = matrixData.columnHeaderList.map(function (column, xIndex) {
      return matrixData.rowHeaderList.map((row, yIndex) => {
        let instrument = null;

        // eslint-disable-next-line no-prototype-builtins
        if (instruments.hasOwnProperty(xIndex) && instruments[xIndex].hasOwnProperty(yIndex)) {
          // eslint-disable-next-line prefer-destructuring
          instrument = instruments[xIndex][yIndex][0];
        }

        return instrument || new context.dataStore.modelDefinitions.Instrument({
          canUserEnterOrders : !dataStore.isBrokerMode(),
          auction            : pageLayout.getOrAddAuction('dormant'),
          dataStore
        });
      }, this);
    }, this);

    // create matrix model
    return new context.dataStore.modelDefinitions.Matrix({
      x                        : matrixData.columnHeaderList,
      y                        : matrixData.rowHeaderList,
      cells                    : instrumentMatrix,
      matrixName               : matrixData.matrixName,
      layoutType               : matrixData.layoutType,
      defaultLinkedMatrixIndex : matrixData.layoutType === 'matrix' ? matrixData.defaultLinkedMatrixIndex : -1,
      columnLinkIndex          : ['triangle', 'triangle-inverted'].includes(matrixData.layoutType) ? matrixData.columnLinkIndex : -1,
      linkedMatrices           : new context.dataStore.collectionDefinitions.MatrixList(linkedMatrices),
      matrixId                 : matrixData.matrixId,
      pageLayout,
      currencyId               : matrixData.currencyId
    });
  };

  /**
   * Matrix list - a list of matrices.
   * @class
   * @example
   * @see http://backbonejs.org
   */
  context.dataStore.collectionDefinitions.MatrixList = Backbone.Collection.extend({
    model : context.dataStore.modelDefinitions.Matrix
  });
}(window.BGC));
