/*global BGC: false, Backbone: false*/

(function(context, utils, logger){
    "use strict";

    // Private static functions
    const _findSecurityLockLeg = function(lockInstruments, securityId) {
        // Split the Security ID (typically a CUSIP or ISIN) into legs
        const legIds = securityId.split('/');

        for (let lock of lockInstruments) {
            if (legIds.includes(lock.getSecurityId())) {
                // return the first lock leg
                return lock;
            }
        }

        // Security does not have a lock leg
        return null;
    };

    context.PortfolioStates = {
        UNKNOWN   : 'Unknown',      // Unable to identify the instrument
        MATCHED   : 'Matched',      // Multiple matches found
        INVALID   : 'Invalid',      // Invalid order size or limit price
        LOADED    : 'Loaded',       // Valid item has been loaded
        PENDING   : 'Pending',      // Order is submitted pending session start
        HELD      : 'Held',         // Order is held - session price is outside of the limit
        SUBMITTED : 'Submitted',    // Order has been submitted
        REJECTED  : 'Rejected',     // Order has been rejected
        ACTIVE    : 'Active',       // Order has been accepted and is active in the session
        CANCELLED : 'Cancelled'     // Order has been cancelled - lock price has changed
    };

    context.modelDefinitions.PortfolioItem = Backbone.Model.extend({
        defaults: {
            fields : [],                // Raw imported text fields
            instrument : undefined,
            structure : null,
            limit : {
                text : '',
                numeric : NaN
            },
            limitB : {
                text : '',
                numeric : NaN
            },
            size : NaN,
            totalSize : 0,              // Total order size rounded down by size increment
            totalFill : 0,              // Total filled size persisted across sessions
            sessionFill : 0,            // Filled size during current session
            side : undefined,
            state : context.PortfolioStates.UNKNOWN,
            status : ''
        },

        initialize : function (attributes, options) {
            const {instrument, structure, matches, locks} = options;
            const {MATCHED} = context.PortfolioStates;

            if (instrument) {
                // Set matching instrument
                logger.logInformation('PortfolioItem::initialize', `[${instrument.get('name')}] Importing instrument: ${this.id}`, true);

                const lock = locks && _findSecurityLockLeg(locks, instrument.getSecurityId());

                this._setInstrument(instrument, lock, true);

                if (Reflect.has(options, 'isHigherVegaFirst')) {
                    this.set('isHigherVegaFirst', options.isHigherVegaFirst);
                }
            } else if (structure) {
                // Set matching structure (custom spread legs)
                logger.logInformation('PortfolioItem::initialize', `Importing structure: ${this.id}`, true);

                this._setStructure(structure);
            } else if (matches && matches.length > 1) {
                // Multiple matches found
                logger.logWarning('PortfolioItem::initialize', `Unable to import: ${this.id} - multiple matches found`);

                this.set('state', MATCHED)
            }
        },

        // Upgrades a structure to a full instrument - when for example a custom spread has been created
        upgradeStructure : function (instrument) {
            const {structure, state, id} = this.attributes;
            const {PENDING, SUBMITTED} = context.PortfolioStates;

            logger.logInformation('PortfolioItem::upgradeStructure', `Upgrading custom structure [${id}] to full instrument: ${this.getDescription()}`, true);

            // Clear the structure and initialize the instrument
            structure.off('change', this.handleStructureChange, this);

            this.set({
                structure : null,
                isHigherVegaFirst :  structure.wasHigherVegaFirst()
            });

            this._setInstrument(instrument);

            if (state === PENDING) {
                this._handleSessionStart(false);
            } else if (state === SUBMITTED) {
                // A spread order has been submitted - bind the instrument active order change handler
                instrument.on('change:activeOrder', this.handleActiveOrderChange, this);
            }
        },

        clean : function () {
            const {instrument, structure} = this.attributes;

            if (instrument) {
                instrument.off('change:state', this.handleSessionStateChange, this);
                instrument.off('change:newPrice', this.handleSessionReprice, this);
                instrument.off('change:activeOrder', this.handleActiveOrderChange, this);
            }

            if (structure) {
                structure.off('change', this.handleStructureChange, this);
            }

            this.clear({
                silent : true
            });
        },

        isHeldByLimit : function() {
            let midPrice, limitPrice, isHigherBidBetter, isLowerOfferBetter;
            const {instrument, structure, side, limit, limitB} = this.attributes;
            const spread =  structure || instrument.get('spread');

            if ((spread && !limit.text && !limitB.text)
                || (instrument && !limit.text)) {
                return false;
            }

            // Ensure the underlying structure is sorted (higher vega first)
            if (structure) {
                structure.sortUnderlyings();
            }

            if (spread) {
                const isHigherVegaFirst = instrument ? this.get('isHigherVegaFirst') : spread.wasHigherVegaFirst();

                isHigherBidBetter = true;
                isLowerOfferBetter = true;

                midPrice = spread.calcSpreadPrice();

                if (isHigherVegaFirst) {
                    limitPrice = spread.calcSpreadPrice(limit.numeric, limitB.numeric)
                } else {
                    limitPrice = spread.calcSpreadPrice(limitB.numeric, limit.numeric)
                }
            } else if (instrument) {
                isHigherBidBetter = instrument.get('isHigherBidBetter');
                isLowerOfferBetter = instrument.get('isLowerOfferBetter');

                midPrice = instrument.get('midPrice');
                limitPrice = limit.numeric;
            } else {
                return true;
            }

            if (side === 'buy' && isHigherBidBetter || side === 'sell' && !isLowerOfferBetter) {
                return utils.compareFPNumGT(midPrice, limitPrice);
            }

            return utils.compareFPNumLT(midPrice, limitPrice);
        },

        handleSessionStateChange : function (instrument, newState) {
            if (newState === 'active') {
                this._handleSessionStart()
            } else if (newState === 'inactive') {
                this._handleSessionEnd()
            }
        },

        handleStructureChange : function () {
            const {structure} = this.attributes;

            if (structure.areUnderlyingsInAuction()) {
                structure.off('change', this.handleStructureChange, this);

                logger.logInformation('PortfolioItem::handleStructureChange', `[${this.getDescription()}] All underlying instruments are now in auction`, true);

                this._handleSessionStart(false);
            }
        },

        handleActiveOrderChange : function (instrument, activeOrder) {
            const {LOADED, ACTIVE} = context.PortfolioStates;
            const {totalSize, side, state, limit} = this.attributes;
            const {newPrice} = instrument.attributes;

            // Update the filled size
            if (activeOrder) {
                this._updateSessionFill(activeOrder);

                this.set('state', ACTIVE);
            }

            if (newPrice && limit.text && !activeOrder && state === ACTIVE) {
                // If the order has been cancelled (by the TS) due to a re-price, re-submit any outstanding size
                logger.logInformation('PortfolioItem::handleActiveOrderChange', `[${this.getDescription()}] Instrument has been re-priced - clearing outstanding size`, true);

                instrument.off('change:activeOrder', this.handleActiveOrderChange, this);

                this.set({
                    totalSize   : 0,
                    sessionFill : 0
                });

                this._handleSessionStart(true);
            } else if (!activeOrder || !activeOrder.hasUnfilledSize(side)
                || utils.compareFPNumEQ(this.get('totalFill'), totalSize)) {
                // If an order has been cancelled or it has been fully filled, clear the total size and revert to a 'loaded' state
                logger.logInformation('PortfolioItem::handleActiveOrderChange', `[${this.getDescription()}] Order has been cancelled or it has been fully filled`, true);

                let nextState = state;

                if (state === ACTIVE) {
                    nextState = LOADED;
                }

                this.set({
                    state : nextState,
                    totalSize : 0
                });

                instrument.off('change:activeOrder', this.handleActiveOrderChange, this);
            }
        },

        handleSessionReprice : function (instrument, newPrice) {
            const {ACTIVE, HELD} = context.PortfolioStates;
            const {state, limit} = this.attributes;

            if (newPrice && limit.text && (state === ACTIVE || state === HELD) && !instrument.hasActiveOrder()) {
                logger.logInformation('PortfolioItem::handleSessionReprice', `[${this.getDescription()}] Session has been repriced - handling limit order`, true);

                this._handleSessionStart(true);
            }
        },

        handleLockPriceChange : function () {
            const {state} = this.attributes;
            const {LOADED, PENDING, SUBMITTED, ACTIVE, HELD, CANCELLED} = context.PortfolioStates;

            if ([LOADED, PENDING, SUBMITTED, ACTIVE, HELD].includes(state)) {
                // First pull any live orders
                if (this.hasLiveOrder()) {
                    this.cancelOrder();
                }

                // Mark order as Cancelled
                logger.logInformation('PortfolioItem::handleLockPriceChange', `[${this.getDescription()}] Lock price has changed - setting state to 'Cancelled'`, true);

                this.set('state', CANCELLED);
            }
        },

        _handleSessionStart : function(isReprice) {
            const {PENDING, HELD} = context.PortfolioStates;
            const {state, limit, limitB} = this.attributes;

            // Submit the pending order if the new session price is within the limit
            if (state === PENDING || isReprice) {
                if (this.isHeldByLimit()) {
                    logger.logInformation('PortfolioItem::_handleSessionStart', `[${this.getDescription()}] Order 'Held' by limit: [${limit.text}, ${limitB.text}]`, true);

                    this.set('state', HELD);
                } else {
                    logger.logInformation('PortfolioItem::_handleSessionStart', `[${this.getDescription()}] Session has started - submitting 'Pending' order`, true);

                    this.submit();
                }
            }
        },

        _handleSessionEnd : function() {
            const {PENDING, CANCELLED} = context.PortfolioStates;
            const {collection} = this;

            // If this is a single-shot submission, remove from portfolio
            if (collection && collection.isSingleShot) {
                logger.logInformation('PortfolioItem::_handleSessionEnd', `[${this.getDescription()}] Removing 'single-shot' order`, true);

                collection.remove(this);

                this.clean();
            } else {
                // Otherwise mark state as 'pending' next session
                const nextState = (this.get('state') === CANCELLED ? CANCELLED : PENDING);

                this.set({
                    state       : nextState,
                    sessionFill : 0
                });

                logger.logInformation('PortfolioItem::_handleSessionEnd', `[${this.getDescription()}] GT Timer is active - Item state set to '${nextState}'`, true);
            }
        },

        _setInstrument : function(instrument, lock, validate) {
            // Bind instrument state change handlers
            instrument.on('change:state', this.handleSessionStateChange, this);
            instrument.on('change:newPrice', this.handleSessionReprice, this);

            // If the instrument has a lock, bind lock price change handler
            if (lock) {
                lock.once('change:midPrice', this.handleLockPriceChange, this);
            }

            // Validate attributes against instrument
            if (validate) {
                this._validateItem(instrument);
            } else {
                this.set('instrument', instrument);
            }
        },

        _setStructure : function (legs) {
            const {LOADED} = context.PortfolioStates;

            // Create a structure from the underlying instrument legs
            const structure = new context.modelDefinitions.Spread({
                instruments : legs,
                displayUnderlyingPrices : true,
                shouldNotSort : false
            });

            // Valid the spread structure
            this._validateItem(null, structure);

            // If the spread has loaded, bind change handler
            if (this.get('state') === LOADED) {
                structure.on('change', this.handleStructureChange, this);
            }
        },

        _validateItem : function (outright, structure) {
            const {size, side} = this.attributes;
            const {LOADED, INVALID} = context.PortfolioStates;

            let state = INVALID, status = '';

            if (!side) {
                status = 'Invalid Side';
            } else if (!size) {
                status = 'Invalid Order Size';
            } else {
                const {limit, limitB} = this.attributes;
                const spread = structure || outright.get('spread');
                const hasLimitA = limit.text !== '' && limit.text !== '-';
                const hasLimitB = spread && limitB.text !== '' && limitB.text !== '-';

                if (hasLimitA) {
                    const instrument = outright || spread.getInstrument(0);
                    const validatedPrice = instrument.validatePrice(limit.text, false, true);

                    limit.numeric = validatedPrice.valid ? validatedPrice.numericValue : NaN;
                }

                if (hasLimitB) {
                    const instrument = spread.getInstrument(1);
                    const validatedPrice = instrument.validatePrice(limitB.text, false, true);

                    limitB.numeric = validatedPrice.valid ? validatedPrice.numericValue : NaN;
                }

                if ((hasLimitA && !limit.numeric) || (hasLimitB && !limitB.numeric)
                    || (spread && !hasLimitB && limitB.text !== '-' && limitB.text !== '')) {
                    status = 'Invalid Limit Price';
                } else {
                    state = LOADED;
                }
            }

            this.set({
                state,
                status,
                structure,
                instrument : outright
            });

            return state === LOADED;
        },

        _updateSessionFill : function (activeOrder) {
            const {side, totalFill, totalSize, sessionFill : currentFill} = this.attributes;
            const {buy, sell} = activeOrder.attributes;
            let newFill = 0;

            if (side === 'buy' && buy) {
                newFill = buy.get('boughtSize');
            } else if (side === 'sell' && sell) {
                newFill = sell.get('soldSize');
            }

            if (utils.compareFPNumGT(newFill, currentFill)) {
                this.set({
                    sessionFill : newFill,
                    totalFill   : Math.min(totalSize, totalFill + newFill - currentFill)
                });
            }
        },

        _calcOutstandingSize : function () {
            const {structure, size, totalFill, sessionFill} = this.attributes;
            const instrument = this.attributes.instrument || structure.getInstrument(0);
            const sizeIncrement = instrument.get('sizeIncrement');

            // Validate against the minimum size or the size increment if already filled
            const minSize = sessionFill ? sizeIncrement : instrument.get('minSize');

            if (size && utils.compareFPNumLT(size - totalFill, minSize)) {
                return NaN;
            }

            return Math.floor((size - totalFill + sessionFill) / sizeIncrement) * sizeIncrement;
        },

        hasLiveOrder : function () {
            const {attributes} = this;
            const {instrument, side} = attributes;

            if (side === 'buy') {
                return instrument && instrument.hasLiveBuyOrder();
            } else if (side === 'sell') {
                return instrument && instrument.hasLiveSellOrder();
            }

            return false;
        },

        submit : function () {
            const {attributes} = this;
            const {instrument, structure} = attributes;
            const {REJECTED} = context.PortfolioStates;

            // Calculate the outstanding total size for the current session
            const sessionTotal = this._calcOutstandingSize();

            if (sessionTotal) {
                if (instrument) {
                    // Submit order directly on the instrument
                    this._submitOrder(sessionTotal);
                } else if (structure) {
                    // Submit order indirectly by first creating the spread from the structure
                    this._submitSpread(sessionTotal);
                }
            } else {
                // Outstanding size is below the minimum
                this.set({
                    state  : REJECTED,
                    status : 'Size below minimum'
                });

                logger.logInformation('PortfolioItem::submit', `[${this.getDescription()}] Order Rejected - outstanding size below minimum`, true);
            }
        },

        _submitOrder : function(sessionTotal) {
            const {instrument, totalFill, side, sessionFill} = this.attributes;
            const {SUBMITTED} = context.PortfolioStates;

            instrument.sendOrder({
                side,
                size : sessionTotal
            }, 'Portfolio View');

            instrument.on('change:activeOrder', this.handleActiveOrderChange, this);

            this.set({
                totalSize : sessionTotal + totalFill - sessionFill,
                state : SUBMITTED
            });
        },

        _submitSpread(sessionTotal) {
            const {side, structure, totalFill} = this.attributes;
            const {REJECTED, SUBMITTED} = context.PortfolioStates;

            // First validate the underlying instruments in the structure
            if (structure.validateUnderlyings(false)) {
                // Calculate the vega weighting
                structure.set('weighting', structure.calcNormalVegaWeighting());

                // Create and submit the spread order
                structure.setOrder(0, side, sessionTotal);
                structure.createSpread(true, true);

                this.set({
                    totalSize : sessionTotal + totalFill,
                    state : SUBMITTED
                });
            } else {
                this.set({
                    state  : REJECTED,
                    status : 'Invalid structure - no vega(s)'
                });

                logger.logWarning('PortfolioItem::_submitSpread', `[${this.getDescription()}] Rejecting order - no vega(s)`);
            }
        },

        remove : function() {
            if (this.hasLiveOrder()) {
                logger.logInformation('PortfolioItem::remove', `[${this.getDescription()}] Item has been removed - cancelling live order`, true);

                this.cancelOrder();
            }

            this.collection.remove(this);

            this.clean();
        },

        cancelOrder : function () {
            const {attributes} = this;
            const {instrument, side} = attributes;

            instrument.sendCancelOrder('Portfolio View', side);
        },

        getDescription: function () {
            const {instrument, structure} = this.attributes;

            if (instrument) {
                return instrument.get('name');
            } else if (structure) {
                return structure.buildSpreadDisplayName();
            }

            return 'Unknown Instrument';
        }
    });

}(window.BGC.dataStore, window.BGC.utils, window.BGC.logger));