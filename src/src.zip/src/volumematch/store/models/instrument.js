/* eslint-disable max-lines,max-params,max-len,func-names,no-underscore-dangle,max-statements,complexity,no-param-reassign,
   no-prototype-builtins,no-magic-numbers */
/* global BGC: false, _:false, Backbone: false*/

import getApp from '../../index';

// eslint-disable-next-line no-shadow-restricted-names
(function (context, utils, priceTypes, validators, undefined) {
  // Selection of active orders happens for many instruments when Sales Trader changes selected account
  // This causes excessive logging in debug mode which floods the console log and needs to be suppressed
  const {dataStore} = context;
  const _activeOrderTrace = function (message) {
    if (!dataStore.isSalesTraderMode()) {
      BGC.utils.trace(message);
    }
  };

  /**
   * Function used to set the instrument attributes based on the
   * instrument message attributes received from the server.
   */
  function setAttributesFromMessage (instrument, message) {
    // eslint-disable-next-line no-use-before-define
    instrument.set(map(instrument, _.omit(message, 'messageName')));

    return instrument;
  }

  function hasLiveOrder (instrument, side) {
    const ownOrder = instrument.getActiveOrder();
    const activeOrder = ownOrder ? ownOrder.serialize() : undefined;
    const isBuy = side === 'buy';

    if (isBuy) {
      return activeOrder && activeOrder.hasBuySize && activeOrder.buyOrder.isLiveBuy;
    }

    return activeOrder && activeOrder.hasSellSize && activeOrder.sellOrder.isLiveSell;
  }

  function getOrderSize (instrument, side) {
    const ownOrder = instrument.getActiveOrder();
    const activeOrder = ownOrder ? ownOrder.serialize() : undefined;
    const isBuy = side === 'buy';

    if (isBuy && activeOrder && activeOrder.hasBuySize) {
      return activeOrder.buySize;
    }

    if (!isBuy && activeOrder && activeOrder.hasSellSize) {
      return activeOrder.sellSize;
    }

    return '';
  }

  /**
   * Function used to map a series of attributes from a message
   * received from the server (websocket instrument message) to
   * the backbone model attributes.
   */
  function map (instrument, message) {
    const {id : appId} = getApp();
    const auction = message.auctions ? message.auctions[0] : null;
    const propMap = {
      instrumentName           : 'name',
      instrumentShortName      : 'shortName',
      instrumentClassification : 'classification',
      isInAuction              : 'inactive',
      sortOrdinal              : 'index'
    };
    const isActivating = message.isInAuction || (auction && auction.isMidPriceIndicative);
    let accumulator = {};

    accumulator = _.reduce(Object.keys(message), (acc, key) => {
      // eslint-disable-next-line no-prototype-builtins
      if (propMap.hasOwnProperty(key)) {
        if (key === 'isInAuction') {
          acc[propMap[key]] = !message[key];
        } else {
          acc[propMap[key]] = message[key];
        }
      } else if (key === 'auctions' && !!message[key]) {
        // eslint-disable-next-line no-shadow
        Object.keys(auction).forEach(key => {
          switch (key) {
            case 'minOrderSize':
              acc.minSize = auction[key];
              break;
            case 'midPriceDirection':
              acc.priceDirection = auction[key];
              break;
            case 'strike1Display':
            case 'strike2Display':
              // Remove percentage formatting if this is an 'Exotics' instrument
              // N.B. GTI should publish price type for generic attributes in the long term
              if (appId === 'LM_DOCUMENT_VM_IRO_EUR_EXOTICS' && auction[key].endsWith('%')) {
                acc[key] = auction[key].slice(0, -1);
              } else {
                acc[key] = auction[key];
              }
              break;
            default:
              acc[key] = auction[key];
          }
        });
      } else if (key === 'spread') {
        acc[key] = new context.dataStore.modelDefinitions.Spread({
          instrument,
          weighting               : message.spread.weighting,
          isSpreadWeightingCustom : message.spread.isSpreadWeightingCustom,
          displayUnderlyingPrices : message.spread.displayUnderlyingPrices,
          instruments             : message.spread.underLyingIds.map(instrumentId => context.dataStore.getInstrumentById(instrumentId))
        });

        instrument.listenTo(acc[key], 'change', instrument.onSpreadChanged);
      } else {
        acc[key] = message[key];
      }

      return acc;
    }, accumulator);

    if (message.hasOwnProperty('isInAuction')) {
      accumulator.myTradePrice = {
        buy  : {},
        sell : {}
      };
    }

    if (context.dataStore.pageLayout) {
      if (auction && auction.auctionId && message.isInAuction) {
        accumulator.state = 'active';
        accumulator.prevAuction = instrument.get('auction') || context.dataStore.pageLayout.getOrAddAuction('dormant');
        accumulator.auction = context.dataStore.pageLayout.getOrAddAuction(auction.auctionId);
        accumulator.auction.set('orderPhaseText', auction.hasOwnProperty('orderPhaseText') ? auction.orderPhaseText : '');
      } else if (auction && auction.hasOwnProperty('isMidPriceIndicative')) {
        if (auction.isMidPriceIndicative) {
          accumulator.state = 'indicative';
          accumulator.prevAuction = instrument.get('auction') || context.dataStore.pageLayout.getOrAddAuction('dormant');
          accumulator.auction = context.dataStore.pageLayout.getOrAddAuction('indicative');
        } else {
          accumulator.state = 'inactive';
          accumulator.prevAuction = instrument.get('auction') || context.dataStore.pageLayout.getOrAddAuction('dormant');
          accumulator.auction = context.dataStore.pageLayout.getOrAddAuction('dormant');
        }
      } else if (message.hasOwnProperty('isInAuction') && !message.isInAuction) {
        accumulator.state = 'inactive';
        accumulator.prevAuction = instrument.get('auction') || context.dataStore.pageLayout.getOrAddAuction('dormant');
        accumulator.auction = context.dataStore.pageLayout.getOrAddAuction('dormant');
        accumulator.auction.set('orderPhaseText', '');
      }
    }

    accumulator.isInit = false;
    accumulator.newPrice = false;
    accumulator.isSubscribed = true;
    accumulator.lastActiveTime = isActivating ? Date.now() : instrument.get('lastActiveTime');

    return accumulator;
  }

  /**
   * Instrument model:
   * =========================================================================================================
   *   Attributes:
   *   - isSubscribed                 : Boolean   : has any data been received for this instrument yet?
   *   - instrumentId                 : String
   *   - productKey                   : Object    : has notionalCurrencyCode and bgcTaxonomy
   *   - productAttributes            : Object    : has swapTenor and optionTenor
   *   - midPrice                     : Number
   *   - priceDisplay                 : String
   *   - priceIncrement               : Number
   *   - priceDirection               : Enum      : "better" if mid moves up, "worse" if it moves down, else "unchanged". Only populated if indicators activated by broker.
   *   - allowsNegativeOrZeroPrice    : Boolean
   *   - isHigherBidBetter            : Boolean
   *   - isLowerOfferBetter           : Boolean
   *   - minBidPrice                  : Number
   *   - maxBidPrice                  : Number
   *   - minOfferPrice                : Number
   *   - maxOfferPrice                : Number
   *   - rawPrice                     : Number
   *   - strike1Display               : String
   *   - strike2Display               : String
   *   - deltaDisplay                 : String
   *   - straddleDisplay              : String
   *   - ratioDisplay                 : String
   *   - crossDisplay                 : String
   *   - minSize                      : Number
   *   - baseSize                     : Number
   *   - classification               : Number
   *   - vega                         : Number    : broker specified vega
   *   - thirdPartyInterest           : Enum      : 3rd party interest type
   *   - hasSameLeBuyInterest         : Boolean   : whether auction has same le interest on the buy side
   *   - hasSameLeSellInterest        : Boolean   : whether auction has same le interest on the sell side
   *   - hasTradedAtMidPrice          : Boolean   : whether or not the instrument has traded within the auction at current mid price
   *   - hasTradedInAuction           : Boolean   : whether or not the instrument has traded within the auction
   *   - isShowGlowAlwaysEnabled      : Boolean   : An override that causes glows to show reghardless of thew auction preferences
   *   - inactive                     : Boolean   : True if the instrument is *not* in VM state
   *   - auctionId                    : String    : Identifies the auction object that the instrument is associated with
   *  - tileId                        : String    : identifies the instrument tile, empty for matrix instrument
   *   - tileIndex                    : Number    : index of the tile within the tiles collection
   *   - auction                      : Model     : The auction model that the instrument is associated with
   *   - prevAuction                  : Model     : The previous auction model that the instrument was associated with
   *   - canUserEnterOrders           : Boolean   : true: order can be entered, false: order enter funtionality is disabled
   *   - own                          : Object OR ActiveOrder model : (optional) the trader's own order(s),
   *                                    or, for Sales Traders, an object keyed by accountId where each value is that account's active order(s)
   *   - index                        : Number    : sort order on tile
   *   - isExcelLiveModeEnabled       : Boolean   : specifies whether Excel Live Mode is enabled
   *   - nomenclature                 : Enum      : an enumerated value used to determine bought/sold/paid/given text
   *   - spread                       : Spread    : (optional) defines instrument spread information
   *   - underlyings                  : Array     : instrument models for underlying instruments of a compound instrument
   *   - orderSubmitTime              : Number    : used to calculate the elapsed time on order submission (for outrights)
   *   - isQoSOpAnOrder               : Boolean   : true for a submit order and false for a cancel order (for outrights)
   *   - priceType                    : String    : price type
   *   - minDecimalPlaces             : Number    : min number of decimal places for a decimal dvar instrument
   *   - maxQuantity                  : Object    : attributes used to determine if the max size has been met.
   *   - state                        : String    : instrument state - 'inactive', 'indicative' or 'active'
   *  - isPickGivePriced              : Boolean   : is it a pick/give spread
   *  - buyLegRatio                   : Number    : 0.0 if none. 1.0 if Buy of spread buys D1/sells D2. -1.0 if Buy of spread buys D2/sells D1.
   *  - isPricingAwayFromMidAllowed   : Boolean   : Specifies whether the aution is fixed price or not.
   */

  context.dataStore.modelDefinitions.Instrument = Backbone.Model.extend({
    defaults : {
      isSubscribed                 : false,
      name                         : '',
      instrumentId                 : '',
      productKey                   : null,
      productAttributes            : null,
      priceDisplay                 : '',
      midPrice                     : 0,
      minBidPrice                  : 0,
      maxBidPrice                  : 0,
      minOfferPrice                : 0,
      maxOfferPrice                : 0,
      priceIncrement               : 1,
      priceDirection               : 'unchanged',
      allowsNegativeOrZeroPrice    : false,
      isHigherBidBetter            : true,
      isLowerOfferBetter           : true,
      strike1Display               : '',
      strike2Display               : '',
      deltaDisplay                 : '',
      straddleDisplay              : '',
      ratioDisplay                 : '',
      crossDisplay                 : '',
      volume                       : '',
      minSize                      : 0,
      baseSize                     : 0,
      classification               : -1,
      vega                         : 0,
      thirdPartyInterest           : 'none',
      haSameLeBuyInterest          : false,
      haSameLeSellInterest         : false,
      hasTradedAtMidPrice          : false,
      hasTradedInAuction           : false,
      isShowGlowAlwaysEnabled      : false,
      sizeIncrement                : 1,
      inactive                     : true,
      auctionId                    : '',
      auction                      : undefined,
      isMidPriceIndicative         : false,
      tileIndex                    : -1,
      tileId                       : '',
      tile                         : null,
      matrix                       : null,
      canUserEnterOrders           : true,
      supportTradeConfirmRequest   : false,
      index                        : 0,
      isExcelLiveModeEnabled       : false,
      spread                       : undefined,
      nomenclature                 : 'bidOffer',
      priceType                    : priceTypes.ETypes.ePriceTypeDecimal,
      minDecimalPlaces             : 0,
      isLockInstrument             : false,
      isPickGivePriced             : false,
      allowTopSpeedSizeIncrement   : false,
      topSpeedSizeIncrement        : 0.0,
      buyLegRatio                  : 0.0,
      state                        : 'inactive',
      isInit                       : true,
      newPrice                     : false,
      lastAuctionMidPriceDirection : 'none',
      priceBDisplay                : '',
      isPricingAwayFromMidAllowed  : false,
      isImmediateTradeConfirm      : false
    },

    idAttribute : 'instrumentId',

    initialize () {
      dataStore.storeInstrumentsForIdLookup(this);

      this.on('change:priceIncrement', this.updatePriceDecimalPrecision, this);
      this.updatePriceDecimalPrecision();

      this.on('change:sizeIncrement', this.updateSizeDecimalPrecision, this);
      this.updateSizeDecimalPrecision();

      dataStore.on('accountSelectionChanged', this._setActiveOrder, this);

      // Track my last traded price per account, to assist with active order selection
      this.myTradePrice = {buy : {}, sell : {}};

      //  - orderSubmitTime : used to calculate the elapsed time on order submission (for outrights)
      //  - isQoSOpAnOrder  : true for a submit order and false for a cancel order (for outrights)
      this.orderSubmitTime = 0;
      this.isQoSOpAnOrder = true;

      // maximum quantity attributes which shouldn't trigger any change in the view so use a POJO to avoid this.
      this.maxQuantity = {overlimitSize : 0, buySizeLimitReached : false, sellSizeLimitReached : false};

      this.isSerializedObjectDirty = true;

      // Event listeners are pushed into an array by Backbone. Ensure this is the first one to fire.
      this.listenTo(this, 'change', function () {
        this.isSerializedObjectDirty = true;
      });
    },

    /** Overidden set function allows us to set serializedObjectDirty before any change events fire */
    set (key, val, options) {
      this.isSerializedObjectDirty = true;

      Backbone.Model.prototype.set.call(this, key, val, options);
    },

    getLogDescStr (omitIndex) {
      let logText = `${this.get('instrumentId')}|${this.get('name')}`;
      let underlyings = [];

      if (!omitIndex) {
        logText += `|${this.get('index')}`;
      }
      if (this.get('spread') && this.get('spread').get('underlyings').length > 0) {
        underlyings = this.get('spread').get('underlyings');

        logText += ' which has underlying instruments ';

        underlyings.forEach(underlying => {
          logText += ` [${underlying.instrument.getLogDescStr(true)}]`;
        });
      }

      return logText;
    },

    /** Get the view model (a Plain Old Javascript Object) for the instrument model */
    serialize () {
      // this.getActiveOrder will return my active order(s) in context of selected account (if accounts are in use)
      // So it may return nothing if the selected account has no orders associated with it
      const ownOrder = this.getActiveOrder();
      const spread = this.get('spread');

      // instrument attributes - only get them all if something has changed since last time
      if (this.isSerializedObjectDirty) {
        this.serializedObject = this.toJSON();

        this.serializedObject.isMoveableBidEnabled = this.isMoveableBidEnabled();
        this.serializedObject.isMoveableOfferEnabled = this.isMoveableOfferEnabled();
        this.serializedObject.pickGiveSymbol = {
          buy  : this.getPickGiveIndicator('buy'),
          sell : this.getPickGiveIndicator('sell')
        };
        this.serializedObject.isSignFlippedForPickGive = {
          buy  : this.isSignFlippedForPickGive('buy'),
          sell : this.isSignFlippedForPickGive('sell')
        };

        // Set up attributes for trading terminology
        this.serializedObject.tradingTerminology = {
          buySize             : this.getAdjustedNomenclature('IDS_BUY_SIZE'),
          buySizePlaceholder  : this.getAdjustedNomenclature('IDS_BUY_SIZE_PLACEHOLDER'),
          buy                 : this.getAdjustedNomenclature('IDS_BUY'),
          bought              : this.getAdjustedNomenclature('IDS_BOUGHT'),
          sellSize            : this.getAdjustedNomenclature('IDS_SELL_SIZE'),
          sellSizePlaceholder : this.getAdjustedNomenclature('IDS_SELL_SIZE_PLACEHOLDER'),
          sell                : this.getAdjustedNomenclature('IDS_SELL'),
          sold                : this.getAdjustedNomenclature('IDS_SOLD')
        };

        this.isSerializedObjectDirty = false;
      } else if (spread) {
        // Have to reset name and shortName as they have the spread price appended to them
        this.serializedObject.name = this.get('name');
        this.serializedObject.shortName = this.get('shortName');
      }

      if (ownOrder) {
        this.serializedObject.ownOrder = ownOrder.serialize();
      } else {
        this.serializedObject.ownOrder = undefined;
      }

      if (spread) {
        this.serializedObject.spread = spread.serialize();
      } else {
        this.serializedObject.strikeString = this.buildStrikeString();
      }

      this.serializedObject.showThirdPartyInterestGlows = this.get('auction').get('showThirdPartyInterestGlows') || this.serializedObject.isShowGlowAlwaysEnabled;
      this.serializedObject.showTradeIndicators = this.get('auction').get('showTradeIndicators');
      this.serializedObject.quickSizes = {buy : this.getQuickSizes('buy'), sell : this.getQuickSizes('sell')};

      // GTI required attributes for order processing
      this.serializedObject.sizeMultiplier = this.get('sizeMultiplier');
      this.serializedObject.sourceSystem = this.get('sourceSystem');
      this.serializedObject.symbolType = this.get('symbolType');
      this.serializedObject.venueType = this.get('venueType');
      this.serializedObject.regulatoryRegime = this.get('regulatoryRegime');

      return this.serializedObject;
    },

    clearActiveState (message) {
      const auction = message.auctions ? message.auctions[0] : null;
      const isIndicative = auction && auction.isMidPriceIndicative;
      let midPrice = this.get('midPrice');
      let priceDisplay = this.get('priceDisplay');
      const priceIncrement = this.get('priceIncrement');

      const mappedInstrument = _.omit(map(this, message), 'auctionId');

      // Clear out any order references or glow flags within the instrument
      // Ignore most other changes in state (so we preserve state at auction end)
      // unless Indicative Mids in play, in which case we must obviously update the price

      if (isIndicative) {
        if (auction.midPrice !== undefined) {
          midPrice = auction.midPrice;
        }
        if (auction.priceDisplay !== undefined) {
          priceDisplay = auction.priceDisplay;
        }
      }

      this.set(_.extend(mappedInstrument, {
        inactive                  : true,
        priceDirection            : 'unchanged',
        isMidPriceIndicative      : isIndicative,
        showInterestAndTradeCount : false,
        hasSameLeBuyInterest      : false,
        hasSameLeSellInterest     : false,
        thirdPartyInterest        : 'none',
        hasTradedAtMidPrice       : false,
        hasTradedInAuction        : false,
        isSubscribed              : true,
        midPrice,
        priceDisplay,
        priceIncrement,
        // eslint-disable-next-line no-nested-ternary
        auction                   : context.dataStore.pageLayout ? isIndicative ? context.dataStore.pageLayout.getOrAddAuction('indicative') : context.dataStore.pageLayout.getOrAddAuction('dormant') : null,
        state                     : isIndicative ? 'indicative' : 'inactive'
      }));

      this._clearActiveOrder();

      // maximum quantity attributes which shouldn't trigger any change in the view so use a POJO to avoid this.
      this.maxQuantity = {overlimitSize : 0, buySizeLimitReached : false, sellSizeLimitReached : false};
    },

    /**
       * Function used to update an existing instrument based on an
       * instrument (delta) message received from the server.
       */
    update (message, msgState) {
      const auction = message.auctions ? message.auctions[0] : null;
      // eslint-disable-next-line consistent-this
      const self = this;

      if (msgState.isEnteringVM || (this.isInAuction() && !msgState.isLeavingVM) ||
          msgState.isEnteringIndicative || (this.get('isMidPriceIndicative') && !msgState.isLeavingIndicative) ||
          this.get('isLockInstrument') || msgState.isLockInstrument) {
        // Update the instrument with the message delta
        this.set(map(this, _.omit(message, ['messageName', 'state'])));

        const {spread} = this.attributes;

        // Update spread weighting
        if (message.hasOwnProperty('spreadWeighting') && spread) {
          spread.set('weighting', message.spreadWeighting);
        } else if (spread) {
          spread.sortUnderlyings();
        }

        if (auction && auction.hasOwnProperty('baseSize')) {
          this._evaluateSizeLimitBreaches(true);
        }
      } else {
        this.clearActiveState(message);
      }

      // If the instrument has been re-priced whilst an auction is running
      if (auction && auction.hasOwnProperty('midPrice') &&
          !msgState.isEnteringVM && this.isInAuction()) {
        // Flash the new price
        this.set('newPrice', true);

        setTimeout(() => {
          self.set({
            newPrice                : false,
            isOrderPriceNewlyNudged : false
          });
        }, dataStore.userSettingsStore.get('newPriceFlashDuration'));

        // Mid-price movement. Potentially means we need to select new active order(s)
        this._setActiveOrder();
      }
    },

    // A custom spread is a spread instrument which is only valid for the duration of the auction, one which a trader creates dynamically
    // from the underlying outrights (in the grid). Currently this feature is only available to the IRO business and there is no way to
    // determine from the (GTI) instrument whether the spread is 'custom' or not. For this reason we use the displayUnderlyingPrices
    // attribute to categorize a custom spread, as this option is only used by the IRO grids.
    isCustomSpread () {
      const {spread} = this.attributes;

      return spread && spread.get('displayUnderlyingPrices');
    },

    hasLiveBuyOrder () {
      return hasLiveOrder(this, 'buy');
    },

    hasLiveSellOrder () {
      return hasLiveOrder(this, 'sell');
    },

    getBuySize () {
      return getOrderSize(this, 'buy');
    },

    getSellSize () {
      return getOrderSize(this, 'sell');
    },

    hasActiveOrder () {
      const hasLiveBuyOrder = this.hasLiveBuyOrder();
      const hasLiveSellOrder = this.hasLiveSellOrder();

      return hasLiveBuyOrder || hasLiveSellOrder;
    },

    getStandardSizes () {
      const {defaultSizes = [], minSize, minOrderSize = 0} = this.attributes;
      const {pageLayout} = context.dataStore;
      const sizeMultipliers = pageLayout ? pageLayout.get('sizeMultipliers') : [1, 2, 4, 8];

      // Return the standard order size with the default sizes value from CM with the sizeMultipliers length provide by the layout
      return defaultSizes.length > 0 ? defaultSizes.slice(0, sizeMultipliers.length) : sizeMultipliers.map(multiplier => multiplier * (minSize || minOrderSize));
    },

    getQuickSizes (side, priceLevel) {
      const totalMode = context.dataStore.userSettingsStore.get('upsizingMode');
      let totalTradedSize = this._getTotalTradedSize(priceLevel, side);
      const standardSizes = this.getStandardSizes();
      let distanceToNextSizeMultiple = 0;
      let quickSizes = [];
      let pickGivePrefix = '';

      if (priceLevel === undefined) {
        priceLevel = this.get('midPrice');

        // The sign of the mid price combined with the side of the order will tell us
        // whether the order price should regarded as Give Up (-ive) or Pick Up (+ive)
        pickGivePrefix = this.getPickGiveIndicator(side);

        if (pickGivePrefix === '+') {
          // Ensure price is positive
          priceLevel = Math.abs(priceLevel);
        } else if (pickGivePrefix === '-') {
          // Ensure price is negative
          priceLevel = -Math.abs(priceLevel);
        }
      }
      if (typeof priceLevel !== 'number') {
        throw new TypeError('instrument.getQuickSizes() called with non-numeric priceLevel parameter');
      }

      // If topspeed increments allowed and we are in total mode,
      // then round up the current total traded size to the nearest auction increment
      // so the quick-size buttons will show numbers ascending from there
      if (totalMode && utils.compareFPNumGT(totalTradedSize, 0.0) &&
          this.get('allowTopSpeedSizeIncrement')) {
        distanceToNextSizeMultiple = standardSizes[0] - (totalTradedSize % standardSizes[0]);
        if (utils.compareFPNumGT(distanceToNextSizeMultiple % standardSizes[0], 0.0)) {
          if (utils.compareFPNumLT(distanceToNextSizeMultiple, this.get('sizeIncrement'))) {
            // If the first quick size value would be less than the size increment away from the traded size
            // then we should generate quick size values starting from the next possible one.
            totalTradedSize += distanceToNextSizeMultiple;
          } else {
            // Drop the traded size down from its real level to the nearest lower multiple of
            // the smallest quick size value
            totalTradedSize = (totalTradedSize + distanceToNextSizeMultiple) - standardSizes[0];
          }
        }
      }

      // Add order totals to standard sizes in total upsizing mode.
      // Otherwise, just return the standard sizes
      quickSizes = _.map(standardSizes, size => {
        if (!totalMode) {
          return size;
        }

        const nextSize = size + totalTradedSize;

        // Eliminate FP addition errors
        const roundedSize = parseFloat(nextSize.toFixed(10));

        return roundedSize;
      }, this);

      return quickSizes;
    },

    getPickGiveIndicator (side) {
      let pickGiveSymbol = '';

      if (this.get('isPickGivePriced')) {
        if (BGC.utils.compareFPNumGT(this.get('buyLegRatio'), 0.0)) {
          // Buy of spread is buy D1/Sell D2. +ive Mid means Bid is Give and Bid Price should be -ive
          if (BGC.utils.compareFPNumGT(this.get('midPrice'), 0.0)) {
            // Bids are GiveUp and must be shown as negative
            if (side === 'buy') {
              pickGiveSymbol = '-';
            }

            // Offers are PickUp and must be shown as +ive
            if (side === 'sell') {
              pickGiveSymbol = '+';
            }
          } else {
            // Bids are PickUp and must be shown as +ive
            if (side === 'buy') {
              pickGiveSymbol = '+';
            }

            // Offers are GiveUp and must be shown as negative
            if (side === 'sell') {
              pickGiveSymbol = '-';
            }
          }
        } else if (BGC.utils.compareFPNumLT(this.get('buyLegRatio'), 0.0)) {
          // Buy of spread is sell D1/buy D2. +ive Mid means Bid is Pick and Bid Price should be +ive
          if (BGC.utils.compareFPNumGT(this.get('midPrice'), 0.0)) {
            // Bids are PickUp and must be shown as +ive
            if (side === 'buy') {
              pickGiveSymbol = '+';
            }

            // Offers are GiveUp and must be shown as negative
            if (side === 'sell') {
              pickGiveSymbol = '-';
            }
          } else {
            // Bids are GiveUp and must be shown as negative
            if (side === 'buy') {
              pickGiveSymbol = '-';
            }

            // Offers are PickUp and must be shown as +ive
            if (side === 'sell') {
              pickGiveSymbol = '+';
            }
          }
        }
      }

      return pickGiveSymbol;
    },

    getSecurityId () {
      // Replicates OMS logic checking for a CUSIP first, ISIN second then finally defaulting to the BGC ID
      const {cusip, isin, instrumentId} = this.attributes;

      return cusip || isin || instrumentId;
    },

    isSignFlippedForPickGive (side) {
      const pickGiveSignSymbol = this.getPickGiveIndicator(side);

      if (pickGiveSignSymbol === '+' && BGC.utils.compareFPNumLT(this.get('midPrice'), 0)) {
        return true;
      }

      if (pickGiveSignSymbol === '-' && BGC.utils.compareFPNumGT(this.get('midPrice'), 0)) {
        return true;
      }

      return false;
    },

    hasOwnOrder () {
      return this.getActiveOrder() !== undefined;
    },

    hasOrderExecuted (side, priceLevel) {
      return this._getFilledSize(side, priceLevel) > 0;
    },

    isInAuction () {
      return !this.get('inactive');
    },

    // Returns properties identifying the matrix or tile layout upon which the instrument resides
    // eslint-disable-next-line consistent-return
    getTileInfo () {
      const tile = this.get('tile');
      const matrix = this.get('matrix');
      const layout = tile || matrix || context.dataStore.pageLayout.findLayout(this.get('tileId'));

      if (layout) {
        return {
          id        : this.get('tileId'),
          name      : layout.getName(),
          layoutPos : layout.get('layoutPos')
        };
      }
      BGC.logger.logWarning('Tile', `Instrument ${this.attributes.name} tileId is empty.`);
    },

    isActive () {
      return this.isInAuction() || this.get('isMidPriceIndicative');
    },

    matchSpread (spread2) {
      let matched = false;
      const spread1 = this.get('spread');

      if (spread1) {
        matched = spread1.getInstrument(0).get('instrumentId') === spread2.getInstrument(0).get('instrumentId') &&
            spread1.getInstrument(1).get('instrumentId') === spread2.getInstrument(1).get('instrumentId');
      }

      return matched;
    },

    matchStructure (structure = []) {
      const matched = false;
      const {spread} = this.attributes;

      if (spread && structure.length === 2 && structure[0] && structure[1]) {
        const {instruments = []} = spread.attributes;
        const legIds = instruments.map(item => item.get('instrumentId'));

        return legIds.includes(structure[0].get('instrumentId')) &&
            legIds.includes(structure[1].get('instrumentId'));
      }

      return matched;
    },

    canEnterSize () {
      return this.isInAuction() && this.get('canUserEnterOrders');
    },

    canRequestTradeConfirms () {
      return this.get('hasTradedInAuction') && this.get('supportTradeConfirmRequest');
    },

    isExcelLiveModeEnabled () {
      return this.get('isExcelLiveModeEnabled') !== false;
    },

    isMoveableMidEnabled () {
      return this.isMoveableBidEnabled() || this.isMoveableOfferEnabled();
    },

    isMoveableBidEnabled () {
      // Bid price controls has to enabled only if numberof price increments are greater than zero and if the price away from mid is allowed.
      if (!this.isInAuction() && !this.get('isPricingAwayFromMidAllowed')) {
        return false;
      }

      const midPrice = this.isSignFlippedForPickGive('buy') ? -this.get('midPrice') : this.get('midPrice');


      return !(BGC.utils.compareFPNumEQ(midPrice, this.get('minBidPrice')) &&
          BGC.utils.compareFPNumEQ(midPrice, this.get('maxBidPrice')));
    },

    isMoveableOfferEnabled () {
      // Bid price controls has to enabled only if numberof price increments are greater than zero and if the price away from mid is allowed.
      if (!this.isInAuction() && !this.get('isPricingAwayFromMidAllowed')) {
        return false;
      }

      const midPrice = this.isSignFlippedForPickGive('sell') ? -this.get('midPrice') : this.get('midPrice');


      return !(BGC.utils.compareFPNumEQ(midPrice, this.get('minOfferPrice')) &&
          BGC.utils.compareFPNumEQ(midPrice, this.get('maxOfferPrice')));
    },

    hasSameLeInterest (side) {
      if (!side) {
        return this.get('hasSameLeBuyInterest') || this.get('hasSameLeSellInterest');
      }

      if (side === 'buy') {
        return this.get('hasSameLeBuyInterest');
      }

      if (side === 'sell') {
        return this.get('hasSameLeSellInterest');
      }

      return false;
    },

    buildStrikeString () {
      let strikeString = _.reduce([this.get('strike1Display'), this.get('strike2Display')], (memo, strike) => (strike.length > 0 ? `${memo + strike} ` : memo), '');

      strikeString = strikeString.trim();

      return strikeString.length === 0 ? '' : `(${strikeString})`;
    },

    sendOrder (order, viewId) {
      const model = this.serialize();

      BGC.logger.logKey('', `${viewId} sending ${order.side} order: ${this.getLogDescStr()} ${order.size}@${order.priceDisplay || model.priceDisplay}${order.accountId ? ` [account = ${order.accountId}]` : ''} [upsizing mode = ${context.dataStore.userSettingsStore.get('upsizingMode') === 0 ? 'incremental]' : 'total]'}`);

      BGC.dataStore.captureOrderOrCancelSubmitTime(this, true);

      BGC.logger.logKey('sendorder', `Instrument [${this.getLogDescStr()}] Order Info: ${order.side} Size: ${order.size} with Current SoftLimit Size : ${this.calcOverlimitSize()}`);

      const orderPrice = order.priceDisplay ? order.price : model.midPrice;

      // These attributes are being set by GTI via SecurityList into the instrument
      // We just retrieve it and pass this on to message adapter to be sent to GTI on order create request
      const {
        sizeMultiplier, sourceSystem, symbolType, venueType, regulatoryRegime
      } = model;

      // Check if order exists - if o send the orderId as its required for GTI
      const matchParams = {instrument : this, orderType : BGC.schemaValidator.OWNERSHIP_MINE, accountId : BGC.dataStore.getActiveAccountId()};
      const matchedOrder = context.dataStore.orderStore.findFirstMatchingOrder(matchParams, orderPrice, order.side);

      // Add non-command params - required by GTI
      const options = {
        sizeMultiplier,
        sourceSystem,
        symbolType,
        venueType,
        regulatoryRegime
      };

      // GTI does not maintain order state - so if its additional quantity send previously bought / sold qty to GTI
      let prevOrderSize = 0;

      if (matchedOrder) {
        prevOrderSize = order.side === 'buy' ? matchedOrder.attributes.boughtSize : matchedOrder.attributes.soldSize;
      }

      // send the order - include orderId and originalOrderId for GTI
      // originalOrderId is the orderId of the initial order - only required for GTI
      BGC.eventsHandler.onClick(viewId, 'postOrder', JSON.stringify({
        instrumentId      : model.instrumentId,
        orderId           : BGC.utils.createUuid().substr(0, 20),
        originalOrderId   : matchedOrder ? matchedOrder.getOrderId(order.side) : null,
        orderPrice,
        orderSide         : order.side === 'buy' ? 1 : 2,
        orderSize         : order.size,
        prevOrderSize,
        orderUpsizingMode : context.dataStore.userSettingsStore.get('upsizingMode'),
        accountId         : order.accountId,
        repostRequest     : false,
        repostOrder       : context.dataStore.modelDefinitions.Order.getRepostAllState()
      }), options);
    },

    sendReprice (price, viewId) {
      BGC.logger.logKey('', utils.format('{0} sending reprice request: {1} [{2}]', [viewId, this.getLogDescStr(), price]));

      // send the request
      BGC.eventsHandler.onClick(viewId, 'vmRepriceRequest', JSON.stringify({
        instrumentId : this.get('instrumentId'),
        price
      }));
    },

    onSpreadChanged () {
      // Something about the underylings changed,
      // so effectively this spread instrument has changed and views may need to update.
      this.trigger('change');
    },

    onMyVMOrderUpdate (incomingOrder, isCreatedFromExecution) {
      if (incomingOrder.get('orderType') === BGC.schemaValidator.OWNERSHIP_MINE) {
        const tradePriceLoookupKey = incomingOrder.get('accountId') || 'default';

        BGC.utils.trace(`Instrument is processing update to my order at price ${incomingOrder.get('price')}`);

        if (isCreatedFromExecution) {
          BGC.utils.trace('The update was for a new order created with bought/sold data already in it');

          // Note the execution price level before establishing what the current active order should be
          if (incomingOrder.hasFilledSize('buy')) {
            BGC.utils.trace(`The bought size is ${incomingOrder.getFilledSize('buy')} and myTradePrice.buy[${tradePriceLoookupKey}] is now ${incomingOrder.get('price')}`);
            this.myTradePrice.buy[tradePriceLoookupKey] = incomingOrder.get('price');
          } else if (incomingOrder.hasFilledSize('sell')) {
            BGC.utils.trace(`The sold size is ${incomingOrder.getFilledSize('sell')} and myTradePrice.sell[${tradePriceLoookupKey}] is now ${incomingOrder.get('price')}`);
            this.myTradePrice.sell[tradePriceLoookupKey] = incomingOrder.get('price');
          }

          // Remove matching footprint
          dataStore.footprints.remove(this.get('footprint'));
        }

        if (incomingOrder.get('accountId') === dataStore.getActiveAccountId()) {
          this._setActiveOrder();
        }

        // evaluate user breaches.
        this._evaluateSizeLimitBreaches();
      }
    },

    getActiveOrder () {
      return this.get('activeOrder');
    },

    removeOrder (orderToRemove) {
      BGC.utils.trace('In instrument.removeOrder');

      const activeOrder = this.getActiveOrder();

      // We only store references to own orders on the instrument
      if (activeOrder === orderToRemove) {
        BGC.utils.trace('orderToRemove matches the current active order.');
        this._setActiveOrder();
      }
    },

    _clearActiveOrder () {
      _activeOrderTrace('Clearing the current active order(s), if any.');

      // Detach the active order object from the instrument,
      // ensuring that we stop listening to events from it
      const activeOrder = this.getActiveOrder();

      if (activeOrder) {
        _activeOrderTrace('Found active order. Stop listening to all its events.');
        activeOrder.off(null, null, this);

        _activeOrderTrace('Active order cleared.');
        this.unset('activeOrder');
      }
    },

    // Find buy/sell side active orders and set them into the instrument.
    _setActiveOrder () {
      // NB. Most users can only have one ActiveOrder object. Sales traders may have one per account.
      //     In the case of Locked Down Orders, such ActiveOrder objects may have unfilled size on both sides.
      //     Normally, an ActiveOrder object points to the same Order object on each side
      //     (because one Order object can represent sizes on both sides at a single price level).
      //     In the case of Locked Down Orders combined with VM+ pricing away from mid, buy and sell sides
      //     may have unfilled size at different prices, meaning TWO underlying Orders can be "active".

      const accountId = dataStore.isSalesTraderMode() ? dataStore.getActiveAccountId() : undefined;
      const ordersToAttach = this._findActiveOrders(accountId);

      let activeOrder = null;
      let prevActiveOrder = null;

      _activeOrderTrace('Recalculating what the active order should be.');

      if (ordersToAttach.length) {
        activeOrder = this._buildActiveOrder(ordersToAttach);
        if (activeOrder) {
          prevActiveOrder = this.getActiveOrder();
          if (prevActiveOrder) {
            _activeOrderTrace('Stop listening to all events on previous ActiveOrder object.');
            prevActiveOrder.off(null, null, this);
          }
          this.set('activeOrder', activeOrder);
        } else {
          this._clearActiveOrder();
        }
      } else {
        _activeOrderTrace('Found no orders suitable to attach as the ActiveOrder object');
        this._clearActiveOrder();
      }
    },

    _findActiveOrders (accountId) {
      let ordersToAttach = [];
      let buyOrdersToAttach = [];
      let sellOrdersToAttach = [];

      const tradePriceLoookupKey = accountId || 'default';
      const matchParams = {instrument : this, orderType : BGC.schemaValidator.OWNERSHIP_MINE};

      // For order searching, also match on accountId if it is supplied
      if (accountId !== undefined) {
        matchParams.accountId = accountId;
      }

      const matched = context.dataStore.orderStore.findOrders(matchParams);

      // Bail out early if there are no orders at all for this user for this instrument
      if (matched.length === 0) {
        _activeOrderTrace(`No orders found at any price for this user/account for instrument${this.getLogDescStr()}`);

        return [];
      }

      // First look for unfilled at ANY price - these should take priority
      ordersToAttach = _.filter(matched, order => order.isUnfilled());

      if (ordersToAttach.length) {
        // Log out the found unfilled orders and partition by side
        _.each(ordersToAttach, order => {
          if (order.hasUnfilledSize('buy')) {
            buyOrdersToAttach.push(order);
            _activeOrderTrace(`Found one unfilled BUY order at price ${order.get('price')}`);
          }
          if (order.hasUnfilledSize('sell')) {
            sellOrdersToAttach.push(order);
            _activeOrderTrace(`Found one unfilled SELL order at price ${order.get('price')}`);
          }
        });
      } else {
        _activeOrderTrace('Found no unfilled orders.');
      }

      // If nothing unfilled found on a particular side, look for filled orders at the current mid-price

      // Buy side first
      if (!buyOrdersToAttach.length) {
        let midPrice = this.get('midPrice');

        if (this.isSignFlippedForPickGive('buy')) {
          midPrice = -midPrice;
        }
        buyOrdersToAttach = context.dataStore.orderStore.findOrders(matchParams, midPrice, 'buy');
        Array.prototype.push.apply(ordersToAttach, buyOrdersToAttach);
        if (buyOrdersToAttach.length) {
          _activeOrderTrace(`Found ${buyOrdersToAttach.length} filled BUY orders at mid price of ${midPrice}`);
        } else {
          _activeOrderTrace(`Found no filled BUY orders at the mid price of ${midPrice}`);
        }
      }

      // Now sell side
      if (!sellOrdersToAttach.length) {
        let midPrice = this.get('midPrice');

        if (this.isSignFlippedForPickGive('sell')) {
          midPrice = -midPrice;
        }
        sellOrdersToAttach = context.dataStore.orderStore.findOrders(matchParams, midPrice, 'sell');
        Array.prototype.push.apply(ordersToAttach, sellOrdersToAttach);
        if (sellOrdersToAttach.length) {
          _activeOrderTrace(`Found ${sellOrdersToAttach.length} filled SELL orders at mid price of ${midPrice}`);
        } else {
          _activeOrderTrace(`Found no filled SELL orders at the mid price of ${midPrice}`);
        }
      }

      // If still nothing found, look for filled orders at the last price we traded at

      // Buy side first
      if (!buyOrdersToAttach.length) {
        if (this.myTradePrice.buy[tradePriceLoookupKey] !== undefined) {
          buyOrdersToAttach = context.dataStore.orderStore.findOrders(matchParams, this.myTradePrice.buy[tradePriceLoookupKey], 'buy');
          Array.prototype.push.apply(ordersToAttach, buyOrdersToAttach);
          if (buyOrdersToAttach.length) {
            _activeOrderTrace(`Found ${buyOrdersToAttach.length} filled BUY orders at my last executed buy price of ${this.myTradePrice.buy[tradePriceLoookupKey]}`);
          } else {
            _activeOrderTrace('Found no filled BUY order at the user\'s last executed buy price.');
          }
        }
      }

      // Now sell side
      if (!sellOrdersToAttach.length) {
        if (this.myTradePrice.sell[tradePriceLoookupKey] !== undefined) {
          sellOrdersToAttach = context.dataStore.orderStore.findOrders(matchParams, this.myTradePrice.sell[tradePriceLoookupKey], 'sell');
          Array.prototype.push.apply(ordersToAttach, sellOrdersToAttach);
          if (sellOrdersToAttach.length) {
            _activeOrderTrace(`Found ${sellOrdersToAttach.length} filled SELL orders at my last executed sell price of ${this.myTradePrice.sell[tradePriceLoookupKey]}`);
          } else {
            _activeOrderTrace('Found no filled SELL order at the user\'s last executed sell price.');
          }
        }
      }

      return ordersToAttach;
    },

    _buildActiveOrder (ordersArray) {
      _activeOrderTrace(`In _buildActiveOrder(), from ${ordersArray.length} orders`);
      if (ordersArray.length === 0) {
        _activeOrderTrace('Can\'t build an active order from 0 orders');

        return undefined;
      }

      if (ordersArray.length > 2) {
        _activeOrderTrace(`Can't build an active order from ${ordersArray.length} orders, must be waiting for order update to cancel some unfilled size`);

        return undefined;
      }

      _activeOrderTrace('Building a new ActiveOrder object');

      const newActiveOrder = new BGC.dataStore.modelDefinitions.ActiveOrder();
      let isBuySideSet = false;
      let isSellSideSet = false;

      if (ordersArray.length === 1) {
        _activeOrderTrace(`Setting the buy and sell sides of the ActiveOrder to order at price ${ordersArray[0].get('price')}`);
        newActiveOrder.setOrder(ordersArray[0]);
      } else {
        _.each(ordersArray, order => {
          // Check for size on each side individually. Unfilled size takes priority.
          // Use order.hasSize() instead of order.hasUnfilledSize() because the former includes
          // orders from Excel that may not be "live" executable orders
          if (order.hasSize('buy')) {
            _activeOrderTrace(`Setting the buy side of the ActiveOrder to order at price ${order.get('price')}`);
            newActiveOrder.setOrder(order, 'buy');
            isBuySideSet = true;
          }
          if (order.hasSize('sell')) {
            _activeOrderTrace(`Setting the sell side of the ActiveOrder to order at price ${order.get('price')}`);
            newActiveOrder.setOrder(order, 'sell');
            isSellSideSet = true;
          }

          if (!isBuySideSet && order.hasFilledSize('buy')) {
            _activeOrderTrace(`Setting the buy side of the ActiveOrder to order at price ${order.get('price')}`);
            newActiveOrder.setOrder(order, 'buy');
          }
          if (!isSellSideSet && order.hasFilledSize('sell')) {
            _activeOrderTrace(`Setting the sell side of the ActiveOrder to order at price ${order.get('price')}`);
            newActiveOrder.setOrder(order, 'sell');
          }
        }, this);
      }

      // Subscribe to side-specific execution notifications, so we can track last executed price
      newActiveOrder.on('buyExecution', function () {
        BGC.utils.trace('Processing buy execution for instrument active order');
        this.myTradePrice.buy[newActiveOrder.getAccountId() || 'default'] = newActiveOrder.getPrice('buy');
        this._setActiveOrder();
      }, this);
      newActiveOrder.on('sellExecution', function () {
        BGC.utils.trace('Processing buy execution for instrument active order');
        this.myTradePrice.sell[newActiveOrder.getAccountId() || 'default'] = newActiveOrder.getPrice('sell');
        this._setActiveOrder();
      }, this);

      // Subscribe to order change events, use them to also trigger instrument change events
      // as instrument-based views may display order info
      newActiveOrder.on('change', function () {
        this.trigger('change');
      }, this);

      // Subscribe to order removal/cancellation events
      newActiveOrder.on('remove', this.removeOrder, this);

      return newActiveOrder;
    },

    // This function returns the base size to which increments must be added
    // when calculating values for quick size entry in Total mode.
    // Since quick size entry is only provided for the selected/active account (for Sales Traders)
    // we don't need to worry about passing in an accountId, we'll grab it from the datastore.
    _getTotalTradedSize (priceLevel, side) {
      const matchParams = {instrument : this, orderType : BGC.schemaValidator.OWNERSHIP_MINE};
      let accountId = undefined;

      if (dataStore.isSalesTraderMode()) {
        accountId = dataStore.getActiveAccountId();
      }

      // For order searching, also match on accountId if it is supplied
      if (accountId !== undefined) {
        matchParams.accountId = accountId;
      }

      const order = context.dataStore.orderStore.findFirstMatchingOrder(matchParams, priceLevel, side);

      if (order) {
        return order.getTotalSize(side);
      }

      return 0;
    },

    _getFilledSize (side, priceLevel) {
      const matchParams = {instrument : this, orderType : BGC.schemaValidator.OWNERSHIP_MINE};
      let accountId = undefined;

      if (dataStore.isSalesTraderMode()) {
        accountId = dataStore.getActiveAccountId();
      }

      // For order searching, also match on accountId if it is supplied
      if (accountId !== undefined) {
        matchParams.accountId = accountId;
      }

      const order = context.dataStore.orderStore.findFirstMatchingOrder(matchParams, priceLevel, side);

      if (order) {
        return order.getFilledSize(side);
      }

      return 0;
    },

    _getUnfilledSize (side, priceLevel) {
      const matchParams = {instrument : this, orderType : BGC.schemaValidator.OWNERSHIP_MINE};
      let accountId = undefined;

      if (dataStore.isSalesTraderMode()) {
        accountId = dataStore.getActiveAccountId();
      }

      // For order searching, also match on accountId if it is supplied
      if (accountId !== undefined) {
        matchParams.accountId = accountId;
      }

      const order = context.dataStore.orderStore.findFirstMatchingOrder(matchParams, priceLevel, side);

      if (order) {
        return order.getUnfilledSize(side);
      }

      return 0;
    },

    calcOverlimitSize () {
      return dataStore.userSettingsCollection.global.get('maxQuantityMultiplier') * this.get('minSize');
    },

    hasSizeLimitBeenBreached (side) {
      // check if a change in the multiplier settings has invalidated the over-limit size previously set.
      if (!BGC.utils.compareFPNumEQ(this.maxQuantity.overlimitSize, this.calcOverlimitSize())) {
        this._evaluateSizeLimitBreaches(true);
      }

      return side === 'buy' ? this.maxQuantity.buySizeLimitReached : this.maxQuantity.sellSizeLimitReached;
    },

    _evaluateSizeLimitBreaches (forceEvaluateSides) {
      const evaluateSizeLimitBreachForSide = function (side) {
        let orderTotalSize = 0;
        const matchParams = {instrument : this, orderType : BGC.schemaValidator.OWNERSHIP_MINE};
        const orderModels = context.dataStore.orderStore.findOrders(matchParams, undefined, side);

        _.each(orderModels, orderModel => {
          orderTotalSize += orderModel.getTotalSize(side);
        });

        const limitBreached = BGC.utils.compareFPNumGT(orderTotalSize, this.calcOverlimitSize());

        if (limitBreached) {
          this.maxQuantity.overlimitSize = this.calcOverlimitSize();
        }

        if (side === 'buy') {
          this.maxQuantity.buySizeLimitReached = limitBreached;
        } else {
          this.maxQuantity.sellSizeLimitReached = limitBreached;
        }
      };

      // Don't do anything if we have not specified the max quantity multiplier
      if (dataStore.userSettingsCollection.global.get('maxQuantityMultiplier')) {
        if (forceEvaluateSides || !this.maxQuantity.buySizeLimitReached) {
          evaluateSizeLimitBreachForSide.call(this, 'buy');
        }

        if (forceEvaluateSides || !this.maxQuantity.sellSizeLimitReached) {
          evaluateSizeLimitBreachForSide.call(this, 'sell');
        }
      }
    },

    getMaxQuantityInfo (orderToSubmit, isSpreadCreationOrder) {
      let isOverlimit = false;
      let totalSize = Number(orderToSubmit.size);
      const orderPrice = orderToSubmit.priceDisplay ? orderToSubmit.price : this.get('midPrice');
      const isTotalMode = !!context.dataStore.userSettingsStore.get('upsizingMode');

      // check if order breaches the max quantity only if multiplier is specified (i.e. non-zero).
      if (dataStore.userSettingsCollection.global.get('maxQuantityMultiplier')) {
        const hasSizeLimitBeenBreached = this.hasSizeLimitBeenBreached(orderToSubmit.side);

        if (!hasSizeLimitBeenBreached || isSpreadCreationOrder) {
          const matchedAttributes = {instrument : this, orderType : BGC.schemaValidator.OWNERSHIP_MINE};

          // only consider the instrument total bought/sold size if we are processing the limit for this instrument. if are creating a spread, we will use the D1 of
          // the spread we are creating which boughts/solds don't apply to the new spread instrument. just check if the size breaches the limit D1 instrument's limit.
          if (!isSpreadCreationOrder) {
            const orderModels = context.dataStore.orderStore.findOrders(matchedAttributes, undefined, orderToSubmit.side);

            // determine the total size (filled/unfilled across all orders) of the instrument including the additional size
            // of the outgoing order. Therefore if we have an order already at the price level of the outgoing order use the total size of the order in total mode
            // or the filled size size only in incremental mode.
            orderModels.forEach(orderModel => {
              if (BGC.utils.compareFPNumEQ(orderModel.get('price'), orderPrice)) {
                totalSize += isTotalMode ? 0 : orderModel.getFilledSize(orderToSubmit.side);
              } else {
                totalSize += orderModel.getTotalSize(orderToSubmit.side);
              }
            });
          }

          isOverlimit = BGC.utils.compareFPNumGT(totalSize, this.calcOverlimitSize());
        }
      }

      return {isOverlimit, totalSize};
    },

    sendCancelOrder (viewId, cancelSide) {
      const hasExistingOrder = this.hasOwnOrder();
      const existingOrder = hasExistingOrder ? this.getActiveOrder().get(cancelSide) : null;

      // When cancelling the active order for an Instrument,
      // we must always be cancelling our own order, in the active account context.
      // This order model is already serialized into instObj.ownOrder

      // Send orderId and originalOrderId for GTI
      // originalOrderId is the orderId of the initial order - only required for GTI
      if (existingOrder && existingOrder.hasCancellableSize(cancelSide)) {
        BGC.dataStore.sendCancelOrder(viewId, {
          instrumentId     : this.get('instrumentId'),
          orderId          : BGC.utils.createUuid().substr(0, 20),
          originalOrderId  : existingOrder.getOrderId(cancelSide),
          price            : existingOrder.get('price'),
          size             : existingOrder.getUnfilledSize(cancelSide),
          side             : cancelSide,
          accountId        : existingOrder.get('accountId'),
          userId           : existingOrder.get('userId'),
          sourceSystem     : this.get('sourceSystem'),
          symbolType       : this.get('symbolType'),
          venueType        : this.get('venueType'),
          regulatoryRegime : this.get('regulatoryRegime')
        });
      }
    },

    sendEnableExcelLiveLink (viewId, shouldEnable) {
      const instObj = this.serialize();

      if (instObj.ownOrder) {
        BGC.dataStore.sendEnableExcelLiveLink(viewId, {
          instrumentId : instObj.instrumentId,
          enable       : shouldEnable
        });
      }
    },

    requestTradeConfirms (viewId) {
      BGC.eventsHandler.onClick(viewId, 'vmRequestTradeConfirms', JSON.stringify({
        instrumentId : this.get('instrumentId')
      }));
    },

    getAdjustedNomenclature (stringId) {
      return BGC.resources.getAdjustedNomenclature(stringId, this.get('nomenclature'));
    },

    /**
       * Validates given size taking into account existing executed
       * order for the given side.
       *
       * @param {String} size
       * @param {String} side
       * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
       */
    validateSize (size, side, priceLevel, suppressErrorDisplay) {
      return validators.executeSizeValidator(this.createSizeValidator({
        size,
        orderExecuted     : this.hasOrderExecuted(side, priceLevel),
        orderUpsizingMode : context.dataStore.userSettingsStore.get('upsizingMode'),
        filledSize        : this._getFilledSize(side, priceLevel),
        unfilledSize      : this._getUnfilledSize(side, priceLevel)
      }), !suppressErrorDisplay, this.getLogDescStr());
    },

    /**
       * Validates given size without checking executed order on the instrument.
       *
       * @param {String} size
       * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
       */
    validateSizeIgnoringOrder (size, suppressErrorMsg) {
      return validators.executeSizeValidator(this.createSizeValidator({
        size
      }), !suppressErrorMsg, this.getLogDescStr());
    },

    /**
       * Creates an instance of the SizeValidator that contains provided
       * size details and default values from the instrument.
       *
       * @param {Object} sizeDetails
       * @returns {validators.SizeValidator}
       */
    createSizeValidator (sizeDetails) {
      return new validators.SizeValidator(_.extend(sizeDetails, {
        sizeIncrement              : this.get('sizeIncrement'),
        sizeMultiplier             : BGC.ui.viewUtils.getSizeSymbol(this.get('sizeMultiplier')),
        minSize                    : this.get('minSize'),
        allowTopSpeedSizeIncrement : this.get('allowTopSpeedSizeIncrement'),
        topSpeedSizeIncrement      : this.get('topSpeedSizeIncrement')
      }));
    },

    /**
       * Validates given price.
       *
       * @param {String} price
       * @param {Boolean} showMsgBox
       * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
       */
    validatePrice (price, showMsgBox, ignoreIncrement) {
      return validators.executePriceValidator(this.createPriceValidator({
        price,
        ignoreIncrement
      }), showMsgBox, this.getLogDescStr());
    },

    /**
       * Validates given bid price.
       *
       * @param {String} price
       * @param {Boolean} showMsgBox
       * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
       */
    validateBidPrice (price, showMsgBox) {
      // Need to get the view model to get the user's view of min and max allowed values,
      // which may have been adjusted from the data model to take account of pick/give sign-flipping
      const viewModel = this.serialize();

      return validators.executePriceValidator(this.createPriceValidator({
        price,
        minPrice : viewModel.minBidPrice,
        maxPrice : viewModel.maxBidPrice
      }), showMsgBox, this.getLogDescStr());
    },

    /**
       * Validates given offer price.
       *
       * @param {String} price
       * @param {Boolean} showMsgBox
       * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
       */
    validateOfferPrice (price, showMsgBox) {
      // Need to get the view model to get the user's view of min and max allowed values,
      // which may have been adjusted from the data model to take account of pick/give sign-flipping
      const viewModel = this.serialize();

      return validators.executePriceValidator(this.createPriceValidator({
        price,
        minPrice : viewModel.minOfferPrice,
        maxPrice : viewModel.maxOfferPrice
      }), showMsgBox, this.getLogDescStr());
    },

    /**
       * Creates an instance of the PriceValidator that contains provided
       * price details and default values from the instrument.
       *
       * @param {Object} priceDetails
       * @returns {validators.PriceValidator}
       */
    createPriceValidator (priceDetails) {
      if (typeof priceDetails.price !== 'string') {
        throw new TypeError('Price must be a string');
      }

      return new validators.PriceValidator(_.extend(priceDetails, {
        priceIncrement       : this.get('priceIncrement'),
        priceDecimals        : this.getMinMaxDecimalPlacesForDVar(),
        allowsNegativeOrZero : this.get('allowsNegativeOrZeroPrice'),
        priceFormatter       : this.formatPrice.bind(this),
        priceType            : this.get('priceType')
      }));
    },

    /**
       * Formats given price or instrument internal mid price to
       * decimal precision set by number of decimal places in price increment.
       *
       * @param {Number} price
       * @returns {String}
       */
    formatPrice (price) {
      if (typeof price !== 'number' && price !== undefined) {
        throw new TypeError('Price must be a number');
      }

      const instrumentPrice = price === undefined ? this.get('midPrice') : price;
      const options = {priceDecimalDVarMinMaxDecimalPlaces : this.getMinMaxDecimalPlacesForDVar()};
      const priceObject = BGC.priceTypes.getPriceObject(this.get('priceType'), instrumentPrice, options);

      return priceObject.stringValue;
    },

    /**
       * Formats given size to decimal precision set by number of decimal places in size increment.
       *
       * @param {Number}
       * @returns {String}
       */
    formatSize (size) {
      if (typeof size !== 'number') {
        throw new TypeError('Size must be a number');
      }

      return utils.formatDecimal(size, this.sizeDecimalPrecision);
    },

    /**
       * Updates current decimal precision for price values based
       * on price increment.
       */
    updatePriceDecimalPrecision () {
      this.priceDecimalPrecision = utils.getDecimalPrecision(this.get('priceIncrement') || 0);
    },

    /**
       * Updates current decimal precision for size values based
       * on size increment.
       */
    updateSizeDecimalPrecision () {
      this.sizeDecimalPrecision = utils.getDecimalPrecision(this.get('sizeIncrement') || 0);
    },

    getMinMaxDecimalPlacesForDVar () {
      if (this.get('priceType') !== BGC.priceTypes.ETypes.ePriceTypeDecimal) {
        return undefined;
      }

      return {max : this.priceDecimalPrecision, min : this.get('minDecimalPlaces')};
    },

    /**
       * Nudges a price by the increment value and validates the result.
       * Can be used with string or numeric input/output values.
       *
       * @param {Number|String} price (input/output)
       * @param {Boolean} isNudgeUp
       * @param {Boolean} displayErrors
       *
       * returns {Boolean}
       */
    nudgePrice (price, isNudgeUp, displayErrors) {
      let numericPrice = undefined;

      if (typeof price === 'string') {
        const validatedPrice = this.validatePrice(price, displayErrors);

        if (validatedPrice.valid) {
          numericPrice = validatedPrice.numericValue;
        } else {
          return false;
        }
      } else if (typeof price === 'number') {
        numericPrice = price;
      } else {
        throw new TypeError('Instrument.nudgePrice was passed an invalid price argument type');
      }

      numericPrice = isNudgeUp ? numericPrice + this.get('priceIncrement') : numericPrice - this.get('priceIncrement');

      if (typeof price === 'string') {
        price = this.formatPrice(numericPrice);
      } else {
        price = numericPrice;
      }

      return true;
    },


    /**
       * Nudges a price by the increment value and validates the result using the VM+ range
       * Can be used with string or numeric input/output values.
       *
       * @param {Number|String} price (input/output)
       * @param {String} side (One of "buy" or "sell". Determines whether to use bid or offer range)
       * @param {Boolean} isNudgeUp - or down?
       * @param {Boolean} display errors - show errors if invalid?
       * @param {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
       *
       * returns {Boolean}
       */
    nudgePriceWithRangeValidation (price, side, isNudgeUp, displayErrors) {
      let validatedPrice = undefined;
      let numericPrice = undefined;
      let stringPrice = '';

      if (side !== BGC.schemaValidator.BUY_SIDE && side !== BGC.schemaValidator.SELL_SIDE) {
        throw new TypeError('Instrument.nudgeVMPlusPrice was passed an invalid side argument');
      }

      // convert price if string
      if (typeof price === 'string') {
        validatedPrice = this.validatePrice(price, displayErrors);
        if (validatedPrice.valid) {
          numericPrice = validatedPrice.numericValue;
        } else {
          return false;
        }
      } else if (typeof price === 'number') {
        numericPrice = price;
      } else {
        throw new TypeError('Instrument.nudgeVMPlusPrice was passed an invalid price argument type');
      }

      // get nudge amount IF a nudge. Otherwise leave price as is
      numericPrice = isNudgeUp ? numericPrice + this.get('priceIncrement') : numericPrice - this.get('priceIncrement');
      stringPrice = this.formatPrice(numericPrice);

      // Now validate the price to ensure that it falls within the range boundaries
      validatedPrice = side === BGC.schemaValidator.BUY_SIDE ? this.validateBidPrice(stringPrice, displayErrors) : this.validateOfferPrice(stringPrice, displayErrors);

      validatedPrice.stringValue = stringPrice;

      if (validatedPrice.valid) {
        numericPrice = validatedPrice.numericValue;
      }

      return validatedPrice;
    },

    /**
       * get own order if available to send to b/end on a nudge or size button click
       * @param side - buy or sell
       * @param modifiedPrice
       * @param modifiedSize
       */
    getOrderDetailsForSubmission (side, modifiedPrice, modifiedSize) {
      let hasExistingOrder = this.hasOwnOrder();
      const existingOrder = hasExistingOrder ? this.getActiveOrder().get(side) : null;

      // fixes issue where user has bid price and clicks in offer and hits return - was sending 0 for size
      if (!existingOrder || (existingOrder && existingOrder.getSize(side) === 0)) {
        hasExistingOrder = false;
      }

      // new order or updated order
      const newOrder = hasExistingOrder ? existingOrder.serialize() : {
        instrumentId : this.get('instrumentId')
      };

      // update order with new values
      if (modifiedSize) {
        newOrder.size = modifiedSize;
      } else if (hasExistingOrder) {
        newOrder.size = existingOrder.getSize(side);
      } else {
        newOrder.size = this.get('minSize');
      }

      if (modifiedPrice !== null && modifiedPrice !== '') {
        newOrder.price = modifiedPrice;
        newOrder.priceDisplay = this.formatPrice(modifiedPrice);
      } else if (hasExistingOrder) {
        newOrder.priceDisplay = this.formatPrice(newOrder.price);
      }

      newOrder.side = side;

      return newOrder;
    }
  },

  // (backbone model) class properties (= public static members)
  {
    compareTenors (instrumentName1, instrumentName2) {
      let result = 0;
      const tenorMatches1 = instrumentName1.match(/[0-9]+[WYM]/g) || [];
      const tenorMatches2 = instrumentName2.match(/[0-9]+[WYM]/g) || [];

      result = tenorMatches1.length - tenorMatches2.length;

      if (result === 0) {
        // eslint-disable-next-line no-plusplus
        for (let index = 0; index < tenorMatches1.length; ++index) {
          result = this.compareMaturity(tenorMatches1[index], tenorMatches2[index]);
          if (result !== 0) {
            break;
          }
        }
      }

      return result;
    },

    compareMaturity (tenor1, tenor2) {
      const getMaturityValue = function (abbreviatedMaturity) {
        // assign a multipler for weeks, months and years so that we can simply compare numerical values.
        switch (abbreviatedMaturity) {
          case 'W':
            return 7;
          case 'M':
            return 28;
          case 'Y':
            return 336;
          default:
            return 0;
        }
      };

      const maturityValue1 = parseInt(tenor1.substring(0, tenor1.length - 1), 10) * getMaturityValue(tenor1[tenor1.length - 1]);
      const maturityValue2 = parseInt(tenor2.substring(0, tenor2.length - 1), 10) * getMaturityValue(tenor2[tenor2.length - 1]);

      return maturityValue1 - maturityValue2;
    },

    getThirdPartyInterestForInstruments (instruments) {
      return instruments.reduce((memo, instrument) => memo + (instrument.get('auction').get('showInterestAndTradeCount') && (instrument.get('thirdPartyInterest') !== 'none') ? 1 : 0), 0);
    },

    getTradedCountForInstruments (instruments) {
      return instruments.reduce((memo, instrument) => memo + (instrument.get('auction').get('showInterestAndTradeCount') && instrument.get('hasTradedInAuction') ? 1 : 0), 0);
    },

    /**
       * Takes an 'instrument' message delta and determines the state changes, whether an instrument is being created
       * or updated or whether an instrument is leaving or entering an auction: live or indicative
       **/
    setUpdateStatesFromMessage (instrument, msg) {
      const msgState = {};
      const auction = msg.auctions ? msg.auctions[0] : null;

      // 1. Whether an instrument is being created or updated
      if (instrument && instrument.get('isInit')) {
        msgState.isDummyInstrumentUpdate = true;
      } else if (instrument) {
        msgState.isInstrumentUpdate = true;
      } else if (!instrument) {
        msgState.isNewInstrumentUpdate = true;
      }

      // 2. Whether an instrument is entering or leaving a live auction
      if (msg.hasOwnProperty('isInAuction')) {
        if (msg.isInAuction && (!instrument || instrument.get('inactive'))) {
          msgState.isEnteringVM = true;
        } else if (!msg.isInAuction && instrument && !instrument.get('inactive')) {
          msgState.isLeavingVM = true;
        }
      }

      // 3. Whether an instrument is entering or leaving an indicative auction
      if (auction && auction.hasOwnProperty('isMidPriceIndicative')) {
        if (auction.isMidPriceIndicative) {
          msgState.isEnteringIndicative = true;
        } else {
          msgState.isLeavingIndicative = true;
        }
      }

      // 4. Whether an instrument is a lock instrument
      if (msg.hasOwnProperty('isLockInstrument') && msg.isLockInstrument) {
        msgState.isLockInstrument = true;
      }

      return msgState;
    },

    /**
       * Function used to update and existing dummy instrument based on an
       * initial instrument message received from the server.
       */
    updateDummyInstrument (instrument, message) {
      return setAttributesFromMessage(instrument, message);
    },

    /**
       * Function used to create a stub instrument based on a few essential attributes
       */
    // eslint-disable-next-line no-shadow
    createStubInstrument (instId, tileId, canUserEnterOrders, dataStore, sortOrder) {
      const instrument = new context.dataStore.modelDefinitions.Instrument({
        dataStore,
        instrumentId : instId,
        tileId,
        canUserEnterOrders,
        index        : sortOrder || 0,
        auction      : dataStore.pageLayout.getOrAddAuction('dormant'),
        isInit       : false
      });

      return instrument;
    },

    /**
       * Function used to create a new instrument based on an
       * initial instrument update message received from the server.
       */
    create (message) {
      const instrument = new context.dataStore.modelDefinitions.Instrument({
        dataStore          : context.dataStore,
        instrumentId       : message.instrumentId,
        tileId             : message.tileId,
        canUserEnterOrders : !context.dataStore.isBrokerMode(),
        isInit             : false
      });

      return setAttributesFromMessage(instrument, message);
    },

    getGenAttrFormattedInstrumentName (instrname, genAttrParams) {
      let displayName = instrname;
      const straddleDisplay = genAttrParams.straddleDisplay ? `S-${genAttrParams.straddleDisplay}` : '';
      const ratioDisplay = genAttrParams.ratioDisplay ? `R-${genAttrParams.ratioDisplay}` : '';
      const deltaDisplay = genAttrParams.deltaDisplay ? `D-${genAttrParams.deltaDisplay}` : '';
      const collatedParams = _.reduce([straddleDisplay, ratioDisplay, deltaDisplay], (memo, param) => (param.length > 0 ? (memo.length > 0 ? `${memo} / ` : '') + param : memo));

      if (collatedParams.length > 0) {
        displayName += ` (${collatedParams})`;
      }

      return displayName;
    }
  });


  context.dataStore.collectionDefinitions.Instruments = Backbone.Collection.extend({
    model : context.dataStore.modelDefinitions.Instrument
  });

  context.dataStore.instruments = new context.dataStore.collectionDefinitions.Instruments([]);
}(window.BGC, window.BGC.utils, window.BGC.priceTypes, window.BGC.validators));
