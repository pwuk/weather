/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */

(function (context, undefined) {
    "use strict";

    context.modelDefinitions.Account = Backbone.Model.extend({
        defaults: {
			id: "", // Mnemonic Id from the C++ data, stored as "id" to make it the Backbone lookup key
			fullName: "",
            shortName: "",
            invariantId: "", // also known as Parent Id or simply Id in the C++ data layer, used for updates
            enabled: false,
            accountType: -1,
            displayIndex: -1
        },

        initialize: function (options) {
            BGC.utils.createEnumeration(this, "EAccountType", ["eBroker", "eActiveTrader", "ePassiveTrader", "eSalesTraderAccount"]);
        },

		serialize: function () {
			return this.toJSON();
		}
    });
	
    context.collectionDefinitions.Accounts = Backbone.Collection.extend({
        model: context.modelDefinitions.Account
	});
	
}(window.BGC.dataStore));