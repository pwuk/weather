/* eslint-disable max-lines,max-len,no-magic-numbers,no-param-reassign,func-names */
/* global BGC: false, _:false, Backbone: false */

import {playSound, sounds} from '../../utils/sound-service';

// eslint-disable-next-line no-shadow-restricted-names
(function (context, undefined) {
  const AUCTION_POPULATION_QOS_REPORT_TIMER_DELAY_MILLISECS = 10000;
  const AUCTION_POPULATION_QOS_ALERT_THRESHOLD_MILLISECS = 5000;

  /**
   * Auction Model: models a single matrix and a collection of tiles
   * Attributes:
   auctionId:                 String      auction identifier
   auctionTitle:              String      the title from the broker VM dialog (not currently displayed)
   orderPhaseText:            String      the text from the broker VM dialog (not currently displayed)
   startTime:                 Number      auction start time
   endTime:                   Number      auction end time
   timeOffset:                Number      time offset in seconds between server and browser
   running:                   Boolean     is the auction running?
   showInterestAndTradeCount: Boolean     stores whether interest and trade count preference has been set for this auction.
   */

  context.dataStore.modelDefinitions.Auction = Backbone.Model.extend({
    defaults : {
      auctionId                                          : '',
      auctionTitle                                       : '',
      auctionNameExt                                     : '',
      orderPhaseText                                     : '',
      runningState                                       : 0,
      runningInstrumentCount                             : 0,
      startTime                                          : 0,
      endTime                                            : 0,
      timeOffset                                         : 0,
      showInterestAndTradeCount                          : false,
      hiddenColumns                                      : [],
      isAuctionStarting                                  : false,
      auctionPopulationStartTimeUtc                      : 0,
      auctionPopulationEndTimeUtc                        : 0,
      auctionPopulationClientProcessingDurationMilliSecs : 0,
      phaseoneEndtime                                    : 0,
      auctionPhase                                       : '',
      layout                                             : undefined,
      auctionEndedTime                                   : 0,
      instruments                                        : []
    },

    idAttribute : 'auctionId',

    EContentState : {
      eNone           : 0,
      eVMOnly         : 1,
      eIndicativeOnly : 2,
      eMixed          : 3
    },

    hasLaterEndTimeThan (otherAuction) {
      return this.get('endTime') > otherAuction.get('endTime');
    },

    initialize (options) {
      const {vmSessionId, auctionId} = options;

      this.id = vmSessionId || auctionId;
    },

    // eslint-disable-next-line max-statements
    onAuctionEvent (auctionEventMessage) {
      if (auctionEventMessage.event === 'start') {
        BGC.logger.logInformation(`VM: ${document.title}`, `Processed auction start message for [${this.get('auctionId')}], end time =  ${new Date(auctionEventMessage.endTime * 1000)}`);

        if (context.dataStore.userSettingsStore.get('playSoundWhenVMLaunch')) {
          playSound(sounds.VM_START);
        }

        // Set the valid generic columns for this auction, based on document definition
        // and any columns that the broker launching the auction has chosen to hide
        const genericColumns = [];
        const hiddenColumns = auctionEventMessage.hiddenColumns || [];

        _.each(this.get('layout').get('genericColumns'), columnDefinition => {
          if (!_.contains(hiddenColumns, columnDefinition.columnId)) {
            genericColumns.push(columnDefinition);
          }
        });

        this.set({
          startTime                   : auctionEventMessage.startTime,
          timeOffset                  : Math.floor(Date.now() / 1000) - auctionEventMessage.nowTime,
          endTime                     : auctionEventMessage.endTime,
          auctionTitle                : auctionEventMessage.auctionName,
          auctionNameExt              : auctionEventMessage.auctionNameExt,
          runningState                : this.EContentState.eVMOnly,
          showThirdPartyInterestGlows : auctionEventMessage.settings.showInterestGlows,
          showTradeIndicators         : auctionEventMessage.settings.showTradeIndicators,
          showInterestAndTradeCount   : auctionEventMessage.settings.showInterestAndTradeIndicators,
          hiddenColumns,
          auctionPhase                : auctionEventMessage.auctionPhase,
          phaseoneEndtime             : auctionEventMessage.phaseoneEndtime,
          genericColumns
        });

        // If an auction is started then we need to signal views of instruments in the indicative auction
        // to inform them to re-render/hide themselves.
        const indicativeAuction = this.get('layout').getOrAddAuction('indicative');

        if (indicativeAuction.get('runningInstrumentCount') > 0) {
          indicativeAuction.isSuspended = true;
          indicativeAuction.trigger('change:runningState', indicativeAuction, false);
        }
      } else if (auctionEventMessage.event === 'update') {
        BGC.logger.logInformation(`VM: ${document.title}`, `Processed auction update (end time) message for [${this.get('auctionId')}], end time =  ${new Date(auctionEventMessage.endTime * 1000)}`);
        this.set({
          endTime      : auctionEventMessage.endTime,
          timeOffset   : Math.floor(Date.now() / 1000) - auctionEventMessage.nowTime,
          auctionPhase : auctionEventMessage.auctionPhase
        });
        this.trigger('auction:extend', this);
      } else if (auctionEventMessage.event === 'end') {
        BGC.logger.logInformation(`VM: ${document.title}`, `Processed auction end message for [${this.get('auctionId')}]`);

        // Set the Attributes to default and trigger change event to clean up
        // auctionEndedTime : This captures the latest auction end time for auction history breach check
        this.set({
          startTime                   : 0,
          endTime                     : 0,
          auctionEndedTime            : new Date().getTime(),
          runningState                : this.EContentState.eNone,
          showThirdPartyInterestGlows : false,
          showTradeIndicators         : false,
          showInterestAndTradeCount   : false,
          auctionPhase                : auctionEventMessage.auctionPhase,
          phaseoneEndtime             : 0
        });

        // Get the In-Active auction items (non-running auctions only) to handle the count breach condition
        const inactiveAuctions = context.dataStore.auctions.where({
          runningState : 0
        });

        // maxAuctionHistoryCount = -1  => No Limit on auction history
        // maxAuctionHistoryCount = 0  => No auction history shown
        // maxAuctionHistoryCount = X => 'X' number of auction history to be shown
        if (context.dataStore.userSettingsStore.get('maxAuctionHistoryCount') === 0) {
          context.dataStore.auctions.remove(this);
        } else if (context.dataStore.userSettingsStore.get('maxAuctionHistoryCount') !== -1 && inactiveAuctions.length > context.dataStore.userSettingsStore.get('maxAuctionHistoryCount')) {
          // If Auction history count breached ,Get the finished auction and sort it on auction ended time.
          // and remove the first finished auction from original auction collection as that will be the oldest finished auction
          inactiveAuctions.sort((model1, model2) => model1.get('auctionEndedTime') - model2.get('auctionEndedTime'));

          context.dataStore.auctions.remove(inactiveAuctions[0]);
        }
      }
    },

    getGenericColumns () {
      const layout = this.get('layout');

      if (layout) {
        return layout.get('genericColumns').filter(item => !this.get('hiddenColumns').includes(item));
      }

      return [];
    },

    // We monitor that state of the running instruments in the auction by processing notifications
    // of instruments entering or leaving auctions based on the instrument update messages since the
    // "auction events" can be out of sync with the current state of the instruments and thus the
    // real running state of the auction.
    onInstrumentActiveStateChange (instrument, isInstrumentEnteringAuction) {
      const prevRunningInstrumentCount = this.get('runningInstrumentCount');

      if (isInstrumentEnteringAuction) {
        this.set('runningInstrumentCount', prevRunningInstrumentCount + 1);

        if (prevRunningInstrumentCount === 0) {
          BGC.logger.logInformation('', `Auction[${this.get('auctionId')}] started, firstInstrument[${instrument.getLogDescStr()}].`);

          this.set({
            isAuctionStarting                                  : true,
            auctionPopulationStartTimeUtc                      : Date.now(),
            auctionPopulationClientProcessingDurationMilliSecs : 0
          });
        }
      } else {
        this.set('runningInstrumentCount', prevRunningInstrumentCount - 1);

        if (prevRunningInstrumentCount === 1) {
          BGC.logger.logInformation('', `Auction[${this.get('auctionId')}] ended, lastInstrument[${instrument.getLogDescStr()}].`);

          if (this.auctionPopulationQoSEventCoalescenceTimer) {
            clearTimeout(this.auctionPopulationQoSEventCoalescenceTimer);
            this.auctionPopulationQoSEventCoalescenceTimer = null;

            // The auction ended before the timer fired.
            BGC.logger.sendQoSEvent({
              type                              : 'auctionWindowAuctionStart',
              databaseKeyName                   : 'HTML_VM_POPUP',
              startTimeUtc                      : this.get('auctionPopulationStartTimeUtc'),
              endTimeUtc                        : this.get('auctionPopulationEndTimeUtc'),
              message                           : this.get('auctionId'),
              alertThresholdMilliSecs           : AUCTION_POPULATION_QOS_ALERT_THRESHOLD_MILLISECS,
              eventReportDelayMilliSecs         : Date.now() - this.get('auctionPopulationEndTimeUtc'),
              clientProcessingDurationMilliSecs : this.get('auctionPopulationClientProcessingDurationMilliSecs')
            });
          }

          this.resetQoSMetrics();
        }
      }
    },

    onInstrumentIndicativeStateChange (instrument, isEnteringIndicativeState) {
      const prevRunningInstrumentCount = this.get('runningInstrumentCount');

      if (this.get('auctionId') !== 'indicative') {
        return;
      }

      if (isEnteringIndicativeState) {
        // Doesn't do any harm to always set running state to Indicative,
        // it won't trigger "change:runningState" event if value doesn't change
        this.set({
          runningInstrumentCount : prevRunningInstrumentCount + 1,
          runningState           : this.EContentState.eIndicativeOnly
        });

        if (prevRunningInstrumentCount === 0) {
          BGC.logger.logInformation('', `Auction['indicative'] started, firstInstrument[${instrument.getLogDescStr()}].`);

          if (this.get('layout').areAnyInstrumentsInAuction()) {
            this.isSuspended = true;
            BGC.logger.logInformation('', 'Auction[\'indicative] set to suspended state, as other auction(s) running.');
          }
        }
      } else if (prevRunningInstrumentCount === 1) {
        this.set({
          runningInstrumentCount : prevRunningInstrumentCount - 1,
          runningState           : this.EContentState.eNone
        });

        BGC.logger.logInformation('', `Auction[${this.get('auctionId')}] ended, lastInstrument[${instrument.getLogDescStr()}].`);
      } else {
        this.set({
          runningInstrumentCount : prevRunningInstrumentCount - 1
        });
      }
    },

    /**
     * Because we do not have any real way (yet) to determine which is the
     * last instrument being processed as part of an auction, we throttle
     * the execution of this function so that it won't be executed for each
     * instrument message (after profiling, it looks like clearing and setting
     * an interval is quite an expensive operation if done repeatedly)
     */
    updateAuctionPopulationEndTime : _.throttle(function () {
      // eslint-disable-next-line consistent-this
      const auction = this;

      // Update the auction population end time.
      this.set('auctionPopulationEndTimeUtc', Date.now());

      if (this.auctionPopulationQoSEventCoalescenceTimer) {
        clearTimeout(this.auctionPopulationQoSEventCoalescenceTimer);
      }

      // If no instrument processing has occured for 10s, we assume the auction
      // is fully populated and send the QoS event.
      this.auctionPopulationQoSEventCoalescenceTimer = setTimeout(() => {
        BGC.logger.sendQoSEvent({
          type                              : 'auctionWindowAuctionStart',
          databaseKeyName                   : 'HTML_VM_POPUP',
          startTimeUtc                      : auction.get('auctionPopulationStartTimeUtc'),
          endTimeUtc                        : auction.get('auctionPopulationEndTimeUtc'),
          message                           : auction.get('auctionId'),
          alertThresholdMilliSecs           : AUCTION_POPULATION_QOS_ALERT_THRESHOLD_MILLISECS,
          eventReportDelayMilliSecs         : Date.now() - auction.get('auctionPopulationEndTimeUtc'),
          clientProcessingDurationMilliSecs : auction.get('auctionPopulationClientProcessingDurationMilliSecs')
        });

        auction.auctionPopulationQoSEventCoalescenceTimer = null;
        auction.resetQoSMetrics();
      }, AUCTION_POPULATION_QOS_REPORT_TIMER_DELAY_MILLISECS);
    }, 100),

    notifyAuctionPopulationStepCompleted (instrument, tile, instrumentProcessingDurationMilliSecs) {
      // Exclude spread instruments or operations involving spread tiles.
      if ((instrument && instrument.get('spread')) ||
        (tile && (tile.get('layoutType') === 'spread'))) {
        return;
      }

      if (this.get('isAuctionStarting') === true) {
        this.updateAuctionPopulationEndTime();

        if (instrumentProcessingDurationMilliSecs) {
          this.set('auctionPopulationClientProcessingDurationMilliSecs', this.get('auctionPopulationClientProcessingDurationMilliSecs') + instrumentProcessingDurationMilliSecs);
        }
      }
    },

    resetQoSMetrics () {
      this.set({
        isAuctionStarting                                  : false,
        auctionPopulationStartTimeUtc                      : 0,
        auctionPopulationEndTimeUtc                        : 0,
        auctionPopulationClientProcessingDurationMilliSecs : 0
      });
    },

    // Get auction third-party interest count
    getInterestCount () {
      const {instruments, showInterestAndTradeCount} = this.attributes;

      if (showInterestAndTradeCount) {
        return instruments.reduce((acc, instrument) => acc + (instrument.get('thirdPartyInterest') === 'none' ? 0 : 1), 0);
      }

      return 0;
    },

    // Get auction traded count
    getTradeCount () {
      const {instruments, showInterestAndTradeCount} = this.attributes;

      if (showInterestAndTradeCount) {
        return instruments.reduce((acc, instrument) => acc + (instrument.get('hasTradedInAuction') ? 1 : 0), 0);
      }

      return 0;
    }
  });

  context.dataStore.collectionDefinitions.AuctionCollection = Backbone.Collection.extend({
    model : context.dataStore.modelDefinitions.Auction,

    processInstrumentMsg : (function () {
      let batch = [];

      const batchUpdate = _.throttle(auctions => {
        const groups = _.groupBy(batch, group => group.get('vmSessionId'));

        // eslint-disable-next-line no-restricted-syntax
        for (const key of Object.keys(groups)) {
          const auction = auctions.get(key);

          if (auction) {
            auction.get('instruments').push(...groups[key]);
            auction.trigger('change:instruments', groups[key]);
          }
        }

        batch = [];
      }, 200, {leading : false});

      // Batch and throttle any updates to a running auction
      return function (instrument) {
        const auction = this.get(instrument.get('vmSessionId'));

        if (auction && !auction.get('instruments').includes(instrument)) {
          batch.push(instrument);

          batchUpdate(this);
        }
      };
    }()),

    getLiveInterestCount () {
      return this.filter(auction => auction.get('runningState') !== auction.EContentState.eNone)
        .reduce((acc, auction) => acc + auction.getInterestCount(), 0);
    },

    getLiveTradeCount () {
      return this.filter(auction => auction.get('runningState') !== auction.EContentState.eNone)
        .reduce((acc, auction) => acc + auction.getTradeCount(), 0);
    }

  });

  context.dataStore.auctions = new context.dataStore.collectionDefinitions.AuctionCollection([]);
}(window.BGC));
