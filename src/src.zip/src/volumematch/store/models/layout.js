/* eslint-disable max-lines,max-len,no-magic-numbers,no-param-reassign,func-names */
/* global BGC: false, _:false, Backbone: false*/
/* eslint-disable max-len */
import {postEventMetric} from '@core-tech/web-api';
import broadcastAuctionWindowState from '../../views/windowstatehelper';
import getApp from '../../index';

// eslint-disable-next-line max-params,no-shadow-restricted-names
(function (namespace, models, collections, undefined) {
  const AUCTION_POPULATION_QOS_REPORT_TIMER_DELAY_MILLISECS = 10000;
  const AUCTION_POPULATION_QOS_ALERT_THRESHOLD_MILLISECS = 5000;

  /**
  Layout Model: contains the details of the VM page layout and global VM parameters for the page

  Attributes:
   titleId:                                  String:                 identifies the header title
   businessConfig:                           String:                 business configuration e.g. IRO, IRS, EUR_INFLATION ...
   pageId:                                   String:                 unique page identifier e.g. LM_DOCUMENT_INF_FIXINGS
   pageName:                                 String:                 page display name
   currencyId:                               String:                 auction currency identifier
   isEditable:                               Boolean:                whether the layout is editable e.g. through the roll process
   startTime:                                Number:                 start time of first auction to start
   endTime:                                  Number:                 end time of last auction to end
   timeOffset:                               Number:                 time offset in seconds between server and browser
   matrices:                                 Matrix collection:
   tiles:                                    Tile Collection:        other standard tiles within auction
   allowSpreadCreation:                      Boolean:                defines whether custom spread instrument creation is allowed
   matrixInstruments:                        Instrument Collection:  list of matrix instruments ordered by maturity
   isExcelAddInEnabled:                      Boolean:                stores whether the Excel Add-in is currently enable
   areAllExcelLiveLinksEnabled:              Boolean:                stores whether all Excel Live Links are enabled
   nomenclature:                             Enum:                   enumerant, determines what title text to use for Buy/Sell etc in tile tiles and orders vie
   auctions:                                 Auction Collection:     The auctions currently running within the page
   areAuctionsStarting:                      Boolean:                True if one or more auctions are in the process of starting (based on heuristic - if after 10s, no further instruments enter the auction, we assume the auction is fully populated)
   areInstrumentsBeingAddedToRunningAuction: Boolean:                True if instruments are being added to one or more auctions after they have already been started (based on heuristic - if after 10s, no further instruments enter the auction, we assume the last instrument has been added)
   auctionPopulationStartTimeUtc             Number:                 The time in milliseconds since 1970 (UTC) when we began populating the window with auctions
   auctionPopulationEndTimeUtc               Number:                 The time in milliseconds since 1970 (UTC) when all the auctions completed population
   firstInstrumentInAuctionSession:          Instrument Model        The first instrument to enter an auction session after any previous session has ended
   isLayoutRecalcPending:                    Boolean:                determines whether a recalcLayout is currently pending
   brokerLiveMode:                           Number:                 active live filter mode is set for broker e.g. (Show All, 1-ShowMyOrdersAndGlows, 2-ShowMyOrdersOnly...)
    traderLiveMode:                          Number:                 active live filter mode is set for trader e.g. (Show All, 1-ShowMyOrdersAndGlows, 2-ShowMyOrdersOnly...)
   */

  models.Layout = Backbone.Model.extend({
    defaults : {
      titleId                                            : '',
      businessConfig                                     : '',
      vmTerminology                                      : '',
      pageId                                             : '',
      pageName                                           : '',
      currencyId                                         : '',
      isEditable                                         : false,
      startTime                                          : 0,
      endTime                                            : 0,
      timeOffset                                         : 0,
      matrices                                           : undefined,
      tiles                                              : undefined,
      allowSpreadCreation                                : false,
      isExcelAddInEnabled                                : false,
      areAllExcelLiveLinksEnabled                        : false,
      isMoveableMidEnabled                               : false,
      nomenclature                                       : 'bidOffer',
      auctions                                           : undefined,
      areAuctionsStarting                                : false,
      areInstrumentsBeingAddedToRunningAuction           : false,
      auctionPopulationStartTimeUtc                      : 0,
      auctionPopulationEndTimeUtc                        : 0,
      auctionPopulationClientProcessingDurationMilliSecs : 0,
      firstInstrumentInAuctionSession                    : null,
      isLayoutRecalcPending                              : false,

      // All generic column identifiers supported by the application
      permissibleGenericColumns : ['volume', 'strike1Display', 'strike2Display', 'deltaDisplay', 'straddleDisplay', 'ratioDisplay', 'crossDisplay', 'priceBDisplay'],

      // Generic column definitions for a particular VM Document
      genericColumns : [],
      brokerLiveMode : 0,
      traderLiveMode : 0
    },

    initialize () {
      BGC.logger.logInformation('layout-model', `Initializing layout model for VM Page [${document.title}|${this.get('pageId')}].`);

      this.set('tiles', new collections.Tiles([]));
      this.set('matrices', new collections.MatrixList([]));
      this.set('auctions', new collections.AuctionCollection([]));

      // The "dormant" auction is the default auction object for everything that
      // needs one and is not currently associated with a running VM
      this.get('auctions').add(new models.Auction({auctionId : 'dormant'}));

      // Set terminology to default - we will revisit how to drive terminology from brand and business as we
      // onboard businesses through GBX Rates
      this.set('vmTerminology', BGC.resources.IDS_VM);

      this.tileAuctionState = {
        anyThirdPartyGlowsEnabled : false
      };

      this.broadcastInstrumentCountChanged = _.debounce(this.trigger.bind(this, 'activeInstrumentCountChanged'), 300);
    },

    // eslint-disable-next-line complexity,max-statements
    processInstrumentMsg (instrument, updateMsg, msgState) {
      const startTimeMilliSecs = performance.now();
      const wasInAuctionState = this.areAnyInstrumentsInAuction();
      const hadIndicativePrices = this.doAnyInstrumentsHaveIndicativeMids();
      let auction = null;
      let isInAuctionState = false;
      const indicativeAuction = this.getOrAddAuction('indicative');
      const displayCustomSpreads = namespace.dataStore.userSettingsStore.get('displayCustomSpreads');

      // Check to see if the auction session is starting, if instruments are being added to
      // the session or if the session is ending.
      if (!wasInAuctionState && msgState.isEnteringVM) {
        BGC.logger.logInformation('layout-model', `Auction session started, firstInstrument[${instrument.getLogDescStr()}].`);

        // Store the first instrument in the auction session and the start time.
        this.set({
          areAuctionsStarting                                : true,
          auctionPopulationStartTimeUtc                      : Date.now(),
          auctionPopulationClientProcessingDurationMilliSecs : 0,
          firstInstrumentInAuctionSession                    : instrument
        });
      } else if (msgState.isEnteringVM && !updateMsg.spread &&
        !this.get('areAuctionsStarting') && !this.get('areInstrumentsBeingAddedToRunningAuction')) {
        BGC.logger.logInformation('layout-model', `Instruments added to auction session, firstInstrument[${instrument.getLogDescStr()}].`);

        // If an instrument is being added to a running auction store the start time.
        this.set({
          areInstrumentsBeingAddedToRunningAuction : true,
          auctionPopulationStartTimeUtc            : Date.now()
        });
      }

      // Check to see if the instrument is entering or leaving a specific auction and notify that auction.
      // NOTE: This code is based on knowledge that the instrument model has already been updated to point
      // at its new auction object. Thus to accurately maintain the state of an auction that the instrument
      // is leaving, we have to update its PREVIOUS auction, not its current auction.
      // I don't like this interdependency between when the instrument is updated, when the layout is updated
      // and when the auction state is updated - it seems very fragile.
      if (msgState.isEnteringVM || msgState.isLeavingVM) {
        auction = msgState.isEnteringVM ? instrument.get('auction') : instrument.get('prevAuction');
        auction.onInstrumentActiveStateChange(instrument, msgState.isEnteringVM);

        if (msgState.isEnteringVM) {
          // Page must be in VM state if instrument is entering VM state!
          isInAuctionState = true;

          // For a mixed matrix/list based auction, the GTI transformer may send an auction start message before the matrix instrument
          // updates have been received. Under this scenario we need to check the instrument update to see whether spread creation is
          // supported.
          if (!this.get('allowSpreadCreation') && displayCustomSpreads && instrument.get('classification') !== -1) {
            this.set('allowSpreadCreation',
              Boolean(this.getMatrixInstruments().find(matrixInstr => matrixInstr.get('instrumentId') === instrument.get('instrumentId'))));
          }
        } else {
          // Check if any instruments left in VM state
          isInAuctionState = this.areAnyInstrumentsInAuction();

          // If leaving auction and there are instruments with indicative (that never went into the auction)
          // then once all instruments are out of auction we can re-display the indicatives
          if (this.doAnyInstrumentsHaveIndicativeMids() && !isInAuctionState && indicativeAuction.isSuspended) {
            indicativeAuction.isSuspended = false;
            indicativeAuction.trigger('change:runningState', indicativeAuction, true);
          }
        }
      } else if (!msgState.isEnteringVM && !msgState.isLeavingVM) {
        // No VM state change for this instrument so it is what it was for the whole page
        isInAuctionState = wasInAuctionState;
      }

      if (msgState.isEnteringIndicative || msgState.isLeavingIndicative) {
        auction = msgState.isEnteringIndicative ? instrument.get('auction') : instrument.get('prevAuction');
        auction.onInstrumentIndicativeStateChange(instrument, msgState.isEnteringIndicative);
      }

      if (instrument.isMoveableMidEnabled()) {
        if (!this.get('isMoveableMidEnabled')) {
          const mmEnabledDetails = {
            id                           : instrument.getLogDescStr(),
            auction                      : instrument.get('auction').get('auctionId'),
            midPrice                     : instrument.get('midPrice'),
            minBidPrice                  : instrument.get('minBidPrice'),
            maxBidPrice                  : instrument.get('maxBidPrice'),
            minOfferPrice                : instrument.get('minOfferPrice'),
            maxOfferPrice                : instrument.get('maxOfferPrice'),
            isMoveableMidEnabledBuySide  : instrument.isMoveableBidEnabled(),
            isMoveableMidEnabledSellSide : instrument.isMoveableOfferEnabled()
          };

          BGC.logger.logInformation('layout-model', `Instrument Update triggered display of moveable mid controls: ${JSON.stringify(mmEnabledDetails)
          } isPricingAwayFromMidAllowed ${instrument.get('isPricingAwayFromMidAllowed')}`);
        }
        this.set('isMoveableMidEnabled', true);
      }

      if (msgState.isLeavingVM && wasInAuctionState) {
        // Clear the first instrument in the auction session (used for QoS code).
        BGC.logger.logInformation('layout-model', `Auction session ended, lastInstrument[${instrument.getLogDescStr()}].`);

        this.set({
          firstInstrumentInAuctionSession : null
        });

        if (this.auctionPopulationQoSEventCoalescenceTimer) {
          clearTimeout(this.auctionPopulationQoSEventCoalescenceTimer);
          this.auctionPopulationQoSEventCoalescenceTimer = null;

          // The auction(s) ended before the timer fired.
          BGC.logger.sendQoSEvent({
            type                              : this.get('areAuctionsStarting') ? 'auctionWindowPopup' : 'auctionWindowAdd',
            databaseKeyName                   : 'HTML_VM_POPUP',
            startTimeUtc                      : this.get('auctionPopulationStartTimeUtc'),
            endTimeUtc                        : this.get('auctionPopulationEndTimeUtc'),
            alertThresholdMilliSecs           : AUCTION_POPULATION_QOS_ALERT_THRESHOLD_MILLISECS,
            eventReportDelayMilliSecs         : Date.now() - this.get('auctionPopulationEndTimeUtc'),
            clientProcessingDurationMilliSecs : this.get('auctionPopulationClientProcessingDurationMilliSecs')
          });
        }

        this.resetQoSMetrics();
      }

      // We don't want to change the state of anything if indicatives are added/removed
      // while the auction is running, but we DO want to cause any necessary changes of view state when:
      // 1. The auction starts or stops
      // 2. We want to display or hide indicatives
      if ((wasInAuctionState !== isInAuctionState) ||
                (!isInAuctionState && (hadIndicativePrices !== this.doAnyInstrumentsHaveIndicativeMids()))) {
        if (!isInAuctionState) {
          this.set('isMoveableMidEnabled', false);
        }

        if (wasInAuctionState !== isInAuctionState) {
          // reset filter to show all if no instrument are active
          this.set('brokerLiveMode', BGC.enums.EVMShowLiveMode.eShowAll);
          this.set('traderLiveMode', BGC.enums.EVMShowLiveMode.eShowAll);
        }

        this.trigger('change:contentState');
      }

      // Check to see if the instrument is entering an auction during auction population.
      if (msgState.isEnteringVM) {
        const durationMilliSecs = performance.now() - startTimeMilliSecs;

        // Update the auction-specific population end time.
        auction.notifyAuctionPopulationStepCompleted(instrument, undefined, durationMilliSecs);

        this.notifyAuctionPopulationStepCompleted(instrument);

        // Maintain a running total of the time taken to process all of the instrument
        // updates.
        this.set('auctionPopulationClientProcessingDurationMilliSecs', this.get('auctionPopulationClientProcessingDurationMilliSecs') + durationMilliSecs);
      }
    },

    addMatrices (matrixListMsg, dataStore) {
      const matrixList = matrixListMsg.reduce((matrices, matrix) => {
        BGC.logger.logInformation('layout-model', `Creating Matrix model: ${matrix.matrixId}.`);

        if (matrix.layoutType === 'matrix') {
          matrices.push(_.extend(matrix, {linkedMatrices : []}));
        } else {
          _.last(matrices).linkedMatrices.push(matrix);
        }

        return matrices;
      }, []);

      this.get('matrices').add(matrixList.map(function (matrix) {
        return models.Matrix.build(matrix, this, dataStore);
      }, this));
    },

    addTiles (tileListMsg) {
      if (tileListMsg.length > 0) {
        const tileModels = tileListMsg.map(function (tileMsg) {
          BGC.logger.logInformation('layout-model', `Creating Tile model: ${tileMsg.tileId}.`);

          const tile = new models.Tile({
            pageLayout           : this,
            tileId               : tileMsg.tileId,
            tileName             : tileMsg.tileName,
            excludeFromFavorites : tileMsg.excludeFromFavorites,
            layoutType           : tileMsg.layoutType,
            instruments          : []
          });

          this.get('tiles').add(tile);
          tile.updateContentFromInstrumentList(tileMsg.instrumentList);

          return tile;
        }, this);

        tileModels.forEach(function (tile) {
          this.listenTo(tile, 'activeInstrumentCountChanged', this.broadcastInstrumentCountChanged);
          this.listenTo(tile, 'glowCountChanged', this.trigger.bind(this, 'glowCountChanged'));
          this.listenTo(tile, 'tradeCountChanged', this.trigger.bind(this, 'tradeCountChanged'));
          this.listenTo(tile.auction, 'change:runningState change:showThirdPartyInterestGlows', this.tileAuctionStateChanged);
          this.tileAuctionStateChanged();
        }, this);
      }
    },

    getGenericColumnIdentifiers () {
      const identifiers = [];

      this.get('genericColumns').forEach(columnDefinition => {
        identifiers.push(columnDefinition.columnId);
      });

      return identifiers;
    },

    getFavoritesExclusionList () {
      return this.get('tiles').where({
        excludeFromFavorites : true
      }).map(tile => tile.get('tileId'));
    },

    setLiveModeForActiveUser (selection) {
      this.set(BGC.dataStore.isBrokerMode() ? 'brokerLiveMode' : 'traderLiveMode', selection);
    },

    getLiveModeForActiveUser () {
      return BGC.dataStore.isBrokerMode() ? this.get('brokerLiveMode') : this.get('traderLiveMode');
    },

    addAuction (auction, internalOnly) {
      BGC.logger.logInformation('layout-model', `Adding auction: ${auction.get('auctionId')}.`);

      this.get('auctions').add(auction);
      if (!internalOnly) {
        this.listenTo(auction, 'change:runningState', this.onAuctionStateChanged);
      }
    },

    getOrAddAuction (auctionId, internalOnly) {
      if (!auctionId) {
        return null;
      }
      let theAuction = this.get('auctions').get(auctionId);

      if (!theAuction) {
        theAuction = new models.Auction({auctionId, hiddenColumns : this.getGenericColumnIdentifiers(), layout : this});
        this.addAuction(theAuction, internalOnly);
      }

      return theAuction;
    },

    // eslint-disable-next-line complexity,max-statements
    onAuctionStateChanged (auction, running) {
      const displayCustomSpreads = namespace.dataStore.userSettingsStore.get('displayCustomSpreads');
      let matrixInstruments = [];

      if (auction.get('auctionId') === 'indicative') {
        return;
      }

      BGC.logger.logInformation('layout-model', `Auction [${auction.get('auctionId')}] state changed to [${running ? 'running' : 'ended'}].`);

      if (!running) {
        // An auction has just ended. Is it the last running auction?
        if (!_.find(this.get('auctions').without('indicative', 'dormant'), auctionModel => auctionModel.get('runningState') !== auction.EContentState.eNone)) {
          this.set('isMoveableMidEnabled', false);
          this.set('allowSpreadCreation', false);
        } else if (this.hasMatrices() && this.get('allowSpreadCreation')) {
          // Auction ended but others are still running.
          // Are any matrix auctions still running that support spread creation or not?
          matrixInstruments = this.getMatrixInstruments();
          if (matrixInstruments.length) {
            this.set('allowSpreadCreation', _.some(matrixInstruments, instrument => instrument.get('auction').get('runningState') &&
                                instrument.get('auction').get('auctionId') !== 'indicative' &&
                                instrument.get('classification') !== -1, this));
          }
        }
      } else if (this.hasMatrices() && displayCustomSpreads && !this.get('allowSpreadCreation')) {
        // An auction has just started and this layout includes a matrix.
        // Are there any matrix instruments in that auction that support spread creation?
        matrixInstruments = this.getMatrixInstruments();
        if (matrixInstruments.length) {
          this.set('allowSpreadCreation', _.some(matrixInstruments, instrument => instrument.get('auction') === auction && instrument.get('classification') !== -1, this));
        }
      }

      if (running) {
        // An auction has just started. Clear the filtering setting.
        this.set('brokerLiveMode', BGC.enums.EVMShowLiveMode.eShowAll);
        this.set('traderLiveMode', BGC.enums.EVMShowLiveMode.eShowAll);
        broadcastAuctionWindowState();
      }
    },

    areAnyInstrumentsInAuction () {
      const firstRunningAuction = this.get('auctions').find(auction => auction.get('runningInstrumentCount') > 0 && auction.get('auctionId') !== 'indicative');

      return firstRunningAuction !== undefined;
    },

    getActiveAuctions () {
      const auctions = this.get('auctions');

      // "isAuctionStarting" equal to "true" means auction has started therefore an active auction

      return auctions.models.filter(auction => auction.attributes.isAuctionStarting === true);
    },

    doAnyInstrumentsHaveIndicativeMids () {
      return this.getOrAddAuction('indicative').get('runningInstrumentCount') > 0;
    },

    clearAuctionTotals (viewId) {
      BGC.eventsHandler.onClick(viewId, 'clearAuctionTotals');
    },

    copyExcelLinks (viewId) {
      BGC.eventsHandler.onClick(viewId, 'vmCopyExcelLinks');
    },

    toggleExcelLiveLinksAll (viewId) {
      this.set('areAllExcelLiveLinksEnabled', !this.get('areAllExcelLiveLinksEnabled'));

      BGC.eventsHandler.onClick(viewId, 'vmToggleExcelLiveLinksAll');
    },

    updateExcelAddInState (message) {
      this.set('isExcelAddInEnabled', message.isExcelAddInEnabled);
    },

    hasMatrices () {
      return !!this.get('matrices').length;
    },

    hasTiles () {
      return !!this.get('tiles').length;
    },

    tileAuctionStateChanged () {
      const wereAnyThirdPartyGlowsEnabled = this.tileAuctionState.anyThirdPartyGlowsEnabled;
      const areAnyThirdPartyGlowsEnabled = this.hasTileWithShowInterestGlows();

      if (wereAnyThirdPartyGlowsEnabled !== areAnyThirdPartyGlowsEnabled) {
        this.trigger('change:tileAuctionState');
      }

      this.tileAuctionState.anyThirdPartyGlowsEnabled = areAnyThirdPartyGlowsEnabled;
    },

    hasTileWithShowInterestGlows () {
      const showInterestGlows = this.get('tiles').some(tile => {
        const {auction} = tile;

        return auction.get('runningState') && auction.get('showThirdPartyInterestGlows');
      });

      return showInterestGlows;
    },

    getTilesActiveInstrumentCount () {
      return this.get('tiles').reduce((runningTotal, tile) => runningTotal + tile.getActiveInstrumentCount(), 0);
    },

    getTilesGlowCount () {
      return this.get('tiles').reduce((runningTotal, tile) => runningTotal + (tile.auction.get('showInterestAndTradeCount') ? tile.getInterestCount() : 0), 0);
    },

    getTilesTradeCount () {
      return this.get('tiles').reduce((runningTotal, tile) => runningTotal + (tile.auction.get('showInterestAndTradeCount') ? tile.getTradeCount() : 0), 0);
    },

    getMatrixInstruments () {
      return _.flatten(this.get('matrices').invoke('getInstruments'));
    },

    getTileInstruments () {
      return _.flatten(this.get('tiles').invoke('getInstruments'));
    },

    getInstruments () {
      return this.getMatrixInstruments().concat(this.getTileInstruments());
    },

    // Returns the 'single' custom spreads tile if the auction supports spread creation
    getCustomSpreadTile () {
      return this.get('tiles').findWhere({layoutType : 'spread'});
    },

    // Returns the 'single' matrix or tile layout that matches the given id
    findLayout (id) {
      let layout = this.get('matrices').findWhere({matrixId : id}) ||
                this.get('tiles').findWhere({tileId : id});

      if (!layout) {
        // Check for linked matrices
        this.get('matrices').forEach(matrix => {
          layout = layout || matrix.get('linkedMatrices').findWhere({matrixId : id});
        });
      }

      return layout;
    },

    isMoveableMidEnabled () {
      return this.get('isMoveableMidEnabled');
    },

    closeAllInstrumentViews (exceptInstrument) {
      this.set('brokerLiveMode', BGC.enums.EVMShowLiveMode.eShowAll);
      this.set('traderLiveMode', BGC.enums.EVMShowLiveMode.eShowAll);
      this.trigger('closeAllInstrumentViews', exceptInstrument);
    },

    /**
         * Because we do not have any real way (yet) to determine which is the
         * last instrument being processed as part of an auction, we throttle
         * the execution of this function so that it won't be executed for each
         * instrument message (after profiling, it looks like clearing and setting
         * an interval is quite an expensive operation if done repeatedly)
         */
    updateAuctionPopulationEndTime : _.throttle(function () {
      // eslint-disable-next-line consistent-this
      const layout = this;
      const {id: appId, path : appPath, desk} = getApp();
      const {userID} = BGC.dataStore.getPrimaryUserDetails();

      // Update the auction population end time.
      this.set('auctionPopulationEndTimeUtc', Date.now());

      if (this.auctionPopulationQoSEventCoalescenceTimer) {
        clearTimeout(this.auctionPopulationQoSEventCoalescenceTimer);
      }

      // If no instrument processing has occured for 10s, we assume the auction window
      // is fully populated and send the QoS event.
      this.auctionPopulationQoSEventCoalescenceTimer = setTimeout(() => {
        BGC.logger.sendQoSEvent({
          type                              : layout.get('areAuctionsStarting') === true ? 'auctionWindowPopup' : 'auctionWindowAdd',
          databaseKeyName                   : 'HTML_VM_POPUP',
          startTimeUtc                      : layout.get('auctionPopulationStartTimeUtc'),
          endTimeUtc                        : layout.get('auctionPopulationEndTimeUtc'),
          alertThresholdMilliSecs           : AUCTION_POPULATION_QOS_ALERT_THRESHOLD_MILLISECS,
          eventReportDelayMilliSecs         : Date.now() - layout.get('auctionPopulationEndTimeUtc'),
          clientProcessingDurationMilliSecs : layout.get('auctionPopulationClientProcessingDurationMilliSecs')
        });

        // Sending Auction Window Pop Up RTT to web-session
        postEventMetric(appPath, 'auctionStart', {
          appId,
          rtt        : layout.get('auctionPopulationEndTimeUtc') - layout.get('auctionPopulationStartTimeUtc'),
          user       : userID,
          desk,
          clientTime : new Date().toISOString()
        });

        layout.auctionPopulationQoSEventCoalescenceTimer = null;
        layout.resetQoSMetrics();
      }, AUCTION_POPULATION_QOS_REPORT_TIMER_DELAY_MILLISECS);
    }, 100),

    notifyAuctionPopulationStepCompleted (instrument, tile) {
      // Exclude spread instruments or operations involving spread tiles.
      if ((instrument && instrument.get('spread')) ||
        (tile && (tile.get('layoutType') === 'spread'))) {
        return;
      }

      if ((this.get('areAuctionsStarting') === true) ||
        (this.get('areInstrumentsBeingAddedToRunningAuction') === true)) {
        this.updateAuctionPopulationEndTime();
      }
    },

    resetQoSMetrics () {
      this.set({
        areAuctionsStarting                                : false,
        areInstrumentsBeingAddedToRunningAuction           : false,
        auctionPopulationStartTimeUtc                      : 0,
        auctionPopulationEndTimeUtc                        : 0,
        auctionPopulationClientProcessingDurationMilliSecs : 0
      });
    },

    getOptionalColHeader (headerName) {
      const {columnHeaders} = this.get('tabsLayout').find(column => column.ID === 'tab-control-view-portfolio-tab');

      const columnHeader = columnHeaders === undefined ? '' : columnHeaders.find(header => header.columnId === headerName);

      return columnHeader ? columnHeader.columnName : '';
    }
  });
}(window.BGC, window.BGC.dataStore.modelDefinitions, window.BGC.dataStore.collectionDefinitions));
