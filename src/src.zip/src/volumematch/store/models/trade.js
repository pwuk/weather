/* global BGC: false, Backbone: false, _: false*/
import getApp from '../../index';

// eslint-disable-next-line func-names
(function (context) {
  const {dataStore} = context;

  dataStore.modelDefinitions.Trade = Backbone.Model.extend({
    defaults : {
      state               : 0,
      instrumentId        : '',
      instrumentName      : '',
      strike1Display      : '',
      strike2Display      : '',
      deltaDisplay        : '',
      straddleDisplay     : '',
      ratioDisplay        : '',
      crossDisplay        : '',
      tradeId             : '',
      tradeGroupId        : '',
      tradeLegId          : 0,
      tradeTime           : -1,
      tradeTimeDisplay    : '',
      tradeSide           : 'none',
      tradePrice          : 0,
      tradeDisplayPrice   : '',
      tradeSize           : -1,
      accountId           : '',
      accountName         : '',
      userId              : '',
      counterparty        : '',
      tradeType           : 'own',
      nomenclature        : 'bidOffer',
      priceBDisplay       : '',
      structureGroupingId : ''
    },

    isOwnTrade () {
      return this.get('tradeType') === BGC.schemaValidator.OWNERSHIP_MINE;
    },

    isSameLETrade () {
      return this.get('tradeType') === BGC.schemaValidator.OWNERSHIP_MY_FIRM;
    },

    isSameGroupTrade () {
      return this.get('tradeType') === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT;
    },

    getAdjustedNomenclature (stringId) {
      return BGC.resources.getAdjustedNomenclature(stringId, this.get('nomenclature'));
    }
  });

  /*
  *  Trade collection
  */
  dataStore.collectionDefinitions.Trades = Backbone.Collection.extend({
    model : dataStore.modelDefinitions.Trade,
    comparator (trade1, trade2) {
      // In a Backbone comparator function:
      // returning -1 signifies that arg1 should sort before arg2;
      // returning 1 signifies that arg2 should sort before arg1.
      let compare = 0;

      if (trade1.get('tradeTime') < trade2.get('tradeTime')) {
        compare = 1;
      } else if (trade1.get('tradeTime') > trade2.get('tradeTime')) {
        compare = -1;
      } else if (trade1.get('tradeGroupId') < trade2.get('tradeGroupId')) {
        compare = 1;
      } else if (trade1.get('tradeGroupId') > trade2.get('tradeGroupId')) {
        compare = -1;
      } else if (trade1.get('tradeLegId') < trade2.get('tradeLegId')) {
        compare = -1;
      } else if (trade1.get('tradeLegId') > trade2.get('tradeLegId')) {
        compare = 1;
      }

      return compare;
    },

    // eslint-disable-next-line complexity, max-statements
    onVMTradeExecution (tradeUpdateMsg, tradeNotificationType, instrument) {
      const {id : appId} = getApp();
      const {
        eOrderExecution,
        eConfirm
      } = BGC.enums.ETradeNotification;

      const trade = tradeUpdateMsg.match || tradeUpdateMsg.execution;
      let tradePrice = trade.price.number;
      let tradeDisplayPrice = trade.price.string;
      let {strike1Display = '', strike2Display = ''} = trade;

      // Remove percentage formatting if this is an 'Exotics' instrument
      // N.B. GTI should publish price type for generic attributes in the long term
      if (appId === 'LM_DOCUMENT_VM_IRO_EUR_EXOTICS') {
        if (strike1Display.endsWith('%')) {
          strike1Display = strike1Display.slice(0, -1);
        }

        if (strike2Display.endsWith('%')) {
          strike2Display = strike2Display.slice(0, -1);
        }
      }

      // For everything other than confirms, we should have have an instrument
      if (tradeNotificationType !== eConfirm && instrument) {
        const pickGivePrefix = instrument.getPickGiveIndicator(trade.side);

        // For pick/give instruments, the sign of the mid price combined
        // with the side of the order will tell us whether the order price should appear as
        // Give Up (-ive) or Pick Up (+ive), and therefore whether the order price sign
        // should be flipped for presentation purposes (since the data we receive for trade price
        // will always carry the same sign as the VM mid price)
        if (pickGivePrefix === '+') {
          // Ensure price is positive
          tradePrice = Math.abs(trade.price.number);
        } else if (pickGivePrefix === '-') {
          // Ensure price is negative
          tradePrice = -Math.abs(trade.price.number);
        }

        // If it is for a SPREAD instrument then the live display price of the D1 should be used
        // as the display price instead of the formatted mid-price of the spread itself, but
        // only for IRO Spreads.
        tradeDisplayPrice = instrument.get('spread') &&
          instrument.get('spread').get('displayUnderlyingPrices') ? instrument.get('spread').getInstrument(0)
            .get('priceDisplay') : instrument.formatPrice(tradePrice);
      }

      const MILLIS_IN_SEC = 1000;

      // Create new trade from update message
      const tradeUpdate = new dataStore.modelDefinitions.Trade({
        state            : tradeNotificationType,
        instrumentId     : tradeUpdateMsg.instrumentId,
        instrumentName   : tradeUpdateMsg.instrumentName,
        nomenclature     : tradeUpdateMsg.nomenclature || 'bidOffer',
        strike1Display,
        strike2Display,
        priceBDisplay    : trade.priceBDisplay || '',
        deltaDisplay     : trade.deltaDisplay || '',
        straddleDisplay  : trade.straddleDisplay || '',
        ratioDisplay     : trade.ratioDisplay || '',
        crossDisplay     : trade.crossDisplay || '',
        tradeId          : trade.id,
        tradeGroupId     : trade.matchId,
        tradeLegId       : tradeUpdateMsg.tradeLegId,
        tradeTime        : trade.tradeTime,
        tradeTimeDisplay : trade.tradeTimeDisplay ||
         new Date(trade.tradeTime * MILLIS_IN_SEC).toTimeString().split(' ')[0],
        tradeSide           : trade.side,
        tradePrice,
        tradeDisplayPrice,
        tradeSize           : trade.size,
        accountName         : tradeUpdateMsg.accountName || '',
        accountId           : tradeUpdateMsg.accountId,
        userId              : tradeUpdateMsg.traderId,
        counterparty        : trade.counterparty,
        tradeType           : trade.type,
        structureGroupingId : trade.structureGroupingId
      });

      // If this is an order execution, add execution to the corresponding order
      if (tradeNotificationType === eOrderExecution) {
        dataStore.orderStore.onOrderExecutionUpdate(tradeUpdate);
      } else {
        // Update auction history (execution/summary waterfalls, trade confirms)
        this.update(tradeUpdate);
      }
    },

    update (tradeUpdate) {
      const updateState = tradeUpdate.get('state');
      const tradeGroup = this.where({tradeGroupId : tradeUpdate.get('tradeGroupId')});

      // it this is a 'trade confirmation' or a 'trade summary',
      // retrieve any existing legs associated with given trade group
      if (updateState === BGC.enums.ETradeNotification.eSummary ||
        updateState === BGC.enums.ETradeNotification.eConfirm) {
        if (tradeGroup) {
          if (updateState === BGC.enums.ETradeNotification.eConfirm) {
            // Ignore duplicate trade confirms (potentially we could receive a duplicate following session loss)
            if (_.find(tradeGroup, trade => trade.get('tradeId') === tradeUpdate.get('tradeId'))) {
              return;
            }

            // 'Trade confirmation' - remove all existing 'summary' and 'execution' trades
            this.remove(_.filter(tradeGroup, trade => trade.get('state') === BGC.enums.ETradeNotification.eSummary ||
              trade.get('state') === BGC.enums.ETradeNotification.eExecution ||
              trade.get('state') === BGC.enums.ETradeNotification.eOrderExecution), {silent : true});
          } else {
            // 'Trade Summary' - remove all existing executions for this trade group
            this.remove(_.filter(tradeGroup, trade => trade.get('state') === BGC.enums.ETradeNotification.eExecution ||
              trade.get('state') === BGC.enums.ETradeNotification.eOrderExecution), {silent : true});
          }
        }
      }

      // Add trade to collection
      this.add(tradeUpdate);
      this.trigger('change');
    }
  });

  dataStore.auctionHistory = new dataStore.collectionDefinitions.Trades([]);
}(window.BGC));
