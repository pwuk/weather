/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */
///////////////////////////////////////////////////////////////////////////////
// Single source of truth for global application's selection,
// which consists of an instrument and a view within which the selection was made.
//
// When a caller attempts to change the selection, then if the currently selected view
// implements a clearSelection method, it will be called first. If views involved in
// making selections do not implement such a method, then they should implement a handler
// for the "selectionChanging" event instead (and listen to this singleton for it),
// should they need to adjust their internal state or styling when the selection moves away.
//
// The view/instrument in the selection object provided to "selectionChanging" event handlers
// are those that were previously selected. Views may also listen to and handle "selectionChanged"
// events from this manager. For these events, the event handlers will receive an object
// referencing the newly selected view/instrument.
///////////////////////////////////////////////////////////////////////////////

(function (context, undefined) {
    "use strict";

    // Function returns singleton object
    context.selectionManager = (function () {
		// Private data
		var _selection = { view: null, instrument: null };
		
        // Private Constructor
        var SelectionManager = function () {
			if (!(this instanceof SelectionManager)) {
				throw new Error("Constructor called as a function.");
			}
			
			// Build in pub/sub eventing support from Backbone.js
			_.extend(this, Backbone.Events);
			
		};

		SelectionManager.prototype.setSelection = function (view, instrument) {
			var oldInstSelection = _selection.instrument;
			
			if (view !== _selection.view || instrument !== _selection.instrument) {
    			this.trigger("selectionChanging", this.getSelection(), { view: view, instrument: instrument });
			}
			
			_selection.view = view;
			_selection.instrument = instrument;
			
			if (!instrument && oldInstSelection) {
				BGC.logger.logInformation("VM: " + document.title, "Selection cleared");
				this.trigger("selectionChanged", this.getSelection());
            } else if (instrument !== oldInstSelection) {
				BGC.logger.logInformation("VM: " + document.title, "Selection changed to instrument " + instrument.getLogDescStr());
				this.trigger("selectionChanged", this.getSelection());
			}
		};
		
		SelectionManager.prototype.getSelection = function () {
			// Return a copy so that selection cannot be directly manipulated by callers
			return { view: _selection.view, instrument: _selection.instrument };
		};
		
		SelectionManager.prototype.getSelectedView = function () {
			return _selection.view;
		};
		
		SelectionManager.prototype.getSelectedInstrument = function () {
			return _selection.instrument;
		};

        return new SelectionManager();
    }());
}(window.BGC.ui));
