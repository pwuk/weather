/* eslint-disable func-names, complexity, no-param-reassign, no-plusplus, max-lines, no-magic-numbers, max-statements, no-underscore-dangle, max-len, no-restricted-syntax */
/* global BGC, Backbone, $, _ */
/*
 * file datastore.js
 * BGC Data store module implementation.
 */

import {logger} from '@core-tech/web-api';
import {UserSettings} from '@core-tech/web-api/user-settings';
import {find} from 'lodash';
import {isWebDeployed} from '../bgc';
import {playSound, sounds} from '../utils/sound-service';
import getApp from '../index';

const MILLISECONDS_IN_DAY = 24 * 60 * 60 * 1000;

function initDataStore (context) {
  context.DataStore = function () {
    if (!(this instanceof context.DataStore)) {
      throw new Error('Constructor called as a function.');
    }

    // Construct from base class first
    context.BackboneDataStore.call(this);

    // Augment the schema for this application
    BGC.schemaValidator.getInstance().augmentSchema(this);

    // For the GTI flow, we need to cache any 'auction' messages we may receive before the layout has loaded
    this.preInitAuctionMsgCache = [];

    // Storage for accounts/users details and active account selection.
    // Private members with public accessors.
    const that = this;
    let accounts = null;
    let activeAccount = '';
    let loggedInUserID = '';
    let loggedInUserType = '';

    // Private functions
    const _setActiveAccount = function (account) {
      BGC.utils.trace(`Changing active account ID from [${activeAccount}] to [${account}]`);
      activeAccount = account;
      that.trigger('accountSelectionChanged');
    };

    // Public functions that access private data
    this.processUserLogin = function (login, layout) {
      const {desk} = getApp();
      const {
        role, managedTraders = [], login : userId, desks, name
      } = login;
      const [firstName, lastName] = name.split(' ');
      let displayIndex = 0;

      loggedInUserID = userId;
      loggedInUserType = managedTraders.length > 0 ? 'salesTrader' : role;

      // Filter managed trader accounts by the application (page) desk
      const managedAccounts = managedTraders.filter(account => account.desks.includes(desk));

      // Adding a default broker account for salesTrader (broker with managed traders) to use Broker mode
      if (loggedInUserType === 'salesTrader' && find(layout.settings, {name : 'displayCustomSpreads'})) {
        managedAccounts.unshift({
          login : loggedInUserID,
          desks,
          alias : `${firstName[0]}. ${lastName}`,
          role  : 'eBroker'
        });
      }

      BGC.logger.logInformation('datastore', `Processing User Login, initializing ${loggedInUserType} account for ${userId}, received ${managedTraders.length} managed accounts`);

      // Initialize managed trader accounts
      this.initializeAccounts(managedAccounts.map(account => ({
        id           : account.login,
        invariantId  : account.login,
        accountId    : account.login,
        desks        : account.desks,
        screenName   : account.alias,
        shortName    : account.alias,
        enabled      : true,
        accountType  : account.role === 'eBroker' ? 'eBroker' : 'ePassiveTrader',
        // eslint-disable-next-line no-plusplus
        displayIndex : displayIndex++
      })));
    };

    // Playing sounds and restoreVMWindow on trade is driven either by eOrderExecution when the auction preference
    // 'Show VM Execution Immediately' is switch on or by vmOrderUpdate when it is switch off since
    // eOrderExecution is not send when it is off
    this.playExecutionSound = function (type) {
      const playSoundWhenAnyOrderTrades = this.userSettingsStore.get('playSoundWhenAnyOrderTrades');
      const playSoundWhenMyOrderTrades = this.userSettingsStore.get('playSoundWhenMyOrderTrades');

      // Play sounds when 'Own' or 'My Firm' orders are executed
      if (playSoundWhenMyOrderTrades && type === BGC.schemaValidator.OWNERSHIP_MINE) {
        playSound(sounds.OWN_TRADE);
      } else if (playSoundWhenAnyOrderTrades && type !== BGC.schemaValidator.OWNERSHIP_MINE) {
        playSound(sounds.COUNTER_PARTY_TRADE);
      }
    };

    this.restoreVMWindow = function (tradeType) {
      const {mainWindow} = getApp();

      // Restore window when 'Own' order is executed
      if (tradeType === BGC.schemaValidator.OWNERSHIP_MINE && this.userSettingsStore.get('restoreWindowOnOwnTrade')) {
        mainWindow.restore();
      }
    };

    this.getPrimaryUserDetails = function () {
      return {
        userID   : loggedInUserID,
        userType : loggedInUserType
      };
    };

    // User type for broker with managed traders is salesTrader
    // We provided broker account in the managed account list
    // Therefore, a salesTrader current active account is the primary user, it is also in broker mode
    this.isBrokerMode = function () {
      return loggedInUserType === 'broker' || (this.isSalesTraderMode() && this.getActiveAccountId() === loggedInUserID);
    };

    this.isActiveBrokerMode = function () {
      return loggedInUserType === 'activeBroker';
    };

    this.isSalesTraderMode = function () {
      return loggedInUserType === 'salesTrader';
    };

    this.initializeAccounts = function (accountsList) {
      let selectionInvariantId = '';
      let firstAccount = null;

      if (accounts) {
        // Full refresh so see if we can restore the current selection afterwards
        selectionInvariantId = activeAccount ? activeAccount.get('invariantId') : '';

        accounts.reset(accountsList);
        accounts.trigger('change:favorites');

        this.setActiveAccountByInvariantId(selectionInvariantId);
      } else {
        accounts = new this.collectionDefinitions.Accounts(accountsList);
        accounts.trigger('change:favorites');

        firstAccount = accounts.findWhere({
          displayIndex : 0
        });
        this.setActiveAccountById(firstAccount ? firstAccount.get('id') : '');
      }
    };

    this.addAccountsObserver = function (observer, addCallback, favoritesCallback) {
      if (typeof observer.listenTo !== 'function') {
        _.extend(observer, Backbone.Events);
      }

      if (!accounts) {
        accounts = new this.collectionDefinitions.Accounts([]);
      }
      observer.listenTo(accounts, 'add', addCallback);
      observer.listenTo(accounts, 'change:favorites', favoritesCallback);
    };

    this.updateAccount = function (updateMsg) {
      const accountToUpdate = accounts.findWhere({
        invariantId : updateMsg.id
      });
      let sortedAccounts = [];
      let didFavoritesChange = false;

      if (accountToUpdate) {
        const currentDisplayIndex = accountToUpdate.get('displayIndex');

        if (currentDisplayIndex !== updateMsg.displayIndex) {
          didFavoritesChange = true;

          if (updateMsg.displayIndex === -1 && currentDisplayIndex !== -1) {
            // Removing account from display, so renumber 0-based
            // display indices of subsequent favourite accounts
            sortedAccounts = this.getFavouriteAccountsOrdered();
            const lastDisplayIndex = sortedAccounts.length - 1;

            if (currentDisplayIndex < lastDisplayIndex) {
              // eslint-disable-next-line max-depth
              for (let index = currentDisplayIndex + 1; index <= lastDisplayIndex; index++) {
                const displayIndex = sortedAccounts[index].get('displayIndex');

                sortedAccounts[index].set('displayIndex', displayIndex - 1);
              }
            }
          }
        }

        accountToUpdate.set({
          id           : updateMsg.accountId,
          fullName     : updateMsg.screenName,
          shortName    : updateMsg.shortName,
          enabled      : updateMsg.enabled,
          displayIndex : updateMsg.displayIndex
        });
        if (didFavoritesChange) {
          accounts.trigger('change:favorites');
        }
      } else {
        this.addAccount(updateMsg);
      }
    };

    this.addAccount = function (addMsg) {
      const model = new this.modelDefinitions.Account({
        id           : addMsg.accountId,
        fullName     : addMsg.screenName,
        shortName    : addMsg.shortName,
        invariantId  : addMsg.id,
        enabled      : addMsg.enabled,
        accountType  : addMsg.accountType,
        displayIndex : addMsg.displayIndex
      });

      accounts.add(model);
    };

    this.removeAccount = function (accountId) {
      accounts.remove(accountId);
    };

    this.getAccount = function (accountId) {
      if (accounts) {
        return accounts.get(accountId);
      }

      return undefined;
    };

    this.getFavouriteAccountsOrdered = function () {
      if (accounts) {
        const favourites = accounts.filter(account => account.get('displayIndex') !== -1);

        return _.sortBy(favourites, account => account.get('displayIndex'));
      }

      return [];
    };

    this.getActiveAccountId = function () {
      return activeAccount ? activeAccount.get('id') : '';
    };

    this.getActiveAccountInvariantId = function () {
      return activeAccount ? activeAccount.get('invariantId') : '';
    };

    this.setActiveAccountById = function (accountId) {
      _setActiveAccount(accounts.get(accountId));
    };

    this.setActiveAccountByInvariantId = function (invariantId) {
      _setActiveAccount(accounts.findWhere({
        invariantId
      }));
    };

    // Caches instruments by id, after first call. Uses zero index because of groupBy creating an array by default
    this.getInstrumentById = function (instrumentId) {
      return this.instruments.get(instrumentId);
    };

    this.storeInstrumentsForIdLookup = function (instruments) {
      this.instruments.add(instruments);
    };

    BGC.logger.logInformation('datastore', 'New datastore instance created');
  };

  // Inherit from BackboneDataStore
  context.DataStore.prototype = Object.create(context.BackboneDataStore.prototype);
  context.DataStore.prototype.constructor = context.DataStore;

  context.DataStore.prototype.initUserSettings = function () {
    // First call the base class to create the 'global' and 'defaults' collections
    context.BackboneDataStore.prototype.initUserSettings.call(this);

    // Configure setting 'defaults'
    // Note: use periodical persistence (3rd parameter - true) of setting changes to prevent
    // immediate persistence of settings back to the server whilst the page is loading
    this.userSettingsCollection.defaults.set('displaySpreadSecondLook', true, true);
    this.userSettingsCollection.defaults.set('enableInPlaceOrderEntry', true, true);
    this.userSettingsCollection.defaults.set('displayFavoritesSecondLook', true, true);
    this.userSettingsCollection.defaults.set('AllowBrokerRepriceLiveVM', false, true);
    this.userSettingsCollection.defaults.set('newPriceFlashDuration', 3000, true);
    this.userSettingsCollection.defaults.set('displayCustomSpreads', false, true);
    this.userSettingsCollection.defaults.set('displayFavorites', false, true);
    this.userSettingsCollection.defaults.set('displayPortfolio', false, true);
    this.userSettingsCollection.defaults.set('retainHistory', false, true);
    this.userSettingsCollection.defaults.set('maxAuctionHistoryCount', -1, true);
    this.userSettingsCollection.defaults.set('disableBatchSubmission', false, true);
    this.userSettingsCollection.defaults.set('displayFavoritesSizeButtons', true, true);
    this.userSettingsCollection.defaults.set('orderAnimationDuration', -1, true);
    this.userSettingsCollection.defaults.set('vmAlwaysOnTop', 1, true);
    this.userSettingsCollection.defaults.set('VmTileViewsUseCompactLayout', 0, true);
    this.userSettingsCollection.defaults.set('zoomLevel', 100, true);
    this.userSettingsCollection.defaults.set('activeTab', 0, true);
    this.userSettingsCollection.defaults.set('isOrdersViewFixedHeight', 1, true);
    this.userSettingsCollection.defaults.set('fixedHeightOrdersViewRowCount', 7, true);
    this.userSettingsCollection.defaults.set('pinned', false, true);
    this.userSettingsCollection.defaults.set('allowRepost', false, true);
    this.userSettingsCollection.defaults.set('swapBidAndOffer', 0, true);
    this.userSettingsCollection.defaults.set('enableOCO', false, true);
    this.userSettingsCollection.defaults.set('ocoBidAndOfferSpecific', false, true);
    this.userSettingsCollection.defaults.set('allowVMOCO', false, true);
    this.userSettingsCollection.defaults.set('nameMinChars', 20, true);
    this.userSettingsCollection.defaults.set('enableCentreOEDB', false, true);

    // 10 days in ms: 10d * 24h * 60m * 60s * 1000ms = 864 000 000ms
    this.userSettingsCollection.defaults.set('maxFootprintInactiveTime', 864e6, true);
  };

  context.DataStore.prototype.initPageSettings = function (message) {
    const {userSettingsCollection} = this;
    const pageDefaultsId = `defaults${message.pageId}`;

    // Create the page level defaults setting collection - do not persist through the settings adapter
    userSettingsCollection[pageDefaultsId] = new UserSettings(pageDefaultsId, true);

    const pageDefaults = userSettingsCollection[pageDefaultsId];

    pageDefaults.addSubordinateSettings(userSettingsCollection.volumeMatch);

    BGC.logger.logInformation('datastore', `Applying default page settings: ${JSON.stringify(message.settings, null, 2)}`);

    // Read page (TPDocument) defaults from the 'page' message
    if (message.settings) {
      for (let index = 0; index < message.settings.length; index++) {
        const setting = message.settings[index];

        switch (setting.name) {
          case 'orderAnimationDuration':
            // Setting is required to be numeric, must explicitly convert the string value
            pageDefaults.set(setting.name, Number(setting.value), true);
            break;
          case 'displayFavorites':
            pageDefaults.set('displayFavorites', this.isSalesTraderMode() || this.isBrokerMode() ? false : setting.value, true);
            break;
          default:
            // Explicitly convert Boolean strings into Boolean setting values
            if (setting.value === 'true') {
              pageDefaults.set(setting.name, true, true);
            } else if (setting.value === 'false') {
              pageDefaults.set(setting.name, false, true);
            } else {
              // String values are acceptable for the setting
              pageDefaults.set(setting.name, setting.value, true);
            }
            break;
        }
      }
    }

    // Create the page settings collection to hold user specific page settings (overridden in the Settings view)
    userSettingsCollection[message.pageId] = new UserSettings(message.pageId);
    userSettingsCollection[message.pageId].addSubordinateSettings(pageDefaults);

    // Override the base 'global' settings reference and point it to the 'page' settings instead
    this.userSettingsStore = userSettingsCollection[message.pageId];
  };

  context.DataStore.prototype.setupEnumerations = function () {
    // Set up any global enumerations required for code clarity
    BGC.enums = BGC.enums || {};

    // Trade messages are for executions, summaries, confirms
    BGC.utils.createEnumeration(BGC.enums, 'ETradeNotification', ['eSummary', 'eExecution', 'eConfirm', 'eOrderExecution']);

    // Show live mode
    BGC.utils.createEnumeration(BGC.enums, 'EVMShowLiveMode', ['eShowAll', 'eShowMyOrdersAndGlows', 'eShowMyOrdersOnly']);

    // call base class
    context.BackboneDataStore.prototype.setupEnumerations.call(this);
  };

  // Create the 'matrix-views', 'spread-views' and 'tile-views' in the order in which
  // they appear in the JSON data stream under 'tileLayouts' in the Page message.
  context.DataStore.prototype.createViews = function (message) {
    const tileViews = document.createElement('div');

    tileViews.setAttribute('id', 'tile-views');
    tileViews.setAttribute('class', 'tile-layouts');
    const matrixViews = document.createElement('div');

    matrixViews.setAttribute('id', 'matrix-views');
    matrixViews.setAttribute('class', 'matrix-layouts');

    const tilesElement = document.getElementsByClassName('tiles')[0];

    const tileLayouts = _.uniq(message.tileLayouts, true, layout => layout.layoutType);

    tileLayouts.forEach(tile => {
      switch (tile.layoutType) {
        case 'outright':
          tilesElement.appendChild(tileViews);
          break;
        case 'matrix':
          tilesElement.appendChild(matrixViews);
          break;
        default:
      }
    });
  };

  // The 'initializePage' message is sent by the marshal when the browser has finished loading.
  // Override base class implementation to create backbone collections and models.
  // eslint-disable-next-line complexity
  context.DataStore.prototype.initializePage = function (message) {
    const pageId = message.pageId.substr(message.pageId.search(':') + 1);
    const {sizeMultipliers = [1, 2, 4]} = message;

    // Set the document title to the VM Document name
    document.title = message.pageName;

    // Set the page favourite icon depending on brand id.
    BGC.ui.theme.Volumematch.setFavIcon(BGC.ui.theme.getBrandId());

    this.defaultLogContext = 'datastore';

    // Configure any 'broker/trader' specific setting defaults
    if (!message.isBrokerMode) {
      this.userSettingsCollection.defaults.set('upsizingMode', 0, true);
      this.userSettingsCollection.defaults.set('forceSecondLook', 0, true);
    }

    // Initialize the 'page' level settings
    this.initPageSettings(message);

    BGC.logger.logInformation('datastore', 'Initializing page layout models');

    // create layout model
    this.pageLayout = new this.modelDefinitions.Layout({
      isEditable     : false,
      titleId        : message.titleId || 'bgc-volume-match',
      businessConfig : 'Iro',
      currencyId     : message.currencyId,
      pageId,
      linkId         : message.pageId,
      nomenclature   : 'bidOffer',
      nameMinChars   : this.userSettingsStore.get('nameMinChars'),
      upsizingMode   : this.isBrokerMode() ? 0 : this.userSettingsStore.get('upsizingMode'),
      sizeMultipliers
    });

    if (message.tabsLayout) {
      this.pageLayout.set('tabsLayout', message.tabsLayout);

      // check if Favorites tab is present in tabs layout if it is then
      // make sure that displayFavorites is set to true in userSettingsStore.
      message.tabsLayout.forEach(tab => {
        if (tab.ID === 'tab-control-view-my-favorites-tab' && !this.userSettingsStore.get('displayFavorites')) {
          this.userSettingsCollection.defaults.set('displayFavorites', true, true);
        }
      });
    } else {
      // If tabs layout secontion is not there then insert the default tabs with visibility true.
      const tabs = [{
        ID          : 'tab-control-view-your-orders-tab',
        DisplayName : 'Orders'
      },
      {
        ID          : 'tab-control-view-your-trades-tab',
        DisplayName : 'Trades'
      }
      ];

      if (this.userSettingsStore.get('displayFavorites')) {
        tabs.push({
          ID          : 'tab-control-view-my-favorites-tab',
          DisplayName : 'Favorites'
        });
      }

      if (this.userSettingsStore.get('displayPortfolio')) {
        tabs.push({
          ID          : 'tab-control-view-portfolio-tab',
          DisplayName : 'Portfolio'
        });
      }

      this.pageLayout.set('tabsLayout', tabs);
    }

    if (message.genericColumns) {
      this.pageLayout.set('genericColumns', message.genericColumns);
    } else if (this.pageLayout.get('pageId').includes('LM_IRO_VM_MATRIX_TSET') ||
      this.pageLayout.get('pageId').includes('LM_DOCUMENT_VM_IRO') ||
      this.pageLayout.get('pageId') === 'LM_IRO_EXOTIC_VM_TILESET_LINK_ID') {
      // Backwards compatibility hack to install generic column values for old VM Page definitions.
      // This way, all code can be written so that non-standard columns are only displayed if they are
      // included in the pageLayout object and not hidden by the auction object.
      // This hack can be removed when all the old VM Pages have been migrated to VM Documents.
      this.pageLayout.set('genericColumns', [{
        columnId   : 'strike1Display',
        columnName : 'Strike A'
      },
      {
        columnId   : 'strike2Display',
        columnName : 'Strike B'
      },
      {
        columnId   : 'deltaDisplay',
        columnName : 'Delta'
      },
      {
        columnId   : 'straddleDisplay',
        columnName : 'Str'
      },
      {
        columnId   : 'ratioDisplay',
        columnName : 'Ratio'
      }
      ]);
    } else {
      this.pageLayout.set('genericColumns', []);
    }

    // Start building the data model and the UI
    this.pageLayout.on('change:contentState', this.onAuctionChangedState, this);

    this.createViews(message);

    const matrixLayouts = message.tileLayouts.filter(item => ['matrix', 'triangle', 'triangle-inverted'].includes(item.layoutType));

    // create the main matrix model and any linked matrices (to model spread triangles)
    if (matrixLayouts.length > 0) {
      this.pageLayout.addMatrices(matrixLayouts, this);

      // make sure that compact tiles disabled if the layout contains matrix
      this.userSettingsStore.set('VmTileViewsUseCompactLayout', false);
    }

    // add collection of tiles to the auction
    this.pageLayout.addTiles(message.tileLayouts.filter(item => item.layoutType === 'outright' || item.layoutType === 'spread'), this);

    BGC.logger.logInformation('datastore', 'Finished building page layout models');

    // Call base class
    context.BackboneDataStore.prototype.initializePage.call(this, message);
  };

  context.DataStore.prototype.updateThemeFromSettings = function () {
    const currentlySelectedTheme = this.userSettingsCollection.volumeMatch.get('themeSelected');
    const supportedThemes = BGC.ui.theme.Volumematch.getSupportedThemes();
    const defaultThemeId = BGC.ui.theme.Volumematch.getDefaultTheme().selectedTheme;
    let themeId = '';

    BGC.logger.logInformation('', `[DataStore::updateThemeFromSettings] Currently selected theme: ${currentlySelectedTheme}, Brand Id: ${BGC.ui.theme.getBrandId()}`);

    if (currentlySelectedTheme !== undefined && _.has(supportedThemes, currentlySelectedTheme)) {
      // theme id is stored as well as indexed in the mark up as 0 based for legacy reasons.
      // E.g. 0 index indicates Pearl and 1 index indicates Charcoal but 'theme1' is pearl and 'theme2' is charcoal.
      themeId = Number(currentlySelectedTheme) + 1;
    } else {
      // If previously stored theme is no more available for this brand - fall back to the brand's default theme.
      themeId = Number(defaultThemeId) + 1;

      this.userSettingsCollection.volumeMatch.set('themeSelected', defaultThemeId);

      BGC.logger.logWarning('DataStore::updateThemeFromSettings', `Currently selected theme[${currentlySelectedTheme}] is unavailable, falling back to default theme[${defaultThemeId}]`);
    }

    BGC.ui.theme.Volumematch.setLocalTheme(`-theme${themeId}`);
  };

  // Override base class implementation to create backbone views. The base datastore triggers this function
  // once the page has been initialized - and all resources have been loaded
  context.DataStore.prototype.finalizeInitialize = function () {
    BGC.logger.logInformation('datastore', 'Initializing application views ...');

    // create header view
    BGC.ui.view.headerView = new context.ui.view.HeaderView({
      model     : this.pageLayout,
      el        : $('.header')[0],
      dataStore : this
    });

    // Create the global toolbar
    BGC.ui.view.globalToolbar = new context.ui.view.GlobalToolbar({
      model     : this.pageLayout,
      el        : $('.header .toolbar')[0],
      dataStore : this
    });

    // create the tab control container and toolbar
    BGC.ui.view.tabControlView = new context.ui.view.TabControlView({
      el        : $('#tab-control-orders-trades')[0],
      model     : this.pageLayout,
      dataStore : this
    });
    BGC.ui.view.ordersToolbar = new context.ui.view.OrdersAndTradesToolbar({
      el        : $('#tab-control-orders-trades .toolbar')[0],
      model     : this.pageLayout,
      dataStore : this
    });
    BGC.ui.view.tabControlView.installToolbar(BGC.ui.view.ordersToolbar);

    // create the main content view
    BGC.ui.view.mainView = new context.ui.view.MainView({
      model     : this.pageLayout,
      el        : $('.main')[0],
      dataStore : this
    });

    BGC.logger.logInformation('datastore', 'Finished building application views');

    // start the local midnight cleanup timer (in browser time)
    this.primeMidnightCleanup();
  };

  // eslint-disable-next-line complexity
  context.DataStore.prototype.update = function (messageData) {
    // Accept a raw JSON string or its object equivalent.
    const jsonMessageData = typeof messageData === 'string' ? (JSON && JSON.parse(messageData)) || $.parseJSON(messageData) : messageData;
    const timeNow = new Date(Date.now());
    const timeNowString = timeNow.toTimeString();

    const messageCount = jsonMessageData.messages.length;
    let isValid = false;
    const validationError = {};

    // Validate against the message schema
    try {
      if (this.isJsonMessageValidationRequired) {
        isValid = this.validateMessage(jsonMessageData, validationError);
      }
    } catch (error) {
      BGC.logger.logError('', `${error.name}: ${error.message}\n\n${JSON.stringify(jsonMessageData)}`);
      throw new Error(`${error.name}: ${error.message}\n\n${JSON.stringify(jsonMessageData)}`);
    }

    // Standard validation failure, no exception but validation returned false
    if (this.isJsonMessageValidationRequired && !isValid) {
      BGC.logger.logError('', `${validationError.message}  [Code = ${validationError.code}]\n\n${JSON.stringify(jsonMessageData)}`);
      throw new Error(`${validationError.message}  [Code = ${validationError.code}]\n\n${JSON.stringify(jsonMessageData)}`);
    }

    // Fields are valid or exception would have been thrown and we wouldn't be here.
    if (!isWebDeployed && messageCount > 5) {
      const logText = `Processing ${messageCount} JSON messages at ${timeNowString} and ${timeNow.getMilliseconds()} milliseconds`;

      BGC.logger.logInformation('DataStore.update()', logText);
      BGC.utils.trace(logText);
    }

    for (let index = 0; index < messageCount; ++index) {
      this.processMessage(jsonMessageData.messages[index]);
    }
  };

  context.DataStore.prototype.processInstrumentMsg = function (message) {
    if (Reflect.has(message, 'productKey')) {
      // Filter out any instruments which GTI may publish a null product key
      const {productKey, productAttributes, instrumentId} = message;

      if (!productKey || !productAttributes) {
        BGC.logger.logWarning('datastore::processInstrumentMsg', `Ignoring instrument with null product key: ${instrumentId} ...`);

        return;
      }
    }

    // First determine the instrument state changes that this message update is signalling
    let instrument = this.getInstrumentById(message.instrumentId);

    if (!instrument && Reflect.has(message, 'spread')) {
      // GTI is currently publishing spread instruments before it has processed the underlying securities
      // Block processing of these spreads until GTI fixes this issue
      const {underLyingIds} = message.spread;

      if (!underLyingIds.every(id => this.getInstrumentById(id))) {
        window.console.error(`[DataStore::processInstrumentMsg] Failed to process custom spread: ${message.instrumentName} - underlying securities have not been published`);

        return;
      }
    }

    // If its a new outright instrument after securityList receive
    // is complete, then set the tile to 'Other'.
    // Otherwise if we haven't yet received securityList complete, then do nothing
    // as layout service will return the tile.
    if (!instrument && !Reflect.has(message, 'spread')) {
      const {instrumentId} = message;
      const {id : appId} = getApp();

      // Check if its after securityList receive is complete
      if (appId && this.pageLayout) {
        // Find the (single) 'other' tile
        const otherTile = this.pageLayout.get('tiles').find(tile => tile.attributes.layoutType === 'outright');

        if (otherTile) {
          const {tileId, tileName} = otherTile.attributes;

          // Now send the tileAdd to set the tile to 'Other'
          this.processTileAddMsg({
            messageName : 'tileAdd',
            tileLayouts : [{
              layoutType     : 'outright',
              tileId,
              tileName,
              instrumentList : [{instrumentId}]
            }]
          });
        } else {
          window.console.error(`[datastore::processInstrumentMsg]Failed to add instrument ${instrumentId} to 'other' tile`);
        }
      }
    }

    const msgState = this.modelDefinitions.Instrument.setUpdateStatesFromMessage(instrument, message);

    // Create the new instrument or update an existing one
    if (msgState.isDummyInstrumentUpdate) {
      instrument = this.modelDefinitions.Instrument.updateDummyInstrument(instrument, message);
    } else if (msgState.isInstrumentUpdate && (this.pageLayout || !msgState.isEnteringVM)) {
      instrument.update(message, msgState);
    } else if (msgState.isNewInstrumentUpdate) {
      instrument = this.modelDefinitions.Instrument.create(message);
    }

    if (msgState.isEnteringVM && this.pageLayout) {
      this.auctions.processInstrumentMsg(instrument, msgState);

      this.portfolio.processInstrumentMsg(instrument, message, msgState);
    }

    this.orderStore.processInstrumentMsg(instrument, message, msgState);

    // For the GTI workflow we may receive 'auction' messages  before the layout has loaded
    if (this.pageLayout) {
      this.pageLayout.processInstrumentMsg(instrument, message, msgState);
    } else if (msgState.isEnteringVM) {
      this.preInitAuctionMsgCache.push(message);
    }

    this.footprints.processInstrumentMsg(instrument, message, msgState);
  };

  context.DataStore.prototype.processOrderMsg = function (msg) {
    const {accountId = ''} = msg;
    const instrument = this.getInstrumentById(msg.instrumentId);

    // Check if its a cancel and only process if we already have the orderId
    if (msg.orderId) {
      const isCancel = msg.status === 'cancelled';

      if (isCancel) {
        // Find orderBy id
        const orderById = this.orderStore.findOrderById(msg.orderId, msg.side);

        if (orderById.length === 0 && msg.orderType === 'own') {
          // Order does not exist by id and its a cancel so drop the cancel message
          // This happens when the cancel is not explicit i.e initiated by user
          // For example when the user wants to chnage the side of existing order
          return;
        }
      }

      // Check if an order exists on opposite side
      const orderType = BGC.schemaValidator.OWNERSHIP_MINE;
      const {SELL_SIDE, BUY_SIDE} = BGC.schemaValidator;
      const oppositeSide = msg.side === BUY_SIDE ? SELL_SIDE : BUY_SIDE;
      const oppositeOrder = this.orderStore.findFirstMatchingOrder({instrument, orderType, accountId}, msg.orderPrice, oppositeSide);

      // If so then set the size, isLive and canBeCancelled from the opposite order
      if (oppositeOrder !== undefined) {
        const {
          sellSize, soldSize, buySize, boughtSize,
          isLiveSell, isLiveBuy, sellCanBeCancelled, buyCanBeCancelled
        } = oppositeOrder.attributes;

        if (msg.side === BUY_SIDE) {
          msg.sellSize = sellSize;
          msg.soldSize = soldSize;
          msg.isLiveSell = isLiveSell;
          msg.sellCanBeCancelled = sellCanBeCancelled;
        } else {
          msg.buySize = buySize;
          msg.boughtSize = boughtSize;
          msg.isLiveBuy = isLiveBuy;
          msg.buyCanBeCancelled = buyCanBeCancelled;
        }
      } else if (msg.side === BUY_SIDE) {
        // If there is no opposite side, set it to defaults as the footprints and favourites use this
        // info from the vmOrderUpdate message
        msg.sellSize = 0;
        msg.soldSize = 0;
        msg.isLiveSell = false;
        msg.sellCanBeCancelled = false;
      } else {
        msg.buySize = 0;
        msg.boughtSize = 0;
        msg.isLiveBuy = false;
        msg.buyCanBeCancelled = false;
      }
    }
    const userId = this.getPrimaryUserDetails().userID;

    msg.userId = msg.userId || userId;

    const favoritesExclusionList = this.pageLayout.getFavoritesExclusionList();
    const previousOrder = this.orderStore.findOrder(instrument, msg);
    let previousFilledSizes = {boughtSize : 0, soldSize : 0};

    if (previousOrder) {
      previousFilledSizes = {boughtSize : previousOrder.getFilledSize('buy'), soldSize : previousOrder.getFilledSize('sell')};
    }

    // Pass the message to the order store for processing
    const order = this.orderStore.processOrderMsg(instrument, msg);

    if (order && this.orderStore.hasInstrumentExecuted(order, previousFilledSizes)) {
      this.playExecutionSound(msg.orderType);
      this.restoreVMWindow(msg.orderType);
    }

    // Pass 'own' order messages to the footprints store for processing
    if (msg.orderType === BGC.schemaValidator.OWNERSHIP_MINE &&
          this.userSettingsStore.get('displayFavorites') &&
          !favoritesExclusionList.includes(instrument.get('tileId'))) {
      this.footprints.processOrderMsg(instrument, order, msg);
    }
  };

  context.DataStore.prototype.processTradeMsg = function (msg, type) {
    const {auctionHistory} = this;
    const {
      eOrderExecution,
      eExecution,
      eSummary,
      eConfirm
    } = BGC.enums.ETradeNotification;

    const instrument = this.getInstrumentById(msg.instrumentId);

    const traderId = this.getPrimaryUserDetails().userID;

    // Ensure we have an instrument for execution and sunmmary updates
    if (type !== eConfirm && !instrument) {
      BGC.logger.logError('trade.js::onVMTradeExecution',
        `Ignoring trade update for unknown instrument: ${msg.instrumentId}`);

      return;
    }

    if (type === eOrderExecution) {
      const tradeType = msg.execution.type;

      // Check if the order was already processed by processOrderMsg (vmOrderUpdate arrived before the eOrderExecution )
      // to prevent playing the sounds twice
      const order = this.orderStore.findOrder(instrument, {
        orderType : tradeType, accountId : msg.accountId, orderPrice : msg.tradePrice, userId : msg.traderId
      });

      const trade = msg.execution;
      const filledSize = {
        boughtSize : trade.side === BGC.schemaValidator.BUY_SIDE ? trade.size : 0,
        soldSize   : trade.side === BGC.schemaValidator.SELL_SIDE ? trade.size : 0
      };

      if (!order || this.orderStore.hasInstrumentExecuted(order, filledSize)) {
        this.playExecutionSound(tradeType);
        this.restoreVMWindow(tradeType);
      }

      // Process trade order execution
      auctionHistory.onVMTradeExecution(msg, type, instrument);
    } else if (type === eExecution || type === eSummary) {
      // Prevent processing of (Waterfall) trade execution and trade summary messages when
      // instrument is configured for immediate trade confirmation
      if (!instrument.get('isImmediateTradeConfirm')) {
        this.auctionHistory.onVMTradeExecution(msg, type, instrument);
      }
    } else if (type === eConfirm) {
      msg.traderId = msg.traderId || traderId;
      auctionHistory.onVMTradeExecution(msg, type);
    }
  };

  context.DataStore.prototype.OnChangeActiveUserByBroker = function () {
    this.orderStore.reset();

    BGC.ui.view.mainView.ShowHideTabControlForActiveAccountType();

    BGC.ui.view.tabControlView.updateControlsVisibility();

    BGC.ui.view.globalToolbar.updateSettingsForActiveUser();

    BGC.ui.view.mainView.hideInPlaceOEBOnContextSwitch();
  };

  context.DataStore.prototype.processTileUpdateMsg = function (msg) {
    msg.tileLayouts.forEach(function (tileMsg) {
      const tile = this.pageLayout.get('tiles').findWhere({tileId : tileMsg.tileId});

      if (tile) {
        tile.updateContentFromInstrumentList(tileMsg.instrumentList);
      }
    }, this);
  };

  context.DataStore.prototype.processTileAddMsg = function (msg) {
    msg.tileLayouts.forEach(function (tileMsg) {
      const tile = this.pageLayout.get('tiles').findWhere({tileId : tileMsg.tileId});

      if (tile) {
        const instDetail = tileMsg.instrumentList.pop();

        // Get all existing instruments and add to instrumentList
        tile.get('instruments').models.forEach(inst => {
          if (inst.id !== instDetail.instrumentId) {
            tileMsg.instrumentList.push({
              instrumentId : inst.id
            });
          }
        });

        // Now add current instrument
        tileMsg.instrumentList.push({
          instrumentId : instDetail.instrumentId
        });
        tile.updateContentFromInstrumentList(tileMsg.instrumentList);
      }
    }, this);
  };

  // Override base class implementation to handle any vm specific messages
  context.DataStore.prototype.processMessage = function (message) {
    BGC.utils.trace(`DataStore.processMessage() : ${JSON.stringify(message)}`);

    switch (message.messageName) {
      case 'userLogin':
        this.processUserLogin(message);
        break;
      case 'instrument':
        this.processInstrumentMsg(message);
        break;
      case 'vmOrderUpdate':
        // The GTI adapter is currently sending this message before the securities complete event has been triggered
        // at start-up. Add this check to restrict this flow before layout has loaded
        if (this.pageLayout) {
          this.processOrderMsg(message);
        } else {
          this.preInitAuctionMsgCache.push(message);
        }
        break;
      case 'tradeExecution':
        if (message.isNotification) {
          this.processTradeMsg(message, BGC.enums.ETradeNotification.eOrderExecution);
        } else {
          this.processTradeMsg(message, BGC.enums.ETradeNotification.eExecution);
        }
        break;
      case 'vmTradeSummary':
        this.processTradeMsg(message, BGC.enums.ETradeNotification.eSummary);
        break;
      case 'tradeCaptureReport':
        this.processTradeMsg(message, BGC.enums.ETradeNotification.eConfirm);
        break;
      case 'auction':
        // The GTI adapter is currently sending this message before the securities complete event has been triggered
        // at start-up. Add this check to restrict this flow before layout has loaded
        if (this.pageLayout) {
          this.onAuctionMsg(message);
        } else {
          this.preInitAuctionMsgCache.push(message);
        }
        break;
      case 'accountsList':
        this.onAccountsListReceived(message);
        break;
      case 'accountUpdate':
        this.onAccountUpdateReceived(message);
        break;
      case 'accountSelectionChanged':
        this.setActiveAccountById(message.accountId);
        break;
      case 'BrokerActiveAccountSelectionChanged':
        this.OnChangeActiveUserByBroker(message);
        break;
      case 'lastError':
        this.onLastErrorMessage(message);
        break;
      case 'excelAddInStateChanged':
        this.pageLayout.updateExcelAddInState(message);
        break;
      case 'vmCreateInstrumentResponse':
        this.onVMCreateInstrumentResponse(message);
        break;
      case 'selectInstrument':
        this.onSelectInstrument(message);
        break;
      case 'tileUpdate':
        this.processTileUpdateMsg(message);
        break;
      case 'tileAdd':
        // The layout may not have been initialised, so add the message to the cache so that it can be processed
        // after layout has been initialised
        if (this.pageLayout) {
          this.processTileAddMsg(message);
        } else {
          this.preInitAuctionMsgCache.push(message);
        }
        break;
      default:
        // pass any unprocessed messages to the base class
        context.BackboneDataStore.prototype.processMessage.call(this, message);
    }
  };

  context.DataStore.prototype.onAuctionChangedState = function () {
    if (this.pageLayout.areAnyInstrumentsInAuction() && this.orderStore.length > 0) {
      // First instrument just entered auction. Remove all order footprints for all instruments.
      // We want to clear entire order store, so no point allowing it to be done instrument by instrument
      this.orderStore.reset();
    }
  };

  context.DataStore.prototype.onAccountsListReceived = function (message) {
    if (BGC.ui.view.mainView) {
      // In case of order of initialization issues, ensure the accounts bar has been created
      BGC.ui.view.mainView.ensureAccountRelatedControlsAreDisplayed();
    }

    const that = this;
    const accounts = [];

    message.accounts.forEach(function (accountData) {
      accounts.push(new this.modelDefinitions.Account({
        id           : accountData.accountId,
        fullName     : accountData.screenName,
        shortName    : accountData.shortName,
        invariantId  : accountData.id,
        enabled      : accountData.enabled,
        accountType  : accountData.accountType,
        displayIndex : accountData.displayIndex
      }));
    }, that);

    this.initializeAccounts(accounts);
  };

  context.DataStore.prototype.onAccountUpdateReceived = function (message) {
    switch (message.operation) {
      case 'add':
        this.addAccount(message.data);
        break;
      case 'update':
        this.updateAccount(message.data);
        break;
      case 'remove':
        this.removeAccount(message.data.accountId);
        break;
      default:
    }
  };

  context.DataStore.prototype.onLoadUserSettings = function (settings, appContext) {
    // First call the base class to load the user settings
    // if "settings" is a truthy value
    if (settings) {
      context.BackboneDataStore.prototype.onLoadUserSettings.call(this, settings, appContext);
    }

    // Restore the selected theme
    this.updateThemeFromSettings();
    this.listenTo(this.userSettingsStore, 'change:themeSelected', this.updateThemeFromSettings);

    // Listen for "loglevel" property change
    this.listenTo(this.userSettingsStore, 'change:loglevel', function () {
      const selectedLogLevel = this.userSettingsCollection.volumeMatch.get('loglevel');

      // Update the logger's log level for the page
      logger.changeLogLevel(selectedLogLevel);
    });

    if (this.userSettingsStore.get('displayFavorites')) {
      // Restore the page footprints from the user settings
      this.footprints.restore(context.dataStore.userSettingsStore.get('persistedFootprints') || []);
    }

    const instruments = this.instruments.models;

    // Once user settings recieved then process instruments
    // so that footprints can be associated with the instruments
    for (const instrument of instruments) {
      this.footprints.processInstrumentMsg(instrument, null, {isLeavingVM : false});
    }
  };

  // Called after setting has been stored by the base class data store
  context.DataStore.prototype.onGeneralSettingChanged = function (setting) {
    BGC.logger.logInformation('', `onGeneralSettingChanged: ${JSON.stringify(setting)}`);

    switch (setting.name) {
      case 'MQ':
        if (!this.isBrokerMode()) {
          setting.value = Number(setting.value);
          setting.name = 'maxQuantityMultiplier';
        }
        break;
      case 'VCVM_TOPMOST':
        setting.name = 'vmAlwaysOnTop';
        if (!isWebDeployed) {
          // Allow the BGC Trader setting to go straight into our settings model
          this.userSettingsCollection.volumeMatch.set(setting.name, setting.value === 'Y' ? 1 : 0, true);
        }
        break;
      case 'DisplayVMMatrixSecondLookDialog':
        setting.name = 'forceSecondLook';
        break;
      case 'VmTileViewsUseCompactLayout':
        if (this.pageLayout && this.pageLayout.hasMatrices()) {
          // Prevent compact tile display in a matrix plus 'other' tile layout
          setting.value = 0;
        }
        break;
      case 'TPAL':
        // Trading Popup Alignment setting used to set the *default* (not the actual setting)
        // for 'Pinned' state. Note: when testing the value of this setting, a value of true
        // should only be acted upon if the layout has no matrices. The setting should only be applied to list VMs.
        this.userSettingsCollection.defaults.set('pinned', setting.value === '1', true);

        return;
      case 'SPRC':
        setting.name = 'swapBidAndOffer';
        break;
      default:
    }

    context.BackboneDataStore.prototype.onGeneralSettingChanged.call(this, setting);
  };

  context.DataStore.prototype.onLastErrorMessage = function (message) {
    BGC.ui.viewUtils.displayErrorMessage(message.context, message.message);
  };

  context.DataStore.prototype.onAuctionMsg = function (message) {
    const {
      auctionId, vmSessionId, settings, orderPhaseText
    } = message;

    // If the page is configured to retain auction history, update the global auction collection,
    // keyed by the unique VM Session ID
    if (this.userSettingsStore.get('retainHistory')) {
      const auction = this.auctions.add(new this.modelDefinitions.Auction({
        auctionId,
        vmSessionId,
        orderPhaseText,
        layout                      : this.pageLayout,
        showThirdPartyInterestGlows : settings.showInterestGlows,
        showTradeIndicators         : settings.showTradeIndicators,
        showInterestAndTradeCount   : settings.showInterestAndTradeIndicators,
        instruments                 : this.instruments.where({
          vmSessionId,
          inactive : false
        })
      }));

      auction.onAuctionEvent(message);

      this.pageLayout.trigger('glowCountChanged');
      this.pageLayout.trigger('tradeCountChanged');
    } else {
      const auction = this.pageLayout.getOrAddAuction(auctionId);

      auction.onAuctionEvent(message);
    }
  };

  context.DataStore.prototype.onMidnightCleanup = function () {
    // remove all trades
    BGC.logger.logInformation('', `Midnight Cleanup: Cleaning up Auction History: items ${this.auctionHistory.length}`);
    this.auctionHistory.reset();

    // Clear the auction history
    this.auctions.remove(this.auctions.where({
      runningState : 0
    }));

    // Clear the pending footprint collection
    this.footprints.clearPendingFootprints();

    // re-prime it for tomorrow
    this.primeMidnightCleanup();
  };

  context.DataStore.prototype.primeMidnightCleanup = function () {
    const timeTomorrow = new Date(Date.now() + MILLISECONDS_IN_DAY);
    const midnightTomorrowMorning = timeTomorrow;
    let millisecsUntilMidnight = 0;

    midnightTomorrowMorning.setHours(0, 0, 1, 0);
    millisecsUntilMidnight = midnightTomorrowMorning.getTime() - Date.now();

    this.midnightCleanupTimer = setTimeout(this.onMidnightCleanup.bind(this), millisecsUntilMidnight);
  };

  context.DataStore.prototype.onVMCreateInstrumentResponse = function (message) {
    if (!message.isSuccessful) {
      this.modelDefinitions.Spread.completeQOSRecord(message.instrumentCreationID);
    }
  };

  context.DataStore.prototype.onSelectInstrument = function (message) {
    const startTimeUtc = Date.now();

    // select an instrument row or cell which should exist in a single view
    const instrument = this.getInstrumentById(message.instrumentId);

    if (instrument.isInAuction()) {
      this.pageLayout.closeAllInstrumentViews(instrument);
      instrument.trigger('requestSelection');

      // Report the QoS event.
      BGC.logger.sendQoSEvent({
        type                    : 'selectInstrument',
        databaseKeyName         : 'HTML_VM_OP',
        startTimeUtc,
        message                 : `Instrument[${instrument.getLogDescStr()}]`,
        alertThresholdMilliSecs : 5000
      });
    }
  };

  context.DataStore.prototype.getField = function (viewId, fieldId) {
    return context.BackboneDataStore.prototype.getField.call(this, viewId, fieldId);
  };

  context.DataStore.prototype.captureOrderOrCancelSubmitTime = function (instrumentModel, isQoSOpAnOrder) {
    const now = new Date().getTime();

    // capture the start time on cancel orders for both outrights and spreads
    // DON'T use Backbone model's 'set' function as it triggers updates of all observing views.
    // Simply store the value as a normal object attribute instead.
    instrumentModel.orderSubmitTime = now;
    instrumentModel.isQoSOpAnOrder = isQoSOpAnOrder;
  };

  context.DataStore.prototype.sendCancelOrder = function (viewId, request) {
    const instrumentModel = this.getInstrumentById(request.instrumentId);

    BGC.logger.logKey('', `${viewId} cancelling ${request.side} order: ${instrumentModel.getLogDescStr()} ${request.size}@${request.price}${request.accountId ? `, account: ${request.accountId}` : ''}`);

    BGC.dataStore.captureOrderOrCancelSubmitTime(instrumentModel, false);

    // Get filledSize so that web api can decide whether to send cancel or cancel update
    let filledSize = 0;
    const orderById = this.orderStore.findOrderById(request.originalOrderId, request.side);

    if (orderById.length !== 0) {
      const {boughtSize, soldSize} = orderById[0].attributes;

      filledSize = request.side === 'buy' ? boughtSize : soldSize;
    }

    // Add non-command params - required by GTI
    const options = {
      sourceSystem     : request.sourceSystem,
      symbolType       : request.symbolType,
      venueType        : request.venueType,
      regulatoryRegime : request.regulatoryRegime
    };

    // OrderId is a uuid required by GTI
    // originalOrderId is the orderId of the initial order - only required for GTI

    BGC.eventsHandler.onClick(viewId, 'cancelOrder', JSON.stringify({
      instrumentId    : request.instrumentId,
      orderId         : request.orderId,
      originalOrderId : request.originalOrderId,
      orderPrice      : request.price,
      orderSide       : request.side === 'buy' ? 1 : 2,
      accountId       : request.accountId,
      userId          : request.userId,
      isBuddyCancel   : request.isBuddyCancel,
      orderSize       : filledSize
    }), options);
  };

  context.DataStore.prototype.cancelAllOrders = function (cancelOwn, cancelPeers) {
    const sides = ['buy', 'sell'];

    this.orderStore.forEach(order => {
      if ((order.isOwnOrder() && cancelOwn) || (order.isCancellationBuddyOrder() && cancelPeers)) {
        sides.forEach(side => {
          if (order.hasUnfilledSize(side)) {
            order.sendCancelOrder('ActiveOrders', side);
          }
        });
      }
    });
  };

  context.DataStore.prototype.sendEnableExcelLiveLink = function (viewId, request) {
    const instrumentModel = this.getInstrumentById(request.instrumentId);

    BGC.logger.logKey('', `${viewId} toggling instrument: ${instrumentModel.getLogDescStr()} Excel Live Link ${request.enable}` ? 'off' : 'on');

    BGC.eventsHandler.onClick(viewId, 'vmEnableExcelLiveLink', JSON.stringify({
      instrumentId : request.instrumentId,
      enable       : request.enable
    }));
  };

  context.dataStore = new context.DataStore();
  context.dataStore.setupEnumerations();
}

initDataStore(window.BGC);

export default {};
