/* eslint-disable no-magic-numbers */
/* global BGC: false,  $: false */

// Create UI utilities module
BGC.ui.viewUtils = {};

$(document).off('mousedown').on('mousedown', event => {
  // Call back into the C++ in order to allow it to dismiss any active popup menus
  // ... Particularly ribbon bar popup menus.
  BGC.eventsHandler.onMouseDown();

  // Clear any active tooltip
  if (BGC.ui.tooltipSingleton) {
    BGC.ui.tooltipSingleton.getInstance().hide();
  }

  // Log the click
  BGC.logger.logUserInteraction(event);
});

// Kill spurious keydown events in the capture phase before we try and process them elsewhere
document.body.addEventListener('keydown', event => {
  if (event.which === 16) {
    event.stopPropagation();

    return false;
  }

  return true;
}, true);

// Catch other keydown events as they bubble up from lower down the DOM tree,
// so that we can log the context of the control where they occur if there is one
document.body.addEventListener('keydown', BGC.logger.logUserInteraction, false);

// Prevent dragging of images, which seems to be their default behaviour.
// Quicker and simpler than finding all instances of <img> tags and adding draggable="false" to them
$('body').on('dragstart', 'img', null, event => {
  event.preventDefault();

  return false;
});

// eslint-disable-next-line import/prefer-default-export
export const isWebDeployed = window.BGCAPP && window.BGCAPP.isWebDeployed;
