/* eslint-disable no-magic-numbers */

import {logger, postEventMetric} from '@core-tech/web-api';
import createApp from '@core-tech/web-api/app';
import {
  getDataStore, getSplash, renderPage, msgProcessor
} from './volumematch';
import broadcastAuctionWindowState from './views/windowstatehelper';
import pkg from '../../package.json';

// 'Singleton' application instance
let app = null;

const getApp = () => app;

(async function createVolumeMatch () {
  async function asyncOp (op, status) {
    getSplash().updateMessage(status);

    await op();
  }

  try {
    const pageStartTimeUtc = Date.now();

    // First create and wait for the app instance to initialize.
    app = await createApp({
      isPrimary  : false,
      appVersion : pkg.version
    }, msgProcessor);

    // Open and establish the trading session connection (to GTI)
    await asyncOp(app.connect.bind(app), 'Opening GTI Trading Session');

    // Subscribe to securities
    await asyncOp(app.subscribe.bind(app, {context : app.id}), 'Subscribing to GTI security list');

    // Request layout service to build page layout for the subscribed instruments/securities.
    await asyncOp(app.buildPageLayout.bind(app, getDataStore().instruments), 'Building page layout');

    // Load the application user settings
    await asyncOp(app.loadUserSettings.bind(app), 'Loading User Settings');

    // Render the application page
    renderPage(app);

    // Sending page loader time to web-session
    postEventMetric(app.path, 'pageLoader', {
      appId      : app.id,
      rtt        : Date.now() - pageStartTimeUtc,
      user       : app.userId,
      desk       : app.desk,
      isEmbedded : app.isEmbedded,
      clientTime : new Date().toISOString()
    });

    // Finally, subscribe to Trade Capture reports
    app.subscribeToTrades({context : app.id});
  } catch (err) {
    logger.error(`[createVolumeMatch] Error starting Volume Match v${pkg.version}: error[${err}]`);

    logger.info(`[createVolumeMatch] Forcing page reload: ${window.location}`);

    // Force page reload after 180 seconds
    setTimeout(() => window.location.reload(), 180000);
  }
}());

function closeApp () {
  if (app) {
    const dataStore = getDataStore();

    // If this is a native browser the user may close the child page
    if (!app.isEmbedded) {
      // Cancel all outstanding orders
      dataStore.cancelAllOrders(true, false);

      // Report trader looking status for all running auctions
      broadcastAuctionWindowState('window_closed');
    }

    logger.info('[closeApp] Application is shutting down normally, flushing all log statements.');
    app.close();
  }
}

window.onbeforeunload = () => {
  closeApp();
};

export default getApp;
