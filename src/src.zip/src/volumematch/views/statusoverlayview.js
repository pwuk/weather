/* global $, _ */
import Backbone from 'backbone';

const StatusOverlayView = Backbone.View.extend({
  template : _.template($('#status-overlay').html()),

  initialize (options) {
    const {autoOpen = false, displayLogo = false, message = ''} = options;

    this.$el.toggleClass('logo', displayLogo);

    this.render();

    if (autoOpen) {
      this.open(message);
    }
  },

  render () {
    this.$el.html(this.template());

    return this;
  },

  updateMessage (message, autoOpen = false) {
    if (!this.isOpen && autoOpen) {
      this.open(message);
    } else {
      this.$el.find('.message').text(message);
    }
  },

  close () {
    this.$el.hide();

    this.isOpen = false;
  },

  open (message) {
    this.$el.find('.message').text(message);

    this.$el.show();

    this.isOpen = true;
  }
});

export default StatusOverlayView;
