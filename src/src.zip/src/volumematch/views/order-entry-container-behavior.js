/* eslint-disable func-names, no-param-reassign, max-statements, id-length, no-magic-numbers, complexity, max-params, max-len, consistent-return */
/* global BGC: false */


// eslint-disable-next-line no-shadow-restricted-names
(function (context, undefined) {
  context.OrderEntryControlsContainerBehavior = {

    // Take Backbone data models or existing view models (plain objects)
    // and create plain objects on the current context.
    // You can tell if a model is one of our Backbone models because it will have a serialize() function.
    setViewModelsAndCallbacks (instrument, activeOrder, callbacks) {
      if (!this.localPriceChangeCallback) {
        this.localPriceChangeCallback = this.onUserChangedPrice.bind(this);
      }

      this.removeLocalPriceChangeEventListener();

      if (instrument) {
        if (typeof instrument.serialize === 'function') {
          this.instrument = instrument.serialize();

          this.callbackFunctions = {
            sizeValidationCallback       : instrument.validateSize.bind(instrument),
            bidPriceValidationCallback   : instrument.validateBidPrice.bind(instrument),
            offerPriceValidationCallback : instrument.validateOfferPrice.bind(instrument)
          };
        } else {
          this.instrument = instrument;

          if (callbacks) {
            this.callbackFunctions = callbacks;
          }
        }

        this.addLocalPriceChangeEventListener();
      } else {
        instrument = {
          shortName : '',
          strike2   : '',
          cross     : ''
        };
      }

      if (activeOrder) {
        if (typeof activeOrder.serialize === 'function') {
          this.order = {...activeOrder.serialize()};
        } else {
          this.order = {...activeOrder};
        }

        // order sizes should be coerced to string by + "", as they will be revert values of size cells
        this.order.buyPrice = activeOrder.buyOrder ? activeOrder.buyOrder.price : this.instrument.midPrice;
        this.order.buySize = `${activeOrder.hasBuySize ? activeOrder.buySize : ''}`;
        this.order.sellPrice = activeOrder.sellOrder ? activeOrder.sellOrder.price : this.instrument.midPrice;
        this.order.sellSize = `${activeOrder.hasSellSize ? activeOrder.sellSize : ''}`;
        this.order.hasCancellableBuySize = activeOrder.hasCancellableBuySize;
        this.order.hasCancellableSellSize = activeOrder.hasCancellableSellSize;
      } else {
        this.order = {
          buySize                : '',
          sellSize               : '',
          hasCancellableBuySize  : false,
          hasCancellableSellSize : false
        };
      }
    },

    addLocalPriceChangeEventListener () {
      // copes with Backbone view or Polymer element
      const containerElement = this.el || this;
      const that = this;

      containerElement.querySelectorAll('nudgeable-price-input, editable-price-cell').forEach(ctrl => {
        ctrl.addEventListener('price:updated', that.localPriceChangeCallback);
      });
    },

    removeLocalPriceChangeEventListener () {
      // copes with Backbone view or Polymer element
      const containerElement = this.el || this;
      const that = this;

      containerElement.querySelectorAll('nudgeable-price-input, editable-price-cell').forEach(ctrl => {
        ctrl.removeEventListener('price:updated', that.localPriceChangeCallback);
      });
    },

    getPriceForSubmission (side) {
      let price = null;

      // copes with Backbone view or Polymer element
      const containerElement = this.el || this;

      if (this.instrument.isMoveableBidEnabled || this.instrument.isMoveableOfferEnabled) {
        const nudgeInput = containerElement.querySelector(`nudgeable-price-input[side='${side}']`);
        const newPriceStr = nudgeInput.getValue();

        if (newPriceStr === '') {
          price = this.instrument.midPrice;
          if (this.instrument.isSignFlippedForPickGive[side]) {
            price = -price;
          }
        } else {
          // if not empty use the value in the input for order
          const validatedPrice = side === 'buy' ? this.callbackFunctions.bidPriceValidationCallback(newPriceStr, true) : this.callbackFunctions.offerPriceValidationCallback(newPriceStr, true);

          if (validatedPrice.valid) {
            price = validatedPrice.numericValue;
          } else {
            return;
          }
        }
      } else {
        price = this.instrument.midPrice;
        if (this.instrument.isSignFlippedForPickGive[side]) {
          price = -price;
        }
      }

      return price;
    },

    processSubmitOrderEvent (event) {
      // copes with Backbone view or Polymer element
      let containerElement = this.el || this;

      event.stopPropagation();

      // Cope with jQuery packaging around the original event if necessary
      if (!event.detail && event.originalEvent) {
        event.detail = event.originalEvent.detail;
      }

      // If the QoS timer is running, generate the interaction metric now
      BGC.utils.generateInteractivityQoSMetric('oebActivated');

      const priceToSubmit = event.detail.price === undefined ? this.getPriceForSubmission(event.detail.side) : event.detail.price;
      const eventDetail = {
        eventSource  : this.el ? 'DockedOrderEntryBar' : 'Inplace-OEB',
        instrumentId : this.instrument.instrumentId,
        price        : priceToSubmit,
        size         : event.detail.size,
        side         : event.detail.side
      };

      // copes with Backbone view or Polymer element
      containerElement = this.el || this;

      if (event.type !== 'SubmitValidatedPriceAndSize' && priceToSubmit === undefined) {
        // User entered price didn't validate, abort! abort!
        return false;
      }

      // If no size supplied, ask the size control for one, with the instrument's
      // current order size (or if none, first quick-size option) as default
      if (!eventDetail.size) {
        let defaultSize = eventDetail.side === 'buy' ? this.order.buySize : this.order.sellSize;

        if (!defaultSize) {
          // eslint-disable-next-line prefer-destructuring
          defaultSize = BGC.ui.viewUtils.getInstrumentVMQuickSizes(this.instrument.instrumentId, eventDetail.side, priceToSubmit)[0];
        }

        const sizeInputCtrl = containerElement.querySelector(`input[is='size-input-control'].${eventDetail.side}`);

        eventDetail.size = sizeInputCtrl.validateAndGetSizeToSubmit(priceToSubmit, defaultSize).numericValue;
      }

      if (eventDetail.size) {
        // trigger submission of an order with validated details
        containerElement.dispatchEvent(new CustomEvent('submitOrder', {detail : eventDetail, bubbles : true}));

        return true;
      }

      return false;
    },

    /**
     This function is called when a bid/offer price is updated (e.g. nudged) by the trader.
     It ensures that the quick size buttons show the correct values for the new price level,
     and that the manual size input control will validate typed size against that price level.
     (We need to take into account any existing order size at that price level)

     This function is also called when a broker edits the mid price, so we can validate and submit the price.
     */
    onUserChangedPrice (event) {
      const price = event.detail.priceText;
      const {side} = event.detail;
      const containerElement = this.el || this;

      if (BGC.dataStore.isBrokerMode() && side === undefined) {
        // User is a broker and edited the mid price
        if (this.handleMidPriceEdited) {
          this.handleMidPriceEdited(event);
        }
      } else if (side !== undefined && this.instrument.instrumentId) {
        // The price changed in a bid/offer control
        const validatedPrice = event.target.validationCallback(price, false);

        if (validatedPrice.valid) {
          const quickSizeButtons = containerElement.querySelector(`quicksize-buttonset[side='${side}']`);

          if (quickSizeButtons) {
            const sizes = BGC.ui.viewUtils.getInstrumentVMQuickSizes(this.instrument.instrumentId, side, validatedPrice.numericValue);

            quickSizeButtons.updateSizes(this.areBuySizesReversed && side === 'buy' ? sizes.reverse() : sizes);
          }

          const sizeInput = containerElement.querySelector(`input[is='size-input-control'].${side}`);

          if (sizeInput) {
            sizeInput.orderPrice = validatedPrice.numericValue;
          }
        }
      }
    }
  };
}(window.BGC.ui.view));
