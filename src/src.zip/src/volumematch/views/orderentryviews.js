/* eslint-disable no-param-reassign, no-magic-numbers, max-len, max-lines, func-names, complexity, no-plusplus, max-statements, id-length */
/* global BGC: false, $: false, _:false, Backbone: false */
// /////////////////////////////////////////////////////////////////////////////
// file orderentryviews.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

(function (context) {
  const AvgMinWidth = 0.52;


  /*
      new DockedOrderEntryView()
  */

  context.ui.view.DockedOrderEntryView = Backbone.View.extend({
    className : 'order-entry-bar',
    template  : BGC.utils.queryTemplate('#docked-order-entry'),
    events    : {
      'click .cancel-sell'        : 'onClickCancelIcon',
      'click .cancel-buy'         : 'onClickCancelIcon',
      SubmitQuickSize             : 'onSubmitQuickSize',
      SubmitValidatedSize         : 'onSubmitValidatedSize',
      SubmitValidatedPriceAndSize : 'onSubmitValidatedSize',
      SubmitValidatedPrice        : 'handleSubmitOrderEvent',
      'mouseenter .name'          : 'onMouseEnterOrderEntryName',
      'mouseleave .name'          : 'onMouseLeaveOrderEntryName'
    },

    initialize (options) {
      this.dataStore = options.dataStore;
      this.pageLayout = options.pageLayout;
      this.pageLayout.on('change:isMoveableMidEnabled', this.updateMoveableMidDisplay, this);
      this.areBuySizesReversed = true;
      this.dataStore.userSettingsStore.on('change:AllowBrokerRepriceLiveVM', this.requestRender, this);
      this.nameMinSizeInCharacters = this.pageLayout.get('nameMinChars');

      _.extend(this, context.ui.view.OrderEntryControlsContainerBehavior);
      this.setViewModelsAndCallbacks();

      // render view
      this.requestRender();

      this.onSubmitQuickSize = this.onSubmitQuickSize.bind(this);
      this.onSubmitValidatedSize = this.onSubmitValidatedSize.bind(this);
      this.listenTo(this.dataStore.userSettingsStore, 'change:swapBidAndOffer', this.requestRender);
    },

    updateModel (newModel) {
      if (newModel !== this.model) {
        // unsubscribe from changes to previous model
        if (this.model) {
          this.model.off('change', this.onModelAttributesChanged, this);
        }

        // subscribe to changes in new model
        if (newModel) {
          newModel.on('change', this.onModelAttributesChanged, this);
        }

        // set new model and render view
        this.model = newModel;
        this.setViewModelsAndCallbacks(
          newModel,
          newModel ? newModel.getActiveOrder() : undefined,
          newModel ? {
            sizeValidationCallback       : newModel.validateSize.bind(newModel),
            bidPriceValidationCallback   : newModel.validateBidPrice.bind(newModel),
            offerPriceValidationCallback : newModel.validateOfferPrice.bind(newModel)
          } : undefined
        );
        this.requestRender();
      }
    },

    /**
     Returns an object with all the attributes needed to render the view template
     */
    produceRenderAttributesObject () {
      // read instrument and trader's order attributes
      const orderModel = this.getOrderModel();
      const order = orderModel && this.model.canEnterSize() ? orderModel.serialize() : undefined;
      const instrument = this.model && this.model.isInAuction() ? this.model.serialize() : undefined;
      const renderAttributes = {
        orderModel,
        instrument,
        order,
        buyOrder       : order && order.buyOrder,
        sellOrder      : order && order.sellOrder,
        instrumentName : instrument ? instrument.shortName : '',
        spread         : instrument ? instrument.spread : undefined
      };

      if (instrument) {
        if (!instrument.spread) {
          renderAttributes.instrumentName += ` ${instrument.strike2Display}`;
        }

        if (!instrument.showTradeIndicators) {
          // Not showing indicators, override the traded flag
          renderAttributes.instrument.hasTradedAtMidPrice = false;
        }
      }

      return renderAttributes;
    },

    tooltip : BGC.ui.tooltipSingleton.getInstance(),

    onMouseEnterOrderEntryName (event) {
      const targetRect = event.target.getBoundingClientRect();
      const offset = 50;

      this.tooltip.hide();

      if (this.produceRenderAttributesObject().spread) {
        this.tooltip.showKeyValueTooltip(this.buildToolTip(), 'right', {x : targetRect.right, y : targetRect.top - offset});
      }
    },

    onMouseLeaveOrderEntryName () {
      this.tooltip.hide(true);
    },

    buildToolTip () {
      const renderAttributes = this.produceRenderAttributesObject();
      const buySize = renderAttributes.buyOrder ? renderAttributes.buyOrder.buySize : '';
      const sellSize = renderAttributes.sellOrder ? renderAttributes.sellOrder.sellSize : '';
      const hasSellSize = renderAttributes.sellOrder && renderAttributes.sellOrder.hasSellSize;
      const hasBuySize = renderAttributes.buyOrder && renderAttributes.buyOrder.hasBuySize;
      const spreadVar = renderAttributes.spread;

      const showBuySize = !!hasBuySize;
      const showSellSize = !!hasSellSize;
      const nameA = `${spreadVar.instruments[0].get('shortName')} ${spreadVar.instruments[0].get('strike1Display')}%`;
      const nameB = `${spreadVar.instruments[1].get('shortName')} ${spreadVar.instruments[1].get('strike1Display')}%`;
      const priceA = spreadVar.instruments[0].get('priceDisplay');
      const priceB = spreadVar.instruments[1].get('priceDisplay');
      const ratio = `${1} / ${spreadVar.weighting}`;

      return BGC.ui.viewUtils.buildSpreadToolTipPairs(nameA, nameB, priceA, priceB, ratio, buySize, sellSize, showBuySize, showSellSize);
    },

    /**
     Updates attributes of contained Polymer elements etc. to avoid full Backbone View re-render.
     This is a bit dirty but far less risky that converting this view to a Polymer component,
     (especially since spread entry view is derived form it) thus allowing poor update performance
     to be addressed sooner (in 4.51 production version).
     Only called when model attributes changed, so we definitely have a model (instrument).
     */
    onModelAttributesChanged () {
      // get instrument and trader's order attributes
      this.instrument = this.model.serialize();
      const renderAttributes = this.produceRenderAttributesObject();
      const nameElement = this.$el.find('#order-entry-bar-instrument-name span:first-of-type');
      const midPriceElement = this.$el.find('#order-entry-bar-instrument-price');
      const gavelElement = midPriceElement.find('span.traded.gavel');
      const buySizeInput = this.$el.find('#order-entry-bar-buy-input');
      const buySizeCancel = this.$el.find('.cancel-buy');
      const sellSizeInput = this.$el.find('#order-entry-bar-sell-input');
      const sellSizeCancel = this.$el.find('.cancel-sell');
      const buyPrice = renderAttributes.buyOrder ? renderAttributes.buyOrder.price : (renderAttributes.instrument && renderAttributes.instrument.midPrice) || 0.0;
      const sellPrice = renderAttributes.sellOrder ? renderAttributes.sellOrder.price : (renderAttributes.instrument && renderAttributes.instrument.midPrice) || 0.0;

      // 1. Instrument name - highly unliely to change, but you never know with Rolls, etc.
      nameElement.html(renderAttributes.instrumentName);

      // 2. Mid Price
      midPriceElement.find('editable-price-cell').attr('price', renderAttributes.instrument ? renderAttributes.instrument.priceDisplay : '');

      // 2a. and gavel display
      if (renderAttributes.instrument && renderAttributes.instrument.hasTradedAtMidPrice) {
        // Does the gavel need to be added?
        if (!gavelElement.length) {
          midPriceElement.prepend('<span class="traded gavel"></span>');
        }
      } else if (gavelElement.length) {
        gavelElement.remove();
      }

      // 3. User's own order size details
      // 3a. Buy side
      let sizeText = renderAttributes.order && renderAttributes.order.hasBuySize ? renderAttributes.order.buySize : '';

      if (sizeText !== buySizeInput[0].inputField.value) {
        buySizeInput.attr('revert-value', sizeText);

        // Need to validate sizes at this price level
        buySizeInput.attr('order-price', buyPrice);
        buySizeInput[0].revert();
      }
      if (renderAttributes.order && renderAttributes.order.hasCancellableBuySize) {
        if (!buySizeCancel.length) {
          // Insert the cancel icon after the input element
          buySizeInput.after('<img class="cancel-icon cancel-buy" src="./assets/images/cancel.png" />');
        }
      } else if (buySizeCancel.length) {
        // Remove the cancel icon
        buySizeCancel.remove();
      }

      // 3b. Sell side
      sizeText = renderAttributes.order && renderAttributes.order.hasSellSize ? renderAttributes.order.sellSize : '';
      if (sizeText !== sellSizeInput[0].inputField.value) {
        sellSizeInput.attr('revert-value', sizeText);

        // Need to validate sizes at this price level
        sellSizeInput.attr('order-price', sellPrice);
        sellSizeInput[0].revert();
      }
      if (renderAttributes.order && renderAttributes.order.hasCancellableSellSize) {
        if (!sellSizeCancel.length) {
          // Insert the cancel icon after the input element
          sellSizeInput.after('<img class="cancel-icon cancel-sell" src="./assets/images/cancel.png" />');
        }
      } else if (sellSizeCancel.length) {
        // Remove the cancel icon
        sellSizeCancel.remove();
      }

      // 4. Update the pre-defined sizes on either side
      const buySizeButtons = this.$el.find('quicksize-buttonset[side=\'buy\']');

      if (buySizeButtons && buySizeButtons.length) {
        buySizeButtons[0].updateSizes(this.model.getQuickSizes('buy').reverse());
      }

      const sellSizeButtons = this.$el.find('quicksize-buttonset[side=\'sell\']');

      if (sellSizeButtons && sellSizeButtons.length) {
        sellSizeButtons[0].updateSizes(this.model.getQuickSizes('sell'));
      }

      // 5. Apply CSS class styling
      this.applyClassStyles(renderAttributes.instrument, renderAttributes.order);

      // 6. Update bid/offer, price nudge arrows etc. if moveable mids in play
      this.updateMoveableMidDisplay();
    },

    /** toggles display of bid and ask nudge inputs if mid is moveable */
    updateMoveableMidDisplay () {
      const instrumentId = this.model && this.model.get('instrumentId');
      const showMidInputs = this.pageLayout.isMoveableMidEnabled();
      const disableBidInput = !this.model || !this.model.get('canUserEnterOrders') || !this.model.isMoveableBidEnabled();
      const disableOfferInput = !this.model || !this.model.get('canUserEnterOrders') || !this.model.isMoveableOfferEnabled();

      this.$el.toggleClass('no-moveable-mids', !showMidInputs);

      if (showMidInputs) {
        const bidControl = this.$el.find('nudgeable-price-input[side=\'buy\']')[0];
        const offerControl = this.$el.find('nudgeable-price-input[side=\'sell\']')[0];

        if (bidControl) {
          let showLiveBidNudge = false;

          if (!disableBidInput) {
            bidControl.setCallbacks(
              this.model.validateBidPrice.bind(this.model),
              this.model.nudgePriceWithRangeValidation.bind(this.model),
              this.model.formatPrice.bind(this.model)
            );
          }

          // If we have been displaying a nudge arrow in flash state because we nudged a live price,
          // then continue to show the arrow as live after flash ceases, so further nudging can be done
          // without having to click it to re-activate it
          if (!disableBidInput && this.flashDetails && this.model &&
            this.flashDetails[instrumentId] &&
            this.flashDetails[instrumentId].side === 'buy') {
            showLiveBidNudge = true;
          }

          bidControl.setInstrument((this.model && this.model.serialize()) || undefined, disableBidInput, showLiveBidNudge);

          if (!disableBidInput && this.model) {
            bidControl.dispatchEvent(new CustomEvent('price:updated', {detail : {priceText : bidControl.getValue(), side : 'buy'}}));
          } else {
            const buySizeButtons = this.$el.find('quicksize-buttonset[side=\'buy\']');

            if (buySizeButtons && buySizeButtons.length) {
              const sizes = this.model ? this.model.getQuickSizes('buy').reverse() : [0, 0, 0];

              buySizeButtons[0].updateSizes(sizes);
            }
          }
        }

        if (offerControl) {
          let showLiveOfferNudge = false;

          if (!disableOfferInput) {
            offerControl.setCallbacks(
              this.model.validateOfferPrice.bind(this.model),
              this.model.nudgePriceWithRangeValidation.bind(this.model),
              this.model.formatPrice.bind(this.model)
            );
          }

          // If we have been displaying a nudge arrow in flash state because we nudged a live price,
          // then continue to show the arrow as live after flash ceases, so further nudging can be done
          // without having to click it to re-activate it
          if (!disableOfferInput && this.flashDetails && this.model &&
            this.flashDetails[instrumentId] &&
            this.flashDetails[instrumentId].side === 'sell') {
            showLiveOfferNudge = true;
          }

          offerControl.setInstrument((this.model && this.model.serialize()) || undefined, disableOfferInput, showLiveOfferNudge);

          if (!disableOfferInput && this.model) {
            offerControl.dispatchEvent(new CustomEvent('price:updated', {detail : {priceText : offerControl.getValue(), side : 'sell'}}));
          } else {
            const sellSizeButtons = this.$el.find('quicksize-buttonset[side=\'sell\']');

            if (sellSizeButtons && sellSizeButtons.length) {
              const sizes = this.model ? this.model.getQuickSizes('sell') : [0, 0, 0];

              sellSizeButtons[0].updateSizes(sizes);
            }
          }
        }

        if (this.flashDetails && this.model && this.flashDetails[instrumentId]) {
          if (this.model.get('newPrice') || this.model.get('isOrderPriceNewlyNudged')) {
            this.$el.find(this.flashDetails[instrumentId].selector).addClass('flash');
          } else {
            // Just finished new price flash time after we nudged, so show nudge controls in live state
            this.$el.find(this.flashDetails[instrumentId].selector).removeClass('flash');
            delete this.flashDetails[instrumentId];
          }
        }
      }
    },

    requestRender () {
      BGC.ui.viewUtils.requestRender('OEB', 'Docked', this, this.render);
    },

    render () {
      // read instrument and trader's order attributes
      const renderAttributes = this.produceRenderAttributesObject();

      // Get rid of price update listeners attached to contained controls before we obliterate them
      this.removeLocalPriceChangeEventListener();

      // generate html from template
      this.$el.html(this.template({
        instrument     : renderAttributes.instrument,
        instrumentName : renderAttributes.instrumentName,
        weighting      : '',
        displaySizes   : renderAttributes.instrument !== undefined,
        order          : renderAttributes.order,
        buyPrice       : renderAttributes.buyOrder ? renderAttributes.buyOrder.price : (renderAttributes.instrument && renderAttributes.instrument.midPrice) || 0.0,
        sellPrice      : renderAttributes.sellOrder ? renderAttributes.sellOrder.price : (renderAttributes.instrument && renderAttributes.instrument.midPrice) || 0.0,
        resources      : BGC.resources,
        terminology    : renderAttributes.instrument ? renderAttributes.instrument.tradingTerminology : {
          buySizePlaceholder  : BGC.resources.getAdjustedNomenclature('IDS_BUY_SIZE_PLACEHOLDER', this.pageLayout.get('nomenclature')),
          sellSizePlaceholder : BGC.resources.getAdjustedNomenclature('IDS_SELL_SIZE_PLACEHOLDER', this.pageLayout.get('nomenclature'))
        },
        defaultNomenclature      : this.pageLayout.get('nomenclature'),
        priceEditable            : !!renderAttributes.instrument && this.dataStore.userSettingsStore.get('AllowBrokerRepriceLiveVM') && this.dataStore.isBrokerMode(),
        showSpreadCommandButtons : false
      }));

      const nameElement = this.$el.find('#order-entry-bar-instrument-name');

      // Listen for trader bid/offer nudges or broker mid-price edit
      this.addLocalPriceChangeEventListener();

            // Set validation callback for the size input controls
            if (this.model) {
                this.el.querySelectorAll("size-input-control").forEach(function (sizeInput) {
                    sizeInput.setValidationCallback(this.model.validateSize.bind(this.model));
                }, this);
            }

      // If moveable mids are in play, updateMoveableMidDisplay() will update the quick sizes too.
      // Otherwise, or if we have no selected instrument, do it here.
      if (!this.pageLayout.isMoveableMidEnabled() || !renderAttributes.instrument) {
        // Update the pre-defined sizes on either side
        const buySizeButtons = this.$el.find('quicksize-buttonset[side=\'buy\']');

        if (buySizeButtons && buySizeButtons.length) {
          const sizes = renderAttributes.instrument ? this.model.getQuickSizes('buy').reverse() : [0, 0, 0];

          buySizeButtons[0].updateSizes(sizes);
        }

        const sellSizeButtons = this.$el.find('quicksize-buttonset[side=\'sell\']');

        if (sellSizeButtons && sellSizeButtons.length) {
          const sizes = renderAttributes.instrument ? this.model.getQuickSizes('sell') : [0, 0, 0];

          sellSizeButtons[0].updateSizes(sizes);
        }
      }

      this.updateMoveableMidDisplay();

      // apply CSS class styling
      this.applyClassStyles(renderAttributes.instrument, renderAttributes.order);

      // set the minimum width on the instrument name field from the document
      nameElement[0].style.minWidth = `${this.calcNameMinWidth(nameElement)}px`;
    },

    calcNameMinWidth (nameElement) {
      const fontSize = parseFloat(nameElement.css('font-size'));

      // extra is padding-left for name element
      return (AvgMinWidth * fontSize * this.pageLayout.get('nameMinChars')) + 7;
    },

    // Note that inputs here are serialized model objects, not actual models
    applyClassStyles (instrument, order) {
      const buyElem = this.$el.find('.buy');
      const sellElem = this.$el.find('.sell');

      this.$el.toggleClass('no-instrument', instrument === undefined);

      this.$el.find('quicksize-buttonset').toggleClass('no-instrument', instrument === undefined);

      // Based on the preference "swapBidAndOffer" toggle the mirror class.
      if (this.dataStore.userSettingsStore.get('swapBidAndOffer')) {
        this.$el.find('#mirrorElements').removeClass('commandLine');
        this.$el.find('#mirrorElements').addClass('mirror');
      }

      // const isInputDisabled = instrument === undefined || !instrument.canUserEnterOrders;
      // BrokerMode already determine user to place an order or not
      // Therefore, check instrument exist or not and isBrokerMode is enough information to set isInputDisabled value
      const isInputDisabled = !!(!instrument || this.dataStore.isBrokerMode());

            // If there is a selected instrument but the user is disallowed from entering orders on it,
            // OR if we are a broker (regardless of whether there is a selected instrument or not)
            // show the whole order entry bar in disabled state
        	this.$el.toggleClass('input-disabled', isInputDisabled);

      // disable input controls when no instrument is selected or the user is disallowed from entering orders
      // this.$el.find('input').not('.editable-price-cell').attr('disabled', instrument === undefined || !instrument.canUserEnterOrders);
            $(buyElem[0].inputField).attr("disabled", isInputDisabled )
            $(sellElem[0].inputField).attr("disabled", isInputDisabled )

      // toggle buy/sell size cell styles dependent on whether an order is being rendered
      buyElem.toggleClass('no-order', !(order && order.hasBuySize));
      buyElem.toggleClass('published-by-excel', !!(order && order.wasBuyPublishedByExcel));

      sellElem.toggleClass('no-order', !(order && order.hasSellSize));
      sellElem.toggleClass('published-by-excel', !!(order && order.wasSellPublishedByExcel));

      // apply VM interest glows to price cell
      if (instrument) {
        BGC.ui.viewUtils.applyThirdPartyInterestGlows(instrument.showThirdPartyInterestGlows ? instrument.thirdPartyInterest : 'none', this.el.querySelectorAll('.price'));
        BGC.ui.viewUtils.applySameLEInterestGlows(instrument.hasSameLeBuyInterest, instrument.hasSameLeSellInterest, this.el.querySelectorAll('.price'));
      }
    },

    onClickCancelIcon (event) {
      const target = $(event.target);

      BGC.ui.viewUtils.cancelOrder(this.model, 'DockedOrderEntryBar', target.hasClass('cancel-buy') ? 'buy' : 'sell');
    },

    onSubmitQuickSize (event) {
      event.stopPropagation();

      // are we rendering a valid model, is the click event suppressed ?
      if (!this.model || !this.model.isInAuction() || this.suppressClickEvent()) {
        return;
      }

      this.processSubmitOrderEvent(event);
    },

    onSubmitValidatedSize (event) {
      event.stopPropagation();

      const eventDetail = {
        eventSource   : 'DockedOrderEntryBar',
        instrumentId  : this.model.get('instrumentId'),
        price         : event.originalEvent.detail.price,
        size          : event.originalEvent.detail.size,
        side          : event.originalEvent.detail.side,
        flashSelector : event.originalEvent.detail.flashSelector
      };

      this.processSubmitOrderEvent(event);

      if (eventDetail.flashSelector) {
        this.flashDetails = this.flashDetails || {};

        // If already flashing something for this instrument, stop it
        if (this.flashDetails[eventDetail.instrumentId]) {
          clearTimeout(this.flashDetails[eventDetail.instrumentId].timerId);
        }

        // Store the details for the new flash
        this.model.set('isOrderPriceNewlyNudged', true);
        this.flashDetails[eventDetail.instrumentId] = {
          selector : eventDetail.flashSelector,
          side     : eventDetail.side,
          timerId  : setTimeout(() => {
            this.model.set('isOrderPriceNewlyNudged', false);
          }, this.dataStore.userSettingsStore.get('newPriceFlashDuration'))
        };

        this.$el.find(eventDetail.flashSelector).addClass('flash');
      }
    },

    handleSubmitOrderEvent (event) {
      // Pass to the inherited behavior. In this instance, we don't care about the success/failure.
      this.processSubmitOrderEvent(event);
    },

    enterOrder (size, side, price) {
      // validate entered size and submit order
      const instrument = this.model;

      if (instrument) {
        if (instrument.isMoveableMidEnabled()) {
          if (price === undefined) {
            price = this.getPriceForSubmission(side);
          } else if (typeof price !== 'number') {
            throw new TypeError('[DockedOrderEntryBar:enterOrder] Price must be numeric!');
          }
        } else {
          price = instrument.get('midPrice');
        }

        const order = this.model.getOrderDetailsForSubmission(side, price, size);

        BGC.ui.viewUtils.submitOrder(instrument, {
          side, size : order.size, price : order.price, priceDisplay : order.priceDisplay
        }, 'DockedOrderEntryBar');
      }
    },

    // This function is called for broker-driven mid-price changes (which it validates and submits),
    handleMidPriceEdited (event) {
      const price = event.detail.priceText;
      const {side} = event.detail;

      if (this.dataStore.isBrokerMode() && side === undefined) {
        if (this.model.validatePrice(price, true).valid) {
          this.model.sendReprice(price, 'DockedOrderEntryBar');
        }
      }
    },

    getOrderModel () {
      return this.model ? this.model.getActiveOrder() : undefined;
    }
  });

  // mixin suppress event function
  _.extend(context.ui.view.DockedOrderEntryView.prototype, context.ui.viewUtils.SuppressEventMixin);

  context.ui.view.SpreadOrderEntryBar = context.ui.view.DockedOrderEntryView.extend({
    className : 'order-entry-bar',
    events () {
      return _.extend(context.ui.view.DockedOrderEntryView.prototype.events, {
        'click .submit' : 'onClickSubmit',
        'click .clear'  : 'onClickClear'
      });
    },

    initialize (options) {
      this.spread = options.spread;
      this.oebIndex = options.oebIndex;
      this.isPreviewMode = options.isPreviewMode;
      this.showSpreadCommandButtons = options.showSpreadCommandButtons;
      this.dataStore = options.dataStore;

      this.model.on('change', this.onUnderlyingStateChange, this);
    },

    render () {
      // read instrument and trader's order attributes
      const orderModel = this.getOrderModel();
      const instrument = this.model.serialize();
      const order = orderModel ? orderModel.serialize() : undefined;
      const instrumentName = `${instrument.shortName} ${instrument.strike2Display}`;

      // generate html from template
      this.$el.html(this.template({
        instrument,
        instrumentName,
        weighting    : this.spread.getOrder(this.oebIndex) ? this.spread.buildWeightingString(this.oebIndex) : '',
        displaySizes : this.oebIndex === 0 || order,
        order,
        buyPrice     : (instrument && instrument.midPrice) || 0.0,
        sellPrice    : (instrument && instrument.midPrice) || 0.0,
        resources    : BGC.resources,
        terminology  : instrument ? instrument.tradingTerminology : {
          buySizePlaceholder  : BGC.resources.getAdjustedNomenclature('IDS_BUY_SIZE_PLACEHOLDER', this.pageLayout.get('nomenclature')),
          sellSizePlaceholder : BGC.resources.getAdjustedNomenclature('IDS_SELL_SIZE_PLACEHOLDER', this.pageLayout.get('nomenclature'))
        },
        defaultNomenclature      : this.dataStore.pageLayout.get('nomenclature'),
        priceEditable            : false,
        showSpreadCommandButtons : this.showSpreadCommandButtons || false,
        submitSpreadAndOrder     : !this.dataStore.isBrokerMode()
      }));

            // Set validation callback for the size input controls
            if (this.model) {
                this.el.querySelectorAll("size-input-control").forEach(function (sizeInput) {
                    sizeInput.setValidationCallback(this.model.validateSize.bind(this.model));
                }, this);
            }

      // Update the pre-defined sizes on either side
      const buySizeButtons = this.$el.find('quicksize-buttonset[side=\'buy\']');

      if (buySizeButtons && buySizeButtons.length) {
        buySizeButtons[0].updateSizes(this.model.getStandardSizes().reverse());
      }

      const sellSizeButtons = this.$el.find('quicksize-buttonset[side=\'sell\']');

      if (sellSizeButtons && sellSizeButtons.length) {
        sellSizeButtons[0].updateSizes(this.model.getStandardSizes());
      }

      // apply CSS class styling
      this.applyClassStyles(instrument, order);

      // Allow traders who are not buy/sell disabled and brokers to create spreads.
      this.$el.find('.submit').attr('disabled', this.spread === undefined || (this.model.get('canUserEnterOrders') && (this.spread.getD1OrderSize() === 0)) || (!this.model.get('canUserEnterOrders') && !this.dataStore.isBrokerMode() && !this.dataStore.isSalesTraderMode()));
      this.$el.find('.clear').attr('disabled', this.spread === undefined);

      // rebind event handlers since parent call to .html unbinds subviews
      this.delegateEvents();

      return this;
    },

    applyClassStyles (instrument, order) {
      context.ui.view.DockedOrderEntryView.prototype.applyClassStyles.apply(this, [instrument, order]);

      // hide mid moveable inputs when creating spread
      this.$el.addClass('no-moveable-mids');

      this.$el.addClass('order-entry-bar');

      if (this.oebIndex !== 0) {
        const restrictToDefaultWeightingOnly = true;

        this.$el.find('.buy').attr('disabled', order === undefined || !order.hasBuySize || restrictToDefaultWeightingOnly);
        this.$el.find('.sell').attr('disabled', order === undefined || !order.hasSellSize || restrictToDefaultWeightingOnly);
        this.$el.find('input').attr('placeholder', '');

        if (restrictToDefaultWeightingOnly) {
          this.$el.find('quicksize-buttonset').addClass('disable-order-entry');
        }
      }
    },

    onSubmitQuickSize (event) {
      this.onSubmitValidatedSize(event);
    },

    onSubmitValidatedSize (event) {
      event.stopPropagation();

      // are we rendering a valid model, is the click event suppressed ?
      if (!this.model || !this.model.isInAuction() || this.suppressClickEvent()) {
        return;
      }

      this.enterOrder(event.originalEvent.detail.size, event.originalEvent.detail.side);
    },

    enterOrder (size, side) {
      if (this.oebIndex === 0 || this.spread.getOrder(this.oebIndex)) {
        if (this.spread.validateSize(this.oebIndex, size).valid) {
          this.spread.setOrder(this.oebIndex, side, size);
        }
      }
    },

    getOrderModel () {
      return this.spread.getOrder(this.oebIndex);
    },

    onClickCancelIcon () {
      // clear the size
      this.spread.clearOrders();
    },

    onUnderlyingStateChange () {
      if (this.isPreviewMode || this.spread.validateUnderlying(this.oebIndex, false)) {
        this.requestRender();
      } else {
        this.off('spreadRequest');
        this.$el.trigger('collapseOrderEntry');
      }
    },

    onClickClear () {
      this.off('spreadRequest');
      this.$el.trigger('collapseOrderEntry');
    },

    onClickSubmit () {
      this.spread.once('spreadRequest', this.onSpreadRequested, this);
      this.spread.createSpread(!this.dataStore.isBrokerMode());
    },

    onSpreadRequested () {
      this.$el.trigger('collapseOrderEntry');
    }
  });

  context.ui.view.SpreadOrderEntryView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#spread-order-entry'),

    initialize (options) {
      this.dataStore = options.dataStore;
      this.oebViews = [];

      this.render();
    },

    updateModel (mode, newModel) {
      let activeModel = false;

      this.oebViews = [];
      this.model = newModel;

      if (mode === 'previewSelection' || (mode === 'selection' && newModel.validateUnderlyings(true))) {
        activeModel = true;

        // If a broker is creating a spread, calculate the custom size ratio using
        // the D1's minimum size as the "buy order size", but don't post any order.
        if (this.dataStore.isBrokerMode()) {
          this.model.setOrder(0, 'buy', this.model.getInstrument(0).get('minSize'));
        }

        this.model.on('change', this.render, this);

        this.initializeOEBars(mode);
        this.render();
      } else {
        // reset the view
        BGC.logger.logInformation('Spreads View:updateModel()', 'Reset and hidden');
        this.model = undefined;
        this.render();
      }

      return activeModel;
    },

    initializeOEBars (mode) {
      if (mode === 'previewSelection') {
        // get unsorted underlyings so that when we see the preview we can see the spread bars consistently while preview each instrument. Otherwise, the vega sorting will make
        // the view hard to look at.
        this.model.get('instruments').forEach(function (instrument, index) {
          this.oebViews.push(new context.ui.view.SpreadOrderEntryBar({
            model : instrument, spread : this.model, oebIndex : index, isPreviewMode : true, dataStore : this.dataStore
          }));
        }, this);
      } else {
        this.model.get('underlyings').forEach(function (underlying, index) {
          this.oebViews.push(new context.ui.view.SpreadOrderEntryBar({
            model : underlying.instrument, spread : this.model, oebIndex : index, isPreviewMode : false, showSpreadCommandButtons : index === (this.model.get('underlyings').length - 1), dataStore : this.dataStore
          }));
        }, this);
      }
    },

    render () {
      this.$el.html(this.template({resources : BGC.resources}));

      const $oebs = this.$el.find('.order-entry-bars');

      $oebs.empty();

      this.oebViews.forEach(oeb => {
        $oebs.append(oeb.render().$el);
      });
    }
  });

  context.ui.view.SpreadCreationView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#spread-creation-view'),

    initialize (options) {
      // create spread search edit
      this.spreadSearchView = new context.ui.view.InstrumentSearchView({
        el    : this.$el.find('.instrument-search')[0],
        model : options.matrix
      });

      this.render();
    },

    render () {
      this.$el.html(this.template({resources : BGC.resources}));

      this.$el.find('.instrument-search').append(this.spreadSearchView.requestRender().$el);
    },

    updateModel (spreadModel) {
      this.model = spreadModel;

      if (this.model) {
        this.model.on('change', this.render, this);
      }

      this.render();
    }
  });

  context.ui.view.SpreadView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#spread-view'),
    events   : {
      searchInstrument   : 'onSearchInstrument',
      collapseOrderEntry : 'onCollapseOrderEntry'
    },

    initialize (options) {
      this.dataStore = options.dataStore;

      this.$el.html(this.template());

      // create spread order entry view
      this.spreadOrderEntryView = new context.ui.view.SpreadOrderEntryView({
        el        : this.$el.find('.spread-order-entry-bar')[0],
        dataStore : this.dataStore
      });

      // create spread creation view
      this.spreadCreationView = new context.ui.view.SpreadCreationView({
        el        : this.$el.find('.spread-creation')[0],
        matrix    : options.matrix,
        dataStore : this.dataStore
      });
    },

    onSearchInstrument (event, instrument) {
      if (context.ui.selectionManager.getSelectedInstrument() && context.ui.selectionManager.getSelectedView() === context.ui.view.matrixView) {
        this.updateModel('selection', [instrument, context.ui.selectionManager.getSelectedInstrument()]);
      } else {
        context.ui.view.matrixView.selectInstrument(instrument, true);
      }
    },

    onCollapseOrderEntry () {
      context.ui.view.dockedOrderEntryView.$el.show();

      this.spreadOrderEntryView.updateModel('cancelSelection', undefined);
      this.spreadCreationView.updateModel(undefined);
      this.spreadCreationView.$el.show();
    },

    updateModel (mode, instruments) {
      const newModel = new this.dataStore.modelDefinitions.Spread({instruments});

      if (this.spreadOrderEntryView.updateModel(mode, newModel)) {
        this.spreadCreationView.updateModel(mode === 'selection' ? newModel : undefined);
        this.spreadCreationView.$el.hide();

        context.ui.view.dockedOrderEntryView.$el.hide();
      } else if (!context.ui.view.dockedOrderEntryView.$el.is(':visible')) {
        context.ui.view.dockedOrderEntryView.$el.show();
        this.spreadCreationView.$el.show();
      }
    },

    isPopulated () {
      return this.spreadOrderEntryView.model !== undefined;
    },

    close () {
      this.spreadCreationView.updateModel(undefined);
      this.spreadOrderEntryView.updateModel('cancelSelection', undefined);

      context.ui.view.dockedOrderEntryView.$el.show();
      this.$el.hide();
    }
  });
}(window.BGC));
