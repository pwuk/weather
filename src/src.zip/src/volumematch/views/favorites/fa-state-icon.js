/* eslint-disable class-methods-use-this */

import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './fa-state-icon.template';

class FaStateIcon extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor () {
    super();
    this.addEventListener('click', this.onClickIcon);
  }


  connectedCallback () {
    super.connectedCallback();
  }

  static get properties () {
    return {
      stateClasses : Array,
      state        : {
        type  : Number,
        value : 0
      }

    };
  }

  getClassList (state, stateClasses) {
    return `fa ${stateClasses[state]}`;
  }

  toggleState () {
    // this.state = this.state === this.stateClasses.length - 1 ? 0 : this.state + 1;
    this.state = (this.state + 1) % this.stateClasses.length;
  }

  onClickIcon (event) {
    if (this.isDisabled) {
      event.stopPropagation();
    } else {
      this.toggleState();
    }
  }
}

customElements.define('fa-state-icon', FaStateIcon);
