/* eslint-disable class-methods-use-this */

import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './fa-icon.template';

class FaIcon extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor () {
    super();
    this.addEventListener('tap', this.onClickIcon);
  }


  connectedCallback () {
    super.connectedCallback();
  }

  onClickIcon (event) {
    if (this.isDisabled) {
      event.stopPropagation();
    }
  }

  // factoryImpl: function (options) {
  //     this.iconClass = options.iconClass;
  // },

  getClassList (iconClass) {
    return `fa ${iconClass}`;
  }


  static get properties () {
    return {
      iconClass : {
        type  : String,
        value : ''
      },
      isDisabled : {
        type               : Boolean,
        value              : false,
        reflectToAttribute : true
      }
    };
  }
}

customElements.define('fa-icon', FaIcon);
