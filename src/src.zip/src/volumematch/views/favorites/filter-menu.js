import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './filter-menu.template';

class FilterMenu extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor () {
    super();
    this.addEventListener('mouseenter', this.onEnterMenu);
    this.addEventListener('mouseleave', this.onLeaveMenu);
  }

  connectedCallback () {
    super.connectedCallback();
  }

  static get properties () {
    return {
      isDisabled : {
        type               : Boolean,
        value              : false,
        reflectToAttribute : true
      }
    };
  }


  onEnterMenu () {
    this.isMenuHidden = false;
  }

  onLeaveMenu () {
    this.isMenuHidden = true;
  }

  ready () {
    super.ready();
    this.isMenuHidden = true;
  }

  onClickMenuItem (event) {
    const filterIcon = event.currentTarget.querySelector('fa-state-icon');

    // Toggle the filter icon state unless the icon icon itself has been clicked
    // (the state icon component automatically toggles its own state when clicked)
    if (event.srcElement.parentElement !== filterIcon) {
      filterIcon.toggleState();
    }

    // Set the menu item state
    event.model.set('item.state', filterIcon.state);

    // Fire an event to let subscribers know the filter state has changed
    this.dispatchEvent(
      new CustomEvent('change:filter', {
        bubbles  : true,
        composed : true
      })
    );
  }
}

customElements.define('filter-menu', FilterMenu);
