/* eslint-disable max-len */

import {html} from '@polymer/polymer';

export default html`
<style>
* { box-sizing: border-box;}

@font-face {
    font-family: 'FontAwesome';
    src: url('../fonts/fontawesome-webfont.eot?v=4.0.3');
    src: url('../fonts/fontawesome-webfont.eot?#iefix&v=4.0.3') format('embedded-opentype'), url('../fonts/fontawesome-webfont.woff?v=4.0.3') format('woff'), url('../fonts/fontawesome-webfont.ttf?v=4.0.3') format('truetype'), url('../fonts/fontawesome-webfont.svg?v=4.0.3#fontawesomeregular') format('svg');
    font-weight: normal;
    font-style: normal;
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-style: normal;
    font-weight: normal;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.counter {
    display: inline-block;

    text-align: right;
    color: var(--submit-button-highlight-text);

    min-width: 10px;
}

.fa {
    font-size: 1.1rem;
    color: var(--submit-button-highlight-text);
}


.submit-button {
    position: relative;
    float: right;
    margin-top: 4px;
    margin-right: 4px;
    padding: 0 0.5rem 1px 0.5rem;
    height: 2rem;
    font-size: 1.2rem;
    font-weight: 600;
    text-transform: uppercase;
    color: white;
    background-color: var(--submit-button-background);
    border: 1px solid var(--submit-button-background-lighter10);
    overflow: hidden;
}
.submit-button:hover:not(:disabled) {
    border-color: var(--submit-button-background-lighter10);
}
.submit-button[disabled] {
    pointer-events: none;
    opacity: 0.5;
}
.submit-button .counter {
    display: inline-block;
    text-align: right;
    color: var(--submit-button-highlight-text);
    min-width: 10px;
}
.submit-button .fa {
    font-size: 1.1rem;
    color: var(--submit-button-highlight-text);
}

.submit-button:hover:not(:disabled) {
    border-color: var(--submit-button-background-lighter10);
}
.submit-button[disabled] {
    pointer-events: none;
    opacity: 0.5;
}
.submit-button .counter {
    display: inline-block;
    text-align: right;
    color: var(--submit-button-highlight-text);
    min-width: 10px;
}
.submit-button .fa {
    font-size: 1.1rem;
    color: var(--submit-button-highlight-text);
}


.fa-star:before {
    content: "\\f005";
}

.fa-star-o:before {
    content: "\\f006";
}
    
</style>
<span>[[getButtonLabel('IDS_SUBMIT_FAVORITES')]]</span>
<span class="counter">[[getButtonCount(count)]]</span>
<i class$="[[getClassList(count, inactiveIconClass, activeIconClass)]]"></i>
`;
