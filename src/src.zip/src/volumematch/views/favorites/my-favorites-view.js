/* eslint-disable no-magic-numbers, func-names, no-plusplus, no-param-reassign, max-lines, class-methods-use-this, max-statements, max-params, complexity, max-len */
/* global BGC: false, $: false, _:false */

import {PolymerElement} from '@polymer/polymer';
import {isWebDeployed} from '../../bgc';
import componentTemplate from './my-favorites-view.template';

const {ui: context, resources, utils} = window.BGC;
const {KeyCodes: keyCodes} = utils;
const defaultVisibleRowCount = 40;
const checkStates = ['unchecked', 'semi-checked', 'checked'];

context.confirmFavorites = $('#confirmFavorites').popup({
  draggable      : false,
  cmdConfirmText : resources.IDS_YES,
  cmdCancelText  : resources.IDS_NO
});

class MyFavoritesView extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  ready () {
    super.ready();
    this.clearAllIcon = this.$['clear-all-icon'];
    this.rowsTemplate = this.$['footprint-rows-template'];
    this.favoriteRows = this.$['favorite-rows'];
    this.filterDropDown = this.$['product-filter'];

    this.submitButton = $('orders-and-trades-toolbar')[0].shadowRoot.querySelector('#submit-button');
    this.submitButton.addEventListener('click', this.onClickSubmit.bind(this));

    // Bind any view labels
    this.labelProduct = resources.IDS_PRODUCT;

    // Configure the generic columns
    this.genericColumns = this.classOptions.layout.get('genericColumns').filter(
      item => (item.columnId === 'strike1Display') || (item.columnId === 'strike2Display')
    );

    // Reference the footprints collection and bind observers to add or remove the corresponding view model
    this.footprints = this.classOptions.footprints;
    this.footprints.on('add', this.addRow, this);
    this.footprints.on('remove', this.removeRow, this);
    this.footprints.on('reset', this.resetRows, this);

    // Reference the settings collection and bind any setting change observers
    this.settings = this.classOptions.settings;
    this.hideSizeButtons = !this.settings.get('displayFavoritesSizeButtons');
    this.enableRowSelectors = !this.settings.get('disableBatchSubmission');
    this.settings.on('change:isOrdersViewFixedHeight', this.updateViewBounds, this);
    this.settings.on('change:fixedHeightOrdersViewRowCount', this.updateViewBounds, this);

    this.settings.on('change:disableBatchSubmission', function () {
      this.set('enableRowSelectors', !this.settings.get('disableBatchSubmission'));
    }, this);

    this.settings.on('change:displayFavoritesSizeButtons', function () {
      this.set('hideSizeButtons', !this.settings.get('displayFavoritesSizeButtons'));
    }, this);

    // Based on swapBidAndOffer preference update the mirrorClass.
    this.mirrorClass = this.settings.get('swapBidAndOffer') ? 'fav-row-Controls mirror' : 'fav-row-Controls';
    this.settings.on('change:swapBidAndOffer', () => {
      this.mirrorClass = this.settings.get('swapBidAndOffer') ? 'fav-row-Controls mirror' : 'fav-row-Controls';
    });

    // If an external view has taken the global selection, clear internal selection
    context.selectionManager.on('selectionChanging', function (currentSelection, newSelection) {
      if (newSelection.view !== this) {
        this.clearSelection();
      }
    }, this);

    // Initialize the view models
    this.redoCollection = [];
    this.undoCollection = [];
    this.resetRows(this.footprints.models);

    // Add a listener to re-render the view when the filter criteria changes
    this.filterDropDown.addEventListener('change:filter', () => {
      this.renderRows();
      this.renderRows();
      this.updateFavoritesHeader();
    });
  }

  sortFunc (row1, row2) {
    const sort1 = row1.footprint.getSortCriteria();
    const sort2 = row2.footprint.getSortCriteria();

    if (sort1.layoutPos !== sort2.layoutPos) {
      return sort1.layoutPos - sort2.layoutPos;
    }
    if (sort1.tilePos !== sort2.tilePos) {
      return sort1.tilePos - sort2.tilePos;
    }

    return sort1.instrumentPos - sort2.instrumentPos;
  }

  filterFunc (row) {
    // If there is a single 'active' row, filter out the 'inactive' rows,
    // otherwise just use the filter state
    if (this.rows.some(rowItem => rowItem.rowState === 'active')) {
      return row.rowState === 'active' && row.filter.state === 1;
    }

    return row.filter.state === 1 && row.rowState !== 'pending';
  }

  constructor (options) {
    super();
    this.classOptions = options;
    this.updateViewBounds = _.debounce(this.updateViewBounds.bind(this), 100);
  }

  static get observers () {
    return [
      'rowsObserver(rows.*)'
    ];
  }

  renderRows () {
    this.classList.toggle('fixed-height', this.settings.get('isOrdersViewFixedHeight') === 1);

    this.rowsTemplate.render();
    this.dispatchEvent(
      new CustomEvent('recalcLayout', {
        bubbles  : true,
        composed : true
      })
    );
  }

  // _.debounce 100
  updateViewBounds () {
    const scrollContainer = this.shadowRoot.querySelector('.scroll-container');
    const scrollableContent = this.shadowRoot.querySelector('.scrollable-content');
    const $headerRow = $(this.$['my-favorites-header']);

    let rowHeight = 0;
    let totalFixedHeight = 0;
    let totalRowHeight = 0;

    // Retrieve the row height from an unneeded property then override the property
    // on the header row's children so that it doesn't affect the rendering of the DOM.
    const rowHeightStr = $headerRow.css('text-indent');

    if (rowHeightStr) {
      rowHeight = Number(rowHeightStr.slice(0, rowHeightStr.indexOf('px')));

      $headerRow.children().each(function () {
        $(this).css('text-indent', '0px');
      });
    }

    // If the scroll container is showing a vertical scrollbar,
    // we need to get rid of the right padding/margin on the contained area
    if (scrollContainer && scrollableContent) {
      const rowElements = this.shadowRoot.querySelectorAll('.footprint-row');
      const isFixedHeight = this.settings.get('isOrdersViewFixedHeight') === 1;

      this.classList.toggle('fixed-height', isFixedHeight);

      // Determine the minimum and maximum height of the scroll container
      // and scrollable content.
      if (isFixedHeight === true) {
        // Apply the fixed height using the user configured number of rows if the
        // fixed height area is enabled.
        totalFixedHeight = this.settings.get('fixedHeightOrdersViewRowCount') * rowHeight;
        if (rowElements && rowElements.length) {
          totalRowHeight = rowElements.length * rowHeight;
        }


        scrollContainer.style.maxHeight = `${totalFixedHeight}px`;
        scrollableContent.style.minHeight = `${totalFixedHeight}px`;
      } else if (rowElements && rowElements.length) {
        // restrict to a maximum number of rows before showing scroll bar
        totalFixedHeight = defaultVisibleRowCount * rowHeight;
        totalRowHeight = rowElements.length * rowHeight;


        scrollContainer.style.maxHeight = `${totalFixedHeight < totalRowHeight ? totalFixedHeight : totalRowHeight}px`;
        scrollableContent.style.minHeight = `${totalRowHeight}px`;
      } else {
        scrollContainer.style.removeProperty('max-height');
        scrollableContent.style.removeProperty('min-height');
      }

      // Sets the overflow to be scrollable/hidden based on whether the content is more than the container height.
      BGC.ui.viewUtils.updateElementVerticalOverflow(scrollContainer, scrollableContent);

      // apply scrollable content width to header to as they don't lineup otherwise.
      // $headerRow.css('margin-right', '0');
    }

    // If no scrollbar required (rows fit within containers)
    // then last row needs to be styled with its own bottom border.
    this.favoriteRows.classList.toggle('bottom-border', totalRowHeight < totalFixedHeight);
  }

  resetRows (models) {
    // Reset the view models
    this.rows = [];
    this.selectedRow = null;
    this.filterList = [];

    models.forEach(function (model) {
      this.addRow(model, null, {restore : false});
    }, this);

    this.updateViewBounds();
  }

  // Invoked when a 'footprint' has been added to the collection, creates a row view model for the new footprint
  addRow (model, collection, options) {
    // If the model is 'pending', bind a listener to add the row when its state changes
    if (model.get('state') === 'pending') {
      // Ensure the new footprint is not already in the 'undo' collection
      this.removeItemFromCollection(this.undoCollection, model);
      this.set('undoCollection.length', this.undoCollection.length);
      this.notifyPath('redoCollection.length');
      this.notifyPath('undoCollection.length');


      model.once('change:state', this.addRow, this);

      return;
    }

    const modelTileInfo = model.getTileInfo();

    // If the model tile info is missing, we are not add into favorite
    if (!modelTileInfo) {
      BGC.logger.logWarning('Tile', 'Model TileInfo is missing, not insert the instrument into favorite tab.');

      return;
    }

    // Update the filter list
    const filter = this.updateFilterList(modelTileInfo);

    // Create the row view model
    this.push('rows', {
      footprint             : model,
      rowState              : model.get('state'),
      checkState            : 'unchecked',
      isSelected            : false,
      instrumentName        : model.getDisplayName(),
      genericFields         : model.getGenericFieldValues(this.genericColumns),
      standardBuySizes      : model.getStandardSizes().reverse(),
      size                  : model.get('unfilledSize'),
      side                  : model.get('side'),
      price                 : model.getDisplayPrice(),
      standardSellSizes     : model.getStandardSizes(),
      lastMidPriceDirection : model.getLastAuctionMidPriceDirection(),
      filter
    });

    // If the row is not being restored, ensure the new footprint is not already in the 'undo' collection
    if (!options || !options.restore) {
      this.removeItemFromCollection(this.undoCollection, model);
      this.set('undoCollection.length', this.undoCollection.length);
      this.notifyPath('redoCollection.length');
      this.notifyPath('undoCollection.length');


      // Bind a listener to update the row state when the model state changes
      model.on('change:state', this.updateRowState, this);
    }

    // Recalculate the view bounds
    this.updateViewBounds();
  }


  // Invoked when a 'footprint' is removed from the collection, deletes the corresponding row view model
  removeRow (model, collection, options) {
    // Remove the row view model
    const removedRow = this.splice('rows', this.findRowIndex(model), 1)[0];

    // If this is the last row with this filter, remove the filter from the filter list
    if (!_.find(this.rows, row => row.filter === removedRow.filter)) {
      this.removeFilterItem(removedRow.filter);
    }

    // If the row is not marked for 'restore', ensure the removed model is not in the 'redo' collection
    if (!options.restore) {
      this.removeItemFromCollection(this.redoCollection, model);
      this.set('redoCollection.length', this.redoCollection.length);


      // Unbind the instrument state listener
      model.off('change:state', this.updateRowState, this);
    }

    this.notifyPath('redoCollection.length');
    this.notifyPath('undoCollection.length');

    // Reset the view bounds
    this.updateViewBounds();
  }

  // Invoked when the model 'state' changes, updates the corresponding view model
  updateRowState (model, newState) {
    const rowIndex = this.findRowIndex(model);
    let doUpdateViewBounds = false;

    if (this.rows[rowIndex] && this.rows[rowIndex].rowState !== model.get('state')) {
      // Row visibility probably changed, need to assess how much height to allow,
      // and adjust scrolling parameters if necessary
      doUpdateViewBounds = true;
    }

    this.set(`rows.${rowIndex}.rowState`, model.get('state'));
    this.set(`rows.${rowIndex}.price`, model.getDisplayPrice());
    this.set(`rows.${rowIndex}.size`, model.get('unfilledSize'));
    this.set(`rows.${rowIndex}.side`, model.get('side'));
    this.set(`rows.${rowIndex}.instrumentName`, model.getDisplayName());
    this.set(`rows.${rowIndex}.genericFields`, model.getGenericFieldValues(this.genericColumns));
    this.set(`rows.${rowIndex}.standardBuySizes`, model.getStandardSizes().reverse());
    this.set(`rows.${rowIndex}.standardSellSizes`, model.getStandardSizes());
    this.set(`rows.${rowIndex}.lastMidPriceDirection`, model.getLastAuctionMidPriceDirection());

    // Ensure the row is un-checked when the model has been deactivated
    if (newState === 'pending') {
      this.set(`rows.${rowIndex}.checkState`, 'unchecked');
      this.clearSelection();
    }

    if (doUpdateViewBounds) {
      this.updateViewBounds();
    }
  }

  updateFilterList (newFilter) {
    let filter = _.find(this.filterList, filterItem => newFilter.id === filterItem.id);

    if (!filter) {
      newFilter.state = 1;
      filter = this.filterList[this.push('filterList', newFilter) - 1];
    }

    return filter;
  }

  removeFilterItem (filter) {
    this.splice('filterList', this.filterList.findIndex(item => item.id === filter.id), 1);
  }

  // Invoked on each mutation of the row collection
  rowsObserver () {
    this.updateFavoritesHeader();
  }


  updateFavoritesHeader () {
    // Synchronize the submit button count with the number of valid order rows
    this.submitButton.count = this.rows.filter(row => row.checkState === 'checked' && row.filter.state === 1 && row.footprint.isReady()).length;

    // Ensure clear all icon is only enabled when there is size to clear
    this.clearAllIcon.isDisabled = !_.find(this.rows, row => row.filter.state === 1 && row.footprint.get('unfilledSize') > 0);
  }

  computeBuySize (side, size) {
    return side === 'buy' ? size : '';
  }

  computePriceDirectionState (rowState, lastPriceDirection) {
    return (rowState === 'active') && (lastPriceDirection !== 'none');
  }

  computeSellSize (side, size) {
    return side === 'sell' ? size : '';
  }

  computePlaceholder (isSelected, side, size) {
    if (isSelected || size) {
      return '';
    }

    return side === 'buy' ? resources.IDS_BUY_SIZE_PLACEHOLDER : resources.IDS_SELL_SIZE_PLACEHOLDER;
  }

  computeFavoriteIconState (checkState) {
    return checkStates.indexOf(checkState);
  }

  // Maintains 'single' row selection
  toggleSelection (model, inputElement) {
    if (model === this.selectedRow) {
      this.clearSelection(true);

      if (inputElement) {
        inputElement.blur();
      }
    } else {
      this.updateSelection(model, true);

      if (inputElement) {
        inputElement.focus();
      }
    }
  }

  updateSelection (rowModel, shouldNotify) {
    // Clear existing selection
    this.clearSelection(false);

    // Select new row
    rowModel.set('row.checkState', rowModel.row.side ? 'checked' : 'semi-checked');
    rowModel.set('row.isSelected', true);
    this.selectedRow = rowModel;

    if (shouldNotify) {
      context.selectionManager.setSelection(this, rowModel.row.footprint.instrument);
    }
  }

  clearSelection (shouldNotify) {
    if (this.selectedRow) {
      this.selectedRow.set('row.isSelected', false);

      // If we are clearing the selection on a row that has no size or we are in single
      // submission mode, ensure the row is always unchecked when the selection is cleared
      if (this.selectedRow.row.size === 0 || this.settings.get('disableBatchSubmission')) {
        this.selectedRow.set('row.checkState', 'unchecked');
      }
    }

    this.selectedRow = null;

    if (shouldNotify) {
      context.selectionManager.setSelection(null, null);
    }
  }

  // Submits a batch of orders, displaying a confirmation dialog when 'Second Look' is configured
  submitOrderBatch (footprints) {
    if (this.settings.get('displayFavoritesSecondLook')) {
      context.confirmFavorites.popup('show', {
        title                 : resources.IDS_SUBMIT_FAVORITES,
        message               : utils.format(resources.IDS_CONFIRM_SUBMIT_FAVORITES, [footprints.length]),
        hasHeaderCloseButton  : false,
        isWarning             : false,
        restrictHeavyPainting : !isWebDeployed,
        confirm () {
          footprints.forEach(footprint => {
            footprint.sendOrder('MyFavoritesView');
          });
        }
      });
    } else {
      footprints.forEach(footprint => {
        footprint.sendOrder('MyFavoritesView');
      });
    }
  }

  onClickCheckAll (event) {
    const icon = event.currentTarget;

    // Toggle the 'checked' state
    this.rows.forEach(function (row, index) {
      if (row.filter.state === 1) {
        this.set(`rows.${index}.checkState`, icon.state && row.side ? 'checked' : 'unchecked');
      }
    }, this);

    // Clear the row selection
    this.clearSelection(true);
  }

  onClickClearAllIcon () {
    this.rows.forEach(function (row, index) {
      if (row.filter.state === 1) {
        // Clear footprint size
        row.footprint.setSize(0);

        // Manually bind empty size to the row view model
        this.set(`rows.${index}.size`, '');
        this.set(`rows.${index}.side`, '');

        // Un-check any 'checked' rows
        this.set(`rows.${index}.checkState`, 'unchecked');
      }
    }, this);

    // Clear the row selection
    this.clearSelection(true);
  }

  onClickRemoveAll () {
    // Push all footprints into the 'Undo' collection
    this.undoCollection.push(this.footprints.slice());

    // Remove all rows and reset the footprint collections
    this.footprints.reset([]);

    // Clear the 'Redo' collection
    this.redoCollection = [];

    // Trigger any bindings to the 'Redo' and 'Undo' collection lengths
    this.set('undoCollection.length', this.undoCollection.length);
    this.set('redoCollection.length', this.redoCollection.length);
  }

  onClickUndo () {
    if (this.undoCollection.length > 0) {
      // Pop the footprint array from the 'undo' collection and push it into the 'redo' collection
      const arrayIndex = this.redoCollection.push(this.undoCollection.pop()) - 1;

      // Restore each footprint in the array
      this.redoCollection[arrayIndex].forEach(function (footprint) {
        this.footprints.add(footprint, {restore : true});
      }, this);

      // Trigger any bindings to the 'Redo' and 'Undo' collection lengths
      this.set('undoCollection.length', this.undoCollection.length);
      this.set('redoCollection.length', this.redoCollection.length);
      this.notifyPath('redoCollection.length');
      this.notifyPath('undoCollection.length');
    }
  }

  onClickRedo () {
    if (this.redoCollection.length > 0) {
      // Pop the footprint array from the 'redo' collection and push it into the 'undo' collection
      const undoIndex = this.undoCollection.push(this.redoCollection.pop()) - 1;

      // Remove each footprint in the array
      this.undoCollection[undoIndex].forEach(function (item) {
        this.footprints.remove(item, {restore : true});
      }, this);

      // Trigger any bindings to the 'Redo' and 'Undo' collection lengths
      this.set('undoCollection.length', this.undoCollection.length);
      this.set('redoCollection.length', this.redoCollection.length);
    }
  }

  onClickSubmit () {
    // Extract valid footprint orders for each 'checked' row
    const footprints = this.rows.filter(row => row.checkState === 'checked' && row.footprint.isReady() && row.filter.state === 1).map(row => row.footprint);

    // Submit order batch
    this.submitOrderBatch(footprints);
  }

  onClickRow (event) {
    let inputFocus = null;
    const side = event.model.row.footprint.get('side');

    // Set the focus to the source input element or the input element on the active side
    if (event.srcElement.tagName === 'INPUT') {
      inputFocus = event.srcElement;
    } else if (side === 'sell') {
      inputFocus = event.currentTarget.querySelector('input.sell');
    } else {
      inputFocus = event.currentTarget.querySelector('input.buy');
    }

    // Toggle the row selection
    this.toggleSelection(event.model, inputFocus);
  }

  // Handles key down events that have bubbled up from the row's input elements - these are the only row elements
  // that can receive focus and therefore bubble key events.
  onKeyDownRow (event) {
    const row = event.currentTarget;
    const buyInput = row.querySelector('input.buy');
    const sellInput = row.querySelector('input.sell');

    // Handle keyboard navigation events
    switch (event.keyCode) {
      case keyCodes.UP:
      case keyCodes.DOWN:
        this.selectNextRow(row, event.keyCode, event.srcElement === buyInput ? 'buy' : 'sell');
        break;
      case keyCodes.ENTER:
        this.selectNextRow(row, keyCodes.DOWN, event.srcElement === buyInput ? 'buy' : 'sell');
        break;
      case keyCodes.LEFT:
        if (event.srcElement === buyInput) {
          sellInput.focus();
        } else {
          buyInput.focus();
        }
        break;
      case keyCodes.RIGHT:
        if (event.srcElement === sellInput) {
          buyInput.focus();
        } else {
          sellInput.focus();
        }
        break;
      case keyCodes.TAB:
        if (event.srcElement === sellInput) {
          this.selectNextRow(row, keyCodes.DOWN, 'buy');
        } else {
          sellInput.focus();
        }
        break;
      default:
        break;
    }

    // Prevent all key down events propagating from the row element
    event.stopPropagation();
  }

  onDragStart () {
    // eslint-disable-next-line no-restricted-globals
    event.preventDefault();
  }

  // Selects the next row
  selectNextRow (row, direction, side) {
    let nextModel = null;
    let nextRow = null;
    let nextSide = null;

    // Find the next row element: if we have reached the header row circle back to the last row, if we have
    // reached the row template element circle back to the first row.
    if (direction === keyCodes.UP) {
      nextRow = row === this.favoriteRows.firstElementChild ? this.rowsTemplate.previousElementSibling : row.previousElementSibling;
    } else if (direction === keyCodes.DOWN) {
      nextRow = row.nextElementSibling === this.rowsTemplate ? this.favoriteRows.firstElementChild : row.nextElementSibling;
    }

    // Ensure the next row is not the current row
    if (nextRow && nextRow !== row) {
      nextModel = this.rowsTemplate.modelForElement(nextRow);
      nextSide = nextModel.row.footprint.get('side');

      // Toggle the row selection
      this.toggleSelection(nextModel, nextRow.querySelector(`input.${nextSide || side}`));
    }
  }

  onClickFavoriteIcon (event) {
    const {row} = event.model;

    if (row.checkState !== 'unchecked') {
      this.clearSelection(true);
      event.model.set('row.checkState', 'unchecked');

      // Prevent propagation (to select row) when un-checking a checked row
      event.stopPropagation();
    }
  }

  onClickRemoveRow (event) {
    const {footprint} = event.model.row;

    // Remove the row footprint and push it into the 'Undo' collection
    this.undoCollection.push([this.footprints.remove(footprint, {restore : true})]);

    // Ensure model is not in the 'Redo' collection
    this.removeItemFromCollection(this.redoCollection, footprint);

    // Trigger any bindings to the 'Redo' and 'Undo' collection lengths
    this.set('undoCollection.length', this.undoCollection.length);
    this.set('redoCollection.length', this.redoCollection.length);
    this.notifyPath('redoCollection.length');
    this.notifyPath('undoCollection.length');
  }

  onClickSizeButton (event) {
    const rowElement = event.currentTarget.parentElement;

    // If this is not the selected row, allow the event to bubble to the parent row (to toggle the selection)
    if (!this.selectedRow || event.model.rowIndex !== this.selectedRow.rowIndex) {
      return;
    }

    // Update the footprint with the standard size
    this.updateFootprintSize(this.selectedRow, rowElement.classList.contains('buy') ? 'buy' : 'sell', event.model.get('standard-size'));

    // Prevent propagation to parent (row) event handlers
    event.stopPropagation();

    // If batch submission is disabled submit the order directly instead of building up the batch
    if (this.settings.get('disableBatchSubmission') && this.selectedRow.row.rowState === 'active') {
      this.submitOrderBatch([this.selectedRow.row.footprint]);
    }
  }

  onClickSizeInput (event) {
    // Prevent propagation to the parent row when editing 'selected' row
    if (event.model.row.isSelected) {
      event.stopPropagation();
    }
  }

  onKeyDownSizeInput (event) {
    const input = event.currentTarget;
    const side = input.classList.contains('buy') ? 'buy' : 'sell';
    const {row} = event.model;
    const inputValue = Number(input.value);

    // If we are moving the cursor within the input element or validation fails, prevent the event bubbling to
    // the parent row and triggering navigation away from the element.
    switch (event.keyCode) {
      case keyCodes.LEFT:
        if (input.selectionEnd > 0 || (input.selectionEnd === 0 &&
                !this.updateFootprintSize(event.model, side, inputValue, input))) {
          event.stopPropagation();
        }
        break;
      case keyCodes.RIGHT: {
        if (input.selectionEnd < input.value.length || (input.selectionEnd === input.value.length &&
                !this.updateFootprintSize(event.model, side, inputValue, input))) {
          event.stopPropagation();
        }
        break;
      }
      case keyCodes.UP:
      case keyCodes.DOWN:
      case keyCodes.TAB: {
        // Validate and update size before allowing event to propagate to the parent row which will trigger
        // navigation away from the element
        if (!this.updateFootprintSize(event.model, side, inputValue, input)) {
          event.stopPropagation();
        }
        event.preventDefault();
        break;
      }
      case keyCodes.ENTER: {
        // Validate and update footprint size before submitting order if the footprint is active
        if (!inputValue || !this.updateFootprintSize(event.model, side, inputValue, input)) {
          event.stopPropagation();
        } else if (row.rowState === 'active') {
          event.stopPropagation();
          this.submitOrderBatch([row.footprint]);
        }
        break;
      }
      case keyCodes.ESC: {
        // Revert the input size and deselect the row
        this.bindFootprintSize(event.model);
        this.toggleSelection(this.selectedRow);
        break;
      }
      default:
        break;
    }
  }

  onBlurSizeInput (event) {
    const input = event.currentTarget;

    this.updateFootprintSize(event.model, input.classList.contains('buy') ? 'buy' : 'sell', Number(input.value), input);
  }

  onFocusSizeInput (event) {
    event.currentTarget.select();
  }

  // Binds the footprint size to the row view model
  bindFootprintSize (model) {
    const {footprint} = model.row;

    model.set('row.size', footprint.get('unfilledSize'));
    model.set('row.side', footprint.get('side'));
    model.notifyPath('row.size');

    // Update checked state to reflect whether the footprint is ready for submission
    if (model.row.isSelected) {
      model.set('row.checkState', model.row.side ? 'checked' : 'semi-checked');
    }
  }

  updateFootprintSize (model, side, size, input) {
    let validated = false;
    const {footprint} = model.row;

    // If we are changing side, prevent clearing of existing size when entering zero size on the opposite side
    if (!size && footprint.get('side') !== side) {
      validated = true;
    } else {
      // Validate and update the footprint domain model size
      context.viewUtils.lastFocusedControl = input;
      validated = model.row.footprint.setSize(size, side, true);
      context.viewUtils.lastFocusedControl = undefined;
    }

    // Manually bind row view size to the footprint size
    this.bindFootprintSize(model);

    return validated;
  }

  findRowIndex (model) {
    return this.rows.findIndex(row => row.footprint === model);
  }

  // Removes the item identified by the given 'model' from a collection of arrays
  removeItemFromCollection (collection, model) {
    let itemArray = [];
    let arrayIndex = 0;

    // Iterate collection of arrays searching for the item identified by the given id
    for (arrayIndex = 0; arrayIndex < collection.length; ++arrayIndex) {
      const itemIndex = collection[arrayIndex].findIndex(item => item.getId() === model.getId());

      // Remove item from array if found
      if (itemIndex >= 0) {
        collection[arrayIndex].splice(itemIndex, 1);
        itemArray = collection[arrayIndex];
        break;
      }
    }

    // If array is empty, remove the array
    if (itemArray && itemArray.length === 0) {
      collection.splice(arrayIndex, 1);
    }
  }
}
customElements.define('my-favorites-view', MyFavoritesView);
context.view.MyFavoritesView = MyFavoritesView;
