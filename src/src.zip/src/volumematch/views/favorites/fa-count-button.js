/* eslint-disable class-methods-use-this */

import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './fa-count-button.template';

const {ui: context, resources} = window.BGC;

class FaCountButton extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  _countChanged () {
    this.disabled = !(this.count > 0);
    if (this.disabled) {
      this.setAttribute('disabled', 'true');
    } else {
      this.removeAttribute('disabled');
    }
  }

  getButtonLabel (resourceLabel) {
    return resources[resourceLabel];
  }

  getButtonCount (count) {
    return count > 0 ? count : '';
  }

  getClassList (count, inactiveIconClass, activeIconClass) {
    return `fa ${count > 0 ? activeIconClass : inactiveIconClass}`;
  }

  onClickIcon (event) {
    if (this.isDisabled) {
      event.stopPropagation();
    }
  }

  static get properties () {
    return {
      count : {
        type     : Number,
        value    : 0,
        observer : '_countChanged'
      },
      activeIconClass : {
        type  : String,
        value : 'fa-star'
      },
      inactiveIconClass : {
        type  : String,
        value : 'fa-star-o'
      }
    };
  }
}
context.FaCountButton = FaCountButton;
customElements.define('fa-count-button', FaCountButton);
