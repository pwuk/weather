/* eslint-disable max-len */

import {html} from '@polymer/polymer';

export default html`
<style>
* { box-sizing: border-box;}

@font-face {
    font-family: 'FontAwesome';
    src: url('../fonts/fontawesome-webfont.eot?v=4.0.3');
    src: url('../fonts/fontawesome-webfont.eot?#iefix&v=4.0.3') format('embedded-opentype'), url('../fonts/fontawesome-webfont.woff?v=4.0.3') format('woff'), url('../fonts/fontawesome-webfont.ttf?v=4.0.3') format('truetype'), url('../fonts/fontawesome-webfont.svg?v=4.0.3#fontawesomeregular') format('svg');
    font-weight: normal;
    font-style: normal;
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-style: normal;
    font-weight: normal;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.fa-caret-down:before {
    content: "\\f0d7";
}

.fa-filter:before {
    content: "\\f0b0";
}

ul {
    position: absolute;
    border: 1px solid var(--live-mode-droplist-border);
    background-color: var(--dropdown-menu-background);
    overflow: hidden;
    margin: 0;
    padding: 0.1rem;
    z-index: 99;
    height: auto;
}
li {
    font-size: 1rem;
    color: var(--content-text);
    display: block;
    line-height: normal;
    cursor: default !important;
    padding: 0 0.1rem 0 0.1rem;
    margin: 0;
    border: 1px solid transparent;
    width: 100%;
    vertical-align: top;
}
li:hover {
    background-color: var(--content-border-lighter05);
}
li.selected {
    background-color: var(--live-mode-select-bg);
    color: white;
}
[is-disabled] {
    opacity: 0.3;
}

#filter-state-icon {
    display: inline-block;
    line-height: 1;
    height: auto;
    width: 2rem;
    color: var(--favorites-icon-color);
    vertical-align: top;
    margin-left: 1rem;
    float: right;
    font-size: 1rem;
    background-color: inherit;
}
.fa {
    font-size: 1.4rem;
}
</style>
    <i class="fa fa-filter"></i>
    <span>[[menuText]]</span>
    <i class="fa fa-caret-down" tiptext="Filtering"></i>
    <ul class="menu-list" hidden="[[isMenuHidden]]" on-mouse-leave="onLeaveMenu">
        <template is="dom-repeat" items="[[menuItems]]">
            <li on-click="onClickMenuItem">
                <span>[[item.name]]</span>
                <fa-state-icon id="filter-state-icon"
                               class="filter-state-icon"
                               state-classes='["fa-square-o", "fa-check-square-o"]'
                               state="[[item.state]]">
                </fa-state-icon>
            </li>
        </template>
    </ul>
`;
