/* eslint-disable max-len */

import {html} from '@polymer/polymer';

export default html`
<style>
* { box-sizing: border-box;}

@font-face {
    font-family: 'FontAwesome';
    src: url('../fonts/fontawesome-webfont.eot?v=4.0.3');
    src: url('../fonts/fontawesome-webfont.eot?#iefix&v=4.0.3') format('embedded-opentype'), url('../fonts/fontawesome-webfont.woff?v=4.0.3') format('woff'), url('../fonts/fontawesome-webfont.ttf?v=4.0.3') format('truetype'), url('../fonts/fontawesome-webfont.svg?v=4.0.3#fontawesomeregular') format('svg');
    font-weight: normal;
    font-style: normal;
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-style: normal;
    font-weight: normal;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.fa {
    font-size: 1.4rem;
}


.fa-star:before {
    content: "\\f005";
}

.fa-star-o:before {
    content: "\\f006";
}

.fa-star-half-empty:before,
.fa-star-half-full:before,
.fa-star-half-o:before {
    content: "\\f123";
}


.fa-square-o:before {
    content: "\\f096";
}

.fa-check:before {
    content: "\\f00c";
}

.fa-check-square-o:before {
    content: "\\f046";
}

.fa-times:before {
    content: "\\f00d";
}

.fa-undo:before {
    content: "\\f0e2";
}

.fa-repeat:before {
    content: "\\f01e";
}

.fa-trash-o:before {
    content: "\\f014";
}


:host(.filter-state-icon) {
    display: inline-block;
    line-height: 1;
    height: auto;
    width: 2rem;
    color: var(--favorites-icon-color);
    vertical-align: top;
    margin-left: 1rem;
    float: right;
    font-size: 1rem;
    background-color: inherit;
    background-color: red;
    
}
    
    
</style>
<i class$="[[getClassList(state, stateClasses)]]"></i>
`;
