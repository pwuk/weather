/* eslint-disable max-lines */
import {html} from '@polymer/polymer';
import {} from '@polymer/polymer/lib/elements/dom-if';

export default html`
<style>
* { box-sizing: border-box;}

:host {
    display: block;
}
[hidden] {
    display: none !important;
}

.scrollable-content {
    width: initial;
    display: flex;
    flex-direction: column;
}
/*.scrollable-content > div {*/
/*    flex: 1;*/
/*}*/
.scroll-container>.scrollable-content {
    margin-right: 1.5rem;
    background-color: var(--content-background);
}

:host(.fixed-height) .scrollable-content {
    border-left: 1px solid var(--content-border);
    border-right: 1px solid var(--content-border);
    border-bottom: 1px solid var(--content-border);
}
:host(.fixed-height) .scrollable-content > div {
    flex-grow: 0;
}
 .scroll-container.vertical-scrollbar {
    border-bottom: 1px solid var(--content-border);
}
.vertical-scrollbar.scrollable-content {
    border-bottom: 1px solid var(--content-border);
}
.scroll-container.vertical-scrollbar > .scrollable-content {
    margin-right: 0;
}


#my-favorites-header {
    margin-right: 1.5rem;
    line-height: 2rem;
    color: var(--favorites-header-row-text);
    font-size: 1rem;
    background-color: var(--favorites-header-row-background);
    display: flex;
    text-indent: 1.6rem;
}
 #my-favorites-header fa-icon,
 #my-favorites-header fa-state-icon {
    width: 2.4rem;
    line-height: inherit;
    height: 2rem;
    font-size: 1.5rem;
    text-align: center;
}
 #my-favorites-header fa-icon:hover:not([is-disabled]),
 #my-favorites-header fa-state-icon:hover:not([is-disabled]) {
    font-size: calc(1.5rem + 0.2rem);
    background-color: var(--favorites-header-row-background-lighter10);
}
 #my-favorites-header fa-icon[is-disabled],
 #my-favorites-header fa-state-icon[is-disabled] {
    opacity: 0.2;
}
 #my-favorites-header #filter-state-icon {
    display: inline-block;
    line-height: 1;
    height: auto;
    width: 2rem;
    color: var(--favorites-icon-color);
    vertical-align: top;
    margin-left: 1rem;
    float: right;
    font-size: 1rem;
    background-color: inherit;
}
 #my-favorites-header #filter-state-icon .fa {
    font-size: 1.4rem;
}
 #my-favorites-header #check-all-icon {
    width: 3rem;
    min-width: 3rem;
}
 #my-favorites-header #product-filter {
    min-width: 10rem;
    border-left: 1px solid var(--content-header-border);
}
 #my-favorites-header #product-filter .fa {
    font-size: 1.5rem;
    vertical-align: text-top;
    padding: 0 0.25rem 0 0.5rem;
}
 #my-favorites-header #product-filter:hover {
    background-color: var(--favorites-header-row-background-lighter10);
}
 #my-favorites-header #padding-element1 {
    flex: 1 0 auto;
}
 #my-favorites-header .strike1Display,
 #my-favorites-header .strike2Display {
    display: block;
    float: left;
    height: 100%;
    width: 6rem;
    min-width: 6rem;
    line-height: 2rem;
    text-align: center;
    background-color: transparent;
    border-left: 1px solid;
    border-color: inherit;
}
 #my-favorites-header .strike2Display {
    border-right: 1px solid var(--content-header-border);
}
 #my-favorites-header #fixed-header {
    display: flex;
    width:37.5rem;
    justify-content: end;
}
 #my-favorites-header #clear-all-icon {
    margin-left: 26.8rem;
    margin-right: 1.5rem;
}
 #my-favorites-header #fixed-header[is-minimized] {
    min-width: 18rem;
}
 #my-favorites-header #fixed-header[is-minimized] #clear-all-icon {
    margin-left: 4.8rem;
}
 #my-favorites-header #undo-icon,
 #my-favorites-header #redo-icon {
    margin-right: 0.5rem;
}
 #my-favorites-header #remove-all-icon {
    margin-left: 1rem;
}
 #favorite-rows {
    border-left: solid 1px var(--content-border);
    border-right: solid 1px var(--content-border);
}
 #favorite-rows.bottom-border .footprint-row:nth-last-child(2) {
    border-bottom: 1px solid var(--content-border);
    height: calc(1.6rem + 1px);
}
 .footprint-row {
    font-size: 1rem;
    height: 1.6rem;
    line-height: 1.6rem;
    color: var(--content-text);
    display: flex;
    font-style: italic;
    font-weight: normal;
}
 .footprint-row fa-icon,
 .footprint-row fa-state-icon {
    min-width: 2.2rem;
    width: 2.2rem;
    line-height: inherit;
    font-size: 1.4rem;
    color: var(--favorites-icon-color);
    text-align: center;
    overflow: hidden;
}
 .footprint-row fa-icon:hover,
 .footprint-row fa-state-icon:hover {
    font-size: 1.5rem;
}
 .footprint-row fa-state-icon {
    min-width: 3rem;
    width: 3rem;
}
 .footprint-row fa-icon {
    margin-left: 0.8rem;
}
 .footprint-row .name {
    min-width: 10rem;
    flex: 0.8 1 auto;
    border-left: solid 1px var(--content-border);
    padding: 0 0 0 0.5rem;
    overflow-x: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
 .footprint-row .strike1Display,
 .footprint-row .strike2Display {
    display: block;
    float: left;
    width: 6rem;
    min-width: 6rem;
    height: 100%;
    background-color: transparent;
    color: inherit;
    border: none;
    border-left: solid 1px var(--content-label-border);
    vertical-align: top;
    padding: 0 0 0 0.5rem;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    text-align: center;
    border-color: var(--content-border);
}
 .footprint-row .mirror {
    flex-direction: row-reverse;
    display: flex;
    flex: 0.2;
}
 .footprint-row .mirror input.sell {
    text-align: right;
    padding-right: 0.5rem;
    border-left: 1px solid var(--content-border);
}
 .footprint-row .mirror input.buy {
    text-align: left;
    padding-left: 0.5rem;
    border-right: 1px solid var(--content-border);
}
 .footprint-row .fav-row-Controls {
    display: flex;
    flex: 0.2;
}
 .footprint-row input {
    width: 5rem;
    min-width: 5rem;
    border: none;
    color: var(--blotter-text);
    line-height: inherit;
    font-size: inherit;
    font-style: inherit;
    font-weight: inherit;
    background-color: var(--blotter-background);
    padding: 0;
    text-align: center;
}
 .footprint-row input.buy {
    text-align: right;
    padding-right: 0.5rem;
    border-left: 1px solid var(--content-border);
}
 .footprint-row input.sell {
    text-align: left;
    padding-left: 0.5rem;
    border-right: 1px solid var(--content-border);
}
 .footprint-row input::-webkit-input-placeholder {
    font-weight: normal;
    font-style: italic;
}
 .footprint-row .price {
    width: 6rem;
    min-width: 6rem;
    text-align: center;
    border-left: solid 1px var(--content-border);
    border-right: solid 1px var(--content-border);
}
 .footprint-row .price .price-direction {
    display: inline-block;
    vertical-align: middle;
    margin-top: -0.35rem;
    background-image: none;
    background-size: 0.9rem;
    background-position: center;
    background-repeat: no-repeat;
    height: 0.8rem;
    width: 0.9rem;
}
 .footprint-row .price .price-direction[midPriceDirection="better"] {
    background-image: url(assets/images/price-direction-up.png), none;
}
 .footprint-row .price .price-direction[midPriceDirection="worse"] {
    background-image: url(assets/images/price-direction-down.png), none;
}
 .footprint-row .size-buttons {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
    font-weight: normal;
}
 .footprint-row .size-buttons.buy {
    border-left: 1px solid var(--content-border);
}
 .footprint-row .size-buttons.sell {
    border-right: 1px solid var(--content-border);
}
 .footprint-row .size-buttons li {
    width: 3.5rem;
    direction: rtl;
     text-overflow: ellipsis;
     overflow: hidden;
     white-space: nowrap;
    cursor: default;
    text-align: center;
    margin-left: 1px;
    color: var(--grey02);
    border-right: 1px solid var(--content-border);
}
 .footprint-row .size-buttons :nth-last-child(2) {
    margin-right: 1px;
    border-right: none;
}
 .footprint-row .size-buttons[is-hidden] {
    display: none;
}
 .footprint-row:nth-child(odd) {
    background-color: var(--favorites-odd-row-inactive-background);
}
 .footprint-row:nth-child(even) {
    background-color: var(--favorites-even-row-inactive-background);
}
 .footprint-row[row-state='active'] {
    font-style: normal;
}
 .footprint-row[row-state='indicative'] .price {
    color: var(--indicative-mid-price);
}
 .footprint-row[check-state='semi-checked'],
 .footprint-row[check-state='checked'] {
    font-weight: bold;
    background-color: var(--content-background);
    border-top: 1px solid var(--content-border);
    line-height: calc(1.6rem - 1px);
}
 .footprint-row[check-state='semi-checked'] + .footprint-row,
 .footprint-row[check-state='checked'] + .footprint-row {
    border-top: 1px solid var(--content-border);
    line-height: calc(1.6rem - 1px);
}
 .footprint-row[check-state='semi-checked'] .size-buttons,
 .footprint-row[check-state='checked'] .size-buttons {
    background-color: var(--content-border-darker05);
}
 .footprint-row[check-state='semi-checked'] .size-buttons li,
 .footprint-row[check-state='checked'] .size-buttons li {
    color: var(--content-border-lighter05);
}
 .footprint-row[is-selected] .name {
    outline: 1px solid var(--selection);
    outline-offset: -1px;
    background-color: var(--highlight-background);
}
 .footprint-row[is-selected] .price {
    outline: 1px solid var(--selection);
    outline-offset: -1px;
}
 .footprint-row[is-selected] .size-buttons {
    /*background-color: var(--command-background);*/
    color: var(--content-header-text);
}
 .footprint-row[is-selected] .size-buttons li {
    line-height: calc(1.6rem - 5px);
    margin-top: 1px;
    margin-bottom: 1px;
    color: var(--content-button-text);
    border-radius: 3px;
}
 .footprint-row[is-selected] .size-buttons.sell li {
    background-color: var(--sell-side);
    border: 1px solid var(--sell-side-border);
}
 .footprint-row[is-selected] .size-buttons.sell li:hover {
    color: yellow;
    font-weight: bold;
}
.footprint-row[is-selected] .size-buttons.buy li {
    background-color: var(--buy-side);
    border: 1px solid var(--buy-side-border);
}
.footprint-row[is-selected] .size-buttons.buy li:hover {
    color: orange;
    font-weight: bold;
}
    filter-menu {
        flex: 1;
    }
</style>
<div id="my-favorites-header" has-overflow-x$="[[hasOverflowX]]">
    <template is="dom-if" if="[[enableRowSelectors]]">
        <fa-state-icon 
                id="check-all-icon" 
                state-classes='["fa-star-o", "fa-star"]' 
                is-disabled$="[[!rows.length]]" 
                on-click="onClickCheckAll">
        </fa-state-icon>
    </template>
    <filter-menu 
            id="product-filter" 
            menu-text="[[labelProduct]]" 
            menu-items="[[filterList]]" 
            is-disabled$="[[!filterList.length]]">
    </filter-menu>
<!--    <span id="padding-element1"></span>-->
    <template is="dom-repeat" items="[[genericColumns]]">
        <span class$="[[item.columnId]]">[[item.columnName]]</span>
    </template>
    <div id="fixed-header" is-minimized$="[[hideSizeButtons]]">
        <fa-icon id="clear-all-icon" icon-class="fa-times" on-click="onClickClearAllIcon"></fa-icon>
        <fa-icon hidden
                 id="undo-icon" 
                 icon-class="fa-undo" 
                 is-disabled$="[[!undoCollection.length]]" 
                 on-click="onClickUndo">[[undoCollection.length]]</fa-icon>
        <fa-icon hidden 
                 id="redo-icon" 
                 icon-class="fa-repeat" 
                 is-disabled$="[[!redoCollection.length]]" 
                 on-click="onClickRedo">[[redoCollection.length]]</fa-icon>
        
    </div>
    <fa-icon id="remove-all-icon" icon-class="fa-trash-o" is-disabled$="[[!rows.length]]" on-click="onClickRemoveAll">[[rows.length]]</fa-icon>
</div>
<div class="scroll-container">
    <div id="favorite-rows" class="scrollable-content" is-fixed-height$="[[isFixedHeight]]" is-overflow-x$="[[isOverflowX]]">
        <template is="dom-repeat" id="footprint-rows-template" items="{{rows}}" as="row" index-as="rowIndex"
                  sort="sortFunc" filter="filterFunc" observe="rowState" on-keydown="onKeyDown">
            <div class="footprint-row" check-state$="[[row.checkState]]" is-selected$="[[row.isSelected]]" row-state$="[[row.rowState]]"
                 on-click="onClickRow" on-keydown="onKeyDownRow" on-dragstart="onDragStart">
                <template is="dom-if" if="[[enableRowSelectors]]">
                    <fa-state-icon
                            state-classes='["fa-star-o", "fa-star-half-o", "fa-star"]'
                            state="[[computeFavoriteIconState(row.checkState)]]" 
                            on-click="onClickFavoriteIcon">
                    </fa-state-icon>
                </template>
                <span class="name">[[row.instrumentName]]</span>
                <template is="dom-repeat" items="[[row.genericFields]]">
                    <span class$="[[item.id]]">[[item.value]]</span>
                </template>
                <div id = "mirrorElements" class$ = "[[mirrorClass]]">
                    <ul class="size-buttons buy" is-hidden$="[[hideSizeButtons]]">
                        <template is="dom-repeat" items="[[row.standardBuySizes]]" as="standard-size">
                            <li row-Index="[[rowIndex]]" on-click="onClickSizeButton">[[standard-size]]</li>
                        </template>
                    </ul>
                    <input type="text" class="buy" draggable="true" placeholder="[[computePlaceholder(row.isSelected, 'buy', row.size)]]"
                           maxlength="6" value="[[computeBuySize(row.side, row.size)]]" disabled="[[!row.isSelected]]"
                           on-click="onClickSizeInput" on-keydown="onKeyDownSizeInput" on-blur="onBlurSizeInput" on-focus="onFocusSizeInput">
                    <div class="price">
                        <span>[[row.price]]</span>
                        <template is="dom-if" if="[[computePriceDirectionState(row.rowState, row.lastMidPriceDirection)]]">
                            <span class="price-direction" midPriceDirection$="[[row.lastMidPriceDirection]]"></span>
                        </template>
                    </div>
                    <input type="text" class="sell" draggable="true" placeholder="[[computePlaceholder(row.isSelected, 'sell', row.size)]]"
                           maxlength="6" value="[[computeSellSize(row.side, row.size)]]" disabled="[[!row.isSelected]]"
                           on-click="onClickSizeInput" on-keydown="onKeyDownSizeInput" on-blur="onBlurSizeInput" on-focus="onFocusSizeInput">
                    <ul class="size-buttons sell" is-hidden$="[[hideSizeButtons]]">
                        <template is="dom-repeat" items="[[row.standardSellSizes]]" as="standard-size">
                            <li row-Index="[[rowIndex]]" on-click="onClickSizeButton">[[standard-size]]</li>
                        </template>
                    </ul>
                </div>
                <fa-icon icon-class="fa-trash-o" on-click="onClickRemoveRow"></fa-icon>
            </div>
        </template>
    </div>
</div>
`;
