
/* global BGC: false, $: false, Backbone: false */
// /////////////////////////////////////////////////////////////////////////////
// file headerview.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

// eslint-disable-next-line func-names
(function (context) {
  // eslint-disable-next-line no-param-reassign
  context.GlobalToolbar = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#global-toolbar'),
    events   : {
      'click .copy-excel-links'     : 'onCopyExcelLinks',
      'click .clear-auction-totals' : 'onClearAuctionTotals'
    },

    initialize (options) {
      this.dataStore = options.dataStore;

      this.settingsView = context.SettingsView.createView({
        settingsCollection : options.dataStore.userSettingsCollection,
        pageLayout         : this.model,
        dataStore          : options.dataStore
      });

      this.showLiveControl = new context.ShowLiveModeControl({model : this.model, dataStore : this.dataStore, resources : BGC.resources});
      this.liveLinkControl = new context.ExcelControl({model : this.model, resources : BGC.resources});

      // render view
      this.render();

      this.model.on('change:isExcelAddInEnabled', this.onExcelAddInEnableStateChanged, this);
      this.tooltip = BGC.ui.tooltipSingleton.getInstance();
      this.dataStore.on('activeUserSelectionChanged', () => {
        this.showLiveControl.updateFilterOptionForActiveUser();
      }, this);
    },

    render () {
      this.$el.off('mouseover', '[tipText]', this.showTooltip);
      this.$el.off('mouseleave click', '[tipText]', this.hideTooltip);

      // render toolbar
      this.$el.html(this.template({
        resources : BGC.resources
      }));

      this.$el.prepend(this.showLiveControl.render().$el);
      this.$el.find('.menu-settings').append(this.settingsView.render().$el);
      this.$el.find('.excel-add-in').append(this.liveLinkControl.render().$el).toggleClass('enabled', !!this.model.get('isExcelAddInEnabled'));

      this.$el.on('mouseover', '[tipText]', this, this.showTooltip);
      this.$el.on('mouseleave click', '[tipText]', this, this.hideTooltip);
    },

    updateSettingsForActiveUser () {
      this.settingsView.remove();

      this.settingsView = context.SettingsView.createView({
        settingsCollection : this.dataStore.userSettingsCollection,
        pageLayout         : this.model,
        dataStore          : this.dataStore
      });

      // render Settings view
      this.$el.find('.menu-settings').append(this.settingsView.render().$el);
    },

    onCopyExcelLinks () {
      this.model.copyExcelLinks('copy-excel-links');
    },

    onClearAuctionTotals () {
      this.model.clearAuctionTotals('header view');
    },

    onExcelAddInEnableStateChanged () {
      const isExcelAddInEnabled = !!this.model.get('isExcelAddInEnabled');

      // Excel Add-in enable state has changed so update Copy Excel Links and Upsizing Mode attributes
      this.$el.find('.excel-add-in').toggleClass('enabled', isExcelAddInEnabled);
      context.dockedOrderEntryView.render();
    },

    showTooltip (event) {
      // Because events are delegated, "this" is the object we are receiving the event from.
      // For this reason, when we add the listener we set the toolbar object
      // as the event data to include every time such an event is thrown
      const toolbar = event.data;
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        // eslint-disable-next-line id-length,no-magic-numbers
        x : targetRect.left + (targetRect.width / 2),
        // eslint-disable-next-line id-length,no-magic-numbers
        y : (targetRect.top + (targetRect.height / 2)) + 12
      };

      toolbar.tooltip.hide();
      toolbar.tooltip.show($(this).attr('tipText'), position);
    },

    hideTooltip (event) {
      const toolbar = event.data;

      toolbar.tooltip.hide(true);
    }
  });
}(window.BGC.ui.view));
