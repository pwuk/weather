import {html} from '@polymer/polymer';

export default html`
<style>
    * { box-sizing: border-box;}
    *[hidden] {
        display: none !important;
    }
    :host {
        display: none;
    }
    :host(.is-visible) {
        display: block;
    }

    .spread-views-row {
        width: 100%;
        display: flex;
        text-align: center;
        border-bottom: 1px solid var(--content-header-background);
        height: 2rem;
        font-weight: var(--font-weight-matrix-cell-data);
    }

    .spread-view-spread {
        align-items: center;
        font-size: 0.8rem;
        font-weight: bold;
        position: relative;
        display: flex;
        color: var(--content-text);
        cursor: pointer;
        border-radius: 4px;
        padding: 2px 0 2px 4px;
        background: var(--blotter-background);
        font-family: inherit;
    }
    .spread-view-spread .traded.gavel {
        position: relative;
        margin-bottom: 0.5rem;
        margin-left: 0.2rem;
        margin-right: 0.2rem;
        background-image: var(--gavel-second-image);
        background-repeat: no-repeat;
        background-size: calc(1.6rem - 4px);
        width: calc(1.6rem - 4px);
        height: calc(1.6rem - 4px);
    }
    .spread-view-spread .traded.gavel.trade-confirm-request:hover {
        cursor: pointer !important;
    }
    .spread-view-spread.third-party-interest {
        font-weight: var(--font-weight-matrix-cell-data);
        background-image: linear-gradient(to right, var(--thirdparty-glow), var(--thirdparty-glow));
        color: var(--thirdparty-glow-text);
    }
    .spread-view-spread.third-party-interest.below-market-size {
        background-image: linear-gradient(to right, var(--thirdparty-glow), var(--content-background), var(--content-background), var(--thirdparty-glow));
        color: var(--thirdparty-glow-text);
    }
    .spread-view-spread.behind-mid {
        background-image: linear-gradient(to right, var(--behind-mid-glow), var(--behind-mid-glow));
        color: var(--thirdparty-glow-text);
    }
    .spread-view-spread.ahead-of-mid {
        background-image: linear-gradient(to right, var(--ahead-of-mid-glow), var(--ahead-of-mid-glow));
        color: var(--thirdparty-glow-text);
    }
    .spread-view-spread.le-buy-interest:before {
        position: absolute;
        top: 0;
        left: 0;
        width: 0;
        height: 0;
        border-top: none;
        border-bottom: calc(1.6rem * 0.8) solid transparent;
        border-left: calc(1.6rem * 0.8) solid var(--same-le-glow);
        content: '';
        display: block;
        opacity: 0.7;
    }
    .spread-view-spread.le-sell-interest:after {
        position: absolute;
        top: 0;
        right: 0;
        width: 0;
        height: 0;
        border-top: none;
        border-bottom: calc(1.6rem * 0.8) solid transparent;
        border-right: calc(1.6rem * 0.8) solid var(--same-le-glow);
        content: '';
        display: block;
        opacity: 0.7;
    }
    .selected .spread-view-spread {
        box-shadow: inset 0 0 0 2px var(--selection);
        background-color: var(--highlight-background);
    }
    .spread-view-spread.spread-view-spread_buy {
        box-shadow: inset 0 0 0 2px var(--buy-side);
    }
    .spread-view-spread.spread-view-spread_sell {
        box-shadow: inset 0 0 0 2px var(--sell-side);
    }
    
    
</style>
<div id="instrumentRow" class="spread-views-row">
    <div class="spread-view-spread" on-mouseenter="onMouseEnterSpreadName" on-mouseleave="onMouseLeaveSpreadName"
         style="flex: 50%; overflow: hidden;">
        <span class="traded gavel" hidden="{{!showNameGavel}}" on-tap="onGavelClick"
              on-mouseenter="onGavelMouseEnter" on-mouseleave="onGavelMouseLeave"></span>
        <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{spread}}</span>
    </div>
    <div id=mirrorElements style="flex: 25%;">
        <vm-midprice-cell class="vmtile-spread-instrument-row" options='{{priceCellOptions}}'></vm-midprice-cell>
    </div>
    <div class="spread-price-display" style="flex: 25%;">{{priceDisplay2}}</div>
</div>
`;