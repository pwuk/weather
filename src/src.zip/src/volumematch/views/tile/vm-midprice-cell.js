/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */

import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './vm-midprice-cell.template';
import {isWebDeployed} from '../../bgc';

const {view: context} = window.BGC.ui;

class TileMidPriceCell extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor () {
    super();
    _.extend(this, Backbone.Events);
    this.addEventListener('mousedown', this.onCellClick);
    this.addEventListener('mouseenter', this.onCellMouseEnter);
  }

  ready () {
    super.ready();
    this.$el = $(this.shadowRoot);
    this.priceDisplay = '';
    this.displayGavel = false;
    this.orderSize = '';
    this.row = undefined;

    this.tooltip = BGC.ui.tooltipSingleton.getInstance();

    _.extend(this, context.NotificationFlashBehavior);

    this.render();
  }

  static get properties () {
    return {
      options : {
        type     : Object,
        notify   : false,
        observer : 'requestRender',
        value () {
          return {model : {dummy : true}, order : {dummy : true}};
        }
      }
    };
  }

  attached () {
    if (this.options.pageLayout) {
      this.listenTo(this.options.pageLayout, 'change:upsizingMode', this.handleChangedUpsizingMode);
    }
  }

  disconnectedCallback () {
    super.disconnectedCallback();

    // Clean up events, we may not get re-attached
    if (this.options.pageLayout) {
      this.stopListening(this.options.pageLayout);
    }
  }


  getInstrumentModel () {
    return this.options.model;
  }

  getRow () {
    return this.options.row;
  }

  getGrid () {
    return this.options.grid;
  }

  requestRender () {
    const instModel = this.getInstrumentModel();

    if (!instModel || instModel.dummy || (!instModel.isActive() && !instModel.get('isLockInstrument'))) {
      // Don't do any rendering if we don't have an instrument,
      // or this cell is in an inactive (hidden) row
      return;
    }

    BGC.ui.viewUtils.requestRender(instModel.get('instrumentId'), 'midPriceCell', this, this.render);
  }

  render () {
    const instModel = this.getInstrumentModel();

    if (!instModel || instModel.dummy || (!instModel.isActive() && !instModel.get('isLockInstrument'))) {
      // Don't do any rendering if we don't have an instrument,
      // or this cell is in an inactive (hidden) row
      return;
    }

    const instrument = instModel.serialize();
    const inplaceOEB = context.inplaceOEB.getInstance();
    const midPrice = this.$el.find('.mid-price');

    if (instrument && !instrument.dummy) {
      if (instrument.spread) {
        this.priceDisplay = instModel.get('spread').getInstrument(0).get('priceDisplay');
      } else {
        this.priceDisplay = instrument.priceDisplay;
      }

      if (inplaceOEB.isOpen && inplaceOEB.getInstrumentId() === instrument.instrumentId) {
        if (instrument.isMidPriceIndicative || instrument.inactive) {
          inplaceOEB.hide();
        } else {
          // otherwise, if open OEB is attached to this cell, update it
          inplaceOEB.setData(instrument, instrument.ownOrder);
        }
      }

      this.applyClassStyles();
    } else {
      // Must be in early stages of initialization
      this.priceDisplay = '';
      this.displayGavel = false;
    }
  }

  applyClassStyles (instrument) {
    if (!instrument) {
      return;
    }

    const instObject = instrument.serialize ? instrument.serialize() : instrument;
    const midPrice = this.$el.find('.mid-price');

    this.displayGavel = instObject.showTradeIndicators && instObject.hasTradedAtMidPrice;

    if (instObject.isMidPriceIndicative) {
      midPrice.addClass('indicative');
    } else {
      midPrice.removeClass('indicative');
    }

    // If the selected instrument is disallowed to enter order by a user(like a broker), then show the quick size buttons in disabled state.
    this.$el.toggleClass('input-disabled', !instObject.canUserEnterOrders);

    // Show price direction
    midPrice.toggleClass('price-direction-up', instObject.priceDirection === 'better').toggleClass('price-direction-down', instObject.priceDirection === 'worse');
  }

  handleChangedUpsizingMode () {
    const model = this.getInstrumentModel();
    const instrument = model.serialize();
    const inplaceOEB = context.inplaceOEB.getInstance();

    if (inplaceOEB.isOpen && inplaceOEB.getInstrumentId() === instrument.instrumentId) {
      // otherwise, if open OEB is attached to this cell, update it
      inplaceOEB.setData(instrument, instrument.ownOrder);
    }
  }

  killEvent (event) {
    event.stopPropagation();

    return false;
  }

  onCellMouseEnter (event) {
  }

  onCellClick (event) {
    const inPlaceOrderEntry = context.inplaceOEB.getInstance();
    const that = this;
    const model = this.getInstrumentModel();
    const row = this.getRow();

    // prevent inactive cells from being clicked
    if (!model || model.get('inactive')) {
      return;
    }

    if (BGC.ui.view.spreadView && BGC.ui.view.spreadView.isPopulated()) {
      BGC.ui.viewUtils.infoPopup.popup('show', {
        modal                 : true,
        draggable             : true,
        title                 : BGC.resources.IDS_SPREADS_BAR_ACTIVE,
        message               : BGC.resources.IDS_MSG_CLEAR_SPREADS_BAR,
        hasHeaderCloseButton  : false,
        hasCancelButton       : true,
        isWarning             : true,
        isError               : false,
        buttonSectionText     : '',
        cssClass              : 'popupDialog ui-dialog',
        restrictHeavyPainting : !isWebDeployed,
        cmdConfirmText        : BGC.resources.IDS_YES,
        cmdCancelText         : BGC.resources.IDS_NO,
        confirm () {
          // Clear the spreads bar
          BGC.ui.view.spreadView.$el.trigger('collapseOrderEntry');

          // Recurse
          that.onCellClick(event);
        }
      });

      return;
    }

    BGC.utils.startInteractivityQoSTimer('instrumentClick', model.get('spread') ? 'Spread' : 'Outright', model.getLogDescStr());

    if (row && !row.isSelected) {
      // lock the grid and change the selected cell
      BGC.ui.viewUtils.setSelectionLockedFlag(this, true);
      this.selectCell();
    } else if (!row) {
      this.selectCell();
    }

    if (event.button === 0 && !inPlaceOrderEntry.isOpen) {
      this.openOEBPopup();
    }
  }

  /*
            Controlling changes in the model
        */
  onGavelClick (event) {
    const {model} = this.options;
    const that = this;

    if (model && model.canRequestTradeConfirms()) {
      BGC.ui.viewUtils.infoPopup.popup('show', {
        modal                : true,
        draggable            : true,
        title                : BGC.resources.IDS_PRINT_CONFIRMS,
        message              : BGC.utils.format(BGC.resources.IDS_MSG_PRINT_CONFIRMS_PROMPT, [this.options.model.get('name')]),
        hasHeaderCloseButton : false,
        hasCancelButton      : true,
        isWarning            : false,
        isError              : false,
        buttonSectionText    : '',
        cssClass             : 'popupDialog ui-dialog',
        cmdConfirmText       : BGC.resources.IDS_YES,
        cmdCancelText        : BGC.resources.IDS_NO,
        confirm () {
          // Request Trade confirms
          that.options.model.requestTradeConfirms('GridCell');
        }
      });
      event.stopPropagation();
    }
  }

  onGavelMouseEnter (event) {
    const {model} = this.options;

    if (!model || !model.canRequestTradeConfirms()) {
      return;
    }

    const targetRect = event.target.getBoundingClientRect();
    const targetRectWidth = targetRect.right - targetRect.left;
    const targetRectHeight = targetRect.bottom - targetRect.top;

    this.tooltip.show(BGC.resources.IDS_PRINT_CONFIRMS_TOOLTIP, {
      x : targetRect.left + targetRectWidth / 2,
      y : targetRect.top + targetRectHeight / 2
    }, this);
  }

  onGavelMouseLeave () {
    const {model} = this.options;

    if (!model || !this.options.model.canRequestTradeConfirms()) {
      return;
    }

    this.tooltip.hide(true);
  }

  selectCell () {
    const row = this.getRow();

    if (row) {
      // selecting the cell implies selecting the row
      this.getRow().selectRow();
    }

    const inPlaceOrderEntry = context.inplaceOEB.getInstance();

    if (inPlaceOrderEntry.isOpen) {
      inPlaceOrderEntry.hide();
    }
  }

  openOEBPopup (side) {
    const model = this.getInstrumentModel();
    const instrument = model.serialize();
    const inPlaceOrderEntry = context.inplaceOEB.getInstance();

    // open in-place OEB popup on given side
    inPlaceOrderEntry.show(
      {
        instrument,
        activeOrder            : instrument.ownOrder,
        moveableMidEnabled     : this.options.pageLayout.isMoveableMidEnabled(),
        grid                   : this.getGrid(),
        sizeValidationCallback : model.validateSize.bind(model)
      },
      {
        sizeValidationCallback       : model.validateSize.bind(model),
        bidPriceValidationCallback   : model.validateBidPrice.bind(model),
        offerPriceValidationCallback : model.validateOfferPrice.bind(model),
        nudgeCallback                : model.nudgePriceWithRangeValidation.bind(model),
        priceFormatter               : model.formatPrice.bind(model)
      },
      side ? inPlaceOrderEntry.ETradeSide[side] : inPlaceOrderEntry.ETradeSide.eBoth,
      this.$.priceCell,

      // uugh needs a better way (.closest() no longer any use)
      document.querySelector('.auction-view .scroll-container')
    );
  }
}
context.TileMidPriceCell = TileMidPriceCell;
customElements.define('vm-midprice-cell', TileMidPriceCell);