import {html} from '@polymer/polymer/polymer-element';

export default html`
    <style>
        * { box-sizing: border-box;}
        *[hidden] {
            display: none !important;
        }
        :host { 
            display: block;
        }
        .notifications {
            display: flex;
            flex-direction: row-reverse;
            align-items: center;
            float: right;
            height: 100%;
            padding: 0.1rem;
        }

        .third-party-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--thirdparty-glow-badge-bg);
            color: var(--thirdparty-glow-badge-text);
            box-shadow: 0 0 1px 1px var(--thirdparty-glow-badge-border);
        }
        .third-party-badge:empty {
            display: none;
        }

        .trade-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--trade-count-badge-bg);
            color: var(--trade-count-badge-text);
            box-shadow: 0 0 1px 1px var(--trade-count-badge-border);
        }
        .trade-count-badge:empty {
            display: none;
        }

        .third-party-badge.flash-500ms {
            background: var(--thirdparty-glow-badge-flash-bg);
            color: var(--thirdparty-glow-badge-flash-text);
        }
        
        
        

        .header-row .straddleDisplay,
        .header-row .ratioDisplay,
        .header-row .deltaDisplay,
        .header-row .strike1Display,
        .header-row .strike2Display,
        .header-row .crossDisplay,
        .header-row .volume,
        .header-row .size,
        .header-row .order-size,
        .header-row .price,
        .header-row .ratio,
        .header-row .priceBDisplay {
            display: block;
            float: left;
            height: 100%;
            width: 6rem;
            min-width: 6rem;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
        }
        .header-row .account-name {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex: 1;
        }
        .header-row .status {
            display: block;
            float: left;
            height: 100%;
            width: 12rem;
            min-width: 12rem;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex:1;
        }
        .header-row .repost-all {
            display: block;
            float: left;
            height: 100%;
            width: 6rem;
            min-width: 6rem;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            display: none;
        }
        .header-row .repost-all.showRepostall {
            display: inline;
        }
        .wide-status .header-row .status {
            width: 18rem;
        }
        .header-row .name {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            border-left: none;
            flex: 1;
            min-width: 6rem;
        }
        .header-row .inner-name {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex: 1;
        }
        .header-row .counterparty {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex: 1;
        }
        .tile-view {
            margin-top: 2px;
            background-color: var(--content-header-background);
        }
        .tooltip-placement-left .tooltip-arrow {
            right: -6px;
            top: 50%;
        }
        .tooltip-placement-right .tooltip-arrow {
            left: -8px;
            top: 50%;
        }
        .tooltiptext {
            width: 100px;
            background-color: var(--tab-inactive-background);
            color: var(--content-header-text);
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;
            font-weight: var(--font-weight-matrix-cell-data);
            /* Position the tooltip */
            right: 115% ;
        }
        .tooltip-inner {
            max-width: 250px;
            padding: 8px 10px;
            color: white;
            text-align: left;
            text-decoration: none;
            background-color: var(--tab-inactive-background);
            border-radius: 4px;
            min-height: 32px;
        }
        .tooltip-arrow {
            position: absolute;
            width: 14px;
            height: 14px;
            border-color: transparent;
            border-style: solid;
            border-width: 1px;
            background-color: var(--tab-inactive-background);
            transform: rotate(45deg);
        }

        .header-row .collapse-toggle,
        .header-row .collapsible-title {
            display: none;
        }
        vm-header-row .header-row:not(.is-active) {
            display: none;
        }
        .collapsible.tile-view .header-row {
            height: 2rem;
            border-radius: 0.5rem 0.5rem 0 0;
        }
        .collapsible.tile-view .header-row,
        .tiles-column-layout .header-row {
            position: relative;
            background-image: none;
            background-color: var(--content-header-background);
        }
        .collapsible.tile-view .header-row.is-empty,
        .tiles-column-layout .header-row.is-empty {
            display: none;
        }
        .collapsible.tile-view .header-row .collapsible-title + .name,
        .tiles-column-layout .header-row .collapsible-title + .name {
            padding-right: 2.2rem;
            line-height: 2rem;
            display: flex;
            min-width: 0;
        }
        .collapsible.tile-view .header-row .collapsible-title + .name > span,
        .tiles-column-layout .header-row .collapsible-title + .name > span {
            text-align: left;
            float: left;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }
        .collapsible.tile-view .header-row .straddleDisplay,
        .tiles-column-layout .header-row .straddleDisplay,
        .collapsible.tile-view .header-row .ratioDisplay,
        .tiles-column-layout .header-row .ratioDisplay,
        .collapsible.tile-view .header-row .deltaDisplay,
        .tiles-column-layout .header-row .deltaDisplay,
        .collapsible.tile-view .header-row .strike1Display,
        .tiles-column-layout .header-row .strike1Display,
        .collapsible.tile-view .header-row .strike2Display,
        .tiles-column-layout .header-row .strike2Display,
        .collapsible.tile-view .header-row .crossDisplay,
        .tiles-column-layout .header-row .crossDisplay,
        .collapsible.tile-view .header-row .volume,
        .tiles-column-layout .header-row .volume,
        .collapsible.tile-view .header-row .size,
        .tiles-column-layout .header-row .size,
        .collapsible.tile-view .header-row .order-size,
        .tiles-column-layout .header-row .order-size,
        .collapsible.tile-view .header-row .price,
        .tiles-column-layout .header-row .price,
        .collapsible.tile-view .header-row .ratio,
        .tiles-column-layout .header-row .ratio,
        .collapsible.tile-view .header-row .priceBDisplay,
        .tiles-column-layout .header-row .priceBDisplay {
            line-height: 2rem;
        }
        .collapsible.tile-view .header-row .order-size,
        .tiles-column-layout .header-row .order-size {
            width: calc(6rem);
        }
        .collapsible.tile-view .header-row .notifications,
        .tiles-column-layout .header-row .notifications {
            display: flex;
            flex-direction: row-reverse;
            align-items: center;
            float: right;
            height: 100%;
            padding: 0.1rem;
            line-height: normal;
            width: initial;
            min-width: 4.76rem;
            float: left;
        }
        .collapsible.tile-view .header-row .notifications .badge,
        .tiles-column-layout .header-row .notifications .badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
        }
        .collapsible.tile-view .header-row .notifications .badge:empty,
        .tiles-column-layout .header-row .notifications .badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .instrument-count-badge,
        .tiles-column-layout .header-row .notifications .instrument-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: white;
            color: black;
            box-shadow: 0 0 1px 1px white;
        }
        .collapsible.tile-view .header-row .notifications .instrument-count-badge:empty,
        .tiles-column-layout .header-row .notifications .instrument-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .instrument-count-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .instrument-count-badge.flash-500ms {
            background: black;
            color: white;
        }
        .collapsible.tile-view .header-row .notifications .third-party-badge,
        .tiles-column-layout .header-row .notifications .third-party-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--thirdparty-glow-badge-bg);
            color: var(--thirdparty-glow-badge-text);
            box-shadow: 0 0 1px 1px var(--thirdparty-glow-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .third-party-badge:empty,
        .tiles-column-layout .header-row .notifications .third-party-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .third-party-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .third-party-badge.flash-500ms {
            background: var(--thirdparty-glow-badge-flash-bg);
            color: var(--thirdparty-glow-badge-flash-text);
        }
        .collapsible.tile-view .header-row .notifications .trade-count-badge,
        .tiles-column-layout .header-row .notifications .trade-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--trade-count-badge-bg);
            color: var(--trade-count-badge-text);
            box-shadow: 0 0 1px 1px var(--trade-count-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .trade-count-badge:empty,
        .tiles-column-layout .header-row .notifications .trade-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .trade-count-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .trade-count-badge.flash-500ms {
            background: var(--trade-count-badge-flash-bg);
            color: var(--trade-count-badge-flash-text);
        }
        .collapsible.tile-view .header-row .notifications .my-order-count-badge,
        .tiles-column-layout .header-row .notifications .my-order-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--my-order-count-glow-badge-bg);
            color: var(--my-order-count-glow-badge-text);
            box-shadow: 0 0 1px 1px var(--my-order-count-glow-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .my-order-count-badge:empty,
        .tiles-column-layout .header-row .notifications .my-order-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .my-trade-count-badge,
        .tiles-column-layout .header-row .notifications .my-trade-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--my-trade-count-glow-badge-bg);
            color: var(--my-trade-count-glow-badge-text);
            box-shadow: 0 0 1px 1px var(--my-trade-count-glow-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .my-trade-count-badge:empty,
        .tiles-column-layout .header-row .notifications .my-trade-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .my-trade-count-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .my-trade-count-badge.flash-500ms {
            background: var(--my-trade-count-badge-flash-bg);
            color: var(--my-trade-count-badge-flash-text);
        }
        .collapsible.tile-view .header-row .collapse-toggle,
        .tiles-column-layout .header-row .collapse-toggle,
        .collapsible.tile-view .header-row .notifications,
        .tiles-column-layout .header-row .notifications,
        .collapsible.tile-view .header-row .collapsible-title,
        .tiles-column-layout .header-row .collapsible-title {
            visibility: visible;
        }
        .collapsible.tile-view .header-row .collapse-toggle,
        .tiles-column-layout .header-row .collapse-toggle,
        .collapsible.tile-view .header-row .collapsible-title,
        .tiles-column-layout .header-row .collapsible-title {
            display: flex;
        }
        .collapsible.tile-view .header-row .collapsible-title,
        .tiles-column-layout .header-row .collapsible-title {
            position: absolute;
            top: 0;
            left: 2rem;
            right: 0;
            padding-left: 0;
        }
        .collapsible.tile-view .header-row .collapse-toggle,
        .tiles-column-layout .header-row .collapse-toggle {
            left: 0;
            width: 2rem;
            background-color: transparent;
        }
        .no-notifications .collapsible.tile-view .header-row .notifications,
        .no-notifications .tiles-column-layout .header-row .notifications {
            display: none;
        }
        .collapsible.tile-view .instrument-rows,
        .tiles-column-layout .instrument-rows {
            display: none;
        }
        .collapsible.tile-view .header-row.is-open .collapsible-title,
        .tiles-column-layout .header-row.is-open .collapsible-title {
            display: none;
        }
        .collapsible.tile-view.is-open .header-row .status,
        .tiles-column-layout.is-open .header-row .status {
            line-height: 2rem;
        }
        .collapsible.tile-view.is-open .header-row .collapsible-title,
        .tiles-column-layout.is-open .header-row .collapsible-title {
            display: none;
        }
        .collapsible.tile-view.is-open .instrument-rows,
        .tiles-column-layout.is-open .instrument-rows {
            display: block;
        }
        .collapsible.tile-view .header-row > * {
            visibility: hidden;
        }
        .collapsible.tile-view.is-open .header-row > * {
            visibility: visible;
        }

        .spread-views-wrapper {
            position: relative;
            width: 260px;
        }
        .collapsible > .spread-views-wrapper {
            background-color: var(--content-header-background);
            border-radius: 0 0.5rem 0 0;
        }
        .collapsible.is-open > .spread-views-wrapper {
            margin-left: 5px;
            border-radius: 5px;
            background-color: var(--content-header-background);
        }
        .spread-views-container {
            height: 100%;
            position: absolute;
            overflow-y: auto;
            padding: 0 2px 4px 2px;
        }
        .spread-views-header {
            background-color: var(--content-header-background);
            width: calc(260px - 15px);
            position: sticky;
            top: 0;
            z-index: 1;
            font-size: 1.1rem;
            display: flex;
            margin-top: 2px;
            margin-bottom: 3px;
            text-align: center;
        }
        .spread-views-row {
            width: 100%;
            display: flex;
            text-align: center;
            border-bottom: 1px solid var(--content-header-background);
            height: 2rem;
            font-weight: var(--font-weight-matrix-cell-data);
        }
        


    </style>
    <div id="tileContainer" class="collapsible spread-tile-view">
        <div class="spread-views-header">
            <div class="name" style="flex: 50%;">
                <div class="notifications">
                    <span class="third-party-badge">{{thirdParty}}</span>
                    <span class="trade-count-badge">{{tradeCount}}</span>
                </div>
                <span>{{resources.SPREAD}}</span>
            </div>
            <span class="price" style="flex: 25%;">{{resources.IDS_PRICE_A}}</span>
            <span class="price" style="flex: 25%;">{{resources.IDS_PRICE_B}}</span>
        </div>
        <div id="instrumentRows" class="instrument-rows"></div>
    </div>
`;
