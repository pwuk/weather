/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global Polymer: false, BGCAPP: false, BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */

import {isWebDeployed} from '../../bgc';

(function (context, undefined) {
  const {KeyCodes} = BGC.utils;

  context.VmTileBehavior = {

    factoryImpl (options) {
      this.model = options.model;
      this.pageLayout = options.pageLayout;
      this.dataStore = options.dataStore;
      this.isVisible = false;
      this.instrumentHeader = this.model.get('tileName');
      this.auctionId = this.model.auction.get('auctionId');
      this.orderPhaseText = '';
      this.resources = BGC.resources;
      this.initialize();
    },

    ready () {
      this.$el = $(this.shadowRoot);
    },

    initialize (options) {
      BGC.logger.logInformation('VmTileBehavior', `Creating VmTileBehavior for tileId[${this.model.get('tileId')}].`);

      const that = this;

      _.extend(this, Backbone.Events);
      _.extend(this, context.NotificationFlashBehavior);

      // set view attributes
      this.selectedRow = undefined;

      // set row type to use
      if (this.is === 'vm-spread-tile') {
        this.rowElementName = 'vmtile-spread-instrument-row';
        this.rowConstructor = context.VmSpreadInstrumentRow;
      } else {
        this.rowElementName = 'vmtile-instrument-row';
        this.rowConstructor = context.VmInstrumentRow;
      }

      // We need an indexed local store of the rows in order to be able to re-use them later,
      // even if we've removed them from the DOM, and to help us build them DOM in the correct
      // tile ordering if we haven't
      this.rowCollection = {};

      // Set up listeners and render view
      this.model.on('change:tileName', this.onChange, this);
      this.model.on('change:sortOrder', this.onInstrumentsChanged, this);
      this.model.on('indicativeInstrumentActivated', this.onIndicativeInstrumentActivated, this);
      this.model.on('remove', this.onDestroy, this);
      this.model.on('tileHasInterest', this.onTileInterest, this);
      this.model.on('instrumentTraded', this.onInstrumentTraded, this);
      this.model.auction.on('change:runningState', this.requestUpdateActiveState, this);
      this.model.auction.on('change:hiddenColumns', this.setColumnsFromAuction, this);
      this.model.auction.on('change:showInterestAndTradeCount', this.showNotificationBadges, this);
      this.model.auction.on('change:startTime change:endTime change:timeOffset change:auctionPhase  change:phaseoneEndtime', this.updateProgress, this);

      // along with whether or not we need to allow space to display off-the-mid order prices
      this.pageLayout.on('change:isMoveableMidEnabled', this.adjustSpaceForMyOrder, this);

      this.pageLayout.on('closeAllInstrumentViews', this.onCloseAll, this);

      // listen to filter changes
      this.pageLayout.on('change:brokerLiveMode change:traderLiveMode', this.applyLiveModeFilter, this);

      // listen for keyboard events to handle special keys
      $('body').on('keydown', {tileContext : this}, this.onBodyKeyDown);

      // Initialise the headers text using getAdjustedNomenclature based on swapBidAndOffer flag
      this.initialiseHeaders();

      // Swap the sides dynamically when we receive the swapBidAndOffer in usersettings.
      this.listenTo(this.dataStore.userSettingsStore, 'change:swapBidAndOffer', this.initialiseHeaders);

      this.recalcLayoutNeeded = false;
      this.initializing = true;
      this.render();
      this.buildRows();
      this.applyLiveModeFilter();
      this.updateProgress();
      this.setColumnsFromAuction();

      // listen to mouseleave to cancel selection
      $(this.$.instrumentRows).on('mouseleave', {tileContext : this}, this.onMouseLeave);

      this.$el.find('.collapse-toggle').on('click', () => that.toggleCollapsedState());

      this.$el.on('click', '.collapse-toggle', () => {
        that.toggleCollapsedState();
      });

      this.attachTooltipMouseEvents(this.$el);

      this.requestUpdateActiveState();
    },

    applyLiveModeFilter () {
      const isFiltered = this.pageLayout.getLiveModeForActiveUser() !== BGC.enums.EVMShowLiveMode.eShowAll;

      // collapsed so can can toggle fully open. col headers still shown though

      this.$.tileContainer.classList.toggle('is-open', !isFiltered);

      // add this to only active tiles
      this.$.tileContainer.classList.toggle('active-tile-filter', isFiltered && this.isVisible);
      this.triggerReCalcLayoutEvent();
    },

    onCloseAll (exceptInstrument) {
      if (exceptInstrument) {
        if (!this.model.findInstrumentById(exceptInstrument.get('instrumentId'))) {
          this.closeTile();
        }
      } else {
        this.closeTile();
      }
    },

    closeTile () {
      this.$.tileContainer.classList.toggle('is-open', false);
      this.triggerReCalcLayoutEvent();
    },

    attached () {
      this.triggerReCalcLayoutEvent();
    },

    remove () {
      this.stopListening();
      this.model.off(null, null, this);
      this.model.auction.off(null, null, this);
      this.pageLayout.off(null, null, this);
      $('body').off('keydown', this.onBodyKeyDown);

      Backbone.View.prototype.remove.apply(this, arguments);
    },

    createContentRow (instrument) {
      // eslint-disable-next-line new-cap
      const row = new this.rowConstructor({
        model : instrument, rowType : 'instrument', tileModel : this.model, pageLayout : this.pageLayout, container : this
      });

      this.rowCollection[instrument.get('instrumentId')] = row;

      row.setAttribute('data-instrument', instrument.get('instrumentId'));
      row.setAttribute('data-tile', this.model.get('tileId'));

      return row;
    },

    deleteContentRow (row) {
      const rowViewsContainer = this.shadowRoot.querySelector('div.instrument-rows');
      const instrumentId = row.getAttribute('data-instrument');

      rowViewsContainer.removeChild(row);
      delete this.rowCollection[instrumentId];

      BGC.logger.logInformation('VmTile', `Deleted instrument row for instrument ID: ${instrumentId} from tile ${this.model.get('tileId')}`);
    },

    requestRender () {
      BGC.ui.viewUtils.requestRender(this.model.get('tileId'), 'TileView', this, this.render);
    },

    // Swap the headers based on the swapBidAndOffer preference
    initialiseHeaders () {
      const swapSidesFlag = this.dataStore.userSettingsStore.get('swapBidAndOffer');

      this.buyText = swapSidesFlag ? this.model.getAdjustedNomenclature('IDS_SELL_SIZE') : this.model.getAdjustedNomenclature('IDS_BUY_SIZE');
      this.sellText = swapSidesFlag ? this.model.getAdjustedNomenclature('IDS_BUY_SIZE') : this.model.getAdjustedNomenclature('IDS_SELL_SIZE');
    },

    render () {
      let permissibleGenericColumns;

      if (this.selectedRow) {
        this.selectedRow.storeInputCellState();
      }

      this.instrumentHeader = this.model.get('tileName');

      if (this.initializing) {
        // Hide all potential generic columns initially
        permissibleGenericColumns = this.pageLayout.get('permissibleGenericColumns');
        permissibleGenericColumns.forEach(function (columnId) {
          this[`show-${columnId}`] = false;
        }, this);
      }

      this.onTileInterest();
      this.onInstrumentTraded();
      this.showNotificationBadges();

      this.$el.toggleClass('moveable-mids-enabled', this.pageLayout.get('isMoveableMidEnabled'));

      if (this.recalcLayoutNeeded && !this.suppressRecalcLayout) {
        this.triggerReCalcLayoutEvent();
      }
      this.recalcLayoutNeeded = false;
      this.suppressRecalcLayout = false;

      if (this.selectedRow) {
        this.selectedRow.restoreInputCellState();
      }

      this.initializing = false;
    },

    // eslint-disable-next-line max-statements
    buildRows () {
      const tile = this.model;
      const tileInstruments = tile.getSortedInstrumentCollection();
      const numRowsBefore = Object.keys(this.rowCollection).length;
      let lastProcessedRow;
      let nextRow;
      const tileViewContainerSelector = this.is === 'vm-spread-tile' ? 'div.collapsible.spread-tile-view' : 'div.collapsible.tile-view';
      const tileViewContainer = this.shadowRoot.querySelector(tileViewContainerSelector);
      const rowViewsContainer = this.shadowRoot.querySelector('div.instrument-rows');
      const fragment = document.createDocumentFragment();
      const logContext = `VM: ${document.title}`;

      if (!isWebDeployed) {
        BGC.logger.logInformation(logContext, `Building/ordering row elements for tileId[${tile.get('tileId')}]`);
      }
      BGC.utils.trace(`Building/ordering row elements for tileId[${tile.get('tileId')}]`);

      tileViewContainer.removeChild(rowViewsContainer);
      fragment.appendChild(rowViewsContainer);

      let activeCount = 0;

      // BGCVM-1185, only render active rows as the tile will now be re-rendered when instruments added/removed.
      const shouldBeVisible = instrument => instrument.isInAuction() || instrument.get('isMidPriceIndicative') || instrument.get('isLockInstrument');

      // eslint-disable-next-line func-names
      tileInstruments.filter(instrument => shouldBeVisible(instrument)).forEach(function (instrument) {
        activeCount += 1;
        nextRow = this.rowCollection[instrument.get('instrumentId')] || this.createContentRow(instrument);

        if (lastProcessedRow === undefined) {
          // If the desired row (i.e nextRow) is not currently the first row in the container
          // then if there is a first row, insert nextRow before it,
          // or if there aren't any rows, append nextRow inside the container as the only row
          if (rowViewsContainer.firstChild !== nextRow) {
            rowViewsContainer.insertBefore(nextRow, rowViewsContainer.firstChild || null);
          }
          lastProcessedRow = nextRow;
        } else {
          // If the desired row (i.e nextRow) is not currently next after the last processed row,
          // then insert it before the current next sibling of the last processed row,
          // or, if the last processed row is not followed by another row,
          // append nextRow as last row in the container
          if (lastProcessedRow.nextSibling !== nextRow) {
            rowViewsContainer.insertBefore(nextRow, lastProcessedRow.nextSibling || null);
          }
          lastProcessedRow = nextRow;
        }
      }, this);

      BGC.logger.logInformation(logContext, `Building/ordering row elements ${activeCount} active instruments of ${tileInstruments.length}`);

      // Re-attach the instrument rows container DOM fragment
      tileViewContainer.appendChild(fragment);

      if (!isWebDeployed) {
        BGC.logger.logInformation(
          logContext,
          // eslint-disable-next-line max-len
          `Finished building/ordering row elements. ${rowViewsContainer ? rowViewsContainer.children.length : 0} rows are now included in DOM for tileId[${tile.get('tileId')}]`
        );
      }
      // eslint-disable-next-line max-len
      BGC.utils.trace(`Finished building/ordering row elements. ${rowViewsContainer ? rowViewsContainer.children.length : 0} rows are now included in DOM for tileId[${tile.get('tileId')}]`);

      return numRowsBefore !== Object.keys(this.rowCollection).length;
    },

    onInstrumentsChanged () {
      this.recalcLayoutNeeded = this.buildRows() || this.recalcLayoutNeeded;
      this.requestRender();
    },

    // We can't get a single auction state transition after all required instruments have
    // gone into indicative state, since there isn't really a genuine auction on the server.
    // Therefore we have to monitor individual instruments going into indicative state.
    onIndicativeInstrumentActivated (instrumentId) {
      if (!this.rowCollection[instrumentId]) {
        // Trigger a debounced action that will result in the tile view being rebuilt
        // and a row for this instrument created
        this.model.coalesceSortRequests();
      }

      if (!this.isVisible) {
        this.requestUpdateActiveState();
      }
    },

    onChange (tileModel) {
      this.requestRender();
    },

    handleAuctionColumnsChanged () {
      this.setColumnsFromAuction();
    },

    setColumnsFromAuction () {
      const layoutGenericColumns = this.pageLayout.get('genericColumns');
      const tileAuction = this.model.auction;
      const auctionHiddenColumns = tileAuction.get('hiddenColumns');

      BGC.utils.trace(`TileView.setColumnsFromAuction: Tile ${this.model.get('tileId')}`);

      _.each(layoutGenericColumns, function (columnDefinition) {
        const showColumn = !_.contains(auctionHiddenColumns, columnDefinition.columnId);

        this[`show-${columnDefinition.columnId}`] = showColumn;
        this[columnDefinition.columnId] = columnDefinition.columnName;
      }, this);

      _.each(this.rowCollection, row => {
        row.setColumnsFromAuction();
      }, this);
    },

    updateProgress () {
      const progressBar = this.$$('progress-bar');

      if (progressBar) {
        progressBar.setAttribute('start-time', this.model.auction.get('startTime'));
        progressBar.setAttribute('end-time', this.model.auction.get('endTime'));
        progressBar.setAttribute('time-offset', this.model.auction.get('timeOffset'));
        progressBar.setAttribute('auction-Phase', this.model.auction.get('auctionPhase'));
        progressBar.setAttribute('phaseoneend-time', this.model.auction.get('phaseoneEndtime'));
      }
    },

    onDestroy () {
      BGC.logger.logInformation('VmTileBehavior', `Detaching VmTileBehavior for tileId[${this.model.get('tileId')}].`);

      $(this).detach();
    },

    requestUpdateActiveState () {
      BGC.ui.viewUtils.requestRender(this.model.get('tileId'), 'TileView', this, this.updateActiveState);
    },

    triggerReCalcLayoutEvent (centreOnApp = false) {
      this.dispatchEvent(
        new CustomEvent('recalcLayout', {
          bubbles  : true,
          composed : true,
          detail   : {centreOnApp}
        })
      );
    },

    updateActiveState () {
      const shouldBeOpen = !!this.model.auction.get('runningState');

      this.orderPhaseText = this.model.auction.get('orderPhaseText');

      BGC.logger.logInformation('VmTileBehavior', `Updating active state for tile view[${this.model.get('tileId')}] to: [${shouldBeOpen}].`);

      if ((shouldBeOpen !== this.isVisible) ||
                (this.isVisible && (this.model.auction.get('runningState') !== this.model.auction.get('prevRunningState')))) {
        // When visibility state is changing, we need to throw an event which our rows will receive.
        // This allows row visibility change to be triggered at the most efficient time,
        // since we have no control over the order in which a tile or the instruments within it will
        // receive the "start" event from an auction object.
        //
        // Such a visibility change event should also be thrown in response to a switch between different
        // types of auction content, since a VM may start on a tile that is already visible because it
        // is showing indicatives. Similarly, we need to re-show rows with indicatives if other rows
        // that were in VM all drop out of VM state.
        //
        // When tile is becoming visible, rows should be triggered first, to reduce browser layout overhead
        // since rows changing their visibility state inside a host element that is invisible shouldn't cause
        // a re-flow/layout calculation.
        // When making tile invisible, the event to the rows should be triggered afterwards, for the same reason.
        //
        // As of version 4.53, because of VM Favourites, all instruments are always placed in the tile model
        // whether or not they have gone into VM. From version 4.56, we also have pre-built/ordered row objects,
        // because we can build them when we get a tile update (introduced in 4.56) and not just when a VM starts.

        BGC.utils.trace(`${shouldBeOpen ? 'Showing' : 'Hiding'} Tile View for tileId[${this.model.get('tileId')}].`);
        BGC.logger.logInformation('VmTileBehavior', `${shouldBeOpen ? 'Showing' : 'Hiding'} Tile View for tileId[${this.model.get('tileId')}].`);

        this.isVisible = shouldBeOpen;

        if (!shouldBeOpen) {
          this.trigger('tileVisibilityChanging', false);
        } else {
          // Set the visibility of each row before we make the tile visible, saves on re-flows.
          // Also sets the generic columns for rows that become visible
          _.each(this.rowCollection, row => {
            row.evaluateAndSetVisibility();
          });

          // Update (or hide) the badges with counts
          this.onTileInterest();
          this.onInstrumentTraded();
          this.showNotificationBadges();

          // Open the tile by default when showing it initially
          this.$.tileContainer.classList.add('is-open');
        }

        this.triggerReCalcLayoutEvent(true);
      }

      this.$.tileContainer.classList.toggle('is-active', this.model.auction.get('runningState') !== this.model.auction.EContentState.eNone);
      if (this.model.auction.get('runningState') && this.model.areAnyInstrumentsInAuction()) {
        this.applyLiveModeFilter();
        this.showNotificationBadges();
        this.onTileInterest();
        this.onInstrumentTraded();
      } else {
        // deactivate the filtering for this inactive tile.
        this.$.tileContainer.classList.remove('active-tile-filter');
      }
    },

    adjustSpaceForMyOrder () {
      this.$el.toggleClass('moveable-mids-enabled', this.pageLayout.get('isMoveableMidEnabled'));
    },

    isCollapsed () {
      return !this.$.tileContainer.classList.contains('is-open');
    },

    toggleCollapsedState () {
      this.$.tileContainer.classList.toggle('is-open');
      this.triggerReCalcLayoutEvent();
      this.trigger('change:collapsed-state', this);
    },

    onTileInterest () {
      const interestCount = this.model.getInterestCount();
      const interestCountText = interestCount ? interestCount.toString() : '';

      if (this.thirdParty !== interestCountText) {
        this.thirdParty = interestCountText;

        this.model.trigger('glowCountChanged');

        if (interestCount && !this.initializing) {
          this.flashNotification(this.EFlashType.eThirdPartyInterest);
        }
      }
    },

    showNotificationBadges () {
      this.toggleClass('no-notifications', !this.model.auction.get('showInterestAndTradeCount'));
    },

    onInstrumentTraded () {
      const tradeCount = this.model.getTradeCount();
      const tradeCountText = tradeCount ? tradeCount.toString() : '';
      let gavelFlash = false;

      if (this.tradeCount !== tradeCountText) {
        this.tradeCount = tradeCountText;
        gavelFlash = true;

        this.model.trigger('tradeCountChanged');
      }

      if (gavelFlash && !this.initializing) {
        this.flashNotification(this.EFlashType.eTradeCount);
      }
    },

    onBodyKeyDown (event) {
      const tile = event.data.tileContext;
      const inplaceOEB = context.inplaceOEB.getInstance();
      let navRow;
      let navRowRect;
      let containerRect;

      // If the selected row isn't in this tile, or body is overlaid with a modal dlg, ignore the event
      if ($(tile).find('.tile-instrument-row.selected').length === 0 || $('body').hasClass('overlaid')) {
        return;
      }

      switch (event.keyCode) {
        case KeyCodes.F6:
          if (!inplaceOEB.isOpen) {
            if (!tile.selectedRow.getInstrumentModel().get('inactive')) {
              tile.selectedRow.openOEBPopup('buy');
            }
            event.preventDefault();
          }
          break;
        case KeyCodes.F7:
          if (!inplaceOEB.isOpen) {
            if (!tile.selectedRow.getInstrumentModel().get('inactive')) {
              tile.selectedRow.openOEBPopup('sell');
            }
            event.preventDefault();
          }
          break;
        case KeyCodes.ENTER:
          if (!inplaceOEB.isOpen) {
            if (!tile.selectedRow.getInstrumentModel().get('inactive')) {
              tile.selectedRow.openOEBPopup();
            }
            event.preventDefault();
          }
          break;

          // Navigation
        case KeyCodes.UP:
        case KeyCodes.DOWN:
          navRow = tile.selectedRow.findNextVisibleRowVertically(event.keyCode);
          if (navRow && navRow !== tile.selectedRow) {
            BGC.ui.viewUtils.setSelectionLockedFlag(navRow, true);

            // Select the next cell WITHOUT re-displaying any open OEB
            navRow.selectRow();

            // Don't want to move the selection AND control any scrollbar
            // unless the selection is about to move outside the viewport
            navRowRect = navRow.getBoundingClientRect();
            containerRect = navRow.offsetParent.getBoundingClientRect();
            if ((navRowRect.bottom <= containerRect.bottom) && (navRowRect.top >= containerRect.top)) {
              event.preventDefault();
            }
          }
          break;
      }
    },

    onMouseLeave (event) {
      const tile = event.data.tileContext;

      // If the selected row isn't in this tile, ignore the event
      if ($(tile).find('.tile-instrument-row.selected').length === 0) {
        return;
      }

      // clear selection when moving away from grid unless it is locked
      if (tile.selectedRow && !BGC.ui.viewUtils.isSelectionLocked(this)) {
        tile.selectedRow.clearSelection();
        $(tile.selectedRow).trigger('selectInstrument', [tile.selectedRow, undefined]);
      }
    },

    openTile (tileId) {
      // Ensure the tile is open.
      if (!this.$.tileContainer.classList.contains('is-open')) {
        this.toggleCollapsedState();
      }
    }
  };
}(window.BGC.ui.view));
