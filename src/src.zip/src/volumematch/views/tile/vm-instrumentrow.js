/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false, Polymer: false */


import {PolymerElement} from '@polymer/polymer';
import {mixinBehaviors} from '@polymer/polymer/lib/legacy/class';
import componentTemplate from './vm-instrumentrow.template';

const {view: context} = window.BGC.ui;

// name instrument-row-cell style-scope vmtile-instrument-row third-party-interest

class VmInstrumentRow extends mixinBehaviors([
  context.VmTileRowBehavior
], PolymerElement) {
  static get template () {
    return componentTemplate;
  }

  constructor (options) {
    super();
    this.classOptions = options;
    _.extend(this, Backbone.Events);
  }

  ready() {
    super.ready();
    this.factoryImpl(this.classOptions);
  }

  shouldBeVisible () {
    const instrument = this.getInstrumentModel();

    return instrument.isInAuction() ||
        (!this.pageLayout.areAnyInstrumentsInAuction() && instrument.get('isMidPriceIndicative')) ||
        instrument.get('isLockInstrument');
  }

  render () {
    const wasVisible = this.isVisible;
    const instrumentModel = this.getInstrumentModel();
    const shouldBeVisible = this.shouldBeVisible();
    let permissibleGenericColumns = null;


    // Ensure the instrument has been serialised first in case we decide not to proceed
    // with the render operation further down but a listener is notified of an event some
    // time later and the data becomes needed.
    this.instrument = instrumentModel.serialize();

    if (this.isWaitingForFirstRender) {
      this.shadowRoot.querySelectorAll('size-input-control').forEach(sizeInput => {
        sizeInput.setValidationCallback(instrumentModel.validateSize.bind(instrumentModel));
      }, this);

      // Hide all potential generic columns initially
      permissibleGenericColumns = this.pageLayout.get('permissibleGenericColumns');
      permissibleGenericColumns.forEach(function (columnId) {
        this[`show-${columnId}`] = false;
      }, this);

      // Then sync with the columns currently active for the tile
      this.setColumnsFromAuction();

      this.isWaitingForFirstRender = false;
    }

    // Swap the Sides (buy/sell) based on the selection of "swapBidAndOffer" setting
    this.shadowRoot.querySelector('#mirrorElements').classList.toggle('mirror', BGC.dataStore.userSettingsStore.get('swapBidAndOffer'));

    // read instrument attributes and retrieve order model to render (if any own order)
    const activeOrderModel = this.getOrderModel();
    const activeOrder = activeOrderModel && activeOrderModel.serialize();
    const buyOrder = activeOrder && activeOrder.buyOrder;
    const sellOrder = activeOrder && activeOrder.sellOrder;
    const lastBuySize = this.buySize || '';
    const lastSellSize = this.sellSize || '';
    let sizeCell;

    // let permissibleGenericColumns;
    let layoutGenericColumns;
    let showColumn;

    this.instrumentName = this.instrument.name;

    // Set display value for generic columns from generic column instrument data
    this.visibleGenericColumnIds.forEach(function (columnId) {
      this[columnId] = this.instrument[columnId];
    }, this);

    // order sizes should be coerced to string by + "", as they will be revert values of size cells
    this.buySize = `${buyOrder && buyOrder.hasBuySize ? buyOrder.buySize : ''}`;
    this.buyPrice = buyOrder ? buyOrder.price : this.instrument.midPrice;
    this.displayCancelBuy = !!(buyOrder && buyOrder.hasCancellableBuySize);
    this.sellSize = `${sellOrder && sellOrder.hasSellSize ? sellOrder.sellSize : ''}`;
    this.sellPrice = sellOrder ? sellOrder.price : this.instrument.midPrice;
    this.displayCancelSell = !!(sellOrder && sellOrder.hasCancellableSellSize);
    this.disableFavoriteIcon = !!(buyOrder || sellOrder);

    this.priceCellOptions = {
      model      : this.getInstrumentModel(),
      order      : activeOrder || {dummy : true},
      row        : this,
      grid       : this.container,
      pageLayout : this.pageLayout
    };

    // Initialize lock row attributes
    if (instrumentModel.get('isLockInstrument') && !this.isLockRow) {
      this.isLockRow = true;
      this.displayFavoriteIcon = false;
      this.querySelector('vm-midprice-cell').render();
    }

    // Size cell options used for the vm-ordersize-cell which was developed for
    // compact tile display without size input columns, and which is still in the row template.
    this.sizeCellOptions = this.priceCellOptions;

    // For size input columns, we may have typed a size resulting in an order execution,
    // but if that whole size executed then the outstanding size (the revert value attribute for the cell)
    // will not have changed, and therefore the control won't call it's revert() method,
    // so the typed text will remain.
    // For that reason, if outstanding size han't changed, call revert directly just in case.
    if (lastBuySize === this.buySize) {
      sizeCell = this.shadowRoot.querySelector('size-input-control[side=\'buy\'');
      if (sizeCell) {
        sizeCell.revert();
      }
    }
    if (lastSellSize === this.sellSize) {
      sizeCell = this.shadowRoot.querySelector('size-input-control[side=\'sell\'');
      if (sizeCell) {
        sizeCell.revert();
      }
    }

    this.buyStatus = activeOrderModel ? activeOrderModel.buildStatusString('buy', true) : '';
    this.sellStatus = activeOrderModel ? activeOrderModel.buildStatusString('sell', true) : '';
    this.statusSeparationText = this.buyStatus && this.sellStatus ? ' / ' : '';

    if (!shouldBeVisible) {
      this.setActive(false);

      return;
    }

    // If row is destined to become visible and its auction is already running
    // then do the necessary to make it visible now and apply styling
    if (!wasVisible && shouldBeVisible) {
      this.evaluateAndSetVisibility();
    } else {
      // Must be visible already, so apply class styling, glows etc. per row
      this.applyClassStyles(this.instrument, activeOrder);
    }
  }
}
context.VmInstrumentRow = VmInstrumentRow;
customElements.define('vmtile-instrument-row', VmInstrumentRow);
