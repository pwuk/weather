import {html} from '@polymer/polymer/polymer-element';

export default html`
    <style>
        * { box-sizing: border-box;}
        *[hidden] {
            display: none !important;
        }

        .collapse-toggle {
            padding-top: 0;
            width: 2rem;
            height: 100%;
            border-right: 0px;
            transition: background 0.2s ease;
            align-items: center;
            position: relative;
            float: left;
        }

        .collapse-toggle:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .collapse-toggle:active {
            background-color: rgba(255, 255, 255, 0.4);
        }

        .collapse-toggle:before {
            font-family: FontAwesome;
            content: "\\f105";
            width: 2rem;
            font-size: 1.4rem;
            font-weight: bold;
            display: block;
            padding-top: 0;
            padding-left: 0.5rem;
            text-align: center;
        }

        .collapsible-title {
            display: flex;
            align-items: center;
            padding: 0;
            margin: 0;
            padding-left: 0;
            font-size: 1rem;
            color: white;
            background-color: inherit;
            line-height: 1;
            height: 100%;
        }

        .is-active .collapsible-title > span {
            font-weight: bold;
        }

        .is-active .collapsible-title > span > span {
            padding-left: 0.4rem;
        }

        .is-active .collapsible-title {
            font-weight: bold;
            color: var(--header-active-text-color);
        }

        .is-open .collapse-toggle:before {
            font-family: FontAwesome;
            content: "\\f107";
            padding-top: 0;
        }

        .is-open .collapsible-title {
            display: none;
        }


        .header-row {
            display: flex;
            color: var(--content-header-text);
            font-size: 1rem;
            height: 2rem;
            background-color: var(--content-header-background);
            border-bottom: 1px solid;
            border-color: var(--content-header-border);
        }
        .header-row .straddleDisplay,
        .header-row .ratioDisplay,
        .header-row .deltaDisplay,
        .header-row .strike1Display,
        .header-row .strike2Display,
        .header-row .crossDisplay,
        .header-row .volume,
        .header-row .size,
        .header-row .order-size,
        .header-row .price,
        .header-row .ratio,
        .header-row .priceBDisplay {
            display: block;
            float: left;
            height: 100%;
            width: 6rem;
            min-width: 6rem;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
        }
        .header-row .account-name {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex: 1;
        }
        .header-row .status {
            display: block;
            float: left;
            height: 100%;
            width: 12rem;
            min-width: 12rem;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex:1;
        }
        .header-row .repost-all {
            display: block;
            float: left;
            height: 100%;
            width: 6rem;
            min-width: 6rem;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            display: none;
        }
        .header-row .repost-all.showRepostall {
            display: inline;
        }
        .wide-status .header-row .status {
            width: 18rem;
        }
        .header-row .name {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            border-left: none;
            flex: 1;
            min-width: 6rem;
        }
        .header-row .inner-name {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex: 1;
        }
        .header-row .counterparty {
            display: block;
            float: left;
            height: 100%;
            width: initial;
            min-width: initial;
            line-height: 2rem;
            text-align: center;
            background-color: transparent;
            border-left: 1px solid;
            border-color: inherit;
            flex: 1;
        }
        .tile-view {
            margin-top: 2px;
            background-color: var(--content-header-background);
        }
        .tooltip-placement-left .tooltip-arrow {
            right: -6px;
            top: 50%;
        }
        .tooltip-placement-right .tooltip-arrow {
            left: -8px;
            top: 50%;
        }
        .tooltiptext {
            width: 100px;
            background-color: var(--tab-inactive-background);
            color: var(--content-header-text);
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;
            font-weight: var(--font-weight-matrix-cell-data);
            /* Position the tooltip */
            right: 115% ;
        }
        .tooltip-inner {
            max-width: 250px;
            padding: 8px 10px;
            color: white;
            text-align: left;
            text-decoration: none;
            background-color: var(--tab-inactive-background);
            border-radius: 4px;
            min-height: 32px;
        }
        .tooltip-arrow {
            position: absolute;
            width: 14px;
            height: 14px;
            border-color: transparent;
            border-style: solid;
            border-width: 1px;
            background-color: var(--tab-inactive-background);
            transform: rotate(45deg);
        }

        .header-row .collapse-toggle,
        .header-row .collapsible-title {
            display: none;
        }
        vm-header-row .header-row:not(.is-active) {
            display: none;
        }
        .collapsible.tile-view .header-row {
            height: 2rem;
            border-radius: 0.5rem 0.5rem 0 0;
        }
        .collapsible.tile-view .header-row,
        .tiles-column-layout .header-row {
            position: relative;
            background-image: none;
            background-color: var(--content-header-background);
        }
        .collapsible.tile-view .header-row.is-empty,
        .tiles-column-layout .header-row.is-empty {
            display: none;
        }
        .collapsible.tile-view .header-row .collapsible-title + .name,
        .tiles-column-layout .header-row .collapsible-title + .name {
            padding-right: 2.2rem;
            line-height: 2rem;
            display: flex;
            min-width: 0;
        }
        .collapsible.tile-view .header-row .collapsible-title + .name > span,
        .tiles-column-layout .header-row .collapsible-title + .name > span {
            text-align: left;
            float: left;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }
        .collapsible.tile-view .header-row .straddleDisplay,
        .tiles-column-layout .header-row .straddleDisplay,
        .collapsible.tile-view .header-row .ratioDisplay,
        .tiles-column-layout .header-row .ratioDisplay,
        .collapsible.tile-view .header-row .deltaDisplay,
        .tiles-column-layout .header-row .deltaDisplay,
        .collapsible.tile-view .header-row .strike1Display,
        .tiles-column-layout .header-row .strike1Display,
        .collapsible.tile-view .header-row .strike2Display,
        .tiles-column-layout .header-row .strike2Display,
        .collapsible.tile-view .header-row .crossDisplay,
        .tiles-column-layout .header-row .crossDisplay,
        .collapsible.tile-view .header-row .volume,
        .tiles-column-layout .header-row .volume,
        .collapsible.tile-view .header-row .size,
        .tiles-column-layout .header-row .size,
        .collapsible.tile-view .header-row .order-size,
        .tiles-column-layout .header-row .order-size,
        .collapsible.tile-view .header-row .price,
        .tiles-column-layout .header-row .price,
        .collapsible.tile-view .header-row .ratio,
        .tiles-column-layout .header-row .ratio,
        .collapsible.tile-view .header-row .priceBDisplay,
        .tiles-column-layout .header-row .priceBDisplay {
            line-height: 2rem;
        }
        .collapsible.tile-view .header-row .order-size,
        .tiles-column-layout .header-row .order-size {
            width: calc(6rem);
        }
        .collapsible.tile-view .header-row .notifications,
        .tiles-column-layout .header-row .notifications {
            display: flex;
            flex-direction: row-reverse;
            align-items: center;
            float: right;
            height: 100%;
            padding: 0.1rem;
            line-height: normal;
            width: initial;
            min-width: 4.76rem;
            float: left;
        }
        .collapsible.tile-view .header-row .notifications .badge,
        .tiles-column-layout .header-row .notifications .badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
        }
        .collapsible.tile-view .header-row .notifications .badge:empty,
        .tiles-column-layout .header-row .notifications .badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .instrument-count-badge,
        .tiles-column-layout .header-row .notifications .instrument-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: white;
            color: black;
            box-shadow: 0 0 1px 1px white;
        }
        .collapsible.tile-view .header-row .notifications .instrument-count-badge:empty,
        .tiles-column-layout .header-row .notifications .instrument-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .instrument-count-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .instrument-count-badge.flash-500ms {
            background: black;
            color: white;
        }
        .collapsible.tile-view .header-row .notifications .third-party-badge,
        .tiles-column-layout .header-row .notifications .third-party-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--thirdparty-glow-badge-bg);
            color: var(--thirdparty-glow-badge-text);
            box-shadow: 0 0 1px 1px var(--thirdparty-glow-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .third-party-badge:empty,
        .tiles-column-layout .header-row .notifications .third-party-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .third-party-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .third-party-badge.flash-500ms {
            background: var(--thirdparty-glow-badge-flash-bg);
            color: var(--thirdparty-glow-badge-flash-text);
        }
        .collapsible.tile-view .header-row .notifications .trade-count-badge,
        .tiles-column-layout .header-row .notifications .trade-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--trade-count-badge-bg);
            color: var(--trade-count-badge-text);
            box-shadow: 0 0 1px 1px var(--trade-count-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .trade-count-badge:empty,
        .tiles-column-layout .header-row .notifications .trade-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .trade-count-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .trade-count-badge.flash-500ms {
            background: var(--trade-count-badge-flash-bg);
            color: var(--trade-count-badge-flash-text);
        }
        .collapsible.tile-view .header-row .notifications .my-order-count-badge,
        .tiles-column-layout .header-row .notifications .my-order-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--my-order-count-glow-badge-bg);
            color: var(--my-order-count-glow-badge-text);
            box-shadow: 0 0 1px 1px var(--my-order-count-glow-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .my-order-count-badge:empty,
        .tiles-column-layout .header-row .notifications .my-order-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .my-trade-count-badge,
        .tiles-column-layout .header-row .notifications .my-trade-count-badge {
            font-size: 0.8rem;
            width: auto;
            min-width: 1.2rem;
            line-height: 1.2rem;
            border-radius: 500px;
            font-weight: 700;
            text-align: center;
            margin: 0.1rem;
            color: black;
            padding-right: 0.2rem;
            padding-left: 0.15rem;
            float: right;
            background-color: var(--my-trade-count-glow-badge-bg);
            color: var(--my-trade-count-glow-badge-text);
            box-shadow: 0 0 1px 1px var(--my-trade-count-glow-badge-border);
        }
        .collapsible.tile-view .header-row .notifications .my-trade-count-badge:empty,
        .tiles-column-layout .header-row .notifications .my-trade-count-badge:empty {
            display: none;
        }
        .collapsible.tile-view .header-row .notifications .my-trade-count-badge.flash-500ms,
        .tiles-column-layout .header-row .notifications .my-trade-count-badge.flash-500ms {
            background: var(--my-trade-count-badge-flash-bg);
            color: var(--my-trade-count-badge-flash-text);
        }
        .collapsible.tile-view .header-row .collapse-toggle,
        .tiles-column-layout .header-row .collapse-toggle,
        .collapsible.tile-view .header-row .notifications,
        .tiles-column-layout .header-row .notifications,
        .collapsible.tile-view .header-row .collapsible-title,
        .tiles-column-layout .header-row .collapsible-title {
            visibility: visible;
        }
        .collapsible.tile-view .header-row .collapse-toggle,
        .tiles-column-layout .header-row .collapse-toggle,
        .collapsible.tile-view .header-row .collapsible-title,
        .tiles-column-layout .header-row .collapsible-title {
            display: flex;
        }
        .collapsible.tile-view .header-row .collapsible-title,
        .tiles-column-layout .header-row .collapsible-title {
            position: absolute;
            top: 0;
            left: 2rem;
            right: 0;
            padding-left: 0;
        }
        .collapsible.tile-view .header-row .collapse-toggle,
        .tiles-column-layout .header-row .collapse-toggle {
            left: 0;
            width: 2rem;
            background-color: transparent;
        }
        .no-notifications .collapsible.tile-view .header-row .notifications,
        .no-notifications .tiles-column-layout .header-row .notifications {
            display: none;
        }
        .collapsible.tile-view .instrument-rows,
        .tiles-column-layout .instrument-rows {
            display: none;
        }
        .collapsible.tile-view .header-row.is-open .collapsible-title,
        .tiles-column-layout .header-row.is-open .collapsible-title {
            display: none;
        }
        .collapsible.tile-view.is-open .header-row .status,
        .tiles-column-layout.is-open .header-row .status {
            line-height: 2rem;
        }
        .collapsible.tile-view.is-open .header-row .collapsible-title,
        .tiles-column-layout.is-open .header-row .collapsible-title {
            display: none;
        }
        .collapsible.tile-view.is-open .instrument-rows,
        .tiles-column-layout.is-open .instrument-rows {
            display: block;
        }
        .collapsible.tile-view .header-row > * {
            visibility: hidden;
        }
        .collapsible.tile-view.is-open .header-row > * {
            visibility: visible;
        }


        :host(.filter-show-mine-only) .active-tile-filter:not(.is-open) .vm-header-row,
        :host(.filter-show-mine-only) .active-tile-filter:not(.is-open) .header-row > *,
        :host(.filter-show-mine-glows) .active-tile-filter:not(.is-open) .vm-header-row,
        :host(.filter-show-mine-glows) .active-tile-filter:not(.is-open) .header-row > * {
            visibility: visible !important;
        }
        :host(.filter-show-mine-only) .active-tile-filter:not(.is-open) .vm-header-row.collapsible-title,
        :host(.filter-show-mine-only) .active-tile-filter:not(.is-open) .header-row .collapsible-title,
        :host(.filter-show-mine-glows) .active-tile-filter:not(.is-open) .vm-header-row.collapsible-title,
       :host(.filter-show-mine-glows) .active-tile-filter:not(.is-open) .header-row .collapsible-title {
            display: none !important;
        }
        :host(.filter-show-mine-only) .active-tile-filter:not(.is-open) div.instrument-rows,
        :host(.filter-show-mine-glows) .active-tile-filter:not(.is-open) div.instrument-rows {
            display: block;
        }
        
        

    </style>
    <div id="tileContainer" hidden="{{!isVisible}}" class="collapsible tile-view">
        <progress-bar timer-id="{{auctionId}}" message="[[orderPhaseText]]" class="hide-me" hide-when-done="true">
        </progress-bar>
        <div class="header-row">
            <span class="collapse-toggle"></span>
            <div class="collapsible-title">
                <div class="notifications">
                    <span class="third-party-badge">{{thirdParty}}</span>
                    <span class="badge trade-count-badge">{{tradeCount}}</span>
                </div>
                <span>{{instrumentHeader}}</span>
            </div>
            <div class="name">
                <div class="notifications">
                    <span class="third-party-badge">{{thirdParty}}</span>
                    <span class="trade-count-badge">{{tradeCount}}</span>
                </div>
                <span>{{instrumentHeader}}</span>
            </div>
            <span class="straddleDisplay" hidden="{{!show-straddleDisplay}}">{{straddleDisplay}}</span>
            <span class="volume" hidden="{{!show-volume}}">{{volume}}</span>
            <span class="strike1Display" hidden="{{!show-strike1Display}}">{{strike1Display}}</span>
            <span class="strike2Display" hidden="{{!show-strike2Display}}">{{strike2Display}}</span>
            <span class="ratioDisplay" hidden="{{!show-ratioDisplay}}">{{ratioDisplay}}</span>
            <span class="deltaDisplay" hidden="{{!show-deltaDisplay}}">{{deltaDisplay}}</span>
            <span class="crossDisplay" hidden="{{!show-crossDisplay}}">{{crossDisplay}}</span>
            <span class="size">{{buyText}}</span>
            <span class="price">{{resources.IDS_PRICE}}</span>
            <span class="size">{{sellText}}</span>
            <span class="priceBDisplay" hidden="{{!show-priceBDisplay}}">{{priceBDisplay}}</span>
            <div class="status">
                <span>{{resources.IDS_TRADE_STATUS}}</span>
            </div>
        </div>
        <div id="instrumentRows" class="instrument-rows"></div>
    </div>
`;
