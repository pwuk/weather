/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */


import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './vm-ordersize-cell.template';

const {view: context} = window.BGC.ui;

class VmOrderSizeCell extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  connectedCallback () {
    super.connectedCallback();
    // _.extend(this, Backbone.Events);
    this.$el = $(this.shadowRoot);
    this.orderSize = '';
    this.row = undefined;

    this.render();
  }


  constructor (options) {
    super();
    this.options = options;

    // this.addEventListener('mousedown', this.onCellClick);
    // this.addEventListener('mouseenter', this.onCellMouseEnter);
  }

  static get properties () {
    return {
      options : {
        type     : Object,
        notify   : false,
        observer : 'requestRender',
        value () {
          return {model : {dummy : true}, order : {dummy : true}};
        }
      }
    };
  }

  getInstrumentModel () {
    return this.options.model;
  }

  getRow () {
    return this.options.row;
  }

  getGrid () {
    return this.options.grid;
  }

  requestRender () {
    const instModel = this.getInstrumentModel();

    if (!instModel || instModel.dummy || !this.getRow() || !this.getRow().isVisible) {
      // Don't do any rendering if we don't have an instrument,
      // or we aren't in a row, or our row isn't visible.
      return;
    }

    BGC.ui.viewUtils.requestRender(instModel.get('instrumentId'), 'orderSizeCell', this, this.render);
  }

  render () {
    if (this.options.model.dummy) {
      return;
    }

    const activeOrderModel = this.getInstrumentModel().getActiveOrder();
    const activeOrder = activeOrderModel && activeOrderModel.serialize();
    const buyOrder = activeOrder && activeOrder.buyOrder;
    const sellOrder = activeOrder && activeOrder.sellOrder;
    let pendingSizeElems;

    this.statusScroll = 0;

    this.buySize = buyOrder && buyOrder.hasBuySize ? buyOrder.buySize : '';
    this.displayBuySize = !!this.buySize;
    this.displayCancelBuy = !!(buyOrder && buyOrder.hasCancellableBuySize);
    if (this.buySize && this.getInstrumentModel().isMoveableMidEnabled()) {
      this.buySize += ` @ ${buyOrder.priceDisplay}`;
    }

    this.sellSize = sellOrder && sellOrder.hasSellSize ? sellOrder.sellSize : '';
    this.displaySellSize = !!this.sellSize;
    this.displayCancelSell = !!(sellOrder && sellOrder.hasCancellableSellSize);
    if (this.sellSize && this.getInstrumentModel().isMoveableMidEnabled()) {
      this.sellSize += ` @ ${sellOrder.priceDisplay}`;
    }

    if (this.displayBuySize || this.displaySellSize) {
      pendingSizeElems = this.$el.find('div.pending-size');
      pendingSizeElems.scrollTop();

      if (this.displayBuySize) {
        pendingSizeElems.find('.buy-size').toggleClass('published-by-excel', activeOrder.wasBuyPublishedByExcel);
      }
      if (this.displaySellSize) {
        pendingSizeElems.find('.sell-size').toggleClass('published-by-excel', activeOrder.wasSellPublishedByExcel);
      }
    }
  }

  onCancelBuyIconClick (event) {
    const {order} = this.options;

    // cancel outstanding order(s)
    if (order.hasCancellableBuySize) {
      this.options.model.sendCancelOrder('GridCell', 'buy');
    }

    event.stopPropagation();
  }

  onCancelSellIconClick (event) {
    const {order} = this.options;

    // cancel outstanding order(s)
    if (order.hasCancellableSellSize) {
      this.options.model.sendCancelOrder('GridCell', 'sell');
    }

    event.stopPropagation();
  }
}
context.VmOrderSizeCell = VmOrderSizeCell;
customElements.define('vm-ordersize-cell', VmOrderSizeCell);