import {html} from '@polymer/polymer';

export default html`
<style>
    * { box-sizing: border-box;}
    *[hidden] {
        display: none !important;
    }

    .order-size {
        display: block;
        float: left;
        width: 6rem;
        min-width: 6rem;
        height: 100%;
        background-color: transparent;
        color: inherit;
        border: none;
        border-left: solid 1px var(--content-border);
        vertical-align: top;
        padding: 0 0 0 0.5rem;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        background-color: var(--content-background);
        line-height: 1.6rem;
        height: 1.6rem;
        font-size: 1rem;
        text-align: center;
        padding: 0px;
        float: none;
    }
    .order-size .pending-size .sell-size {
        font-weight: var(--font-weight-buy-sell-size);
        position: relative;
        border-width: 1px;
        border-style: solid;
        width: 100%;
        height: 1.6rem;
    }
    .order-size .pending-size {
        position: relative;
        height: 1.6rem;
        line-height: 1.6rem;
        border: none;
        /* For locked down orders, could have buy and sell size one above the other with scrolling */
        overflow-x: hidden;
        overflow-y: auto;
    }
    .order-size .pending-size .buy-size {
        color: var(--buy-order);
        border-color: var(--buy-order);
        text-align: left;
        padding-left: 1px;
    }
    

</style>
<div id="sizeCell" class="order-size">
    <div class="pending-size">
        <div class="buy-size" hidden="{{!displayBuySize}}">
            <span>{{buySize}}</span>
            <img class="quick-cancel" src="assets/images/cancel.png" on-tap="onCancelBuyIconClick"
                 hidden="{{!displayCancelBuy}}"/>
        </div>
        <div class="sell-size" hidden="{{!displaySellSize}}">
            <img class="quick-cancel" src="assets/images/cancel.png" on-tap="onCancelSellIconClick"
                 hidden="{{!displayCancelSell}}"/>
            <span>{{sellSize}}</span>
        </div>
    </div>
</div>
`;
