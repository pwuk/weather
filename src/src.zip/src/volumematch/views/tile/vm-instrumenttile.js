/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */

import {PolymerElement} from '@polymer/polymer';
import {mixinBehaviors} from '@polymer/polymer/lib/legacy/class';
import componentTemplate from './vm-instrumenttile.template';

const {view: context} = window.BGC.ui;

class InstrumentTileView extends mixinBehaviors([
  context.VmTileBehavior,
  context.GridViewNavigationMixin
], PolymerElement) {
  static get template () {
    return componentTemplate;
  }

  constructor (options) {
    super();
    _.extend(this, Backbone.Events);
    this.classOptions = options;
  }

  ready () {
    super.ready();
    this.factoryImpl(this.classOptions);
  }

}
context.InstrumentTileView = InstrumentTileView;
customElements.define('vm-instrument-tile', InstrumentTileView);
