import {html} from '@polymer/polymer/polymer-element';

// <!--    tile-instrument-row style-scope vm-tile-instrument-row selected-->

export default html`
    <style>
        * { box-sizing: border-box;}
        *[hidden] { display: none !important; }

        .tile-view {
            margin-top: 2px;
            background-color: var(--content-header-background);
        }
        :host {
            display: none;
        }
        :host(.is-visible) {
            display: block;
        }
        :host(.is-filtered) {
            display: none
        }
        
        .size img.cancel-buy {
            right: 0.15rem;
            position: absolute;
            top: 50%;
            margin-top: -0.5rem;
            width: 1rem;
            left: auto;
        }
        .size img.cancel-sell {
            position: absolute;
            top: 50%;
            margin-top: -.5rem;
            width: 1rem;
            left: .15rem;
            right: 0;
        }
        .instrument-row-cell {
            border-right: solid 1px var(--content-border);
            float: left;
            line-height: calc(1.6rem - 1px);
            position: relative;
            background-color: var(--tile-cell-background);
            display: block;
            height: 100%;
            color: inherit;
            vertical-align: top;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            width: 6rem;
            min-width: 6rem;
            font-weight: inherit;
        }
        .tile-instrument-row {
            position: relative;
            display: flex;
            height: 1.6rem;
            line-height: calc(1.6rem - 1px);
            overflow: hidden;
            font-size: 1rem;
            color: var(--content-text);
            border-bottom: solid 1px var(--content-border);
            background-image: none;
            background-color: var(--tile-cell-background);
            font-weight: bold;
        }
        .tile-instrument-row .status {
            display: block;
            float: left;
            width: 12rem;
            min-width: 12rem;
            height: 100%;
            background-color: transparent;
            color: inherit;
            border: none;
            border-left: solid 1px var(--content-border);
            vertical-align: top;
            padding: 0 0 0 0.5rem;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            font-weight: normal;
            flex: 1;
        }
        .tile-instrument-row.executed .status {
            font-weight: 700;
        }
        .sell-status {
            color: var(--sell-status-executed);
        }
        .buy-status {
            color: var(--buy-status-executed);
        }
        
        .tile-instrument-row.executed .status .buy-status {
            color: var(--buy-status-executed);
        }
        .tile-instrument-row.executed .status .sell-status {
            color: var(--sell-status-executed);
        }

        .tile-instrument-row .name {
            border-right: solid 1px var(--content-border);
            display: block;
            float: left;
            width: initial;
            height: 100%;
            background-color: transparent;
            color: inherit;
            border-left: solid 1px var(--content-border);
            vertical-align: top;
            padding: 0 0 0 0.5rem;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            flex: 1;
            padding-right: 2rem;
            font-weight: inherit;
            position: relative;
        }

        .vm-tile-instrument-row.selected .name,
        .vm-tile-instrument-row.selected .inner-name,
        .vm-tile-instrument-row.selected vm-midprice-cell {
            outline: 1px solid var(--selection);
            outline-offset: -1px;
            background-color: transparent;
            box-shadow: inset 0 0 0 2px var(--selection);
            background-color: var(--highlight-background);
        }

        .third-party-interest {
            font-weight: var(--font-weight-matrix-cell-data);
            background-image: linear-gradient(to right, var(--thirdparty-glow), var(--thirdparty-glow));
            color: var(--thirdparty-glow-text);
        }
        .third-party-interest.below-market-size {
            background-image: linear-gradient(to right, var(--thirdparty-glow), var(--content-background), var(--content-background), var(--thirdparty-glow));
            color: var(--thirdparty-glow-text);
        }
        

        fa-state-icon {
            width: 2.2rem;
            line-height: inherit;
            font-size: 1.4rem;
            color: var(--favorites-icon-color);
            text-align: center;
            overflow: hidden;
            border-right: 1px solid var(--content-border);
        }
        .size {
            background-color: var(--content-background);
            line-height: calc(1.5rem - 2px);
            /*height: calc(1.5rem - 1px);*/
            text-align: center;
            width: 6rem;
        }

        .name.le-buy-interest:before {
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 0;
            border-top: none;
            border-bottom: calc(1.6rem * 0.8) solid transparent;
            border-left: calc(1.6rem * 0.8) solid var(--same-le-glow);
            content: '';
            display: block;
            opacity: 0.7;
        }
        .instrument-row .name.le-sell-interest:after {
            position: absolute;
            top: 0;
            right: 0;
            width: 0;
            height: 0;
            border-top: none;
            border-bottom: calc(1.6rem * 0.8) solid transparent;
            border-right: calc(1.6rem * 0.8) solid var(--same-le-glow);
            content: '';
            display: block;
            opacity: 0.7;
        }
        
        
        .name.le-buy-interest:before {
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 0;
            border-top: none;
            border-bottom: calc(1.6rem * 0.8) solid transparent;
            border-left: calc(1.6rem * 0.8) solid var(--same-le-glow);
            content: '';
            display: block;
            opacity: 0.7;
        }
        .instrument-row .name.le-sell-interest:after {
            position: absolute;
            top: 0;
            right: 0;
            width: 0;
            height: 0;
            border-top: none;
            border-bottom: calc(1.6rem * 0.8) solid transparent;
            border-right: calc(1.6rem * 0.8) solid var(--same-le-glow);
            content: '';
            display: block;
            opacity: 0.7;
        }

        .traded.gavel {
        position: absolute;
        right: 2px;
        top: 2px;
        background-image: var(--gavel-image);
        background-repeat: no-repeat;
        background-size: calc(1.6rem - 4px);
        width: calc(1.6rem - 4px);
        height: calc(1.6rem - 4px);
        }

        .name-flex {
            padding-right: 4.1rem !important;
            /*Cater for extra space when the favourite (Flex) start icon is not present*/
        }
        
    </style>
    <div id="instrumentRow" class$=[[rowClassString]]>
    <fa-state-icon 
            state-classes='["fa-star-o", "fa-star"]' 
            hidden="[[!displayFavoriteIcon]]"
            state="[[favoriteIconState]]" 
            is-disabled$="[[disableFavoriteIcon]]"
            on-tap="onClickFavoriteIcon">
    </fa-state-icon>
    <div class$="name [[nameWithFavoriteIcon]]">
        <span>{{instrumentName}}</span>
        <span class="traded gavel" hidden="{{!showNameGavel}}" on-click="onGavelClick" on-mouseenter="onGavelMouseEnter" on-mouseleave="onGavelMouseLeave"></span>
    </div>
    <span class="straddleDisplay instrument-row-cell" hidden="{{!show-straddleDisplay}}">{{straddleDisplay}}</span>
    <span class="volume instrument-row-cell" hidden="{{!show-volume}}">{{volume}}</span>
    <span class="strike1Display instrument-row-cell" hidden="{{!show-strike1Display}}">{{strike1Display}}</span>
    <span class="strike2Display instrument-row-cell" hidden="{{!show-strike2Display}}">{{strike2Display}}</span>
    <span class="ratioDisplay instrument-row-cell" hidden="{{!show-ratioDisplay}}">{{ratioDisplay}}</span>
    <span class="deltaDisplay instrument-row-cell" hidden="{{!show-deltaDisplay}}">{{deltaDisplay}}</span>
    <span class="crossDisplay instrument-row-cell" hidden="{{!show-crossDisplay}}">{{crossDisplay}}</span>
    <div id="mirrorElements">
        <div class="size buy instrument-row-cell" side="buy">
            <size-input-control 
                    type="text" 
                    side="buy" 
                    disabled="{{sizeEntryProhibited(instrument)}}" 
                    class="buy" 
                    maxlength=6 value="{{buySize}}" 
                    revert-value="{{buySize}}" 
                    order-price="{{buyPrice}}"
            ></size-input-control>
            <img on-click="onClickOrderCancel" class="cancel-buy" hidden="{{!displayCancelBuy}}" src="./assets/images/cancel.png" />
        </div>
        <vm-midprice-cell class="instrument-row-cell" options='{{priceCellOptions}}'></vm-midprice-cell>
<!--        <vm-ordersize-cell class="instrument-row-cell" options='{{sizeCellOptions}}'></vm-ordersize-cell>-->
        <div class="size sell instrument-row-cell" side="sell">
            <size-input-control 
                type="text" 
                side="sell" 
                disabled="{{sizeEntryProhibited(instrument)}}" 
                class="sell" 
                maxlength=6 
                value="{{sellSize}}" 
                revert-value="{{sellSize}}" 
                order-price="{{sellPrice}}"
            ></size-input-control>
            <img on-click="onClickOrderCancel" class="cancel-sell" hidden="{{!displayCancelSell}}" src="./assets/images/cancel.png" />
        </div>
    </div>
    <span class="priceBDisplay instrument-row-cell" hidden="{{!show-priceBDisplay}}">{{priceBDisplay}}</span>
    <div class="status" on-mouseenter="onMouseEnterStatusCell" on-mouseleave="onMouseLeaveStatusCell">
        <span class="buy-status">{{buyStatus}}</span>
        <span>{{statusSeparationText}}</span>
        <span class="sell-status">{{sellStatus}}</span>
    </div>
</div>`;
