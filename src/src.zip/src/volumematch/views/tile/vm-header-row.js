/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false, Polymer: false */


import {mixinBehaviors} from '@polymer/polymer/lib/legacy/class';
import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './vm-header-row.template';

const {view: context} = window.BGC.ui;

class VmHeaderRow extends mixinBehaviors([
  context.NotificationFlashBehavior
], PolymerElement) {
  static get template () {
    return componentTemplate;
  }

  static get properties () {
    return {
      pageLayout : {
        type : Object
      },
      tile : {
        type     : Object,
        observer : 'tileChanged'
      },
      initializing : {
        type  : Boolean,
        value : true
      },
      headerTitle : String,
      buyText     : String,
      sellText    : String,
      thirdParty  : String,
      tradeCount  : String,
      isActive    : {
        type     : Boolean,
        observer : '_isActiveChanged'
      },
      isEmpty : {
        type     : Boolean,
        observer : '_isEmptyChanged'
      }
    };
  }

  disconnectedCallback () {
    super.disconnectedCallback();
    this.detachFromTile();
  }


  attached () {
    this.attachToTile();
  }

  connectedCallback () {
    super.connectedCallback();
    _.extend(this, Backbone.Events);
    this.attachToTile();
  }

  ready () {
    super.read();
    this.resources = BGC.resources;
    this.attachTooltipMouseEvents($(this));
  }

  tileChanged () {
    this.detachFromTile();
    this.attachToTile();
  }

  _isActiveChanged () {
    this.toggleClass('is-active', this.isActive);
  }

  _isEmptyChanged () {
    this.toggleClass('is-empty', this.isEmpty);
  }

  attachToTile () {
    this.tile.on('change change:instruments change:sortOrder change:instrumentRemoved', this.synchronizeWithTile, this);
    this.tile.on('tileHasInterest', this.synchronizeWithTile, this);
    this.tile.on('instrumentTraded', this.synchronizeWithTile, this);
    this.tile.on('remove', this.tileRemoved, this);

    this.tile.auction.on('change:runningState', this.synchronizeWithTile, this);
    this.tile.auction.on('change:hiddenColumns', this.onChangeTileColumns, this);
    this.tile.auction.on('change:startTime change:endTime change:timeOffset change:auctionPhase  change:phaseoneEndtime', this.updateProgress, this);

    this.hasSyncedWithTileSinceAttached = false;
    this.onTileControlTransferredToNewAuction();
  }

  detachFromTile () {
    if (this.tile) {
      this.tile.off(null, null, this);
      this.tile.auction.off(null, null, this);
    }
  }

  tileRemoved () {
    this.detachFromTile();
    this.remove();
  }

  onTileControlTransferredToNewAuction () {
    if (this.auction) {
      this.auction.off(null, null, this);
    }
    this.auction = this.tile.auction;
    this.auction.on('change:runningState', this.synchronizeWithTile, this);
    this.auction.on('change:hiddenColumns', this.onChange, this);
    this.auction.on('change:startTime change:endTime change:timeOffset change:auctionPhase change:phaseoneEndtime', this.updateProgress, this);
    this.auction.on('change:showInterestAndTradeCount', this.showNotificationBadges, this);

    this.synchronizeWithTile();
    this.updateProgress();
  }

  updateProgress () {
    const progressBar = this.shadowRoot.$$('progress-bar');

    if (progressBar) {
      progressBar.setAttribute('start-time', this.auction.get('startTime'));
      progressBar.setAttribute('time-offset', this.auction.get('timeOffset'));
      progressBar.setAttribute('end-time', this.auction.get('endTime'));
      progressBar.setAttribute('auction-Phase', this.auction.get('auctionPhase'));
      progressBar.setAttribute('phaseoneend-time', this.auction.get('phaseoneEndtime'));
    }
  }

  synchronizeWithTile () {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }

    this.debounceTimer = window.setTimeout(() => {
      delete this.debounceTimer;

      if (!this.pageLayout) {
        this.pageLayout = this.tile.get('pageLayout');
        this.pageLayout.on('change:contentState', this.synchronizeWithTile, this);
        this.pageLayout.on('closeAllInstrumentViews', this.onCloseAll, this);
      }

      const isVmInProgress = this.pageLayout.areAnyInstrumentsInAuction();
      const interest = this.tile.getInterestCount();
      const interestText = interest ? interest.toString() : '';
      const tradeCount = this.tile.getTradeCount();
      const tradeCountText = tradeCount ? tradeCount.toString() : '';
      let gavelFlash = false;
      let permissibleGenericColumns;
      let layoutGenericColumns;
      let showColumn;

      this.headerTitle = this.tile.get('tileName');
      this.buyText = this.tile.getAdjustedNomenclature('IDS_BUY_SIZE');
      this.sellText = this.tile.getAdjustedNomenclature('IDS_SELL_SIZE');

      if (this.initializing) {
        // Hide all potential generic columns initially
        permissibleGenericColumns = this.pageLayout.get('permissibleGenericColumns');
        permissibleGenericColumns.forEach(function (columnId) {
          this[`show-${columnId}`] = false;
        }, this);

        this.onChangeTileColumns();
        this.initializing = false;
      }

      this.showNotificationBadges();

      if (this.thirdParty !== interestText) {
        this.thirdParty = interestText;

        this.tile.trigger('glowCountChanged');

        // Don't flash counts as the header row is created, only when they change
        if (interest && this.hasSyncedWithTileSinceAttached) {
          this.flashNotification(this.EFlashType.eThirdPartyInterest);
        }
      }

      this.isActive = this.tile.areAnyInstrumentsInAuction();
      this.isEmpty = !this.auction.get('runningState');

      if (this.tradeCount !== tradeCountText) {
        this.tradeCount = tradeCountText;

        this.tile.trigger('tradeCountChanged');

        // Don't flash counts as the header row is created, only when they change
        if (tradeCount && this.hasSyncedWithTileSinceAttached) {
          gavelFlash = true;
        }
      }

      if (gavelFlash) {
        this.flashNotification(this.EFlashType.eTradeCount);
      }

      this.hasSyncedWithTileSinceAttached = true;
    }, 200);
  }

  showNotificationBadges () {
    this.toggleClass('no-notifications', !this.tile.get('auction').get('showInterestAndTradeCount'));
  }

  onChangeTileColumns () {
    const layoutGenericColumns = this.pageLayout.get('genericColumns');
    const tileAuction = this.tile.auction;
    const auctionHiddenColumns = tileAuction.get('hiddenColumns');

    _.each(layoutGenericColumns, function (columnDefinition) {
      const showColumn = !this.tile.areAnyInstrumentsInAuction() ? false : !_.contains(auctionHiddenColumns, columnDefinition.columnId);

      this[`show-${columnDefinition.columnId}`] = showColumn;
      this[columnDefinition.columnId] = columnDefinition.columnName;
    }, this);
  }

  onCloseAll (exceptInstrument) {
    if (exceptInstrument) {
      if (this.tile && !this.tile.findInstrumentById(exceptInstrument.get('instrumentId'))) {
        this.closeTile();
      }
    } else {
      this.closeTile();
    }
  }

  closeTile () {
    if ($(this.shadowRoot).hasClass('is-open')) {
      $(this.shadowRoot).find('.collapse-toggle').click();
    }
  }
}
context.VmHeaderRow = VmHeaderRow;
customElements.define('vm-header-row', VmHeaderRow);