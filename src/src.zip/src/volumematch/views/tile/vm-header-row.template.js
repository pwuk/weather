import {html} from '@polymer/polymer/polymer-element';

export default html`
<style>
    :host.header-row {
        display: block;
        overflow: hidden;
        height: auto;
    }

    :host.header-row.is-empty {
        display: none;
    }

    :host.header-row > div {
       overflow: hidden;
        display: flex;
    }
    [hidden] {
        display: none !important;
    }
    .header-row {
        display: flex;
        color: var(--content-header-text);
        font-size: 1rem;
        height: 2rem;
        background-color: var(--content-header-background);
        border-bottom: 1px solid;
        border-color: var(--content-header-border);
    }
    .header-row .straddleDisplay,
    .header-row .ratioDisplay,
    .header-row .deltaDisplay,
    .header-row .strike1Display,
    .header-row .strike2Display,
    .header-row .crossDisplay,
    .header-row .volume,
    .header-row .size,
    .header-row .order-size,
    .header-row .price,
    .header-row .ratio,
    .header-row .priceBDisplay {
        display: block;
        float: left;
        height: 100%;
        width: 6rem;
        min-width: 6rem;
        line-height: 2rem;
        text-align: center;
        background-color: transparent;
        border-left: 1px solid;
        border-color: inherit;
    }
    .header-row .account-name {
        display: block;
        float: left;
        height: 100%;
        width: initial;
        min-width: initial;
        line-height: 2rem;
        text-align: center;
        background-color: transparent;
        border-left: 1px solid;
        border-color: inherit;
        flex: 1;
    }
    .header-row .status {
        display: block;
        float: left;
        height: 100%;
        width: 12rem;
        min-width: 12rem;
        line-height: 2rem;
        text-align: center;
        background-color: transparent;
        border-left: 1px solid;
        border-color: inherit;
        flex: 1;
    }
    .header-row .repost-all {
        display: block;
        float: left;
        height: 100%;
        width: 6rem;
        min-width: 6rem;
        line-height: 2rem;
        text-align: center;
        background-color: transparent;
        border-left: 1px solid;
        border-color: inherit;
        display: none;
    }
    .header-row .repost-all.showRepostall {
        display: inline;
    }
    .wide-status .header-row .status {
        width: 18rem;
    }
    .header-row .name {
        display: block;
        float: left;
        height: 100%;
        width: initial;
        min-width: initial;
        line-height: 2rem;
        text-align: center;
        background-color: transparent;
        border-left: 1px solid;
        border-color: inherit;
        border-left: none;
        flex: 1;
        min-width: 6rem;
    }
    .header-row .inner-name {
        display: block;
        float: left;
        height: 100%;
        width: initial;
        min-width: initial;
        line-height: 2rem;
        text-align: center;
        background-color: transparent;
        border-left: 1px solid;
        border-color: inherit;
        flex: 1;
    }
    .header-row .counterparty {
        display: block;
        float: left;
        height: 100%;
        width: initial;
        min-width: initial;
        line-height: 2rem;
        text-align: center;
        background-color: transparent;
        border-left: 1px solid;
        border-color: inherit;
        flex: 1;
    }

    .collapse-toggle {
        padding-top: 0;
        width: 2rem;
        height: 100%;
        border-right: 0px;
        transition: background 0.2s ease;
        align-items: center;
        position: relative;
        float: left;
    }

    .collapse-toggle:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }

    .collapse-toggle:active {
        background-color: rgba(255, 255, 255, 0.4);
    }

    .collapse-toggle:before {
        font-family: FontAwesome;
        content: "\\f105";
        width: 2rem;
        font-size: 1.4rem;
        font-weight: bold;
        display: block;
        padding-top: 0;
        padding-left: 0.5rem;
        text-align: center;
    }

    .collapsible-title {
        display: flex;
        align-items: center;
        padding: 0;
        margin: 0;
        padding-left: 0;
        font-size: 1rem;
        color: white;
        background-color: inherit;
        line-height: 1;
        height: 100%;
    }

    .is-active .collapsible-title > span {
        font-weight: bold;
    }

    .is-active .collapsible-title > span > span {
        padding-left: 0.4rem;
    }

    .is-active .collapsible-title {
        font-weight: bold;
        color: var(--header-active-text-color);
    }

    .is-open .collapse-toggle:before {
        font-family: FontAwesome;
        content: "\\f107";
        padding-top: 0;
    }

    .is-open .collapsible-title {
        display: none;
    }
    .header-row .collapse-toggle,
    .header-row .collapsible-title {
        display: none;
    }
    .header-row:not(.is-active) {
        display: none;
    }
    .collapsible.tile-view .header-row {
        height: 2rem;
        border-radius: 0.5rem 0.5rem 0 0;
    }
    .collapsible.tile-view .header-row,
    .tiles-column-layout .header-row {
        position: relative;
        background-image: none;
        background-color: var(--content-header-background);
    }
    .collapsible.tile-view .header-row.is-empty,
    .tiles-column-layout .header-row.is-empty {
        display: none;
    }
</style>
<progress-bar></progress-bar>
<div class="header-row ui-sortable-handle">
    <div class="collapse-toggle"></div>
    <div class="collapsible-title">
        <div class="notifications">
            <span class="third-party-badge">{{thirdParty}}</span>
            <span class="trade-count-badge">{{tradeCount}}</span>
        </div>
        <span>{{headerTitle}}</span>
    </div>
    <div class="name">
        <div class="notifications">
            <span class="third-party-badge">{{thirdParty}}</span>
            <span class="trade-count-badge">{{tradeCount}}</span>
        </div>
        <span>{{headerTitle}}</span>
    </div>
    <span class="volume" hidden="{{!show-volume}}">{{volume}}</span>
    <span class="strike1Display" hidden="{{!show-strike1Display}}">{{strike1Display}}</span>
    <span class="strike2Display" hidden="{{!show-strike2Display}}">{{strike2Display}}</span>
    <span class="straddleDisplay" hidden="{{!show-straddleDisplay}}">{{straddleDisplay}}</span>
    <span class="ratioDisplay" hidden="{{!show-ratioDisplay}}">{{ratioDisplay}}</span>
    <span class="deltaDisplay" hidden="{{!show-deltaDisplay}}">{{deltaDisplay}}</span>
    <span class="crossDisplay" hidden="{{!show-crossDisplay}}">{{crossDisplay}}</span>
    <span class="size">{{buyText}}</span>
    <span class="price">{{resources.IDS_PRICE}}</span>
    <span class="order-size">{{resources.IDS_MY_SIZE}}</span>
    <span class="size">{{sellText}}</span>
    <span class="priceBDisplay" hidden="{{!show-priceBDisplay}}">{{priceBDisplay}}</span>
    <div class="status">
        <span>{{resources.IDS_TRADE_STATUS}}</span>
    </div>
</div>
`;
