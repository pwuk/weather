/* global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false, Polymer: false */

import {PolymerElement} from '@polymer/polymer';
import {mixinBehaviors} from '@polymer/polymer/lib/legacy/class';
import componentTemplate from './vm-spread-instrumentrow.template';

const {view: context} = window.BGC.ui;

class VmSpreadInstrumentRow extends mixinBehaviors([
  context.VmTileRowBehavior
], PolymerElement) {
  static get template () {
    return componentTemplate;
  }

  constructor (options) {
    super();
    _.extend(this, Backbone.Events);

    this.classOptions = options;
    this.is = 'vm-vmtile-spread-instrument-row';
    this.tooltip = BGC.ui.tooltipSingleton.getInstance();
    this.firstCall = true;
  }

  ready() {
    super.ready();
    this.factoryImpl(this.classOptions);
  }
  onMouseEnterSpreadName (event) {
    const targetRect = event.target.getBoundingClientRect();
    const offset = this.showBuySize || this.showSellSize ? 50 : 45;

    this.tooltip.hide();
    this.tooltip.showKeyValueTooltip(this.buildToolTipPairs(), 'left', {x : targetRect.left, y : targetRect.top - offset});
  }

  onMouseLeaveSpreadName (event) {
    this.tooltip.hide(true);
  }

  render () {
    const wasVisible = this.isVisible;
    const instrumentModel = this.getInstrumentModel();
    const shouldBeVisible = this.shouldBeVisible();

    // Ensure the instrument has been serialised first in case we decide not to proceed
    // with the render operation further down but a listener is notified of an event some
    // time later and the data becomes needed.
    this.instrument = instrumentModel.serialize();

    if (this.isWaitingForFirstRender) {
      this.shadowRoot.querySelectorAll('size-input-control').forEach(sizeInput => {
        sizeInput.setValidationCallback(instrumentModel.validateSize.bind(instrumentModel));
      }, this);

      this.isWaitingForFirstRender = false;
    }

    // Swap the Sides (buy/sell) based on the selection of "swapBidAndOffer" setting
    this.shadowRoot.querySelector('#mirrorElements').classList.toggle('mirror', BGC.dataStore.userSettingsStore.get('swapBidAndOffer'));

    if (!shouldBeVisible) {
      this.setActive(false);

      return;
    }

    // read instrument attributes and retrieve order model to render (if any own order)
    let spread;
    let strikeA;
    let strikeB;
    const activeOrderModel = this.getOrderModel();
    const activeOrder = activeOrderModel && activeOrderModel.serialize();
    const buyOrder = activeOrder && activeOrder.buyOrder;
    const sellOrder = activeOrder && activeOrder.sellOrder;
    const lastBuySize = this.buySize || '';
    const lastSellSize = this.sellSize || '';
    let sizeCell;
    let hasSellSize;
    let hasBuySize;
    let sideClass;

    spread = this.getInstrumentModel().get('spread');
    this.priceDisplay1 = spread.getInstrument(0).get('priceDisplay');
    this.priceDisplay2 = spread.getInstrument(1).get('priceDisplay');
    this.ratioDisplay = spread.buildRatioString();
    strikeA = spread.getInstrument(0).get('strike1Display');
    strikeB = spread.getInstrument(1).get('strike1Display');
    this.nameA = spread.getInstrument(0).get('shortName');
    this.nameB = spread.getInstrument(1).get('shortName');
    this.fullNameA = `${this.nameA} ${strikeA}%`;
    this.fullNameB = `${this.nameB} ${strikeB}%`;
    this.spread = `${this.nameA} vs ${this.nameB}`;

    hasSellSize = sellOrder && sellOrder.hasSellSize;
    hasBuySize = buyOrder && buyOrder.hasBuySize;

    sideClass = hasBuySize ? 'spread-view-spread_buy' : hasSellSize ? 'spread-view-spread_sell' : undefined;
    const spreadName = this.shadowRoot.querySelector('.spread-view-spread');

    spreadName.classList.remove('spread-view-spread_buy', 'spread-view-spread_sell');
    if (sideClass) {
      spreadName.classList.add(sideClass);
    }

    this.priceCellOptions = {
      model      : this.getInstrumentModel(),
      order      : activeOrder || {dummy : true},
      row        : this,
      grid       : this.container,
      pageLayout : this.pageLayout
    };

    this.showBuySize = !!hasBuySize;
    this.showSellSize = !!hasSellSize;

    // order sizes should be coerced to string by + "", as they will be revert values of size cells
    this.buySize = `${hasBuySize ? buyOrder.buySize : ''}`;
    this.buyPrice = buyOrder ? buyOrder.price : this.instrument.midPrice;
    this.displayCancelBuy = !!(buyOrder && buyOrder.hasCancellableBuySize);
    this.sellSize = `${hasSellSize ? sellOrder.sellSize : ''}`;
    this.sellPrice = sellOrder ? sellOrder.price : this.instrument.midPrice;
    this.displayCancelSell = !!(sellOrder && sellOrder.hasCancellableSellSize);
    this.disableFavoriteIcon = !!(buyOrder || sellOrder);

    // For size input columns, we may have typed a size resulting in an order execution,
    // but if that whole size executed then the outstanding size (the revert value attribute for the cell)
    // will not have changed, and therefore the control won't call it's revert() method,
    // so the typed text will remain.
    // For that reason, if outstanding size han't changed, call revert directly just in case.
    if (lastBuySize === this.buySize) {
      sizeCell = this.shadowRoot.querySelector('.size input.buy');
      if (sizeCell) {
        sizeCell.revert();
      }
    }
    if (lastSellSize === this.sellSize) {
      sizeCell = this.shadowRoot.querySelector('.size input.sell');
      if (sizeCell) {
        sizeCell.revert();
      }
    }

    this.buyStatus = activeOrderModel ? activeOrderModel.buildStatusString('buy', true) : '';
    this.sellStatus = activeOrderModel ? activeOrderModel.buildStatusString('sell', true) : '';
    this.statusSeparationText = this.buyStatus && this.sellStatus ? ' / ' : '';

    // If row is destined to become visible and its auction is already running
    // then do the necessary to make it visible now and apply styling
    if (!wasVisible && shouldBeVisible) {
      this.evaluateAndSetVisibility();
    } else {
      // Must be visible already, so apply class styling, glows etc. per row
      this.applyClassStyles(this.instrument, activeOrder);
    }
  }

  shouldBeVisible () {
    return this.getInstrumentModel().isInAuction();
  }

  buildToolTipPairs () {
    return BGC.ui.viewUtils.buildSpreadToolTipPairs(this.fullNameA, this.fullNameB, this.priceDisplay1, this.priceDisplay2, this.ratioDisplay, this.buySize, this.sellSize, this.showBuySize, this.showSellSize);
  }

  applySpreadClassStyles (instrument, order) {
    this.$el.find('.price').addClass('spreadPrice');

    BGC.ui.viewUtils.applySameLEInterestGlows(instrument.hasSameLeBuyInterest, instrument.hasSameLeSellInterest, this.shadowRoot.querySelectorAll('.spread-view-spread, .spread-price-display'));

    // apply 'third party' interest glow to instrument cell (as well as price cell)
    BGC.ui.viewUtils.applyThirdPartyInterestGlows(instrument.showThirdPartyInterestGlows ? instrument.thirdPartyInterest : 'none', this.shadowRoot.querySelectorAll('.spread-view-spread, .spread-price-display'));

    if (instrument.spread.isSpreadWeightingCustom) {
      this.$el.find('.ratio').addClass('custom-ratio');
    }
  }

  setColumnsFromAuction () {
    // Spead instrument rows don't display generic columns
  }
}
context.VmSpreadInstrumentRow = VmSpreadInstrumentRow;
customElements.define('vm-vmtile-spread-instrument-row', VmSpreadInstrumentRow);
