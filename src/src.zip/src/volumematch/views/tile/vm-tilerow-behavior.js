/* eslint max-lines: off */
// eslint-disable-next-line max-len
/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global BGC: false, $: false, _:false, Backbone: false, Polymer: false  */

import {dom} from '@polymer/polymer/lib/legacy/polymer.dom';
import {isWebDeployed} from '../../bgc';

// eslint-disable-next-line func-names,no-shadow-restricted-names
(function (context, undefined) {
  const {KeyCodes} = BGC.utils;

  /**
     * Behaviour that is shared by standard and spread instrument row components.
     */
  // eslint-disable-next-line no-param-reassign
  context.VmTileRowBehavior = {
    listeners : {
      tap                 : 'onClickRow',
      mousedown           : 'onMouseDown',
      dragstart           : 'onDragStart',
      SubmitValidatedSize : 'handleSubmitOrderEvent'
    },

    properties : {
      isFiltered : {
        type  : Boolean,
        value : false
      },
      isVisible : {
        type  : Boolean,
        value : false
      },
      isLockRow : {
        type               : Boolean,
        reflectToAttribute : true,
        value              : false
      }
    },

    factoryImpl (options) {
      this.$el = $(this.shadowRoot);

      // an instrument model
      this.model = options.model;
      this.auction = this.model.get('auction');
      this.pageLayout = options.pageLayout;
      this.tileModel = options.tileModel;

      // the container component that contains this row
      this.container = options.container;
      this.isSelected = false;
      this.visibleGenericColumnIds = [];
      if (!this.tileModel) {
        throw new TypeError('TileRow attached with undefined tile model!');
      }

      this.initialize();
    },

    disconnectedCallback () {
      this.clearStatusTooltip();
    },

    storeInputCellState () {
      this.focusedInputInfo = undefined;
      const focusedCellInput = this.$el.find(':focus');

      if (focusedCellInput.length > 0) {
        this.focusedInputInfo = {
          inputEdit      : focusedCellInput,
          text           : focusedCellInput.val(),
          selectionStart : focusedCellInput[0].selectionStart,
          selectionEnd   : focusedCellInput[0].selectionEnd
        };
      }
    },

    restoreInputCellState () {
      if (this.focusedInputInfo !== undefined) {
        this.focusedInputInfo.inputEdit.val(this.focusedInputInfo.text);
        this.focusedInputInfo.inputEdit.focus();
        this.focusedInputInfo.inputEdit[0].setSelectionRange(this.focusedInputInfo.selectionStart, this.focusedInputInfo.selectionEnd);
        this.focusedInputInfo = undefined;
      }
    },

    // eslint-disable-next-line max-statements
    initialize () {
      _.extend(this, Backbone.Events);
      _.extend(this, context.NotificationFlashBehavior);

      this.tooltip = BGC.ui.tooltipSingleton.getInstance();

      // listen for instrument change and remove events
      this.listenTo(this.model, 'change', this.instrumentChanged);
      this.listenTo(this.model, 'change:volume', this.flashNewVolume);
      this.listenTo(this.model, 'remove', this.removeFromDOM);
      this.listenTo(this.model, 'requestSelection', this.onRequestSelection);
      this.listenTo(this.model, 'change:newPrice', this.midPriceChanged);

      // Initialize favorite icon state
      // eslint-disable-next-line max-len
      this.displayFavoriteIcon = this.model.get('canUserEnterOrders') && BGC.dataStore.userSettingsStore.get('displayFavorites') && !this.tileModel.get('excludeFromFavorites');
      this.nameWithFavoriteIcon = this.displayFavoriteIcon ? '' : 'name-flex';


      this.favoriteIconState = this.model.get('footprint') ? 1 : 0;
      // eslint-disable-next-line func-names
      this.listenTo(this.model, 'change:footprint', function (instrument) {
        this.favoriteIconState = instrument.get('footprint') ? 1 : 0;
      });

      this.listenTo(this.tileModel.auction, 'change:runningState', this.handleTileAuctionStarted, this);
      this.listenTo(BGC.dataStore.userSettingsStore, 'change:swapBidAndOffer', this.requestRender);

      // Filtering changes
      this.listenTo(this.pageLayout, 'change:brokerLiveMode change:traderLiveMode', this.applyLiveModeFiltering);

      // and changes in display style (if this isn't a spread row, which only works in wide layout mode)
      if (this.is !== 'vmtile-spread-instrument-row') {
        this.listenTo(BGC.dataStore.userSettingsStore, 'change:VmTileViewsUseCompactLayout', this.requestRender);
      }

      // Ensure the instrument has been serialised first in case we decide not to proceed
      // with the render operation further down but a listener is notified of an event some
      // time later and the data becomes needed.
      this.instrument = this.getInstrumentModel().serialize();
      this.isWaitingForFirstRender = true;
      this.requestRender();
    },

    getInstrumentModel () {
      return this.model;
    },

    getOrderModel () {
      return this.getInstrumentModel().getActiveOrder();
    },

    getTileModel () {
      return this.tileModel;
    },

    getInstrumentName () {
      return this.getInstrumentModel().get('name');
    },

    getContainer () {
      return this.container;
    },

    requestRender () {
      if (this.isWaitingForFirstRender) {
        // We need to render immediately so our content also gets created and
        // can attach listeners to the model before any further events occur
        this.render();
      } else {
        BGC.ui.viewUtils.requestRender(this.getInstrumentModel().get('instrumentId'), 'tileRow', this, this.render);
      }
    },

    instrumentChanged () {
      this.clearStatusTooltip();

      // If the instrument's auction ID has changed, we need to change what auction we are listening to
      if (this.getInstrumentModel().get('auction') !== this.auction) {
        this.instrumentAuctionChanged();
      }

      // If the instrument has changed because we have added an order to it
      // then calling syncWithActiveOrder() will set up the necessary listeners
      // and do the rendering. Otherwise, we trigger the rendering manually.

      if (!this.syncWithActiveOrder()) {
        this.requestRender();
      }

      if (this.getInstrumentModel().get('inactive')) {
        this.cleanupOEB();
      }
    },

    instrumentAuctionChanged () {
      if (this.auction) {
        this.stopListening(this.auction, 'change:runningState', this.onInstrumentAuctionRunningStateChanged);
      }
      this.auction = this.getInstrumentModel().get('auction');
      this.listenTo(this.auction, 'change:runningState', this.onInstrumentAuctionRunningStateChanged);
    },

    onInstrumentAuctionRunningStateChanged () {
      if (this.auction.get('runningState')) {
        this.applyClassStyles();
      }
    },

    flashNewVolume (model, newValue) {
      if (BGC.utils.compareFPNumGT(newValue, 0)) {
        this.flashNotification(this.EFlashType.eVolume, this.$el.find('.volume'), false);
      }
    },

    midPriceChanged (model, isNewMidPrice) {
      if (isNewMidPrice) {
        const midPriceElement = $(this.$el.find('vm-midprice-cell')[0].shadowRoot).find('.mid-price');

        this.flashNotification(this.EFlashType.eNewPrice, midPriceElement, false);
      }
    },

    evaluateAndSetVisibility () {
      const rowWasVisible = this.isVisible;
      const rowShouldBeVisible = this.shouldBeVisible();

      if (rowWasVisible !== rowShouldBeVisible) {
        if (rowShouldBeVisible) {
          this.setActive(true);

          if (this.container.isVisible) {
            // This row went active after the auction start message was received,
            // or because it is in a subsequent auction launced in the same tile as a running auction,
            // so it can't rely on the tile activation to request window size reevaluation
            this.$el.trigger('recalcLayout', {centreOnApp : true});
          }
        } else {
          // It would be nice to only make rows invisible when their tile has been deactivated
          // This way, they switch state once their container has been removed from the DOM,
          // which reduces vastly the amount of reflow/layout calc the browser has to do.
          // Unfortunately, an instrument can drop out of auction (e.g. TC) whilst other instruments do not,
          // so we have to let each row hide itself as and when it wants to.
          this.setActive(false);
          this.$el.trigger('recalcLayout', {centreOnApp : true});
        }
      }
    },

    handleTileAuctionStarted () {
      // For proper auctions instruments will be asked to set their visibility by the tile view
      // when the tile running state changes (allowing a big bang approach on the auction start event).
      if (this.model.get('isMidPriceIndicative')) {
        this.evaluateAndSetVisibility();
      }
    },

    handleTileColumnsChanged () {
      if (this.tileModel.auction.get('runningState') && this.isVisible) {
        this.setColumnsFromAuction();
      }
    },

    handleSubmitOrderEvent (event) {
      event.stopPropagation();

      let priceToSubmit = null;
      let eventDetail = null;

      if (event.type === 'SubmitValidatedPriceAndSize') {
        priceToSubmit = event.detail.price;
      } else {
        priceToSubmit = this.getInstrumentModel().get('midPrice');
        if (this.getInstrumentModel().isSignFlippedForPickGive(event.detail.side)) {
          priceToSubmit = -priceToSubmit;
        }
      }

      eventDetail = {
        eventSource  : 'Tile Instrument Row',
        instrumentId : this.getInstrumentModel().get('instrumentId'),
        price        : priceToSubmit,
        size         : event.detail.size,
        side         : event.detail.side
      };

      // trigger submission of an order in response to size entry
      this.dispatchEvent(new CustomEvent('submitOrder', {detail : eventDetail, bubbles : true, composed : true}));
      event.target.blur();
    },

    setColumnsFromAuction () {
      const layoutGenericColumns = this.pageLayout.get('genericColumns');
      const tileAuction = this.tileModel.auction;
      const auctionHiddenColumns = tileAuction.get('hiddenColumns');

      this.visibleGenericColumnIds = [];

      // eslint-disable-next-line func-names
      _.each(layoutGenericColumns, function (columnDefinition) {
        // Set column visibility from the dominant auction for this tile, so all rows have same columns
        // When indicative "auction" holds sway, no generic columns are shown
        const showColumn = !_.contains(auctionHiddenColumns, columnDefinition.columnId);

        this[`show-${columnDefinition.columnId}`] = showColumn;
        if (showColumn) {
          this.visibleGenericColumnIds.push(columnDefinition.columnId);
          this[columnDefinition.columnId] = this.instrument[columnDefinition.columnId];
        }
      }, this);
    },

    setActive (active) {
      if (active) {
        if (!this.isVisible) {
          BGC.logger.logInformation('VmTileRowBehavior', `Setting row for instrument ${this.getInstrumentModel().getLogDescStr()} visible`);
        }
        this.isVisible = true;
        this.applyClassStyles();
      } else {
        if (this.isVisible) {
          BGC.logger.logInformation('VmTileRowBehavior', `Setting row for instrument ${this.getInstrumentModel().getLogDescStr()} hidden`);
        }
        this.isVisible = false;
        this.isFiltered = true;
        this.buyStatus = '';
        this.sellStatus = '';
        this.statusSeparationText = '';
        this.setRowClassString();
      }
    },

    removeFromDOM () {
      this.clearStatusTooltip();
      this.cleanupOEB();
      this.stopListening();
      this.container.deleteContentRow(this);
      if (this.isVisible) {
        this.isVisible = false;
        this.$el.trigger('recalcLayout', {composed : true});
      }
    },

    cleanupOEB () {
      const model = this.getInstrumentModel();
      const inplaceOEB = context.inplaceOEB.getInstance();

      if (inplaceOEB.isOpen && inplaceOEB.getInstrumentId() === model.get('instrumentId')) {
        inplaceOEB.hide();
      }
    },

    syncWithActiveOrder () {
      const myOrderInCurrentContext = this.getOrderModel();

      if (this.myOrderInCurrentContext !== myOrderInCurrentContext) {
        if (this.myOrderInCurrentContext) {
          this.stopListening(this.myOrderInCurrentContext);
        }

        if (myOrderInCurrentContext) {
          this.listenTo(myOrderInCurrentContext, 'change', this.requestRender);
        }

        this.myOrderInCurrentContext = myOrderInCurrentContext;
        this.requestRender();

        // we did stuff and re-rendered
        return true;
      }

      // no rendering occurred
      return false;
    },

    sizeEntryProhibited () {
      return !this.getInstrumentModel().canEnterSize();
    },

    // eslint-disable-next-line complexity,max-statements
    applyClassStyles (instrument, order) {
      const $row = $(this.$.instrumentRow);
      const priceCell = this.$.instrumentRow.querySelector('vm-midprice-cell');
      let activeOrder = null;

      if (!instrument) {
        // eslint-disable-next-line no-param-reassign
        instrument = this.getInstrumentModel().serialize();
      }

      if (!order) {
        activeOrder = this.getOrderModel();
        // eslint-disable-next-line no-param-reassign
        order = activeOrder ? activeOrder.serialize() : undefined;
      }

      this.setRowClassString(instrument, order);
      if (priceCell) {
        priceCell.applyClassStyles(instrument);
      }

      // Show gavel on name cell if gavels are enabled and the instrument traded
      this.showNameGavel = !!(!instrument.inactive && instrument.showTradeIndicators && instrument.hasTradedInAuction);

      // allow brokers to request trade confirm by clicking gavel icon
      $row.find('.name .gavel').toggleClass('trade-confirm-request', !!(this.showNameGavel && instrument.supportTradeConfirmRequest));

      // apply 'same le' interest glow to price and instrument cells
      BGC.ui.viewUtils.applySameLEInterestGlows(
        instrument.hasSameLeBuyInterest,
        instrument.hasSameLeSellInterest,
        this.shadowRoot.querySelectorAll('vm-midprice-cell, div.tile-instrument-row > .name')
      );

      // apply 'third party' interest glow to price and instrument cells
      BGC.ui.viewUtils.applyThirdPartyInterestGlows(
        instrument.showThirdPartyInterestGlows ? instrument.thirdPartyInterest : 'none',
        this.shadowRoot.querySelectorAll('vm-midprice-cell, div.tile-instrument-row > .name')
      );

      // If we are a spread instrument row, do additional cell glowing etc.
      if (this.applySpreadClassStyles) {
        this.applySpreadClassStyles(instrument, activeOrder);
      }

      // apply classes used for row filtering
      this.applyLiveModeFiltering();

      // force disable size entry input controls when user is disallowed from entering orders
      // $row.find(".size input").attr("disabled", !this.getInstrumentModel().canEnterSize());
      $row.find('.size size-input-control')
        .each(
          (_, {inputField}) => $(inputField).attr('disabled', !this.getInstrumentModel().canEnterSize())
        );

      // allow brokers to request trade confirm by clicking gavel icon in price cell
      if (this.getInstrumentModel().canRequestTradeConfirms()) {
        // $row.find('.mid-price .gavel').addClass('trade-confirm-request');
        $($row.find('vm-midprice-cell')[0].shadowRoot).find('.gavel').addClass('trade-confirm-request');
      }
    },

    // eslint-disable-next-line complexity,max-statements
    setRowClassString (instrument, order) {
      const rowClasses = ['tile-instrument-row', 'style-scope', 'vm-tile-instrument-row'];
      let activeOrder = null;

      if (!instrument) {
        // eslint-disable-next-line no-param-reassign
        instrument = this.getInstrumentModel().serialize();
      }

      if (!order) {
        activeOrder = this.getOrderModel();
        // eslint-disable-next-line no-param-reassign
        order = activeOrder ? activeOrder.serialize() : undefined;
      }

      if (!this.isVisible) {
        this.classList.remove('is-visible');
      }

      if (!instrument.inactive && this.isVisible && !this.isFiltered) {
        // apply active row styles
        if (order) {
          // apply 'executed order' style
          if (order.hasBoughtSize || order.hasSoldSize) {
            rowClasses.push('executed');
          }

          // apply 'blotter published by Excel' style
          if (order.wasBuyPublishedByExcel) {
            rowClasses.push('buy-blotter-published-by-excel');
          }
          if (order.wasSellPublishedByExcel) {
            rowClasses.push('sell-blotter-published-by-excel');
          }
        }

        if (this.isSelected) {
          rowClasses.push('selected');
        }
        this.shadowRoot.querySelector('vm-midprice-cell')
          .classList.toggle('selected', this.isSelected);
      }

      this.rowClassString = rowClasses.join(' ');

      if (this.isVisible) {
        if (this.isFiltered) {
          this.classList.add('is-visible', 'is-filtered');
        } else {
          this.classList.remove('is-filtered');
          this.classList.add('is-visible');
        }
      }
    },

    // apply 'mine', 'gavel', 'glow' classes for potential filtering
    // eslint-disable-next-line complexity
    applyLiveModeFiltering () {
      const wasFiltered = this.isFiltered;
      let notFiltered = false;
      const liveMode = this.pageLayout.getLiveModeForActiveUser();
      const instrument = this.getInstrumentModel().serialize();

      // Always display traded rows
      if (instrument.hasTradedAtMidPrice || instrument.hasTradedInAuction) {
        this.isFiltered = false;
      } else {
        // eslint-disable-next-line default-case
        switch (liveMode) {
          case BGC.enums.EVMShowLiveMode.eShowAll:
            this.isFiltered = false;
            break;
          case BGC.enums.EVMShowLiveMode.eShowMyOrdersAndGlows:
            // Glows
            notFiltered = (instrument.showThirdPartyInterestGlows && instrument.thirdPartyInterest !== 'none') || !!instrument.sameLEInterest;

          // Drop through for my orders
          // eslint-disable-next-line no-fallthrough
          case BGC.enums.EVMShowLiveMode.eShowMyOrdersOnly:
            notFiltered = notFiltered || !!instrument.ownOrder;
            this.isFiltered = !notFiltered && !instrument.isLockInstrument;
            break;
        }
      }

      if (wasFiltered !== this.isFiltered) {
        this.classList.toggle('is-filtered', this.isFiltered);
        BGC.logger.logInformation('VmTileRowBehavior',
          BGC.utils.format('Live mode filtering set to {0} row for instrument {1}',
            [this.isFiltered ? 'HIDE' : 'SHOW', this.getInstrumentModel().getLogDescStr()]));
        if (this.isVisible) {
          this.$el.trigger('recalcLayout', {composed : true});
        }
      }
    },

    findNextVisibleRowVertically (direction) {
      const nextRow = direction === KeyCodes.UP ? this.previousElementSibling : this.nextElementSibling;

      // If there isn't a next row or its instrument is on a different tile, give up
      if (!nextRow || nextRow.tileModel !== this.tileModel) {
        return null;
      }

      if (!$(nextRow).is(':visible')) {
        return nextRow.findNextVisibleRowVertically(direction);
      }

      return nextRow;
    },

    // eslint-disable-next-line max-statements
    findNextVisibleRowHorizontally (direction) {
      const thisColumn = this.closest('.column');
      let thisRowIndex = -1;
      const nextColumn = thisColumn && (direction === KeyCodes.LEFT ? thisColumn.previousElementSibling : thisColumn.nextElementSibling);
      let $thisColumnsRows = null;
      let $nextColumnsRows = null;
      let nextRow = null;
      let alternativeNextRow = null;

      // const instModel = this.getInstrumentModel();
      // const spreadModel = instModel.get('spread');
      // const instType = spreadModel ? 'Spread' : 'Outright';

      // If there isn't a next column, give up
      if (!nextColumn) {
        return null;
      }

      // Try and land on a row that occupies the same vertical space as this one
      $thisColumnsRows = $(thisColumn).find('> *');
      thisRowIndex = $thisColumnsRows.index(this);

      $nextColumnsRows = $(nextColumn).find('> *');
      nextRow = $nextColumnsRows.get(thisRowIndex);

      if (nextRow) {
        if (!$(nextRow).is(':visible')) {
          alternativeNextRow = nextRow.findNextVisibleRowVertically(KeyCodes.UP);
          nextRow = alternativeNextRow || nextRow.findNextVisibleRowVertically(KeyCodes.DOWN);
        }
      } else {
        nextRow = $nextColumnsRows[$nextColumnsRows.length - 1];
      }

      return nextRow;
    },

    onMouseDown () {
      const instModel = this.getInstrumentModel();
      const spreadModel = instModel.get('spread');
      const instType = spreadModel ? 'Spread' : 'Outright';
      const instName = instModel.getLogDescStr();

      // If the row isn't already selected (and it will be if the click was on the mid-price cell),
      // then the row should start QoS timing for user interaction such as price entry
      if (!this.getInstrumentModel().get('inactive') && !this.isSelected) {
        BGC.utils.startInteractivityQoSTimer('instrumentClick', instType, instName);
      }
    },

    onClickRow () {
      if (this.getInstrumentModel().get('inactive')) {
        return;
      }

      BGC.ui.viewUtils.setSelectionLockedFlag(this, true);
      this.selectRow();
    },

    onClickOrderCancel (event) {
      const target = $(event.target);

      BGC.ui.viewUtils.cancelOrder(this.getInstrumentModel(), 'ActiveOrders', $(target).hasClass('cancel-buy') ? 'buy' : 'sell');
    },

    onKeyDownInput (event) {
      const target = Polymer.dom(event).rootTarget;
      const $inputCell = $(target);
      const size = $inputCell.val();
      const side = $(target).hasClass('buy') ? 'buy' : 'sell';

      // eslint-disable-next-line default-case
      switch (event.keyCode) {
        case KeyCodes.ENTER:
          // remove focus from input cell and prevent event from bubbling up to parent
          $(target).blur();
          event.stopPropagation();

          // validate size and submit order
          BGC.ui.viewUtils.submitOrder(this.getInstrumentModel(), {size, side}, 'ActiveOrders');
          break;
        case KeyCodes.ESC:
          $(event.target).blur();
          break;
      }
    },

    onBlurInput (event) {
      this.revertSizeInputCell($(Polymer.dom(event).rootTarget));
    },

    onClickInput (event) {
      if (!this.isSelected) {
        // select row and lock selection to this row
        this.onClickRow();
      }

      $(dom(event).rootTarget).select();
    },

    onFocusInput (event) {
      const $inputCell = $(Polymer.dom(event).rootTarget);
      const side = $inputCell.hasClass('buy') ? 'buy' : 'sell';

      if (!this.isSelected) {
        // select row and lock selection to this row
        this.onClickRow();
      }

      // store existing input value
      $inputCell.data('original-value', $inputCell.val());

      // hide cancel icon
      if (side === 'buy') {
        this.displayCancelBuy = false;
      } else {
        this.displayCancelSell = false;
      }
    },

    revertSizeInputCell ($inputCell) {
      const side = $inputCell.hasClass('buy') ? 'buy' : 'sell';
      const orderModel = this.getOrderModel();
      const order = orderModel && orderModel.serialize();
      // eslint-disable-next-line no-nested-ternary
      const size = order ? side === 'buy' ? order.buySize : order.sellSize : 0;
      const revertSize = order && (size > 0) ? size : '';

      // show cancel icon if there was order size before
      if (revertSize) {
        if (side === 'buy') {
          this.displayCancelBuy = order.hasCancellableBuySize;
        } else {
          this.displayCancelSell = order.hasCancellableSellSize;
        }
      } else if (side === 'buy') {
        this.displayCancelBuy = false;
      } else {
        this.displayCancelSell = false;
      }

      // revert order size
      $inputCell.val(revertSize);
    },

    clearSelection () {
      this.$.instrumentRow.classList.remove('selected');
      this.$.mirrorElements.querySelector('vm-midprice-cell').classList.remove('selected');
      this.isSelected = false;
    },

    // eslint-disable-next-line max-statements
    selectRow (openOEB) {
      const that = this;

      // only allow an instrument row (in the tile view) to be selected
      if (this.isSelected) {
        return;
      }

      if (BGC.ui.view.spreadView && BGC.ui.view.spreadView.isPopulated()) {
        BGC.ui.viewUtils.infoPopup.popup('show', {
          modal                 : true,
          draggable             : true,
          title                 : BGC.resources.IDS_SPREADS_BAR_ACTIVE,
          message               : BGC.resources.IDS_MSG_CLEAR_SPREADS_BAR,
          hasHeaderCloseButton  : false,
          hasCancelButton       : true,
          isWarning             : true,
          isError               : false,
          buttonSectionText     : '',
          cssClass              : 'popupDialog ui-dialog',
          restrictHeavyPainting : !isWebDeployed,
          cmdConfirmText        : BGC.resources.IDS_YES,
          cmdCancelText         : BGC.resources.IDS_NO,
          confirm () {
            // Clear the spreads bar
            BGC.ui.view.spreadView.$el.trigger('collapseOrderEntry');

            // Recurse
            that.selectRow(openOEB);
          }
        });

        return;
      }

      // Hide the OEB wherever it was before
      const inPlaceOrderEntry = context.inplaceOEB.getInstance();

      if (inPlaceOrderEntry.isOpen) {
        inPlaceOrderEntry.hide();
      }

      // select row
      this.$.instrumentRow.classList.add('selected');
      this.$.mirrorElements.querySelector('vm-midprice-cell').classList.add('selected');
      this.isSelected = true;
      this.getContainer().selectedRow = this;

      // request change global in instrument selection
      this.dispatchEvent(new CustomEvent('selectInstrument', {
        bubbles  : true,
        composed : true,
        detail   : {
          view       : this,
          instrument : this.model
        }
      }));

      // and listen for de-selection event
      this.listenToOnce(BGC.ui.selectionManager, 'selectionChanging', this.clearSelection.bind(this));

      if (openOEB) {
        this.openOEBPopup();
      }
    },

    openOEBPopup (side) {
      const midPriceCell = this.$$('vm-midprice-cell');

      if (midPriceCell) {
        midPriceCell.openOEBPopup(side);
      }
    },

    onDragStart (event) {
      event.preventDefault();
    },

    onMouseEnterStatusCell (event) {
      this.clearStatusHoverTimer();
      if (event.target.textContent.trim()) {
        // eslint-disable-next-line no-magic-numbers
        this.statusHoverTimer = setTimeout(this.onHoverStatusCellTimer.bind(this, event), 1000);
      }
    },

    onMouseLeaveStatusCell () {
      this.clearStatusHoverTimer();
      this.tooltip.hide();
    },

    clearStatusHoverTimer () {
      if (this.statusHoverTimer) {
        clearTimeout(this.statusHoverTimer);
        this.statusHoverTimeout = null;
      }
    },

    onHoverStatusCellTimer (event) {
      // Event may have bubbled from target which is one of multiple spans inside the status cell
      // but we want the text of the whole status, so ignore event.target and find it directly
      const statusCell = this.$el.find('.status')[0];
      const tipText = statusCell.textContent.trim();
      const position = {
        // eslint-disable-next-line id-length
        x : event.pageX,
        // eslint-disable-next-line id-length,no-magic-numbers
        y : $(statusCell).offset().top + 2
      };

      this.statusHoverTimer = null;
      this.tooltip.hide();
      if (tipText) {
        this.tooltip.show(tipText, position);
        this.isShowingStatusTooltip = true;
      }
    },

    clearStatusTooltip () {
      if (this.isShowingStatusTooltip) {
        this.tooltip.hide();
      }
    },

    onClickFavoriteIcon (event) {
      if (this.model.hasOwnOrder()) {
        // Prevent registration of a favorite footprint when the user has an order

      } else {
        // If the favorite icon is being 'checked', register the new footprint, otherwise remove it
        // eslint-disable-next-line no-lonely-if
        if (event.currentTarget.state) {
          BGC.dataStore.footprints.add(new BGC.dataStore.modelDefinitions.Footprint({}, {instrument : this.model}));
        } else {
          BGC.dataStore.footprints.remove(this.model.get('footprint'));
        }
      }
    },

    onGavelClick (event) {
      const that = this;

      if (this.getInstrumentModel().canRequestTradeConfirms()) {
        BGC.ui.viewUtils.infoPopup.popup('show', {
          modal                : true,
          draggable            : true,
          title                : BGC.resources.IDS_PRINT_CONFIRMS,
          message              : BGC.utils.format(BGC.resources.IDS_MSG_PRINT_CONFIRMS_PROMPT, [this.getInstrumentName()]),
          hasHeaderCloseButton : false,
          hasCancelButton      : true,
          isWarning            : false,
          isError              : false,
          buttonSectionText    : '',
          cssClass             : 'popupDialog ui-dialog',
          cmdConfirmText       : BGC.resources.IDS_YES,
          cmdCancelText        : BGC.resources.IDS_NO,
          confirm () {
            // Request Trade confirms
            that.model.requestTradeConfirms('ActiveOrders');
          }
        });
        event.stopPropagation();
      }
    },

    onGavelMouseEnter (event) {
      // const normalizedEvent = dom(event);
      const target = dom(event).rootTarget;
      let targetRect = null;
      let targetRectWidth = null;
      let targetRectHeight = null;

      if (this.getInstrumentModel().canRequestTradeConfirms()) {
        targetRect = target.getBoundingClientRect();
        targetRectWidth = targetRect.right - targetRect.left;
        targetRectHeight = targetRect.bottom - targetRect.top;

        this.tooltip.show(BGC.resources.IDS_PRINT_CONFIRMS_TOOLTIP, {
          // eslint-disable-next-line id-length,no-magic-numbers
          x : targetRect.left + targetRectWidth / 2,
          // eslint-disable-next-line no-magic-numbers,id-length
          y : targetRect.top + targetRectHeight / 2
        }, this);
      }
    },

    onGavelMouseLeave () {
      if (this.getInstrumentModel().canRequestTradeConfirms()) {
        this.tooltip.hide(true);
      }
    },

    onRequestSelection (suppressActivation) {
      if (this.pageLayout.get('isLayoutRecalcPending')) {
        // eslint-disable-next-line func-names
        this.pageLayout.once('change:isLayoutRecalcPending', function () {
          // eslint-disable-next-line no-magic-numbers
          window.setTimeout(this.doRequestSelection.bind(this, suppressActivation), 200);
        }, this);
      } else {
        this.doRequestSelection(suppressActivation);
      }
    },

    doRequestSelection (suppressActivation) {
      if (!this.isVisible) {
        return;
      }

      // Filtering could be on or tile could be deliberately closed
      if (!$(this).is(':visible')) {
        this.container.openTile(this.model.get('tileId'));
      }

      BGC.ui.viewUtils.setSelectionLockedFlag(this, true);

      this.selectRow();

      if (!suppressActivation) {
        this.scrollToRow();
      }
    },

    scrollToRow () {
      // attempt to scroll to the instrument row after the recalclayout which invalidates the current scroll position.
      if (this.pageLayout.get('isLayoutRecalcPending')) {
        // eslint-disable-next-line func-names
        this.pageLayout.once('change:isLayoutRecalcPending', function () {
          window.setTimeout(() => {
            if (this.isVisible) {
              this.$el[0].scrollIntoView();
            }
            // eslint-disable-next-line no-magic-numbers
          }, 200);
        }, this);
      } else {
        this.$el[0].scrollIntoView();
      }
    }
  };
}(window.BGC.ui.view));
