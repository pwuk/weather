/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */


(function (context, undefined) {
    "use strict";

    var callbacksList = [],
        flashTimer = setInterval(function () {
            callbacksList.forEach(function (callbackDetails, detailsIndex) {
                if (callbackDetails) {
                    callbackDetails.callbackFn.call(callbackDetails.context, detailsIndex);
                } else {
                    callbacksList.splice(detailsIndex, 1);
                }
            });
        }, 500);

    context.NotificationFlashBehavior = {
        EFlashType: {
        	eThirdPartyInterest: 0,
			eTradeCount: 1,
			eMyTradeCount: 2,
			eMyOrderCount: 3,
			eNewPrice: 4,
			eVolume: 5,
            eInstrumentCount: 6
        },
        
        flashNotification: function (flashType, elementsToFlash, isFlashIndefinite) {
            var elements, flashId;

            if (flashType === context.NotificationFlashBehavior.EFlashType.eThirdPartyInterest) {
                elements = elementsToFlash || $(this).find(".third-party-badge");
            } else if (flashType === context.NotificationFlashBehavior.EFlashType.eTradeCount) {
                elements = elementsToFlash || $(this).find(".trade-count-badge");
            } else if (flashType === context.NotificationFlashBehavior.EFlashType.eMyTradeCount) {
                elements = elementsToFlash || $(this).find(".my-trade-count-badge");
            } else if (flashType === context.NotificationFlashBehavior.EFlashType.eMyOrderCount) {
                elements = elementsToFlash || $(this).find(".my-order-count-badge");
            } else if (flashType === context.NotificationFlashBehavior.EFlashType.eNewPrice) {
				elements = elementsToFlash || $(this).find(".mid-price");
			} else if (flashType === context.NotificationFlashBehavior.EFlashType.eVolume) {
				elements = elementsToFlash || this.$el.find(".volume");
			} else if (flashType === context.NotificationFlashBehavior.EFlashType.eInstrumentCount) {
			    elements = elementsToFlash || this.$el.find(".instrument-count-badge");
			}
	
            if (!isFlashIndefinite || (isFlashIndefinite && this._findInfiniteFlashIndex(flashType, elements) === -1)) {
                this.startFlashing(flashType, elements, isFlashIndefinite);
            }
		},

        startFlashing: function (flashType, elements, isFlashIndefinite) {
            callbacksList.push({
                context: this,
                callbackFn: this.flashCallback,
                flashType: flashType,
                elements: elements,
                numberOfFlashes: isFlashIndefinite ? -1 : 6
            });
		},

        _stopFlashing: function (callbacksListIndex) {
            var callbackDetails = callbacksList[callbacksListIndex];

            if (callbackDetails) {
                callbackDetails.elements.removeClass("flash-500ms");
                callbacksList[callbacksListIndex] = null;
            }
        },

        stopFlashing: function (flashType, elements) {
            var callbacksListIndex = this._findInfiniteFlashIndex(flashType, elements);

            if (callbacksListIndex !== -1) {
                this._stopFlashing(callbacksListIndex);
            }
        },

        _findInfiniteFlashIndex: function (flashType, elements) {
            return callbacksList.findIndex(function (callbackDetails) {
                var passedTest = true, i,
                    doInspectElements = callbackDetails && callbackDetails.flashType === flashType && callbackDetails.numberOfFlashes === -1;

                if (doInspectElements) {
                    if (elements.length === callbackDetails.elements.length) {
                        for (i=0; i < elements.length; ++i) {
                            if (elements[i] !== callbackDetails.elements[i]) {
                                passedTest = false;
                            }
                        };
                    }
                } else {
                    passedTest = false;
                }

                return passedTest;
            });
        },

        flashCallback: function (callbacksListIndex) {
            var callbackDetails = callbacksList[callbacksListIndex];

            // Number of flashes is -1 if we want to flash indefinitely
            if (callbackDetails && callbackDetails.numberOfFlashes !== 0) {
                callbackDetails.elements.toggleClass("flash-500ms");
		        if (callbackDetails.numberOfFlashes > 0) {
		            callbackDetails.numberOfFlashes -= 1;
		        }
            } else if (callbackDetails) {
		        this._stopFlashing(callbacksListIndex);
		    }
		},

		attachTooltipMouseEvents: function (element) {
		    var controls = ".third-party-badge, .trade-count-badge, .my-order-count-badge, .my-trade-count-badge, .instrument-count-badge";

		    element.on("mouseover", controls, this.showNotificationTooltip.bind(this));
		    element.on("mouseout", controls, this.hideNotificationTooltip);
		},

		getNotificationFlashType: function(event) {
		    if ($(event.target).hasClass("trade-count-badge")) {
		        return this.EFlashType.eTradeCount;
		    } else if ($(event.target).hasClass("third-party-badge")) {
		        return this.EFlashType.eThirdPartyInterest;
		    } else if ($(event.target).hasClass("my-order-count-badge")) {
		        return this.EFlashType.eMyOrderCount;
		    } else if ($(event.target).hasClass("my-trade-count-badge")) {
		        return this.EFlashType.eMyTradeCount;
		    } else if ($(event.target).hasClass("instrument-count-badge")) {
		        return this.EFlashType.eInstrumentCount;
		    }
		},

		getNotificationFlashString: function (flashType) {
		    switch (flashType) {
		        case this.EFlashType.eTradeCount:
		            return BGC.resources.IDS_TRADE_COUNT;
		        case this.EFlashType.eThirdPartyInterest:
		            return BGC.resources.IDS_INTEREST_COUNT;
		        case this.EFlashType.eMyOrderCount:
		            return BGC.resources.IDS_MY_ORDER_COUNT;
		        case this.EFlashType.eMyTradeCount:
		            return BGC.resources.IDS_MY_TRADE_COUNT;
		        case this.EFlashType.eInstrumentCount:
		            return BGC.resources.IDS_INST_COUNT_BADGE_TIP;
		    }
		},

		showNotificationTooltip: function (event) {
		    var tooltipType = this.getNotificationFlashType(event),
                tooltipStr = this.getNotificationFlashString(tooltipType),
                targetRect = event.target.getBoundingClientRect(),             
                targetRectWidth = targetRect.right - targetRect.left,
                targetRectHeight = targetRect.bottom - targetRect.top;

            BGC.ui.tooltipSingleton.getInstance().show(tooltipStr, { x: targetRect.left + targetRectWidth / 2, y: (targetRect.top + targetRectHeight / 2) }, this);
        },

		hideNotificationTooltip: function () {
            BGC.ui.tooltipSingleton.getInstance().hide(true);
        }
	};

}(window.BGC.ui.view));
