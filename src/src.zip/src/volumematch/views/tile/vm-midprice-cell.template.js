import {html} from '@polymer/polymer';

export default html`
<style>
    * { box-sizing: border-box;}
    *[hidden] {
        display: none !important;
    }

    :host(.vmtile-spread-instrument-row) .mid-price {
        background: none;;
    }


    .mid-price {
        font-weight: inherit;
        cursor: default;
        height: calc(1.6rem - 1px);
        display: block;
        float: left;
        width: 6rem;
        min-width: 6rem;
        background-color: var(--content-price-background);
        color: inherit;
        border: none;
        border-left: solid 1px var(--content-border);
        vertical-align: top;
        padding: 0 0 0 0.5rem;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        text-align: center;
        padding: 0;
        font-size: 1rem;
        height: 100%;
        line-height: 1.6rem;
        float: none;
        position: relative;
    }



    :host {
        width: 6rem;
    }
    :host(.third-party-interest.below-market-size) .order,
    :host(.third-party-interest.below-market-size) .mid-price {
        background-image: linear-gradient(to right, var(--thirdparty-glow), var(--content-background), var(--content-background), var(--thirdparty-glow));
        color: var(--thirdparty-glow-text);
    }
    :host(.third-party-interest) .mid-price {
        font-weight: var(--font-weight-matrix-cell-data);
        background-image: linear-gradient(to right, var(--thirdparty-glow), var(--thirdparty-glow));
        color: var(--thirdparty-glow-text);
    }
    .flash-500ms {
        background-color: var(--new-price-flash-bg) !important;
        color: var(--new-price-flash-fg);
    }

    :host(.instrument-row-cell.selected) .mid-price {
        outline: 1px solid var(--selection);
        outline-offset: -1px;
        box-shadow: inset 0 0 0 2px var(--selection);
        background-color: var(--highlight-background);
        color: var(--selection);
    }
    
    .mid-price .traded.gavel {
        background-image: var(--gavel-image);
        background-repeat: no-repeat;
        background-size: calc(1rem + 2px);
        display: inline-block;
        width: calc(1rem + 2px);
        height: calc(1rem + 2px);
        vertical-align: middle;
        margin-bottom: 3px;
    }

    :host(.vmtile-spread-instrument-row) .gavel {
        display: none !important;
    }

    :host(.le-buy-interest) .mid-price:before {
        position: absolute;
        top: 0;
        left: 0;
        width: 0;
        height: 0;
        border-top: none;
        border-bottom: calc(1.6rem * 0.8) solid transparent;
        border-left: calc(1.6rem * 0.8) solid var(--same-le-glow);
        content: '';
        display: block;
        opacity: 0.7;
    }
    :host(.le-sell-interest) .mid-price:after {
        position: absolute;
        top: 0;
        right: 0;
        width: 0;
        height: 0;
        border-top: none;
        border-bottom: calc(1.6rem * 0.8) solid transparent;
        border-right: calc(1.6rem * 0.8) solid var(--same-le-glow);
        content: '';
        display: block;
        opacity: 0.7;
    }
    .indicative{
        color: var(--indicative-mid-price) !important;
        font-style:italic;
    }
    
    
</style>
<div id="priceCell" class="tile" draggable="true">
    <div draggable="false">
        <div class="mid-price">
            <span class="traded gavel" hidden="{{!displayGavel}}" on-mousedown="onGavelClick"
                  on-mouseenter="onGavelMouseEnter" on-mouseleave="onGavelMouseLeave"></span>
            <span>{{priceDisplay}}</span>
            <div class="price-direction"></div>
        </div>
    </div>
</div>
`;
