/* eslint-disable max-lines, max-statements, max-len, func-names, no-param-reassign, no-plusplus, no-magic-numbers */
/* global BGC: false, $: false, _:false, Backbone: false */
// /////////////////////////////////////////////////////////////////////////////
// file activeordersview.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

// eslint-disable-next-line no-shadow-restricted-names
(function (context, dataStore, undefined) {
  const theTooltip = BGC.ui.tooltipSingleton.getInstance();

  context.OrderListView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#order-list-view'),
    events   : {
      'click .header-row .excel-live-link-all' : 'onClickExcelLiveLinkAll',
      'click .repost-all'                      : 'onCheckRepostAll'
    },

    initialize (options) {
      this.pageLayout = options.pageLayout;
      this.parentView = options.parentView;
      this.adjustedNomenclature = '';

      if (dataStore.userSettingsStore.get('swapBidAndOffer')) {
        this.adjustedNomenclature = {
          buyText  : BGC.resources.getAdjustedNomenclature('IDS_SELL_SIZE', options.pageLayout.get('nomenclature')),
          sellText : BGC.resources.getAdjustedNomenclature('IDS_BUY_SIZE', options.pageLayout.get('nomenclature'))
        };
      } else {
        this.adjustedNomenclature = {
          buyText  : BGC.resources.getAdjustedNomenclature('IDS_BUY_SIZE', options.pageLayout.get('nomenclature')),
          sellText : BGC.resources.getAdjustedNomenclature('IDS_SELL_SIZE', options.pageLayout.get('nomenclature'))
        };
      }
      this.rows = [];
      this.notifications = {orderCount : 0, tradeCount : 0, executionCount : 0};
      this.notificationType = {eMyOrder : 0, eMyTrade : 1};

      // Prepare generic columns HTML for the header row
      this.genericColumnsHtml = '';
      this.genericPriceBColumnHtml = '';
      _.each(this.pageLayout.get('genericColumns'), function (columnDefinition) {
        if (columnDefinition.columnId === 'priceBDisplay') {
          this.genericPriceBColumnHtml += `<span class='${columnDefinition.columnId}'>${columnDefinition.columnName}</span>`;
        } else {
          this.genericColumnsHtml += `<span class='${columnDefinition.columnId}'>${columnDefinition.columnName}</span>`;
        }
      }, this);

      this.render();

      this.listenTo(options.parentView, 'change:activeView', this.contentHeightChanged);
      this.listenTo(dataStore.userSettingsStore, 'change:swapBidAndOffer', this.updateSwapSides, this);
      this.listenTo(dataStore.userSettingsStore, 'change:showTradesForFirm', this.requestRender);
      this.listenTo(dataStore.userSettingsStore, 'change:showTradesForExternalGroupUsers', this.requestRender);
      this.listenTo(dataStore, 'accountSelectionChanged', this.requestRender);
      this.listenTo(dataStore.userSettingsStore, 'change:isOrdersViewFixedHeight', this.requestRender);
      this.listenTo(dataStore.userSettingsStore, 'change:fixedHeightOrdersViewRowCount', this.requestRender);
      this.listenTo(this.pageLayout, 'rootFontSizeChanged', this.contentHeightChanged);
      this.listenTo(this.pageLayout, 'change:isExcelAddInEnabled', this.requestRender);
      this.listenTo(this.pageLayout, 'change:isMoveableMidEnabled', this.onMoveableMidStateChanged);
      this.collection.on('add', this.onOrderAdded, this);
      this.collection.on('reset', this.requestRender, this);
      this.collection.on('remove', this.onOrderRemoved, this);
    },

    updateSwapSides () {
      const swapBidAndOffer = dataStore.userSettingsStore.get('swapBidAndOffer');

      this.adjustedNomenclature.buyText = swapBidAndOffer ? BGC.resources.getAdjustedNomenclature('IDS_SELL_SIZE', this.pageLayout.get('nomenclature')) : BGC.resources.getAdjustedNomenclature('IDS_BUY_SIZE', this.pageLayout.get('nomenclature'));
      this.adjustedNomenclature.sellText = swapBidAndOffer ? BGC.resources.getAdjustedNomenclature('IDS_BUY_SIZE', this.pageLayout.get('nomenclature')) : BGC.resources.getAdjustedNomenclature('IDS_SELL_SIZE', this.pageLayout.get('nomenclature'));
      this.requestRender();
    },

    onCheckRepostAll () {
      const repostAllCheckBox = this.el.querySelector('#repost-all');

      dataStore.modelDefinitions.Order.setRepostAllState(repostAllCheckBox ? repostAllCheckBox.checked : false);

      this.rows.forEach(row => {
        // Repost all check should be applied to own orders only
        if (row.model.get('orderType') === BGC.schemaValidator.OWNERSHIP_MINE) {
          row.model.set('repostCheck', repostAllCheckBox ? repostAllCheckBox.checked : false);
        }
      });
    },

    updateNotifications () {
      const prevOrderCount = this.notifications.orderCount;
      const prevTradeCount = this.notifications.tradeCount;
      const prevExecutionCount = this.notifications.executionCount;
      let newOrderCount = 0;
      let newTradeCount = 0;
      let newExecutionCount = 0;

      this.rows.forEach(row => {
        newOrderCount += row.view.orderCount;
        newTradeCount += row.view.tradeCount;
        newExecutionCount += row.view.executionCount;
      }, this);

      if (prevOrderCount !== newOrderCount) {
        this.$el.trigger('update:notificationBadges', {badgeType : 'orderCount', count : newOrderCount, flash : false});
      }

      if (prevTradeCount !== newTradeCount || prevExecutionCount !== newExecutionCount) {
        this.$el.trigger('update:notificationBadges', {
          badgeType : 'tradeCount', count : newTradeCount, flash : !!newTradeCount, view : this.el
        });
      }

      this.notifications.orderCount = newOrderCount;
      this.notifications.tradeCount = newTradeCount;
      this.notifications.executionCount = newExecutionCount;
    },

    onOrderAdded (orderModel) {
      if (!this.$el.hasClass('populated')) {
        this.render();

        return;
      }

      const orderSource = orderModel.get('orderType');
      const accountId = orderModel.get('accountId');
      const showTradesForFirm = !!dataStore.userSettingsStore.get('showTradesForFirm');
      const showOtherGroupTrades = !!dataStore.userSettingsStore.get('showTradesForExternalGroupUsers');

      // Should the new order be shown in the list, according to our current settings?
      if (orderSource === BGC.schemaValidator.OWNERSHIP_MINE ||
                (showTradesForFirm && (orderSource === BGC.schemaValidator.OWNERSHIP_MY_FIRM)) ||
                (showOtherGroupTrades && (orderSource === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT) && accountId)) {
        const row = new context.OrderRowView({
          model : orderModel, collection : this.collection, rowType : orderModel.get('orderType'), pageLayout : this.pageLayout
        });

        this.listenTo(row, 'update:notifications', this.updateNotifications);

        // Listen to event indicating expansion/collapse of executions area for the row
        this.listenTo(row, 'change:executionRowsHeightChanged', this.contentHeightChanged);

        // Store the row so that when we next execute render() and remove all the rows (see above),
        // we can do so by calling remove() on each and thus clear up their listeners,
        // rather than by simply setting the innerHTML of the container to empty.
        this.rows.splice(0, 0, {model : orderModel, view : row});

        // As its no longer just ordered by creationTime, we need a render
        // taking into account if its own or myFirm or sharedAccount order
        this.requestRender();
        if (context.mainView.selection && context.mainView.selection.instrument === orderModel.get('instrument')) {
          row.$el.find('.instrument-row').addClass('selected');
        }
      }
    },

    onOrderRemoved (model) {
      // Maintain our array of rows
      this.rows = this.rows.filter(function (row) {
        if (row.model === model) {
          this.stopListening(row.view);
        }

        return row.model !== model;
      }, this);

      // if collection is empty, remove content (i.e. the header row) and hide border
      if (this.collection.length === 0) {
        this.$el.removeClass('populated');
        if (!dataStore.userSettingsStore.get('isOrdersViewFixedHeight')) {
          this.$el.empty();
          this.$el.trigger('recalcLayout');
        }
      }

      // Update any listeners with the state of notifications relevant to this view
      this.updateNotifications();

      // set Excel Live Link All icon to active or inactive dependent on whether Excel Live Link mode is enabled for all instruments or not
      this.updateExcelLiveLinkAllIcon();

      this.contentHeightChanged();
    },

    requestRender () {
      BGC.ui.viewUtils.requestRender('ActiveOrders', 'OrdersView', this, this.render);
    },

    render () {
      const showTradesForFirm = !!dataStore.userSettingsStore.get('showTradesForFirm');
      const showOtherGroupTrades = !!dataStore.userSettingsStore.get('showTradesForExternalGroupUsers');

      // Before clearing the content and the rows, take a backup of existing orders which are expanded.
      const expandedOrders = [];

      this.rows.forEach(row => {
        if (row.view.orderExecutionRowsExpanded) {
          expandedOrders.push(row.model);
        }
      }, this);

      // clear existing content, ensuring that listeners are cleaned up
      this.rows.forEach(function (row) {
        this.stopListening(row.view);
        row.view.clearStatusTooltip();
        row.view.remove();
      }, this);
      this.rows = [];
      this.$el.empty();

      // Get the orders we want to show, governed by current filtering settings
      const orders = this.collection.filter(model => {
        const orderSource = model.get('orderType');
        const accountId = model.get('accountId');

        // In Sales trader mode & "showOtherGroupTrades" setting is false
        // then set "selectedAccountId" to active account id, this would filter orders by selected the account
        const selectedAccountId = dataStore.isSalesTraderMode() && showOtherGroupTrades === false ? dataStore.getActiveAccountId() : accountId;

        // eslint-disable-next-line no-mixed-operators
        return orderSource === BGC.schemaValidator.OWNERSHIP_MINE && selectedAccountId === accountId ||
          (showTradesForFirm && (orderSource === BGC.schemaValidator.OWNERSHIP_MY_FIRM)) ||
          (showOtherGroupTrades && (orderSource === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT) && accountId);
      });

      // render template
      this.$el.html(this.template({
        instrumentHeader        : BGC.resources.IDS_INSTRUMENT,
        resources               : BGC.resources,
        adjustedNomenclature    : this.adjustedNomenclature,
        genericColumnsHtml      : this.genericColumnsHtml,
        genericPriceBColumnHtml : this.genericPriceBColumnHtml

      }));

      // Set the visibility and fixed-height of the header row and content area
      this.$el.toggleClass('populated', orders.length > 0);
      this.$el.toggleClass('fixed-height', dataStore.userSettingsStore.get('isOrdersViewFixedHeight') === 1);

      // Toggle the show/hide for Repost-all setting
      this.$el.find('.repost-all')
        .toggleClass('showRepostall', dataStore.userSettingsStore.get('allowRepost'));

      // Reset the check all state after re-creating the UI
      const repostAllCheckBox = this.el.querySelector('#repost-all');

      if (repostAllCheckBox) {
        repostAllCheckBox.checked = dataStore.modelDefinitions.Order.getRepostAllState();
      }

      if (orders.length) {
        // render each order row
        const $orderRows = this.$el.find('.order-rows');

        _.each(orders, function (order) {
          const expandedOrderFound = _.find(expandedOrders, expandedOrder => expandedOrder === order);
          const row = new context.OrderRowView({
            model                      : order,
            collection                 : this.collection,
            rowType                    : order.get('orderType'),
            pageLayout                 : this.pageLayout,
            orderExecutionRowsExpanded : expandedOrderFound !== undefined
          });

          // Listen to event indicating expansion/collapse of executions area for the row
          this.listenTo(row, 'change:executionRowsHeightChanged', this.contentHeightChanged);

          this.listenTo(row, 'update:notifications', this.updateNotifications);

          // Store the row so that when we next execute render() and remove all the rows (see above),
          // we can do so by calling remove() on each and thus clear up their listeners,
          // rather than by simply setting the innerHTML of the container to empty.
          this.rows.push({
            model : order,
            view  : row
          });
          $orderRows.append(row.$el);
        }, this);
      }

      // Update any listeners with the state of notifications relevant to this view
      this.updateNotifications();

      // set Excel Live Link All icon to active or inactive dependent on whether Excel Live Link mode is enabled for all instruments or not
      this.updateExcelLiveLinkAllIcon();

      this.contentHeightChanged();
    },

    // eslint-disable-next-line complexity
    contentHeightChanged () {
      const scrollContainer = this.el.querySelector('.scroll-container');
      const scrollableContent = this.el.querySelector('.scrollable-content');
      const $headerRow = this.$el.find('.header-row');

      let rowHeight = 10;
      let numberOfCounterpartyExpansionRows = 0;

      // Retrieve the row height from an unneeded property then override the property
      // on the header row's children so that it doesn't affect the rendering of the DOM.
      const rowHeightStr = $headerRow.css('text-indent');

      if (rowHeightStr) {
        rowHeight = Number(rowHeightStr.slice(0, rowHeightStr.indexOf('px')));

        $headerRow.children().each(function () {
          $(this).css('text-indent', '0px');
        });
      }

      // If the scroll container is showing a vertical scrollbar,
      // we need to get rid of the right padding/margin on the contained area
      if (scrollContainer && scrollableContent) {
        const isFixedHeight = dataStore.userSettingsStore.get('isOrdersViewFixedHeight') === 1;
        const isFloatOver = !!this.$el.hasClass('float-over');

        numberOfCounterpartyExpansionRows = _.reduce(this.rows, (memo, row) => memo + ((row.view.orderExecutionRowsExpanded && row.view.counterpartyCount) || 0), 0);

        // Determine the minimum and maximum height of the scroll container
        // and scrollable content.
        if ((isFixedHeight === true) && (isFloatOver === false)) {
          // Apply the fixed height using the user configured number of rows if the
          // fixed height area is enabled.
          const totalFixedHeight = dataStore.userSettingsStore.get('fixedHeightOrdersViewRowCount') * rowHeight;

          scrollContainer.style.maxHeight = `${totalFixedHeight}px`;
          scrollableContent.style.minHeight = `${totalFixedHeight}px`;
        } else if ((this.rows.length > 0) && (isFloatOver === false)) {
          // restrict to a maximum of 10 rows before showing scroll bar
          // but only when grid is locked into the document flow (not floating)
          const totalFixedHeight = 10 * rowHeight;
          let totalRowHeight = this.rows.length * rowHeight;

          totalRowHeight += numberOfCounterpartyExpansionRows * rowHeight;

          scrollContainer.style.maxHeight = `${totalFixedHeight < totalRowHeight ? totalFixedHeight : totalRowHeight}px`;
          scrollableContent.style.minHeight = `${totalRowHeight}px`;
        } else {
          scrollContainer.style.removeProperty('max-height');
          scrollableContent.style.removeProperty('min-height');
        }

        // Sets the overflow to be scrollable/hidden based on whether the content is more than the container height.
        BGC.ui.viewUtils.updateElementVerticalOverflow(scrollContainer, scrollableContent);

        // UNLESS we are in "float-over" display mode, in which case the document flow is unaffected,
        // ...do recalc layout
        if (!(this.parentView && this.parentView.$el.hasClass('float-over'))) {
          this.$el.trigger('recalcLayout');
        }
      }
    },

    // set Excel Live Link All icon to active or inactive dependent on whether Excel Live Link mode is enabled for all instruments or not
    updateExcelLiveLinkAllIcon () {
      const isExcelAddInEnabled = this.pageLayout.get('isExcelAddInEnabled');
      const excelLiveLinkElem = this.$el.find('.excel-live-link');

      if (excelLiveLinkElem && excelLiveLinkElem.length > 0) {
        excelLiveLinkElem[0].style.display = isExcelAddInEnabled ? 'inline' : 'none';
        this.excelLiveLinkEnabled = isExcelAddInEnabled;

        if (isExcelAddInEnabled) {
          this.$el.find('.excel-live-link-all').attr('src', this.areAllExcelLiveLinksEnabled() ? './assets/images/excel_link_active.png' : './assets/images/excel_link_inactive.png');
        }
      }
    },

    areAllExcelLiveLinksEnabled () {
      const showTradesForFirm = !!dataStore.userSettingsStore.get('showTradesForFirm');
      const showOtherGroupTrades = !!dataStore.userSettingsStore.get('showTradesForExternalGroupUsers');

      let areAllExcelLiveLinksEnabled = false;

      for (let index = 0; index < this.collection.length; index++) {
        const order = this.collection.models[index];
        const orderSource = order.get('orderType');

        // Filter out the orders we don't want to show, governed by current filtering settings
        if (orderSource === BGC.schemaValidator.OWNERSHIP_MINE ||
          ((showTradesForFirm === true) && (orderSource === BGC.schemaValidator.OWNERSHIP_MY_FIRM)) ||
          ((showOtherGroupTrades === true) && (orderSource === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT))) {
          if (order.get('instrument').isExcelLiveModeEnabled()) {
            areAllExcelLiveLinksEnabled = true;
          } else {
            areAllExcelLiveLinksEnabled = false;

            break;
          }
        }
      }

      return areAllExcelLiveLinksEnabled;
    },

    onMoveableMidStateChanged () {
      this.$el.toggleClass('wide-status', this.pageLayout.isMoveableMidEnabled());
    },

    applySelectionGlowStyleAndScrollToView (instrument) {
      this.$el.find('.instrument-row').removeClass('selected');

      const activeOrder = instrument.getActiveOrder();
      const buyOrder = activeOrder ? activeOrder.get('buy') : undefined;
      const sellOrder = activeOrder ? activeOrder.get('sell') : undefined;
      let scrolledIntoView = false;

      if (buyOrder) {
        const rowToSelect = _.find(this.rows, row => row.model === buyOrder);

        if (rowToSelect) {
          rowToSelect.view.$el.find('.instrument-row').addClass('selected');
          rowToSelect.view.el.scrollIntoView();
          scrolledIntoView = true;
        }
      }

      if (sellOrder && sellOrder !== buyOrder) {
        const rowToSelect = _.find(this.rows, row => row.model === sellOrder);

        if (rowToSelect) {
          rowToSelect.view.$el.find('.instrument-row').addClass('selected');
          if (!scrolledIntoView) {
            rowToSelect.view.el.scrollIntoView();
          }
        }
      }
    },

    onClickExcelLiveLinkAll () {
      const enable = !this.areAllExcelLiveLinksEnabled();

      this.collection.forEach(order => {
        order.get('instrument').sendEnableExcelLiveLink('ActiveOrders', enable);
      });
    }
  });

  _.extend(context.OrderListView.prototype, context.GridViewNavigationMixin);

  context.OrderRowView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#order-view'),

    events : {
      'click .instrument-row'          : 'onClickRow',
      'click .size img'                : 'onClickOrderCancel',
      'click .fa.fa-caret-down'        : 'onClickOrderExecutionsExpandCollapse',
      'click .fa.fa-caret-up'          : 'onClickOrderExecutionsExpandCollapse',
      'click .remove'                  : 'onClickRemoveFootprint',
      'click .excel-live-link-toggle'  : 'onClickExcelLiveLink',
      'mouseenter .status'             : 'onMouseEnterTradeStatus',
      'mouseleave .status'             : 'onMouseLeaveTradeStatus',
      SubmitValidatedSize              : 'handleSubmitOrderEvent',
      'click input[type=\'checkbox\']' : 'onCheckRepostRow'
    },

    initialize (options) {
      this.pageLayout = options.pageLayout;

      // Ensure that the render function is always executed in the correct context
      this.requestRender = this.requestRender.bind(this);

      // Because then we can use underscoreJS to do easy coalescence of calls to the function
      this.coalescedRender = _.debounce(this.requestRender, 100);

      // set row attributes
      this.counterpartyCount = 0;
      this.orderExecutionRowsExpanded = options.orderExecutionRowsExpanded;
      this.selected = false;

      // instrument, ownOrder or firmOrder
      this.rowType = options.rowType;
      this.orderCount = 0;
      this.tradeCount = 0;
      this.executionCount = 0;

      // render row template
      this.render();

      // and initialise the notification flags for "unfilled order" and "traded" status
      this.setRowNotificationCounts();

      this.listenTo(this.pageLayout, 'change:isExcelAddInEnabled', this.requestRender);
      const myOrderModel = this.getOrderModel();
      const myInstrumentModel = this.getInstrumentModel();

      myOrderModel.on('change', this.handleOrderChanged, this);
      myOrderModel.on('remove', this.removeOrder, this);
      myInstrumentModel.on('change', this.coalescedRender, this);
      myOrderModel.on('change:repostCheck', this.sendRepostCheckState, this);
    },

    onCheckRepostRow () {
      const repostCheckBox = this.el.querySelector('#repost');

      this.getOrderModel().set('repostCheck', repostCheckBox ? repostCheckBox.checked : false);
    },

    sendRepostCheckState () {
      // Send Repost check state to VM marshal
      const order = this.getOrderModel();

      BGC.eventsHandler.onClick('activeOrderView', 'postOrder', JSON.stringify({
        instrumentId      : this.getInstrumentModel().get('instrumentId'),
        orderPrice        : order.get('price'),
        orderSide         : order.get('isLiveBuy') ? 1 : 2,
        orderSize         : 0,
        accountId         : order.get('accountId'),
        userId            : order.get('userId'),
        orderUpsizingMode : 0,
        repostRequest     : true,
        repostOrder       : order.get('repostCheck')
      }));

      BGC.logger.logInformation(`Post VM Repost Checked [${order.get('repostCheck')}] For Instrument [${this.getInstrumentModel().get('instrumentId')} ]`);
    },

    getOrderModel () {
      return this.model;
    },

    getInstrumentModel () {
      return this.getOrderModel().get('instrument');
    },

    tooltip : BGC.ui.tooltipSingleton.getInstance(),

    handleOrderChanged () {
      this.setRowNotificationCounts();
      this.requestRender();
    },

    // eslint-disable-next-line complexity
    setRowNotificationCounts () {
      const model = this.getOrderModel();
      const order = model.serialize();
      let orderCount = 0;
      let tradeCount = 0;
      let executionCount = 0;
      let triggerUpdate = false;

      if (this.rowType === BGC.schemaValidator.OWNERSHIP_MINE && !order.isAuctionEndFootprint) {
        if (model.hasUnfilledSize('buy')) {
          ++orderCount;
        }
        if (model.hasUnfilledSize('sell')) {
          ++orderCount;
        }

        // There are various different ways we could choose to evaluate the trade count.
        // Current thinking is that the count should increment by 1 for each traded row,
        // but that we should use a separate count of actual executions to flash the count
        // whenever a new execution occurs
        if (model.hasExecuted()) {
          if (model.hasFilledSize('buy')) {
            ++tradeCount;
            ++executionCount;
          }

          if (model.hasFilledSize('sell')) {
            ++tradeCount;
            ++executionCount;
          }

          // If we have got immediate execution data, use that instead for a better execution count
          if (order.executions && order.executions.length) {
            executionCount = order.executions.length;
          }
        }
      }

      if (this.orderCount !== orderCount || this.tradeCount !== tradeCount || this.executionCount !== executionCount) {
        triggerUpdate = true;
      }

      this.orderCount = orderCount;
      this.tradeCount = tradeCount;
      this.executionCount = executionCount;

      if (triggerUpdate) {
        this.trigger('update:notifications');
      }
    },

    removeInstrument () {
      if (this.collection) {
        this.remove();
      }
    },

    removeOrder (model) {
      const myOrderModel = this.getOrderModel();
      const myInstrumentModel = this.getInstrumentModel();

      if (myOrderModel === model) {
        this.clearStatusTooltip();

        myOrderModel.off(null, null, this);
        myInstrumentModel.off(null, null, this);
        this.remove();
      }
    },

    requestRender () {
      BGC.ui.viewUtils.requestRender(this.getInstrumentModel().get('instrumentId') + this.getOrderModel().get('priceDisplay'), 'orderRow', this, this.render);
    },

    // eslint-disable-next-line complexity
    render () {
      const wasSelected = this.$el.find('.instrument-row').hasClass('selected');

      this.clearStatusTooltip();

      this.storeSizeCellState();

      const instrumentModel = this.model.get('instrument');

      // take a copy so we don't modify stored POJO
      const instrument = {...instrumentModel.serialize()};
      const order = {...this.model.serialize()};
      const accountModel = BGC.dataStore.getAccount(order.accountId);

      // If there is an account Id on the order, add the account name for display
      order.accountShortName = accountModel ? accountModel.get('shortName') : '';
      order.accountLongName = accountModel ? accountModel.get('fullName') : '';

      // order sizes should be coerced to string by + "", as they will be revert values of size cells
      order.buySize = `${order.hasBuySize ? order.buySize : ''}`;
      order.sellSize = `${order.hasSellSize ? order.sellSize : ''}`;

      // if execution counterparties are being rendered, first group executions by counterparty
      if (order.executions) {
        this.executionsByCounterparty = _.groupBy(order.executions, 'counterparty');
        this.counterpartyCount = _.size(this.executionsByCounterparty);
      }

      // Only show the gavel if an order for a traded instrument is at a traded price level
      // OR if the order itself has executed size
      if ((instrument.showTradeIndicators && order.hasInstrumentTradedAtOrderPrice) ||
            order.hasBoughtSize || order.hasSoldSize) {
        instrument.showGavel = true;
      }

      // Inject generic columns into the template for the order row.
      // Ignore the total volume colume as this is only for instrument rows, not active orders
      this.genericColumnsHtml = '';
      this.genericPriceBColumnHtml = '';
      _.each(this.pageLayout.get('genericColumns'), function (columnDefinition) {
        if (columnDefinition.columnId === 'priceBDisplay') {
          this.genericPriceBColumnHtml += `<span class='${columnDefinition.columnId}'>${
            order ? order[columnDefinition.columnId] : instrument[columnDefinition.columnId]}</span>`;
        } else {
          this.genericColumnsHtml += `<span class='${columnDefinition.columnId}'>${
            order ? order[columnDefinition.columnId] : instrument[columnDefinition.columnId]}</span>`;
        }
      }, this);

      // render html template to display instrument row view
      this.$el.html(this.template({
        instrument,
        instrumentName : dataStore.modelDefinitions.Instrument.getGenAttrFormattedInstrumentName(instrument.name,
          {
            straddleDisplay : instrument.straddleDisplay,
            ratioDisplay    : instrument.ratioDisplay,
            deltaDisplay    : instrument.deltaDisplay
          }),
        order,
        buyStatus               : this.model.buildStatusString('buy'),
        sellStatus              : this.model.buildStatusString('sell'),
        counterpartyText        : this.getCounterpartyText(order),
        counterpartyCount       : this.counterpartyCount,
        resources               : BGC.resources,
        genericColumnsHtml      : this.genericColumnsHtml,
        genericPriceBColumnHtml : this.genericPriceBColumnHtml,
        shouldRepost            : order.repostCheck ? 'checked' : ''
      }));

      this.el.querySelectorAll('size-input-control').forEach(sizeInput => {
        sizeInput.setValidationCallback(instrumentModel.validateSize.bind(instrumentModel));
      }, this);

      // apply class styling
      this.applyClassStyles(instrument, order);
      if (wasSelected) {
        this.$el.find('.instrument-row').addClass('selected');
      }

      // Document setting to show hide Repost div
      this.$el.find('.repost').toggleClass('showRepost', dataStore.userSettingsStore.get('allowRepost'));

      // set Excel Live Link icon to active or inactive dependent on whether Excel Live Link mode is enabled for the instrument or not
      this.updateExcelLiveLinkIcon();

      // If we have multiple counterparties, restore order execution expansion state.
      this.restoreExecutionRowExpansionState();

      this.restoreSizeCellState();
    },

    storeSizeCellState () {
      this.focusedSizeInfo = undefined;
      const focusedSizeCell = this.$el.find('input:focus');

      if (focusedSizeCell.length > 0 && focusedSizeCell.is('.buy, .sell')) {
        this.focusedSizeInfo = {
          side           : focusedSizeCell.hasClass('buy') ? 'buy' : 'sell',
          text           : focusedSizeCell.val(),
          selectionStart : focusedSizeCell[0].selectionStart,
          selectionEnd   : focusedSizeCell[0].selectionEnd
        };
      }
    },

    restoreSizeCellState () {
      if (this.focusedSizeInfo !== undefined) {
        const sizeEdit = this.$el.find(this.focusedSizeInfo.side === 'buy' ? 'input.buy' : 'input.sell');

        sizeEdit.val(this.focusedSizeInfo.text);
        sizeEdit.focus();
        sizeEdit[0].setSelectionRange(this.focusedSizeInfo.selectionStart, this.focusedSizeInfo.selectionEnd);
        this.focusedSizeInfo = undefined;
      }
    },

    // eslint-disable-next-line complexity
    applyClassStyles (instrument, order) {
      const $row = this.$el.find('.instrument-row');

      // apply "my firm's order" row style if this is same LE order row in active orders view
      if (this.rowType === BGC.schemaValidator.OWNERSHIP_MY_FIRM) {
        $row.addClass('same-LE-highlight');
      } else if (this.rowType === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT) {
        // For sales traders we display orders for 3rd party users who are in our group(s), for shared
        // accounts in those groups. These are inactive (we can't modify them although we can cancel them)
        // and styled differently to distinguish them from our own orders
        $row.addClass('group-thirdparty-highlight');
      } else if (this.rowType === BGC.schemaValidator.OWNERSHIP_MINE) {
        $row.addClass('ownership-mine-highlight');
      }

      // Based on the preference "swapBidAndOffer" add mirror class.
      if (BGC.dataStore.userSettingsStore.get('swapBidAndOffer')) {
        $row.find('#mirrorElements').addClass('mirror');
      }

      // disable input controls when instrument is inactive or order entry is disallowed
      // or it's a row in the active orders grid and it's not my order
      if (instrument.inactive || !instrument.canUserEnterOrders ||
            (this.rowType !== 'instrument' && this.rowType !== BGC.schemaValidator.OWNERSHIP_MINE)) {
        $row.find('input').attr('disabled', true);
      }

      if (instrument.inactive) {
        // Not in auction, display with footprint row styling
        $row.addClass('footprint');
        $row.find('.counterparty').addClass('footprint');
        $row.find('.mid-price').removeClass('newPrice');
        $row.removeClass('executed expanded buy-blotter-published-by-excel sell-blotter-published-by-excel');
      } else {
        // In auction, remove any previous footprint or Excel styling and apply active row styles
        $row.removeClass('footprint');
        $row.find('.counterparty').removeClass('footprint');

        if (order) {
          // apply 'executed order' style
          if (order.hasBoughtSize || order.hasSoldSize) {
            $row.addClass('executed');
          }

          // apply 'blotter published by Excel' style
          if (order.wasBuyPublishedByExcel) {
            $row.addClass('buy-blotter-published-by-excel');
          } else {
            $row.removeClass('buy-blotter-published-by-excel');
          }
          if (order.wasSellPublishedByExcel) {
            $row.addClass('sell-blotter-published-by-excel');
          } else {
            $row.removeClass('sell-blotter-published-by-excel');
          }
        }

        // apply 'third party' interest glow to instrument name cell for all order rows and tile rows
        BGC.ui.viewUtils.applyThirdPartyInterestGlows(instrument.showThirdPartyInterestGlows ? instrument.thirdPartyInterest : 'none', this.el.querySelectorAll('.price, .name'));

        // apply 'same le' interest glow to price and instrument cells
        BGC.ui.viewUtils.applySameLEInterestGlows(instrument.hasSameLeBuyInterest, instrument.hasSameLeSellInterest, this.el.querySelectorAll('.price, .name'));
      }

      // alow brokers to request trade confirm by clicking gavel icon in price cell
      if (this.getInstrumentModel().canRequestTradeConfirms()) {
        $row.find('.price .gavel').addClass('trade-confirm-request');
      }
    },

    getCounterpartyText (order) {
      let counterpartyText = '';

      if (this.counterpartyCount === 1) {
        counterpartyText = order.executions[0].counterparty;
      } else if (this.counterpartyCount > 1) {
        counterpartyText = BGC.resources.IDS_COUNTERPARTIES;
      }

      return counterpartyText;
    },

    // set Excel Live Link icon to active or inactive dependent on whether Excel Live Link mode is enabled for the instrument or not
    updateExcelLiveLinkIcon () {
      const isExcelAddInEnabled = this.pageLayout.get('isExcelAddInEnabled');

      this.$el.find('.excel-live-link')[0].style.display = isExcelAddInEnabled ? 'inline' : 'none';
      if (isExcelAddInEnabled) {
        this.$el.find('.excel-live-link-toggle').attr('src', this.getInstrumentModel().isExcelLiveModeEnabled() ? '.assets//images/excel_link_active.png' : './assets/images/excel_link_inactive.png');
      }
    },

    // Handler for bubbling custom event was added using jQuery,
    // so original event will be wrapped in jQuery event.
    // Therefore custom event auxiliary data may be found in event.originalEvent.detail
    handleSubmitOrderEvent (event) {
      event.stopPropagation();
      event.detail = event.originalEvent.detail;

      let priceToSubmit = 0;

      const pickGiveSignSymbol = this.getInstrumentModel().getPickGiveIndicator(event.detail.side);

      if (event.type === 'SubmitValidatedPriceAndSize') {
        priceToSubmit = event.detail.price;
      } else {
        priceToSubmit = this.model.get('price');
      }

      // If entering size on the opposite side to the resting order for a pick/give spread,
      // then we must change the sign of the order price before submitting. This will become
      // an entirely new order.
      // eslint-disable-next-line no-mixed-operators
      if (pickGiveSignSymbol && ((pickGiveSignSymbol === '+' && BGC.utils.compareFPNumLT(priceToSubmit, 0))) ||
            (pickGiveSignSymbol === '-' && BGC.utils.compareFPNumGT(priceToSubmit, 0))) {
        priceToSubmit = -priceToSubmit;
      }

      const eventDetail = {
        accountId    : this.model.get('accountId'),
        eventSource  : 'Active Order Row',
        instrumentId : this.model.get('instrument').get('instrumentId'),
        price        : priceToSubmit,
        size         : event.detail.size,
        side         : event.detail.side
      };

      // trigger submission of an order in response to size entry
      this.el.dispatchEvent(new CustomEvent('submitOrder', {detail : eventDetail, bubbles : true}));
      event.target.blur();
    },

    onClickRow () {
      const instrument = this.getInstrumentModel();

      // Only select if not a footprint row

      if (instrument.isInAuction()) {
        // Do not scroll into view or pop OEB
        instrument.trigger('requestSelection', true);
      }
    },

    onClickRemoveFootprint () {
      BGC.dataStore.orderStore.remove(this.model);
    },

    onClickExcelLiveLink () {
      this.getInstrumentModel().sendEnableExcelLiveLink('ActiveOrders', !this.getInstrumentModel().isExcelLiveModeEnabled());
    },

    onClickOrderCancel (event) {
      if ($(event.target).hasClass('cancel-buy')) {
        this.onClickOrderCancelBuy();
      } else {
        this.onClickOrderCancelSell();
      }
    },

    onClickOrderCancelBuy () {
      BGC.ui.viewUtils.cancelOrder(this.getOrderModel(), 'ActiveOrders', 'buy');
    },

    onClickOrderCancelSell () {
      BGC.ui.viewUtils.cancelOrder(this.getOrderModel(), 'ActiveOrders', 'sell');
    },

    restoreExecutionRowExpansionState () {
      // If a new order comes in or is in an expanded state and the order gets updated, we don't want the order execution expanded state to become a collapsed state.
      if (this.orderExecutionRowsExpanded) {
        // It is better to remove them if anything existing already since some of them might need updation as well.
        this.removeOrderExecutionRows();
        this.addOrderExecutionRows();
      }
    },

    createGenericColumnsHtml () {
      let genericColumnsHtml = '';

      // Prepare generic columns HTML for order execution row, this shouldn't have any values set but just the column Ids.
      this.pageLayout.get('genericColumns').forEach(column => {
        // Ignore the total volume column as this is only for instrument rows, not active orders
        if (column.columnId !== 'volume') {
          genericColumnsHtml += `<span class="${column.columnId}"></span>`;
        }
      }, this);

      return genericColumnsHtml;
    },

    addOrderExecutionRows () {
      if (this.counterpartyCount > 1) {
        const genericColumnsHtml = this.createGenericColumnsHtml();

        // eslint-disable-next-line no-restricted-syntax
        for (const counterparty in this.executionsByCounterparty) {
          // eslint-disable-next-line no-prototype-builtins
          if (this.executionsByCounterparty.hasOwnProperty(counterparty)) {
            const orderExecutionRow = new context.OrderExecutionRowView({
              instrument                  : this.getInstrumentModel(),
              counterparty,
              executions                  : this.executionsByCounterparty[counterparty],
              genericColumnsHtml,
              excelLiveLinkEnabled        : this.excelLiveLinkEnabled,
              isSameLEHeightLightRequired : this.rowType === BGC.schemaValidator.OWNERSHIP_MY_FIRM
            });

            this.$el.find('.executions').append(orderExecutionRow.$el);
          }
        }
      }
    },

    removeOrderExecutionRows () {
      this.$el.find('.execution-row').remove();
    },

    onClickOrderExecutionsExpandCollapse () {
      // Click to expand and click to contract
      this.orderExecutionRowsExpanded = !this.orderExecutionRowsExpanded;
      if (this.orderExecutionRowsExpanded) {
        this.addOrderExecutionRows();
        this.$el.find('.fa.fa-caret-down').removeClass('fa-caret-down').addClass('fa-caret-up');
      } else {
        this.removeOrderExecutionRows();
        this.$el.find('.fa.fa-caret-up').removeClass('fa-caret-up').addClass('fa-caret-down');
      }

      this.trigger('change:executionRowsHeightChanged');
    },

    onMouseEnterTradeStatus (event) {
      this.clearStatusHoverTimer();
      if (event.target.textContent.trim()) {
        this.statusHoverTimer = setTimeout(this.onHoverStatusCellTimer.bind(this, event), 1000);
      }
    },

    onMouseLeaveTradeStatus () {
      this.clearStatusHoverTimer();
      theTooltip.hide();
    },

    clearStatusHoverTimer () {
      if (this.statusHoverTimer) {
        clearTimeout(this.statusHoverTimer);

        this.statusHoverTimer = null;
      }
    },

    onHoverStatusCellTimer (event) {
      // Event may have bubbled from target which is one of multiple spans inside the status cell
      // but we want the text of the whole status, so ignore event.target and find it directly
      const statusCell = this.$el.find('.status')[0];
      const tipText = statusCell.textContent.trim();
      const position = {
        // eslint-disable-next-line id-length
        x : event.pageX,
        // eslint-disable-next-line id-length
        y : $(statusCell).offset().top + 2
      };

      this.statusHoverTimer = null;
      theTooltip.hide();
      if (tipText) {
        theTooltip.show(tipText, position);
        this.isShowingStatusTooltip = true;
      }
    },

    clearStatusTooltip () {
      if (this.isShowingStatusTooltip) {
        theTooltip.hide();
      }
    },

    revertSizeInputCell ($inputCell) {
      const order = this.getOrderModel();
      const side = $inputCell.hasClass('buy') ? 'buy' : 'sell';
      const revertSize = order && (order.getSize(side) > 0) ? order.getSize(side) : '';

      // show cancel icon
      $inputCell.next().show();

      // revert order size
      $inputCell.val(revertSize);
    }

  });

  /* order execution view: displays total bought and sold size executed with a given counterparty  */
  context.OrderExecutionRowView = Backbone.View.extend({
    template  : BGC.utils.queryTemplate('#order-execution-row'),
    tagName   : 'div',
    className : 'instrument-row execution-row',

    initialize (options) {
      this.counterparty = options.counterparty;
      this.executions = options.executions;
      this.genericColumnsHtml = options.genericColumnsHtml;
      this.excelLiveLinkEnabled = options.excelLiveLinkEnabled;
      this.isSameLEHeightLightRequired = options.isSameLEHeightLightRequired;
      this.adjustedNomenclature = {
        boughtText : options.instrument.getAdjustedNomenclature('IDS_BOUGHT'),
        soldText   : options.instrument.getAdjustedNomenclature('IDS_SOLD')
      };
      this.render();
    },

    render () {
      this.$el.html(this.template({
        counterparty       : this.counterparty,
        executionStatus    : this.getExecutionStatus(),
        genericColumnsHtml : this.genericColumnsHtml
      }));

      this.$el.find('excel-live-link').toggleClass('enabled', this.excelLiveLinkEnabled);
      this.$el.find('status').toggleClass('same-LE-highlight', this.isSameLEHeightLightRequired);
      this.$el.find('counterparty').toggleClass('same-LE-highlight', this.isSameLEHeightLightRequired);
    },

    getExecutionStatus () {
      let totalBought = 0;
      let totalSold = 0;
      let tradeTotalsString = '';

      // calculate bought/sold totals
      this.executions.forEach(execution => {
        if (execution.tradeSide === BGC.schemaValidator.BUY_SIDE) {
          totalBought += execution.tradeSize;
        } else if (execution.tradeSide === BGC.schemaValidator.SELL_SIDE) {
          totalSold += execution.tradeSize;
        }
      });

      // build trade totals string
      if (totalBought > 0) {
        tradeTotalsString += `${totalBought} ${this.adjustedNomenclature.boughtText}`;
      }
      if (totalBought > 0 && totalSold > 0) {
        tradeTotalsString += ' / ';
      }
      if (totalSold > 0) {
        tradeTotalsString += `${totalSold} ${this.adjustedNomenclature.soldText}`;
      }

      return tradeTotalsString;
    }
  });
}(window.BGC.ui.view, window.BGC.dataStore));
