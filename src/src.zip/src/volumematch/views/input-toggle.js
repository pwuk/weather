import {PolymerElement} from '@polymer/polymer/polymer-element';
import componentTemplate from './input-toggle.template';


const {
  ui: {view: context}, dataStore
} = window.BGC;


class InputToggle extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor () {
    super();
    this.addEventListener('click', this.onToggle.bind(this));
  }

  static get properties () {
    return {
      label : {
        type  : String,
        value : ''
      },
      checked : {
        type               : 'Boolean',
        value              : false,
        reflectToAttribute : true,
        notify             : true
      },

      disabled : {
        type               : 'Boolean',
        value              : true,
        reflectToAttribute : true
      },

      settingName : {
        type  : String,
        value : undefined
      }
    };
  }

  ready () {
    const {userSettingsStore} = dataStore;
    const {settingName} = this;

    // If a boolean setting has been configured, associate the setting property with the toggle control
    if (userSettingsStore && settingName) {
      const setting = userSettingsStore.get(settingName);

      if (typeof setting === 'boolean') {
        this.checked = setting;
      } else {
        this.set('settingName', undefined);
      }
    }
  }

  onToggle (event) {
    const {userSettingsStore} = dataStore;
    const {checked, settingName, disabled} = this;

    if (disabled) {
      event.preventDefault();
    } else {
      this.set('checked', !checked);

      if (userSettingsStore && settingName) {
        userSettingsStore.set(settingName, !checked);
      }
    }
  }
}

customElements.define('input-toggle', InputToggle);
context.InputToggle = InputToggle;
