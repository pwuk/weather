/* global $: false */
/**
 * Created by kcowan on 23/09/2014.
 */
$.widget('ui.dialog', $.extend({}, $.ui.dialog.prototype, {
  _title (title) {
    if (this.options.title) {
      title.html(this.options.title);
    } else {
      title.html('&#160;');
    }
  }
}));
