/* eslint-disable max-lines, max-statements, no-magic-numbers, func-names, max-len, complexity, no-param-reassign, no-plusplus */
/* global BGC: false, $: false, _:false, Backbone: false */

(function (context) {
  const LAYOUT_DEBOUNCE_TIMEOUT = 500;
  const DEFAULT_NAME_COL_WIDTH = 200;
  const {KeyCodes} = BGC.utils;

  /**
   * Responsible for populating provided element with the elements
   * representing tiles. Works by comparing current element layout and provided
   * tiles state.
   *
   * @param {HTMLNode} element - is the element to use as a layout container
   * @class TilesLayout
   */
  const TilesLayout = function (pageLayout, element) {
    if (!(this instanceof TilesLayout)) {
      throw new Error('Constructor called as a function');
    }

    this.pageLayout = pageLayout;
    this.layout = element;
  };

  /**
   * Updates the current element layout state with the given collection of tiles.
   * Element can be in the freshly initialized state or already populated.
   * Method will compare two states and find only required changes to apply.
   *
   * @param {Tiles} tiles - list of tiles representing updated state
   * @method
   */
  TilesLayout.prototype.update = function (tiles) {
    const layoutFragment = document.createDocumentFragment();
    const rootElement = this.layout.parentNode;

    // detach layout element from the DOM
    layoutFragment.appendChild(this.layout);

    let unprocessedInstrumentIds = this.getCurrentInstrumentIdsFromLayout();
    let unprocessedTileIds = this.getCurrentTileIdsFromLayout();

    // ignore spread tiles at the moment and process only standard tiles
    tiles.where({layoutType : 'outright'}).forEach(function (tile) {
      const tileId = tile.get('tileId');
      let lastFoundInstrument = null;
      let currentTileHeader = null;

      // create header element for the current tile if it
      // has not been created yet and add to the end of
      // the layout
      if (_.contains(unprocessedTileIds, tileId)) {
        currentTileHeader = this.layout.querySelector(`.original-header[data-tile='${tile.get('tileId')}']`);
      } else {
        const headerElement = this.createHeaderRow(tile);

        this.layout.appendChild(headerElement);
        currentTileHeader = headerElement;
      }

      tile.getInstruments().forEach(function (instrument) {
        const instrumentId = instrument.get('instrumentId');

        // create instrument element if it has not been created
        // and insert it before instrument that should be next in the layout
        if (_.contains(unprocessedInstrumentIds, instrumentId)) {
          // Tile sort order may have changed since last render,
          // so process previously existing rows in similar way
          const instrumentElement = this.layout.querySelector(`[data-instrument='${instrumentId}']`);
          const elementBefore = lastFoundInstrument || currentTileHeader;

          elementBefore.parentNode.insertBefore(instrumentElement, elementBefore.nextSibling);

          lastFoundInstrument = instrumentElement;
        } else {
          const instrumentElement = this.createInstrumentElement(this.pageLayout, tile, instrument);
          const elementBefore = lastFoundInstrument || currentTileHeader;

          elementBefore.parentNode.insertBefore(instrumentElement, elementBefore.nextSibling);

          // NOTE: this belongs to expand/collapse logic, but it has to be applied here for performance
          // optimisation.
          instrumentElement.classList.toggle('parent-closed', !currentTileHeader.classList.contains('is-open'));
          instrumentElement.classList.toggle('active-tile-filter', currentTileHeader.classList.contains('active-tile-filter'));

          lastFoundInstrument = instrumentElement;
        }

        unprocessedInstrumentIds = _.without(unprocessedInstrumentIds, instrumentId);
      }, this);

      unprocessedTileIds = _.without(unprocessedTileIds, tileId);
    }, this);

    // remove tiles and instruments that are not on the given list of tiles
    // but exist in the layout
    this.removeInstrumentElements(unprocessedInstrumentIds);
    this.removeTileElements(unprocessedTileIds);

    // attach layout element to the DOM
    rootElement.appendChild(this.layout);
  };

  /**
   * Returns a list of instrument ids that have
   * been added to the layout
   *
   * @returns {Array[String]}
   * @method
   */
  TilesLayout.prototype.getCurrentInstrumentIdsFromLayout = function () {
    return _.map(this.layout.querySelectorAll('[data-instrument]'), instrumentElement => instrumentElement.getAttribute('data-instrument'));
  };

  /**
   * Returns a list of tile ids that
   * have been added to the layout.
   *
   * @return {Array[String]}
   * @method
   */
  TilesLayout.prototype.getCurrentTileIdsFromLayout = function () {
    return _.map(this.layout.querySelectorAll('.original-header[data-tile]'), headerElement => headerElement.getAttribute('data-tile'));
  };

  /**
   * Removes instruments with the given ids from the layout.
   *
   * @param {Array[String]} elementIds
   * @method
   */
  TilesLayout.prototype.removeInstrumentElements = function (elementIds) {
    elementIds.forEach(function (instrumentId) {
      this.layout.querySelector(`[data-instrument='${instrumentId}']`).remove();
    }, this);
  };

  /**
   * Removes elements related to the given tile ids (headers, any left instruments)
   * from the layout.
   *
   * @param {Array[String]} tileIds
   * @method
   */
  TilesLayout.prototype.removeTileElements = function (tileIds) {
    tileIds.forEach(function (tileId) {
      this.layout.querySelector(`[data-tile='${tileId}']`).remove();
    }, this);
  };

  /**
   * Creates and configures a new header row for provided tile.
   *
   * @param {Tile} tile
   * @return {HTMLNode} vm-header-row
   * @method
   */
  TilesLayout.prototype.createHeaderRow = function (tile) {
    const headerElement = document.createElement('vm-header-row');
    const isVmInProgress = this.pageLayout.areAnyInstrumentsInAuction();
    const shouldBeOpen = (isVmInProgress && tile.areAnyInstrumentsInAuction()) || (!isVmInProgress && tile.doAnyInstrumentsHaveIndicativeMids());

    headerElement.tile = tile;
    headerElement.classList.add('header-row', 'original-header');
    headerElement.classList.toggle('is-open', shouldBeOpen);
    headerElement.setAttribute('data-tile', tile.get('tileId'));

    return headerElement;
  };

  /**
   * Creates and configures a new instrument element for provided instrument.
   *
   * @param {Tile} tile - tile containing the instrument
   * @param {Instrument} instrument
   * @return {HTMLNode} vm-instrument-row
   * @method
   */
  TilesLayout.prototype.createInstrumentElement = function (pageLayout, tile, instrument) {
    const instrumentElement = new context.VmInstrumentRow({
      pageLayout,
      model     : instrument,
      rowType   : 'instrument',
      tileModel : tile,
      container : this
    });

    instrumentElement.setAttribute('data-instrument', instrument.get('instrumentId'));
    instrumentElement.setAttribute('data-tile', tile.get('tileId'));

    return instrumentElement;
  };

  TilesLayout.prototype.deleteContentRow = function (row) {
    // For this type of row container, we don't need to do anything here...
    // The row will remove itself from the DOM when necessary and trigger a recalcLayout,
    // which will (when the coalescence timer tiggers it) cause this layout to update
    // and re-flow. When it does so, it will only include active instruments from the tile.
    return row;
  };

  /**
   * Returns currently selected instrument row.
   *
   * @returns {VmInstrumentRow}
   * @method
   */
  TilesLayout.prototype.getSelectedRow = function () {
    return this.selectedRow;
  };

  /**
   * Opens tile container.
   *
   * @method
   */
  TilesLayout.prototype.openTile = function (tileId) {
    const tileHeader = this.layout.querySelector(`.original-header[data-tile='${tileId}']`);

    if (tileHeader && !tileHeader.classList.contains('is-open')) {
      tileHeader.classList.toggle('is-open', true);

      _.each(this.layout.querySelectorAll(`vmtile-instrument-row[data-tile='${tileId}']`), element => {
        element.classList.toggle('parent-closed', false);
      });

      $(this.layout).trigger('recalcLayout');
    }
  };

  /**
   * Gets all the child nodes in the provided element and
   * sorts them into columns, that don't exceed parent height.
   *
   * @param {HTMLNode} element
   * @class ColumnFlow
   */
  const ColumnFlow = function (element) {
    if (!(this instanceof ColumnFlow)) {
      throw new Error('Constructor called as a function');
    }

    this.layout = element;
    this.rootElement = this.layout.parentNode;
    this.ensureInitialColumnExists();
  };

  /**
   * Creates at least one column element if none have been
   * previously added.
   *
   * @method
   */
  ColumnFlow.prototype.ensureInitialColumnExists = function () {
    if (!this.layout.getElementsByClassName('column').length) {
      this.layout.appendChild(this.createColumnElement());
    }
  };

  /**
   * Finds how many columns allowed to be displayed within layout.
   *
   * @return {Number}
   * @method
   */
  ColumnFlow.prototype.getAllowedColumnCount = function () {
    const layoutWidth = this.layout.offsetWidth;
    let maxNameWidth = 0;
    const $columns = $(this.layout).find('.column');
    const $visibleTileHeaders = $(_.filter(this.layout.querySelectorAll('vm-header-row'), headerElem => headerElem.cachedLayoutProperties &&
          headerElem.cachedLayoutProperties.isVisible &&
          headerElem.cachedLayoutProperties.visibleCells.length > 0));
    const $visibleRows = $(_.filter(this.layout.querySelectorAll('vmtile-instrument-row'), rowElem => rowElem.cachedLayoutProperties && rowElem.cachedLayoutProperties.isVisible));
    let $nameCells = $visibleTileHeaders.find('.name');
    const that = this;

    this.columnWidth = 0;

    // Collapse header content down to smallest required width so we can measure it
    $columns.css({width : 0, 'min-width' : 0});
    $nameCells.css({'min-width' : '-webkit-fit-content', flex : 'none'});

    // Need to allow space for "(cont.)" text used on continuation headers.
    // This is added via styling (it uses a psuedo-selector to inject a pseudo-element using :after)
    $visibleTileHeaders.addClass('continue-header').css({'min-width' : '-webkit-fit-content'});
    $visibleTileHeaders.each((index, headerRow) => {
      const contentWidth = _.reduce(headerRow.cachedLayoutProperties.visibleCells, (width, element) => width + $(element).outerWidth(true), 0);

      // contentWidth += headerRow.querySelector(".collapse-toggle").offsetWidth;

      that.columnWidth = Math.max(that.columnWidth, contentWidth);

      maxNameWidth = Math.max(maxNameWidth, headerRow.cachedLayoutProperties.nameCell ? $(headerRow.cachedLayoutProperties.nameCell).outerWidth() : DEFAULT_NAME_COL_WIDTH);
    });

    // Clear the temporarily imposed styling from the header elements after measuring
    $nameCells.css({'min-width' : '', flex : ''});
    $visibleTileHeaders.removeClass('continue-header').css({'min-width' : ''});

    // Now do similar to get the max width of name cells in the instrument rows
    $nameCells = $visibleRows.find('.name.instrument-row-cell');
    $nameCells.css({'min-width' : '-webkit-fit-content', flex : 'none'});
    $visibleRows.css({'min-width' : '-webkit-fit-content'});
    $visibleRows.each((index, rowElement) => {
      maxNameWidth = Math.max(maxNameWidth, rowElement.cachedLayoutProperties.nameCell ? $(rowElement.cachedLayoutProperties.nameCell).outerWidth() : DEFAULT_NAME_COL_WIDTH);
    });

    // Clear the temporarily imposed styling from the row elements after measuring
    $nameCells.css({'min-width' : '', flex : ''});
    $visibleRows.css({'min-width' : ''});

    // Add the max name cell column width to the cell column widths for other header cells encountered
    this.columnWidth += maxNameWidth;

    // Need to keep a sensible default in case there are no visible tiles in open state
    if ($visibleTileHeaders.length === 0 || this.columnWidth < DEFAULT_NAME_COL_WIDTH) {
      this.columnWidth = Math.max(DEFAULT_NAME_COL_WIDTH, $columns.length > 0 ? $columns[0].offsetWidth : layoutWidth);
    }

    // Set the minimum for the columns to the calculated necessary width.
    // Actual display width will be set later as a %age of available width, according to number of columns.
    $columns.css({'min-width' : this.columnWidth});

    return Math.floor(layoutWidth / this.columnWidth);
  };

  /**
   * Finds all child nodes that currently not in a column and
   * moves them to the last column in the layout.
   *
   * @method
   */
  ColumnFlow.prototype.moveElementsWithoutParentColumn = function () {
    const children = $(this.layout).children(':not(.column)');
    const lastColumn = $(this.layout).find('.column:last');

    lastColumn.append(children);
  };

  /**
   * Detaches layout element from the DOM.
   *
   * @method
   */
  ColumnFlow.prototype.detachLayout = function () {
    const layoutFragment = document.createDocumentFragment();

    layoutFragment.appendChild(this.layout);
  };

  /**
   * Attaches layout element to the DOM
   *
   * @method
   */
  ColumnFlow.prototype.attachLayout = function () {
    this.rootElement.appendChild(this.layout);
  };

  /**
   * Removes all elements that are simply clones of tile headers. The clones
   * are used at the top of columns to display that a list of instruments
   * below is the part of a tile, started in one of the previous columns.
   *
   * @method
   */
  ColumnFlow.prototype.removeContinuedHeaders = function () {
    _.invoke(this.layout.querySelectorAll('.continue-header'), 'remove');
  };

  /**
   * Returns column layout changed state.
   * Layout considered changed if amount of columns has changed.
   *
   * @return {Boolean}
   * @method
   */
  ColumnFlow.prototype.isLayoutChanged = function () {
    return this.columnLayoutChanged;
  };

  /**
   * Creates and returns a new column element.
   *
   * @return {HTMLNode}
   * @method
   */
  ColumnFlow.prototype.createColumnElement = function () {
    const column = document.createElement('div');

    column.className = 'column';

    return column;
  };

  /**
   * Creates a copy of provided header element and sets "continued header" attributes
   * to it.
   *
   * @param {HTMLNode} originalHeader
   * @return {HTMLNode}
   * @method
   */
  ColumnFlow.prototype.createContinuedHeaderFor = function (originalHeader) {
    const continuedHeader = originalHeader.cloneNode(true);

    continuedHeader.tile = originalHeader.tile;
    continuedHeader.classList.add('continue-header');

    return continuedHeader;
  };

  /**
   * Caches visibility state of all column children for later reuse.
   * This is required since it's impossible to get styling properties
   * when layout is detached from the DOM tree.
   *
   * @method
   */
  ColumnFlow.prototype.cacheRowsVisibility = function () {
    _.each(this.layout.querySelectorAll('.column > *'), rowElement => {
      const isVisible = rowElement.classList.contains('header-row') ? $(rowElement).is(':visible') : rowElement.isVisible && !rowElement.getAttribute('is-filtered');

      rowElement.cachedLayoutProperties = rowElement.cachedLayoutProperties || {};
      rowElement.cachedLayoutProperties.isVisible = isVisible;
      if (rowElement.classList.contains('header-row')) {
        if (isVisible && !rowElement.classList.contains('continue-header') &&
          (rowElement.classList.contains('active-tile-filter') || rowElement.classList.contains('is-open'))) {
          rowElement.cachedLayoutProperties.visibleCells = [];
          rowElement.cachedLayoutProperties.nameCell = undefined;

          // First element inside header row is the progress bar.
          // Second is a <div> containing the header cells
          const headerCells = rowElement.children[1] ? rowElement.children[1].children || [] : [];

          _.each(headerCells, headerCell => {
            const $headerCell = $(headerCell);

            if (headerCell.classList.contains('name')) {
              rowElement.cachedLayoutProperties.nameCell = headerCell;
            } else if ($headerCell.is(':visible')) {
              rowElement.cachedLayoutProperties.visibleCells.push(headerCell);
            }
          });
        } else {
          rowElement.cachedLayoutProperties.visibleCells = [];
        }
      } else if (isVisible) {
        rowElement.cachedLayoutProperties.nameCell = rowElement.querySelector('.name');
      }
    });
  };

  /**
   * Returns amount of rows that can fit within one column.
   *
   * @param {Number} columnCount
   * @return {Number}
   * @method
   */
  ColumnFlow.prototype.getElementsPerColumnCount = function (columnCount) {
    let continuedHeadersRequired = 0;

    // find only visible children elements
    const layoutVisibleRows = _.filter(this.layout.querySelectorAll('.column > *'), element => element.cachedLayoutProperties && element.cachedLayoutProperties.isVisible);
    const elementsPerColumn = Math.ceil(layoutVisibleRows.length / columnCount);

    // account for additional continued headers
    for (let columnIndex = 1; columnIndex < columnCount; columnIndex++) {
      const columnElement = layoutVisibleRows[elementsPerColumn * columnIndex - continuedHeadersRequired];

      if (columnElement && !columnElement.classList.contains('header-row')) {
        continuedHeadersRequired++;
      }
    }

    // return elements count per column taking continued headers into account
    return Math.ceil((layoutVisibleRows.length + continuedHeadersRequired) / columnCount);
  };

  /**
   * Ensures that all required columns exist. For instance if layout
   * can fit three columns, all three column elements must be created.
   * If column amount changes,  additional columns must be created or removed.
   *
   * @param {Number} columnCount - amount of columns that must be represented in the layout
   * @method
   */
  ColumnFlow.prototype.ensureColumnsExistFor = function (columnCount) {
    const currentColumnElements = this.layout.getElementsByClassName('column');
    const columnDifference = columnCount - currentColumnElements.length;

    this.columnLayoutChanged = false;

    // if layout contains less columns than required, make
    // sure that additional columns created
    if (columnDifference > 0) {
      _(columnDifference).times(function () {
        this.layout.appendChild(this.createColumnElement());
      }, this);

      this.columnLayoutChanged = true;
      $(this.layout).find('.column').css({'min-width' : this.columnWidth});
    } else if (columnDifference < 0) {
      // if layout contains more columns than required, make
      // sure that additional columns removed
      _(Math.abs(columnDifference)).times(() => {
        const lastColumn = _.last(currentColumnElements);
        const previousColumn = lastColumn.previousSibling;

        // move column children to previous sibling if exists
        // eslint-disable-next-line no-unmodified-loop-condition
        while (previousColumn && lastColumn.firstChild) {
          previousColumn.appendChild(lastColumn.firstChild);
        }

        _.last(currentColumnElements).remove();
      }, this);

      this.columnLayoutChanged = true;
    }
  };

  /**
   * Flows children rows within existing columns.
   *
   * @param {Number} columnCount
   * @method
   */
  ColumnFlow.prototype.flowElementsWithinColumnCount = function (columnCount) {
    const layoutColumns = this.layout.getElementsByClassName('column');
    const elementsPerColumn = this.getElementsPerColumnCount(columnCount);

    if (this.elementsPerColumn !== elementsPerColumn) {
      // Will cause a recalcLayout to main view and adjust window height
      this.columnLayoutChanged = true;
      this.elementsPerColumn = elementsPerColumn;
    }

    $(this.layout).find('.column').css({width : `${100 / columnCount}%`});

    _.each(layoutColumns, function (column, index) {
      const visibleChildren = _.filter(column.children, child => child.cachedLayoutProperties && child.cachedLayoutProperties.isVisible);
      let childDifference = elementsPerColumn - visibleChildren.length;
      const nextColumn = column.nextSibling;
      let visibleElementsMoved = 0;

      // create continued header if first element  in the column is not header element
      if (index !== 0 && visibleChildren[0] && !visibleChildren[0].classList.contains('header-row')) {
        const previousColumnHeaders = column.previousSibling.getElementsByClassName('header-row');

        if (previousColumnHeaders.length) {
          column.insertBefore(this.createContinuedHeaderFor(_.last(previousColumnHeaders)), column.firstChild);
        }

        childDifference--;
      }

      if (nextColumn) {
        // move elements from the next column if current column should contain more children than it
        // has at the moment
        if (childDifference > 0) {
          while (visibleElementsMoved < childDifference && nextColumn.firstChild) {
            if (nextColumn.firstChild.cachedLayoutProperties &&
              nextColumn.firstChild.cachedLayoutProperties.isVisible) {
              visibleElementsMoved++;
            }

            column.appendChild(nextColumn.firstChild);
          }
        } else if (childDifference < 0) {
          // move elements to the next column if current column should contain less children than it
          // has at the moment
          while (visibleElementsMoved < Math.abs(childDifference)) {
            if (column.lastChild.cachedLayoutProperties && column.lastChild.cachedLayoutProperties.isVisible) {
              visibleElementsMoved++;
            }

            nextColumn.insertBefore(column.lastChild, nextColumn.firstChild);
          }
        }
      }
    }, this);
  };

  /**
   * Reflows elements in the layout.
   *
   * @method
   */
  ColumnFlow.prototype.update = function () {
    // cache row visibility and columns count, since it won't be available when layout element
    // is detached from the DOM tree
    this.cacheRowsVisibility();

    const allowedColumnCount = this.getAllowedColumnCount();

    this.moveElementsWithoutParentColumn();
    this.detachLayout();
    this.removeContinuedHeaders();
    this.ensureColumnsExistFor(allowedColumnCount);
    this.flowElementsWithinColumnCount(allowedColumnCount);
    this.attachLayout();
  };

  /**
   * Handles key press events that are relevant to the tiles layout.
   *
   * @param {TilesLayout}
   * @class LayoutKeyHandler
   */
  const LayoutKeyHandler = function (tilesLayout) {
    if (!(this instanceof LayoutKeyHandler)) {
      throw new Error('Constructor called as a function');
    }

    this.layout = tilesLayout;
    this.handlers = {};

    this.registerKeyHandlers();
    this.subscribeToKeyEvents();
  };

  /**
   * Registers keys that should be handled.
   *
   * @method
   */
  LayoutKeyHandler.prototype.registerKeyHandlers = function () {
    this.handlers[KeyCodes.F6] = this.openPopup.bind(this, 'buy');
    this.handlers[KeyCodes.F7] = this.openPopup.bind(this, 'sell');
    this.handlers[KeyCodes.UP] = this.navigate.bind(this, KeyCodes.UP);
    this.handlers[KeyCodes.DOWN] = this.navigate.bind(this, KeyCodes.DOWN);
    this.handlers[KeyCodes.LEFT] = this.navigate.bind(this, KeyCodes.LEFT);
    this.handlers[KeyCodes.RIGHT] = this.navigate.bind(this, KeyCodes.RIGHT);
  };

  /**
   * Subscribers to global/window keydown events and handles them
   * if a handler is found.
   *
   * @method
   */
  LayoutKeyHandler.prototype.subscribeToKeyEvents = function () {
    window.addEventListener('keydown', event => {
      if (_.has(this.handlers, event.keyCode) &&
        !!BGC.dataStore.userSettingsStore.get('VmTileViewsUseCompactLayout')) {
        this.handlers[event.keyCode]();
        event.preventDefault();
      }
    });
  };

  /**
   * Opens in-place order entry bar for the given side.
   *
   * @param {String} side
   * @method
   */
  LayoutKeyHandler.prototype.openPopup = function (side) {
    const selectedRow = this.layout.getSelectedRow();
    const instrument = selectedRow && selectedRow.getInstrumentModel();
    const inplaceOEB = context.inplaceOEB.getInstance();

    if (instrument && !instrument.get('inactive') && !inplaceOEB.isOpen) {
      this.layout.getSelectedRow().openOEBPopup(side);
    }
  };

  /**
   * Navigates from one row to another in response to the arrow keys
   */
  LayoutKeyHandler.prototype.navigate = function (direction) {
    const selectedRow = this.layout.getSelectedRow();
    let navRow = null;

    if (!selectedRow) {
      return;
    }

    switch (direction) {
      case KeyCodes.UP:
      case KeyCodes.DOWN:
        navRow = selectedRow.findNextVisibleRowVertically(direction);
        if (navRow && navRow !== selectedRow) {
          BGC.ui.viewUtils.setSelectionLockedFlag(navRow, true);
          navRow.selectRow();
        }
        break;
      case KeyCodes.LEFT:
      case KeyCodes.RIGHT:
        navRow = selectedRow.findNextVisibleRowHorizontally(direction);
        if (navRow && navRow !== selectedRow) {
          BGC.ui.viewUtils.setSelectionLockedFlag(navRow, true);
          navRow.selectRow();
        }
        break;
      default:
        break;
    }
  };

  context.ColumnLayoutView = Backbone.View.extend({
    className : 'tiles-column-layout',
    events    : {
      'click .collapse-toggle' : 'onHeaderCollapseToggle',
      recalcLayout             : 'onRecalcLayout',
      keydown                  : 'onKeyDown',
      'mouseleave .column'     : 'onMouseLeave'
    },

    initialize (options) {
      this.tiles = options.tiles;
      this.pageLayout = options.pageLayout;
      this.dataStore = options.dataStore;
      this.initializeLayouts();

      const that = this;
      const initialRender = function () {
        that.render();
        that.applyLiveModeFilter();
      };

      const debounceInitRender = _.debounce(initialRender, LAYOUT_DEBOUNCE_TIMEOUT);

      this.debounceRender = _.debounce(this.render, LAYOUT_DEBOUNCE_TIMEOUT);

      this.updateFlow = this.updateFlow.bind(this);
      this.debounceUpdateFlow = _.debounce(this.updateFlow, LAYOUT_DEBOUNCE_TIMEOUT);

      this.onWindowResize = this.onWindowResize.bind(this);

      this.listenTo(this.tiles, 'add remove change change:sortOrder change:instruments change:instrumentRemoved', this.debounceRender);
      this.listenTo(this.tiles, 'change:active', this.tileActiveChanged);
      this.listenTo(this.pageLayout, 'change:isMoveableMidEnabled', this.render);
      this.listenTo(this.pageLayout, 'change:brokerLiveMode change:traderLiveMode', this.applyLiveModeFilter);

      // listen to account selection change to adjust the view of the rows
      // (which only show my active orders for the currently selected account)
      if (this.dataStore.isSalesTraderMode()) {
        this.listenTo(this.dataStore, 'accountSelectionChanged', this.onAccountSelectionChanged);
      }

      debounceInitRender();

      $(window).on('resize', this.onWindowResize);
    },

    initializeLayouts () {
      const layoutElement = $('<div/>', {class : 'layout'});

      this.$el.append(layoutElement);
      this.tilesLayout = new TilesLayout(this.pageLayout, layoutElement[0]);
      this.columnLayout = new ColumnFlow(layoutElement[0]);
      this.layoutKeyHandler = new LayoutKeyHandler(this.tilesLayout);
    },

    render () {
      const logContext = `VM: ${document.title}`;

      $(this.el).toggleClass('moveable-mids-enabled', this.pageLayout.get('isMoveableMidEnabled'));

      BGC.logger.logInformation(logContext, 'In ColumnLayoutView.render()');

      this.tilesLayout.update(this.tiles);
      this.updateFlow();
      this.$el.trigger('recalcLayout');
    },

    onWindowResize () {
      this.isWindowResizing = true;
      this.debounceUpdateFlow();
    },

    updateFlow () {
      // Allow free resizing of layout area within natural layout width
      // in order to get a realistic result for minimum column sizes
      this.$el.css('min-width', '');

      this.columnLayout.update();

      const cols = this.el.getElementsByClassName('column');
      const colsWidth = _.reduce(cols, (width, col) => width + parseInt($(col).css('min-width'), 10), 0);

      // Restore a min width based on the newly calculated min width for columns
      // and the newly calculated/created number of columns
      this.$el.css('min-width', colsWidth);

      if (this.columnLayout.isLayoutChanged() || this.isWindowResizing) {
        this.$el.trigger('recalcLayout');
      }

      this.isWindowResizing = false;
      this.pageLayout.notifyAuctionPopulationStepCompleted();
    },

    onAccountSelectionChanged () {
      const rows = this.el.getElementsByTagName('vmtile-instrument-row');
      let recalcLayout = false;

      _.each(rows, row => {
        // We only show (our own) in-place order for the currently selected account.
        // If this row has an own order, we need to tell it to re-render in the new context.
        if (row.onAccountSelectionChanged()) {
          recalcLayout = true;
        }
      });

      if (recalcLayout) {
        this.updateFlow();
      }
    },

    onRecalcLayout (event) {
      if (event.target !== this.$el[0]) {
        this.debounceUpdateFlow();
      }
    },

    onHeaderCollapseToggle (event) {
      this.toggleTileOpenState($(event.target).parents('[data-tile]').attr('data-tile'));
    },

    toggleTileOpenState (tileId) {
      const headerRow = this.$el.find(`.original-header[data-tile='${tileId}']`);

      headerRow.toggleClass('is-open');
      this.$el.find(`vmtile-instrument-row[data-tile='${tileId}']`).toggleClass('parent-closed', !headerRow.hasClass('is-open'));

      this.debounceUpdateFlow();
      this.$el.trigger('recalcLayout');
    },

    tileActiveChanged (tile) {
      const tileId = tile.get('tileId');
      const $tile = this.$el.find(`.original-header[data-tile='${tileId}']`);
      const tileHeaderClosed = !$tile.hasClass('is-open');
      const isVmInProgress = this.pageLayout.areAnyInstrumentsInAuction();
      const shouldBeOpen = (isVmInProgress && tile.areAnyInstrumentsInAuction()) || (!isVmInProgress && tile.doAnyInstrumentsHaveIndicativeMids());

      if (!tile.get('active')) {
        // deactivate the filtering for this tile. don't set the filter active for the tile
        // if it wasn't active at the time the filter was set.
        $tile.removeClass('active-tile-filter');
        this.$el.find(`vmtile-instrument-row[data-tile='${tile.get('tileId')}']`).removeClass('active-tile-filter');
      }

      if ((shouldBeOpen && tileHeaderClosed) || (!shouldBeOpen && !tileHeaderClosed)) {
        this.toggleTileOpenState(tileId);
      }
    },

    onMouseLeave () {
      const selectedRow = this.tilesLayout.getSelectedRow();

      if (selectedRow && !BGC.ui.viewUtils.isSelectionLocked(this.$el)) {
        selectedRow.clearSelection();
        $(selectedRow).trigger('selectInstrument', [selectedRow, undefined]);
      }
    },

    remove () {
      $(window).off('resize', this.updateFlow);
      // eslint-disable-next-line prefer-rest-params
      Backbone.View.prototype.remove.apply(this, arguments);
    },

    applyLiveModeFilter () {
      const isFiltered = this.pageLayout.getLiveModeForActiveUser() !== BGC.enums.EVMShowLiveMode.eShowAll;

      this.tiles.forEach(function (tile) {
        const $tile = this.$el.find(`.original-header[data-tile='${tile.get('tileId')}']`);
        const $rows = this.$el.find(`vmtile-instrument-row[data-tile='${tile.get('tileId')}']`);

        // close the tile if filtering is selected, open it if Show All selected
        $tile.toggleClass('is-open', !isFiltered && tile.get('active'));
        $rows.toggleClass('parent-closed', !$tile.hasClass('is-open'));

        // set if the filtering is active or not.
        $tile.toggleClass('active-tile-filter', isFiltered && tile.get('active'));
        $rows.toggleClass('active-tile-filter', isFiltered && tile.get('active'));
      }, this);

      this.debounceUpdateFlow();
      this.$el.trigger('recalcLayout');
    }
  });
}(window.BGC.ui.view));
