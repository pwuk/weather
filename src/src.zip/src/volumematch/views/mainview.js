/* eslint-disable max-lines, func-names, no-param-reassign, max-statements, no-magic-numbers, max-len */
/* global BGC: false, $: false, _:false, Backbone: false */

// /////////////////////////////////////////////////////////////////////////////
// file mainview.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

import {get, hasIn} from 'lodash';
import {isWebDeployed} from '../bgc';
import broadcastAuctionWindowState from './windowstatehelper';
import getApp from '../index';

// Window is being resized. Note that this event may either be triggered once at the end of a resize operation
// or several times during the resize depending on the host browser implementation.
$(window).resize(() => {
  BGC.ui.view.resize();
});

(function (context) {
  let waitingForMainViewAdjustmentAnimationFrame = false;

  function reCalculateInplaceOEBPosition () {
    const inplaceOEB = context.inplaceOEB.getInstance();

    if (inplaceOEB.isOpen) {
      if (BGC.dataStore.userSettingsStore.get('enableCentreOEDB')) {
        inplaceOEB.calcCentrePositioning();
      } else {
        inplaceOEB.calcPositioning();
      }
    }
  }

  function triggerMainViewScrollingAdjustments (areOverflowsToBeAdjusted) {
    // eslint-disable-next-line no-use-before-define
    let doAdjustOverflows = areOverflowsToBeAdjusted || doAdjustOverflows;

    if (!waitingForMainViewAdjustmentAnimationFrame) {
      window.requestAnimationFrame(() => {
        if (doAdjustOverflows) {
          doAdjustOverflows = false;

          // ensure that elements that require scrollbars adapt to the new size
          context.mainView.updateElementsWithOverflow();
        }

        reCalculateInplaceOEBPosition();

        waitingForMainViewAdjustmentAnimationFrame = false;
      });

      waitingForMainViewAdjustmentAnimationFrame = true;
    }
  }

  // Fixes issue with horizontal overflow auto when scrollbar overlaps content
  function updateElementHorizontalOverflow (element) {
    const overflowX = element.clientWidth < element.scrollWidth ? 'scroll' : 'hidden';

    if (overflowX !== element.style.overflowX) {
      element.style.overflowX = overflowX;
    }
  }

  context.MainView = Backbone.View.extend({
    events : {
      selectInstrument    : 'onSelectInstrument',
      recalcLayout        : 'onRecalcLayout',
      'dragstart .matrix' : 'onDragStart',
      'dragend .matrix'   : 'onDragEnd',
      selectSpread        : 'onSelectSpread'
    },

    initialize (options) {
      const that = this;
      const $body = $('body');
      const {mainWindow} = getApp();

      // initialize view attributes
      this.dataStore = options.dataStore;
      this.baseRootFontSize = parseInt($('html').css('fontSize'), 10);
      this.rootFontSize = this.baseRootFontSize;
      this.contentHeight = 0;
      this.contentWidth = 0;
      this.ZOOM_STEP = 12.5;
      this.MAX_MATRIXVM_WIDTH_ADJUSTMENT = 1.5;
      this.MAX_TILEVM_WIDTH_ADJUSTMENT = 2;
      this.MAX_WIDTH = 1200;
      this.recalcLayoutTimer = null;
      this.hasInitialized = false;
      this.hasOwnTradedInLastSession = false;
      this.hasFirmTradedInLastSession = false;
      this.updateElementsWithOverflowTimer = null;
      this.centreOnApp = false;

      const {userSettingsStore, auctionHistory} = this.dataStore;

      this.$el.toggleClass('auction-active', this.model.areAnyInstrumentsInAuction());
      this.$el.find('orders-and-trades-toolbar').toggleClass('auction-active', this.model.areAnyInstrumentsInAuction());


      // listen for changes in model attributes
      this.model.on('change:contentState', this.onActivationStateChanged, this);
      auctionHistory.on('add', this.onTrade, this);

      // ...and global selection
      this.listenTo(BGC.ui.selectionManager, 'selectionChanged', this.onSelectionChanged);

      // / TODO: Stubbed out for Polymer3
      // create order entry bar view
      context.dockedOrderEntryView = new context.DockedOrderEntryView({
        el         : this.$el.find('.order-entry-bar')[0],
        pageLayout : this.model,
        dataStore  : this.dataStore
      });

      // check to see if a spreads view should be created
      if (this.model.hasMatrices()) {
        // At present, spread creation is tied to matrix view, so only allow if there's a matrix
        this.model.on('change:allowSpreadCreation', function () {
          this.updateVMSpreadsViews();
        }, this);

        this.updateVMSpreadsViews();
      }

      if (this.dataStore.isBrokerMode()) {
        // hide tab control in broker modew
        this.$el.find('.auction-view').addClass('broker-mode');

        // disable drag and drop in broker mode
        this.$el.find('.auction-view').attr('draggable', false);
      }

      this.CreateTabViews();

      // Listen to order-related requests bubbling up from in-place OEB
      $body.on('cancelActiveOrder', this.handleCancelActiveOrder);
      $body.on('submitOrderAtMid', this.handleSubmitOrderAtMid);
      $body.on('submitOrder', this.handleSubmitOrder);
      this.ShowHideTabControlForActiveAccountType();

      // Create the accounts bar if necessary
      if (this.dataStore.isSalesTraderMode()) {
        this.ensureAccountRelatedControlsAreDisplayed();
      }

      // Create the matrix layout - the holds the outright and linked spread matrices
      this.createMatrixLayout();

      this.$el.find('.tiles').sortable({
        cursor : 'move',
        handle : '.header-row, .axis.x',
        update : this.saveTilesOrder.bind(this)
      });

      // Create the spreads layout - this holds a 'single' custom spreads tile view
      if (this.dataStore.userSettingsStore.get('displayCustomSpreads')) {
        this.createSpreadLayout();
      } else {
        const spreadViewWrapper = this.$el.find('.spread-views-wrapper');

        if (spreadViewWrapper) {
          spreadViewWrapper.hide();
        }
      }

      this.listenTo(userSettingsStore, 'change:tilesOrder', this.restoreTilesOrder);
      this.restoreTilesOrder();

      this.listenTo(userSettingsStore, 'change:zoomLevel', this.updateRootFontSize);
      this.updateRootFontSize(true);


      // If the page is configured to retain auction history, create a stack layout to persist previous auction
      // views, otherwise continue to use the dynamic tiles layout
      if (userSettingsStore.get('retainHistory')) {
        this.createStackLayout();
      } else {
        this.updateTilesLayout();
      }

      // update order entry views when upsizing mode changes
      this.listenTo(this.model, 'change:upsizingMode', () => {
        context.dockedOrderEntryView.requestRender();
      });

      // listen to filter changes...
      this.listenTo(this.model, 'change:brokerLiveMode change:traderLiveMode', this.applyLiveModeFilter, this);

      this.listenTo(this.model, 'change:isMoveableMidEnabled', function () {
        this.$el.toggleClass('moveable-mids-active', this.model.get('isMoveableMidEnabled'));
      }, this);

      // recalc layout if the Excel Add-in enable state changes to dynamically show or hide the
      // tab view control for a broker user
      if (this.dataStore.isBrokerMode()) {
        this.listenTo(this.model, 'change:isExcelAddInEnabled', this.onRecalcLayout);
      }

      // set page specific class for ui styling
      $body.addClass(this.model.get('pageId'));
      $body.addClass(this.model.get('businessConfig'));
      $body.addClass(BGC.ui.theme.getBrandId());

      // Deal with re-positioning of floating OEB when auction content is scrolled
      const auctionScrollContainer = this.el.querySelector('.auction-view .scroll-container');

      auctionScrollContainer.addEventListener('scroll', triggerMainViewScrollingAdjustments);

      // force re-calculation of main layout
      this.recalcLayout();

      // to prevent the VM start notification popup from falsely appearing when a page
      // with a running auction is opened, we set a timer and allow the popup to appear
      // if we are inside that timer interval
      window.setTimeout(this.viewInitializedTimerExpired.bind(this), 5000);

      // Set any window options persisted to the user setting store
      mainWindow.updateOptions({alwaysOnTop : !!userSettingsStore.get('vmAlwaysOnTop')});

      this.listenTo(userSettingsStore, 'change:vmAlwaysOnTop', () => {
        mainWindow.updateOptions({alwaysOnTop : !!userSettingsStore.get('vmAlwaysOnTop')});
      });

      // Send initial trader looking event
      broadcastAuctionWindowState();

      document.addEventListener('visibilitychange', () => {
        broadcastAuctionWindowState();
      });

      // OpenFin deployed...
      if (BGC.openfin.isOpenFinDeployed()) {
        const mainOpenFinWindow = BGC.openfin.getMainWindow();

        // Add window event listeners.
        BGC.openfin.addOpenFinEventListener('main-window-restored', () => {
          // Stop any auto-close timer.
          that.stopOpenFinWindowAutoClose();

          BGC.logger.logInformation('', 'OpenFin window Restored', true);

          // Force a layout recalculation now that the window has been restored to
          // its normal dimensions.
          that.recalcLayout();

          // Notify trader looking that the window has been restored.
          BGC.ui.viewUtils.sendTraderLookingEvent('wndRestored');
        });

        mainOpenFinWindow.addEventListener('maximized', () => {
          BGC.logger.logInformation('', 'OpenFin window Maximized', true);

          // Notify trader looking that the window has been maximised and thus
          // potentially restored.
          BGC.ui.viewUtils.sendTraderLookingEvent('wndRestored');
        });

        mainOpenFinWindow.addEventListener('minimized', () => {
          BGC.logger.logInformation('', 'OpenFin window Minimized', true);

          // Notify trader looking that the window has been minimised.
          BGC.ui.viewUtils.sendTraderLookingEvent('wndMinimized');
        });

        // If running under OpenFin, we control our own window's Always on Top setting.
        // Initialize it now and listen for changes so we can react accordingly
        let openfinAOT = !!userSettingsStore.get('vmAlwaysOnTop');

        BGC.logger.logInformation('', `Setting main OpenFin window "alwaysOnTop" setting to [${openfinAOT}]`, true);
        mainOpenFinWindow.updateOptions({alwaysOnTop : openfinAOT});
        this.listenTo(userSettingsStore, 'change:vmAlwaysOnTop', () => {
          openfinAOT = !!userSettingsStore.get('vmAlwaysOnTop');
          BGC.logger.logInformation('', `Setting main OpenFin window "alwaysOnTop" setting to [${openfinAOT}]`, true);

          mainOpenFinWindow.updateOptions({alwaysOnTop : openfinAOT});
        });
      }

      // Set the initial activation state.
      this.onActivationStateChanged();
    },

    // Create the tabs based on configuration in VM<TabsLayout>. If TabsLayout section is present tabs
    // will be created based on that. If TabsLayout doesn't exists it creates default tabs (order and trades) and
    // based on setting section will create other tabs.
    CreateTabViews () {
      const {
        userSettingsStore, auctionHistory, orderStore, portfolio, pageLayout
      } = this.dataStore;

      // Hide all the tabs before creating views.
      context.tabControlView.$el.find('#tab-control-view-your-orders-tab').hide();
      context.tabControlView.$el.find('#tab-control-view-my-favorites-tab').hide();
      context.tabControlView.$el.find('#tab-control-view-your-trades-tab').hide();
      context.tabControlView.$el.find('#tab-control-view-portfolio-tab').hide();

      pageLayout.get('tabsLayout').forEach(function (tab) {
        if (tab.ID === 'tab-control-view-your-orders-tab') {
          context.activeOrdersView = new context.OrderListView({
            collection : orderStore,
            el         : $('.active-orders-view')[0],
            parentView : context.tabControlView,
            pageLayout : this.model
          });
          context.tabControlView.$el.find(`#${tab.ID}`).show();
        }

        if (tab.ID === 'tab-control-view-my-favorites-tab') {
          context.myFavoritesView = this.createFavoritesView(
            $('#my-favorites-page')[0],
            context.tabControlView
          );
        }

        if (tab.ID === 'tab-control-view-your-trades-tab') {
          context.auctionHistoryView = new context.AuctionHistoryView({
            collection : auctionHistory,
            el         : $('.trade-history-view')[0],
            parentView : context.tabControlView,
            pageLayout : this.model
          });
        }

        if (tab.ID === 'tab-control-view-portfolio-tab') {
          const tabPage = $('#portfolio-page')[0];

          context.portfolioView = new context.PortfolioView({
            portfolio,
            settingsStore : userSettingsStore
          });

          tabPage.appendChild(context.portfolioView);
        }
        context.tabControlView.$el.find(`#${tab.ID}`).show();
      }, this);
    },

    ShowHideTabControlForActiveAccountType () {
      if (this.dataStore.isBrokerMode()) {
        context.tabControlView.$el.find('#tab-control-view-your-orders-tab').hide();
        context.tabControlView.$el.find('#tab-control-view-your-trades-tab').hide();
        context.tabControlView.$el.find('#tab-control-view-my-favorites-tab').hide();
        context.tabControlView.$el.find('#tab-control-view-portfolio-tab').hide();

        // hide tab control in broker modew
        this.$el.find('.auction-view').addClass('broker-mode');

        // disable drag and drop in broker mode
        this.$el.find('.auction-view').attr('draggable', false);
      } else if (this.dataStore.isSalesTraderMode()) {
        context.tabControlView.$el.find('#tab-control-view-my-favorites-tab').hide();
        context.tabControlView.$el.find('#tab-control-view-portfolio-tab').hide();
      }
    },

    createFavoritesView (parentElement, tabControl) {
      // Create the Polymer view element
      const favoritesIcon = tabControl.getTab(context.TabPages.myFavorites).getElementsByTagName('FA-STATE-ICON')[0];
      const favoritesView = new context.MyFavoritesView({
        footprints : this.dataStore.footprints,
        settings   : this.dataStore.userSettingsStore,
        layout     : this.dataStore.pageLayout
      });

      // Append view to the 'favorites' page (in the tab control)
      parentElement.appendChild(favoritesView);

      // Listen for changes in the footprint collection
      this.dataStore.footprints.on('add remove reset', function () {
        // Apply a tab glow to signal the addition or removal of a footprint
        tabControl.glowTab(context.TabPages.myFavorites);

        // Update the 'Favorites' icon state to reflect whether footprints are present
        favoritesIcon.state = this.dataStore.footprints.length > 0 ? 1 : 0;

        // If the page is visible, recalculate the parent layout
        if (tabControl.isTabActive(context.TabPages.myFavorites)) {
          this.recalcLayout();
        }
      }, this);

      return favoritesView;
    },

    applyLiveModeFilter () {
      const liveMode = this.model.getLiveModeForActiveUser();
      const tiles = this.el.querySelector('.tiles');
      const tileWebComponent = tiles.querySelector('vm-instrument-tile');

      tiles.classList.toggle('filter-show-mine-glows', liveMode === BGC.enums.EVMShowLiveMode.eShowMyOrdersAndGlows);
      tiles.classList.toggle('filter-show-mine-only', liveMode === BGC.enums.EVMShowLiveMode.eShowMyOrdersOnly);
      tileWebComponent.classList.toggle('filter-show-mine-glows', liveMode === BGC.enums.EVMShowLiveMode.eShowMyOrdersAndGlows);
      tileWebComponent.classList.toggle('filter-show-mine-only', liveMode === BGC.enums.EVMShowLiveMode.eShowMyOrdersOnly);
    },

    viewInitializedTimerExpired () {
      this.hasInitialized = true;
    },

    restoreTilesOrder () {
      const tilesElement = this.$el.find('.tiles');
      const matricesElement = this.$el.find('.tiles .matrix-layouts');
      let matricesGroupAdded = false;
      const tilesOrder = this.dataStore.userSettingsStore.get('tilesOrder') || [];

      tilesOrder.forEach(currentElementId => {
        const pos = currentElementId.indexOf('matrix-view-');

        // if currentElementId does not have "-" after "matrix-view", then assign the first linked matrix id to it.
        if (currentElementId.indexOf('matrix-view') >= 0 && currentElementId.indexOf('matrix-view-') < 0) {
          currentElementId = context.matrixViews[0].$el.attr('id');
        }

        if (pos >= 0) {
          if (!matricesGroupAdded) {
            tilesElement.append(matricesElement);
            matricesGroupAdded = true;
          }

          matricesElement.append(matricesElement.find(`#${currentElementId.replace(/ /g, '\\ ')}`));
        } else {
          tilesElement.append(tilesElement.find(`#${currentElementId.replace(/ /g, '\\ ')}`));
        }
      });
    },

    saveTilesOrder () {
      const allElementIds = _.pluck(this.el.querySelector('.tiles').children, 'id');
      const matrixElementIds = _.pluck(this.el.querySelector('.tiles .matrix-layouts').children, 'id');
      let elementIds = [];

      allElementIds.forEach(item => {
        switch (item) {
          case 'spread-views':
          case 'tile-views':
            elementIds.push(item);
            break;
          case 'matrix-views':
            elementIds = elementIds.concat(matrixElementIds);
            break;
          default:
            break;
        }
      });
      this.dataStore.userSettingsStore.set('tilesOrder', elementIds);
    },

    ensureAccountRelatedControlsAreDisplayed () {
      if (!this.$el.find('accounts-bar').length) {
        // BGCVM-973 removed 2 lines prevent error
        this.$el.find('#accounts-bar-location').append(new context.AccountsBar({dataStore : this.dataStore}));

        // And stop hiding everything account-related
        $('body').removeClass('no-account-context');

        // Ensure that the toolbar is rendered with the My Accounts switch shown
        //      context.ordersToolbar.render();
      }
    },

    updateTilesLayout () {
      const tileLayoutsElement = this.$el.find('.tile-layouts');

      // Set the layout position - this is the position of the vertical tile layout within the
      // layout container holding the matrix, spread and tile layout groups
      this.model.get('tiles').forEach(tile => {
        if (tile.get('layoutType') === 'outright') {
          tile.set('layoutPos', tileLayoutsElement.index());
        }
      });

      if (this.layout) {
        this.layout.remove();
      }

      this.layout = this.createVerticalLayout();

      tileLayoutsElement.append(this.layout.$el);
      this.recalcLayout();
    },

    createVerticalLayout () {
      return new context.VerticalLayoutView({
        tiles     : this.model.get('tiles'),
        model     : this.model,
        dataStore : this.dataStore
      });
    },

    createStackLayout () {
      const {dataStore} = this;

      this.layout = new context.StackLayoutView({
        auctions     : dataStore.auctions,
        tiles        : dataStore.pageLayout.get('tiles'),
        settings     : dataStore.userSettingsStore,
        isBrokerMode : dataStore.isBrokerMode()
      });

      this.$el.find('.scroll-container .scrollable-content').append(this.layout.$el);

      this.recalcLayout();
    },

    createSpreadLayout () {
      const spreadLayoutElement = $('#spread-views');
      const spreadTile = this.model.get('tiles').findWhere({
        layoutType : 'spread'
      });

      if (spreadTile) {
        spreadTile.set('layoutPos', spreadLayoutElement.index());
        spreadLayoutElement.addClass('isActive');
        spreadLayoutElement.append(new context.SpreadTileView({
          model      : spreadTile,
          dataStore  : this.dataStore,
          pageLayout : this.model
        }));
      }
    },

    createMatrixLayout () {
      const matrixViewsElement = $('#matrix-views');

      // Set the layout position - this is the position of the matrix layout within the
      // layout container holding the matrix, spread and tile layout groups
      this.model.get('matrices').forEach(matrix => {
        matrix.set('layoutPos', matrixViewsElement.index());
      });

      // Create the individual matrix views
      context.matrixViews = this.model.get('matrices').map(function (matrix) {
        return new context.MatrixView({
          model      : matrix,
          dataStore  : this.dataStore,
          pageLayout : this.model
        });
      }, this);

      // Append views to the matrix view container
      if (context.matrixViews.length) {
        context.matrixView = _.first(context.matrixViews);

        context.matrixViews.reverse().forEach(matrixView => {
          matrixViewsElement.prepend(matrixView.$el);
        }, this);
      }
    },

    onSelectInstrument (event, view, instrument) {
      // start listening to 'inactive instrument' event for new selection
      if (!view && !instrument) {
        /**
         * this is here due to the change in event dispatch functionality.
         * src/views/tile/vm-tilerow-behavior.js:713
         *    this.$el.trigger('selectInstrument', [this, this.model]);
         * is replaced by dispatch custom event with the data attached to
         * event detail
         */
        view = event.detail.view;
        instrument = event.detail.instrument;
      }

      if (instrument && !instrument.inactive) {
        instrument.once('change:inactive', this.onSelectionInactive, this);
      }

      // select new instrument
      this.selectInstrument(view, instrument);
    },

    selectInstrument (view, instrument) {
      const currentSelectedInstrument = BGC.ui.selectionManager.getSelectedInstrument();

      // stop listening to 'inactive instrument' event for current selection
      if (currentSelectedInstrument && (currentSelectedInstrument !== instrument)) {
        currentSelectedInstrument.off('change:inactive', this.onSelectionInactive, this);
      }

      // update selection
      BGC.ui.selectionManager.setSelection(view, instrument);
    },

    onSelectionChanged (newSelection) {
      const selectedViewDomElement = newSelection.view && (newSelection.view.el || (newSelection.view.$el && newSelection.view.$el[0]));

      // This should cancel us out of spread-builder display mode
      if (context.spreadView && context.spreadView.isPopulated()) {
        BGC.ui.view.spreadView.$el.trigger('collapseOrderEntry');
      }

      // update instrument model in docked order entry bar
      context.dockedOrderEntryView.updateModel(newSelection.instrument);
      if ((context.activeOrdersView !== undefined && newSelection.view !== undefined && newSelection.instrument !== undefined) && BGC.ui.viewUtils.isSelectionLocked(selectedViewDomElement)) {
        context.activeOrdersView.applySelectionGlowStyleAndScrollToView(newSelection.instrument);
      }
    },

    onSelectionInactive () {
      this.selectInstrument(null, null);
    },

    onSelectSpread (event, mode, instruments) {
      context.spreadView.updateModel(mode, instruments);
    },

    onTrade (trade) {
      switch (trade.get('tradeType')) {
        case BGC.schemaValidator.OWNERSHIP_MINE:
          this.hasOwnTradedInLastSession = true;
          break;
        case BGC.schemaValidator.OWNERSHIP_MY_FIRM:
        case BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT:
          this.hasFirmTradedInLastSession = true;
          break;
        default:
          break;
      }
    },

    onRecalcLayout (event, options) {
      // eslint-disable-next-line no-prototype-builtins
      if (options && options.hasOwnProperty('centreOnApp')) {
        this.centreOnApp = options.centreOnApp;
      } else if (hasIn(event, ['detail', 'centreOnApp'])) {
        this.centreOnApp = get(event, ['detail', 'centreOnApp'], false);
      }

      this.recalcLayout();
    },

    recalcLayout () {
      if (this.recalcLayoutTimer) {
        clearTimeout(this.recalcLayoutTimer);
      }

      this.recalcLayoutTimer = window.setTimeout(this.recalcLayoutNow.bind(this), 200);

      this.model.set('isLayoutRecalcPending', true);
    },

    startUpdateElementsWithOverflowTimer () {
      this.stopUpdateElementsWithOverflowTimer();
      this.updateElementsWithOverflowTimer = window.setTimeout(this.onUpdateElementsWithOverFlow.bind(this), 150);
    },

    stopUpdateElementsWithOverflowTimer () {
      // Clear the timer if one is running.
      if (this.updateElementsWithOverflowTimer) {
        clearTimeout(this.updateElementsWithOverflowTimer);
        this.updateElementsWithOverflowTimer = null;
      }
    },

    hideInPlaceOEBOnContextSwitch () {
      // ensure that any open OEB is closed on broker context change.
      const inplaceOEB = context.inplaceOEB.getInstance();

      if (inplaceOEB.isOpen) {
        inplaceOEB.hide();
      }
    },

    onUpdateElementsWithOverFlow () {
      // Reset the time and assign to null.
      this.updateElementsWithOverflowTimer = null;

      this.updateElementsWithOverflow();

      // ensure that any open OEB is repositioned.
      reCalculateInplaceOEBPosition();
    },

    // Handler for bubbling event was added using jQuery,
    // so original event will be wrapped in jQuery event
    // Therefore custom event auxiliary data may be found in event.originalEvent.detail
    handleCancelActiveOrder (event) {
      const {originalEvent} = event;
      const instrumentModel = BGC.dataStore.getInstrumentById(originalEvent.detail.instrumentId);

      instrumentModel.sendCancelOrder(originalEvent.detail.eventSource, originalEvent.detail.side);
    },

    // Handler for bubbling custom event was added using jQuery,
    // so original event will be wrapped in jQuery event.
    // Therefore custom event auxiliary data may be found in event.originalEvent.detail
    handleSubmitOrderAtMid (event) {
      const {originalEvent} = event;
      const instrumentModel = BGC.dataStore.getInstrumentById(originalEvent.detail.instrumentId);
      const order = instrumentModel.getOrderDetailsForSubmission(
        originalEvent.detail.side,
        instrumentModel.get('midPrice'),
        originalEvent.detail.size
      );

      BGC.ui.viewUtils.submitOrder(
        instrumentModel,
        {
          side         : originalEvent.detail.side,
          size         : order.size,
          price        : order.price,
          priceDisplay : order.priceDisplay
        },
        originalEvent.detail.eventSource
      );
    },

    // Handler for bubbling event was added using jQuery,
    // so original event will be wrapped in jQuery event
    // Therefore custom event auxiliary data may be found in event.originalEvent.detail
    handleSubmitOrder (event) {
      const {originalEvent} = event;
      const instrumentModel = BGC.dataStore.getInstrumentById(originalEvent.detail.instrumentId);
      const order = instrumentModel.getOrderDetailsForSubmission(
        originalEvent.detail.side,
        originalEvent.detail.price,
        originalEvent.detail.size
      );

      BGC.ui.viewUtils.submitOrder(
        instrumentModel,
        {
          accountId    : originalEvent.detail.accountId,
          side         : originalEvent.detail.side,
          size         : order.size,
          price        : order.price,
          priceDisplay : order.priceDisplay
        },
        originalEvent.detail.eventSource
      );
    },

    onDragStart (event) {
      const dragHandler = $(event.target);
      const container = this.$el.find('.auction-view');
      const offset = BGC.utils.getRelativeOffset(dragHandler, container);
      const $dropTargetLine = $('.drop-target-line');

      event.originalEvent.dataTransfer.setData('source', 'auction-view');
      event.originalEvent.dataTransfer.setDragImage(container[0], event.originalEvent.offsetX + offset.left, event.originalEvent.offsetY + offset.top);

      // hide drop-target-line above the element
      $dropTargetLine.show();
      $dropTargetLine.eq($('.draggable-block').index(container[0])).hide();
    },

    onDragEnd () {
      $('.drop-target-line').hide();
    },

    /**
     * * Calculates current ideal size and notifies layout resize handler if width or height
     * * have been changed.
     * *
     * * @method
     **/
    recalcLayoutNow () {
      this.recalcLayoutTimer = null;

      // update sortable plugin in case new elements were added
      this.$el.find('.tiles').sortable('refresh');

      BGC.utils.trace('mainview.recalcLayoutNow() calling mainview.resizeLayout()');

      this.resizeLayout({});

      this.model.set('isLayoutRecalcPending', false);
    },

    /**
     * * Increases application root font size and sends new ideal size to layout resize handler.
     * * Increasing root font size forces all elements' sizes/paddings/margins
     * * defined in rem units to recalculate itself according to the new root font size.
     * *
     * * @param {Boolean} doNotForceWindowResize
     * * @method
     * */
    updateRootFontSize (doNotForceWindowResize) {
      // create new root font size by applying a delta from 100% so that the base font size can be modified
      // independently from the zoom level
      this.rootFontSize = this.baseRootFontSize + (this.dataStore.userSettingsStore.get('zoomLevel') - 100) / this.ZOOM_STEP;

      $('html').css('font-size', this.rootFontSize);

      // Due to the reliance on calculations for row height based on root font size in the Active Orders view,
      // in order to support the fixed rows algorithm, it needs to update when the zoom level changes.
      // Unfortunately, if we simply add a listener to the settings store in the orders view, it gets triggered
      // BEFORE this handler in the main view, so the base font size hasn't yet changed.
      // Hence we fire an alternative event here, AFTER the root font size has changed.
      this.model.trigger('rootFontSizeChanged');

      if (!doNotForceWindowResize) {
        this.resizeLayout();
      }
    },

    /**
     * * Sends layout resize message containing ideal sizes of the
     * * updated layout. This method provides sensible default sizes
     * * that can be changed/extended by providing values in the parameter object.
     * *
     * * @param {Object} layoutSize - object containing values to overwrite the provided defaults
     * * @method
     * */
    // eslint-disable-next-line complexity
    resizeLayout (layoutSize) {
      const contentSize = this.getContentSize();
      const auctionArea = this.el.querySelector('.auction-view');
      const hasContentSizeChanged = (this.contentWidth !== contentSize.width) || (this.contentHeight !== contentSize.height);
      const minWidth = contentSize.width;
      const maxWidth = Math.round(minWidth * (this.model.hasMatrices() ? this.MAX_MATRIXVM_WIDTH_ADJUSTMENT : this.MAX_TILEVM_WIDTH_ADJUSTMENT));
      const minHeight = this.model.hasMatrices() || !auctionArea ? contentSize.height : auctionArea.offsetTop;
      const isPinned = !this.model.hasMatrices() && this.dataStore.userSettingsStore.get('pinned');

      layoutSize = layoutSize || {};

      // make sure that the main element never can be bigger than max width
      this.el.style.maxWidth = maxWidth;

      if (hasContentSizeChanged || isPinned || isPinned !== this.isPinned) {
        this.contentWidth = contentSize.width;
        this.contentHeight = contentSize.height;

        // If the window is pinned, we have to send information to the container even if content size didn't change.
        // It needs to know that the "pinned" setting is ON and what the ideal height should be if it is maximised.

        const app = getApp();
        const windowWidth = app.isEmbedded ? this.contentWidth : Math.max(this.contentWidth, window.innerWidth);

        window.BGC.eventsHandler.onLayoutResize(_.extend({
          // eslint-disable-next-line id-length
          y           : contentSize.height,
          minY        : minHeight,
          maxY        : contentSize.height,
          // eslint-disable-next-line id-length
          x           : windowWidth,
          minX        : Math.min(minWidth, this.MAX_WIDTH),
          maxX        : maxWidth,
          isPinned    : !!isPinned,
          centreOnApp : this.centreOnApp
        }, layoutSize));
      }

      if (hasContentSizeChanged || this.isProcessingExternalWindowResizeEvent) {
        this.startUpdateElementsWithOverflowTimer();
      } else if (contentSize.width === this.MAX_WIDTH) {
        // if there is no window resizing necessary as it reached maximum possible browser window width or height,
        // the content can still spill over, and hence need to update the overflow styling too.

        const currentContentWidth = Math.ceil($('body').outerWidth(true));

        if (contentSize.width < currentContentWidth) {
          this.startUpdateElementsWithOverflowTimer();
        }
      }

      this.centreOnApp = false;
      this.isProcessingExternalWindowResizeEvent = false;
      this.isPinned = isPinned;
    },

    /**
     * * Gets ideal size of the application content.
     * * The body element has CSS rules assigned that force it to never be less than
     * * its children content size and never be bigger than html height.
     * * This method collapses html element width and expands height to provided maximum height,
     * * that forces body element to shrink to content minimum width and height. This provides ideal minimum
     * * content size, which gets measured and html element is restored back to previous size.
     * *
     * * @method
     * */
    getContentSize () {
      const htmlElement = document.querySelector('html');
      const bodyElement = document.querySelector('body');
      const $bodyElement = $(bodyElement);
      const scrollContainer = this.el.querySelector('.auction-view .scroll-container');
      const {scrollTop} = scrollContainer;

      htmlElement.style.width = '0px';

      // THIS NEXT STATEMENT RESETS THE SCROLL POSITION OF THE AUCTION CONTAINER!!!
      htmlElement.style.height = '-webkit-fit-content';
      bodyElement.style.minWidth = '-webkit-fit-content';

      // +1 pixel to height helps avoid unnecessary vertical scrollbar - CEF issue?
      const height = Math.ceil($bodyElement.outerHeight(true)) + 1;
      const width = Math.ceil($bodyElement.outerWidth(true));

      bodyElement.style.removeProperty('min-width');
      htmlElement.style.removeProperty('width');
      htmlElement.style.removeProperty('height');

      // Try to restore the last scroll position of the auction area of the display.
      // If the position is greater than the scroll range, it automatically adjusts to the max value.
      if (scrollTop !== scrollContainer.scrollTop) {
        scrollContainer.scrollTop = scrollTop;
      }

      return {
        height,
        width
      };
    },

    updateElementsWithOverflow () {
      const scrollContainer = this.el.querySelector('.auction-view .scroll-container');
      const scrollableContent = scrollContainer.querySelector('.scrollable-content');
      const currentOverflowY = scrollContainer.style.overflowY;
      const currentOverflowX = scrollContainer.style.overflowX;

      updateElementHorizontalOverflow(scrollContainer);
      BGC.ui.viewUtils.updateElementVerticalOverflow(scrollContainer, scrollableContent);

      if (currentOverflowX !== scrollContainer.style.overflowX ||
                currentOverflowY !== scrollContainer.style.overflowY) {
        this.recalcLayout();
      }
    },

    updateVMSpreadsViews () {
      if (this.model.get('allowSpreadCreation')) {
        if (context.spreadView) {
          BGC.logger.logInformation('', 'Some of the instruments\' types and auction preferences permit spread creation so showing spread tile.');

          context.spreadView.$el.show();
        } else {
          BGC.logger.logInformation('', 'Some of the instruments\' types and auction preferences permit spread creation so creating spread tile.');

          context.spreadView = new context.SpreadView({
            el     : this.$el.find('.spread-view')[0],
            matrix : this.model.get('matrices')
              .first(),
            dataStore : this.dataStore
          });
        }
      } else if (context.spreadView) {
        BGC.logger.logInformation('', 'No instrument types and auction preferences permit spread creation so hiding spread tile.');

        context.spreadView.close();
      }

      this.recalcLayout();
    },

    // eslint-disable-next-line complexity
    onActivationStateChanged () {
      const that = this;
      const {mainWindow} = getApp();
      const inAuctionState = this.model.areAnyInstrumentsInAuction();
      const firstInstrumentInAuctionSession = this.model.get('firstInstrumentInAuctionSession');

      if (inAuctionState) {
        this.hasOwnTradedInLastSession = false;
        this.hasFirmTradedInLastSession = false;
      }

      this.$el.toggleClass('auction-active', inAuctionState);
      this.$el.find('orders-and-trades-toolbar').toggleClass('auction-active', inAuctionState);

      // Notify trader looking that the window has been triggered by the start of a new VM session.
      if (inAuctionState && isWebDeployed) {
        BGC.ui.viewUtils.sendTraderLookingEvent('wndTriggered', firstInstrumentInAuctionSession.get('auctionId'), firstInstrumentInAuctionSession.get('instrumentId'));
      }

      if (!BGC.openfin.isOpenFinDeployed() && mainWindow === undefined) {
        return;
      }

      // NOTE: the following code is for web-deployed builds and uses the 'moment' library which
      // is injected by the 'web-deployed' build process
      let bgcVmTitle = BGC.resources.IDS_VM_HEADER;

      if (inAuctionState) {
        if (BGC.ui.theme.getBrandId() !== 'GFI' ||
                    BGC.ui.theme.getBrandId() !== 'GFI-FXO') {
          bgcVmTitle = BGC.resources.IDS_VM_HEADER_GFI;
        } else if (this.model.get('businessConfig') === 'AusIro') {
          bgcVmTitle = BGC.resources.IDS_VM_HEADER_AUSIRO;
        } else {
          switch (BGC.ui.theme.getBrandId()) {
            case 'AUREL':
              bgcVmTitle = BGC.resources.IDS_VM_HEADER_BGC_AUREL;
              break;
            case 'MINT':
              bgcVmTitle = BGC.resources.IDS_VM_HEADER_MINT;
              break;
            case 'GBX':
              bgcVmTitle = BGC.resources.IDS_VM_HEADER_GBX;
              break;
            case 'RPMARTIN':
              bgcVmTitle = BGC.resources.IDS_VM_HEADER_RPMARTIN;
              break;
            case 'FENICS':
              bgcVmTitle = BGC.resources.IDS_VM_HEADER_FENICS;
              break;
            case 'COLLEX':
              bgcVmTitle = BGC.resources.IDS_VM_HEADER_COLLEX;
              break;
            case 'FREEDOM':
              bgcVmTitle = BGC.resources.IDS_VM_HEADER_FREEDOM;
              break;
            default:
              bgcVmTitle = BGC.resources.IDS_VM_HEADER;
              break;
          }
        }

        if (BGC.openfin.isOpenFinDeployed()) {
          // OpenFin deployed...

          BGC.openfin.executeAfterInit(() => {
            // Stop any auto-close timer.
            that.stopOpenFinWindowAutoClose();

            // Restore the window and bring it to the front.
            BGC.openfin.restoreOpenFinWindowAndBringToFront(BGC.openfin.getMainWindow());
          });

          // Display a notification indicating that a VM has started.
          if (this.hasInitialized) {
            BGC.openfin.executeAfterInit(() => {
              BGC.openfin.displayOpenFinNotification(bgcVmTitle, `${document.title} started`);
            });
          }
        } else {
          // Restore the main window when the auction starts
          mainWindow.restore();
        }
      } else if (BGC.openfin.isOpenFinDeployed()) {
        // OpenFin deployed...

        // Minimise the window after 5 seconds now that all VMs have ended
        // unless a trade occured.
        if ((this.hasOwnTradedInLastSession === false) && (!this.dataStore.userSettingsStore.get('showTradesForFirm') || this.hasFirmTradedInLastSession === false)) {
          BGC.openfin.executeAfterInit(this.startOpenFinWindowAutoClose.bind(this, 5000));
        }
      }
    },

    // Minimise the OpenFin window after the specified interval.
    startOpenFinWindowAutoClose (timeoutMilliSecs) {
      const that = this;
      const openFinWindow = BGC.openfin.getMainWindow();

      if (!this._openFinWindowAutoCloseTimer) {
        this._openFinWindowAutoCloseTimer = setTimeout(() => {
          // Check to make sure the auto-close timer has not been stopped.
          // eslint-disable-next-line no-underscore-dangle
          if (that._openFinWindowAutoCloseTimer) {
            // eslint-disable-next-line no-underscore-dangle
            delete that._openFinWindowAutoCloseTimer;

            openFinWindow.minimize();
          }
        }, timeoutMilliSecs);
      }
    },

    // Stop any OpenFin window auto-close timer.
    stopOpenFinWindowAutoClose () {
      if (this._openFinWindowAutoCloseTimer) {
        clearTimeout(this._openFinWindowAutoCloseTimer);
        delete this._openFinWindowAutoCloseTimer;
      }
    }
  });

  context.resize = function () {
    if (context.mainView) {
      context.mainView.isProcessingExternalWindowResizeEvent = true;

      context.mainView.recalcLayout({});
    }
  };
}(window.BGC.ui.view));
