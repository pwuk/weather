import {html} from '@polymer/polymer/polymer-element';

export default html`
    <style>
        :host .first-row {
            pointer-events: none;
        }
        .fa {
            display: inline-block;
            font-family: FontAwesome;
            font-style: normal;
            font-weight: normal;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .fa-times:before {
            content: "\\f00d";
        }
        .popupXButton {
            background: #606061;
            color: #FFFFFF;
            line-height: 25px;
            position: absolute;
            right: -12px;
            text-align: center;
            top: -10px;
            width: 24px;
            text-decoration: none;
            font-weight: bold;
            -webkit-border-radius: 12px;
            -moz-border-radius: 12px;
            border-radius: 12px;
            -moz-box-shadow: 1px 1px 3px #000;
            -webkit-box-shadow: 1px 1px 3px #000;
            box-shadow: 1px 1px 3px #000;
            z-index: 103;
        }
        .popupXButton:hover {
            background: #d01212;
        }
        .popupXButton:active {
            -moz-box-shadow: 1px 1px 3px #880000 inset;
            -webkit-box-shadow: 1px 1px 3px #880000 inset;
            box-shadow: 1px 1px 3px #880000 inset;
        }
        [hidden] {
            display: none !important;
        }
body {
  position: absolute;
  z-index: 5;
  background-color: transparent;
  height: auto;
}
.top-callout-allowance,
.bottom-callout-allowance {
  overflow: hidden;
  position: relative;
  content: "";
  height: 1rem;
  width: 100%;
}
.oeb-panel {
  display: flex;
  flex-direction: column;
  position: relative;
  line-height: normal;
  height: auto;
  background-color: var(--inplace-oeb-background);
  color: var(--content-text);
  border: 3px solid var(--selection);
  font-weight: bold;
  padding: 7px 5px 5px 5px;
  border-radius: 8px;
}
.oeb-panel .popupXButton {
  color: var(--tab-active-text);
  background-color: var(--content-header-background);
  top: -14px;
  right: -14px;
  -moz-box-shadow: 0 0 0 2px var(--selection);
  -webkit-box-shadow: 0 0 0 2px var(--selection);
  box-shadow: 0 0 0 2px var(--selection);
}
.oeb-panel .popupXButton:visited,
.oeb-panel .popupXButton:hover,
.oeb-panel .popupXButton:active,
.oeb-panel .popupXButton:link {
  color: var(--content-header-text);
}
.oeb-panel .popupXButton:hover {
  background-color: var(--sell-side);
  filter: brightness(var(--sell-side-filter));
}
.oeb-panel .order-entry {
  overflow: hidden;
  flex: 1;
}
.oeb-panel .order-entry > div {
  margin: 0 1px 2px 2px;
}
.oeb-panel .order-entry .oeb-midprice {
  margin: 0;
  font-size: 2rem;
  float: left;
}
.oeb-panel .order-entry .mirror {
  transform: rotateY(180deg);
}
.oeb-panel .order-entry .mirror .oeb-midprice,
.oeb-panel .order-entry .mirror ul li {
  transform: rotateY(180deg);
}
.oeb-panel .order-entry .mirror .slow-data-entry {
  transform: rotateY(180deg);
}
.oeb-panel .order-entry .mirror .slow-data-entry .size input.buy {
  text-align: right;
  padding-right: 0.4rem;
  padding-left: 0;
}
.oeb-panel .order-entry .mirror .slow-data-entry .size input.sell {
  padding-left: 0.4rem;
  padding-right: 0;
  text-align: left;
}
.oeb-panel .order-entry .mirror .slow-data-entry .size span.cancel-icon.sell {
  right: calc(2px + 0.15rem);
  left: auto;
}
.oeb-panel .order-entry .mirror .slow-data-entry .size span.cancel-icon.buy {
  left: calc(2px + 0.15rem);
  right: auto;
}
.oeb-panel .order-entry {
  margin: 0;
  width: 100%;
  height: 100%;
  display: inline-flex;
  padding: 0 1px 0 1px;
  font-size: 1.1rem;
  flex: 1;
  max-width: none;
  line-height: 2.4rem;
  font-size: 1.5rem;
}
.oeb-panel .order-entry quicksize-buttonset ul {
  list-style: none;
  margin: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 0;
  width: auto;
}
.oeb-panel .order-entry quicksize-buttonset ul li {
  margin: 0 2px 0 2px;
  flex: 1;
  min-width: 6rem;
  cursor: default;
  text-align: center;
  color: var(--content-button-text);
  border-radius: 12px;
  font-weight: bold;
  position: relative;
}
.oeb-panel .order-entry ul li.user-input-disabled {
  pointer-events: none;
}
.oeb-panel .order-entry ul li.user-input-disabled:before {
  content: "";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(255, 255, 255, 0.6);
}
.oeb-panel .order-entry ul.sell li {
  background-color: var(--sell-side);
  border: 1px solid var(--sell-side-border);
}
.oeb-panel .order-entry ul.sell li:hover {
  color: var(--buy-hover-text-color);
  font-weight: bold;
}
.oeb-panel .order-entry ul.buy li {
  background-color: var(--buy-side);
  border: 1px solid var(--buy-side-border);
}
.oeb-panel .order-entry ul.buy li:hover {
  color: var(--sell-hover-text-color);
  font-weight: bold;
}
.oeb-panel .order-entry ul li {
  margin-bottom: 7px;
  height: 2.4rem;
}
.oeb-panel .order-entry .slow-data-entry {
  display: flex;
  flex-direction: column;
  float: left;
}
.oeb-panel .order-entry .slow-data-entry.buy {
  margin-right: 5px;
}
.oeb-panel .order-entry .slow-data-entry.sell {
  margin-left: 5px;
}
.oeb-panel .order-entry .slow-data-entry .size {
  float: left;
  width: initial;
  min-width: initial;
  height: 100%;
  background-color: transparent;
  color: inherit;
  border: none;
  border-left: solid 1px var(--content-border);
  vertical-align: top;
  padding: 0 0 0 0.5rem;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 0;
  position: relative;
  display: block;
  float: none;
  width: calc(6rem + 4px);
  height: auto;
  padding: 0 1px 0 1px;
  margin-bottom: 7px;
  border: 1px solid var(--inplace-oeb-group-border);
}
.oeb-panel .order-entry .slow-data-entry .size input {
  width: 100%;
  height: 100%;
  font-weight: inherit;
  font-size: 1.1rem;
  border: none;
  background-color: var(--blotter-background);
  color: var(--blotter-text);
  display: block;
}
.oeb-panel .order-entry .slow-data-entry .size input.buy {
  padding-left: 0.5rem;
}
.oeb-panel .order-entry .slow-data-entry .size input.sell {
  padding-right: 0.5rem;
  text-align: right;
}
.oeb-panel .order-entry .slow-data-entry .size input.no-order {
  text-align: center;
  font-weight: normal;
}
.oeb-panel .order-entry .slow-data-entry .size input.no-order::-webkit-input-placeholder {
  color: var(--bg-sensitive-text-color-for-order-entry);
}
.oeb-panel .order-entry .slow-data-entry .size input.published-by-excel {
  background-color: var(--excel-green);
}
.oeb-panel .order-entry .slow-data-entry .size input:disabled {
  color: inherit;
  background-color: transparent;
}
.oeb-panel .order-entry .slow-data-entry .size img {
  position: absolute;
  top: 50%;
  margin-top: -0.55rem;
  width: 1.1rem;
}
.oeb-panel .order-entry .slow-data-entry .size img.cancel-buy,
.oeb-panel .order-entry .slow-data-entry .size img.buy {
  right: 0.15rem;
  left: auto;
}
.oeb-panel .order-entry .slow-data-entry .size img.cancel-sell,
.oeb-panel .order-entry .slow-data-entry .size img.sell {
  left: 0.15rem;
  right: 0px;
}
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon {
  width: 1.1rem;
  height: 1.1rem;
  background-image: url('./assets/images/cancel.png');
  background-size: 1.1rem;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.cancel-buy,
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.buy {
  right: 0.15rem;
  left: auto;
}
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.cancel-sell,
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.sell {
  left: 0.15rem;
  right: 0px;
}
.oeb-panel .order-entry .slow-data-entry .size.user-input-disabled:before {
  content: "";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(255, 255, 255, 0.6);
  pointer-events: none;
}
.oeb-panel .order-entry .slow-data-entry .size input {
  padding: 3px 0 2px 0.4rem;
  border: 1px solid var(--content-border);
  width: 100%;
}
.oeb-panel .order-entry .slow-data-entry .size input.buy {
  padding-left: 0.5rem;
  padding-right: 0;
  text-align: left;
}
.oeb-panel .order-entry .slow-data-entry .size input.sell {
  padding-right: 0.5rem;
  padding-left: 0;
  text-align: right;
}
.oeb-panel .order-entry .slow-data-entry .size input.no-order {
  text-align: center;
}
.oeb-panel .order-entry .slow-data-entry .size input.validation-error {
  background-color: #ffc;
  color: red;
}
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.cancel-sell,
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.sell {
  left: calc(2px + 0.15rem);
  right: auto;
  top: 75%;
}
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.cancel-buy,
.oeb-panel .order-entry .slow-data-entry .size span.cancel-icon.buy {
  right: calc(2px + 0.15rem);
  left: auto;
  top: 75%;
}
.oeb-panel .order-entry .slow-data-entry .size button {
  position: relative;
  width: 100%;
  color: var(--content-button-text);
  font-weight: bold;
  padding: 2px 0 2px 0;
  margin-bottom: 7px;
  border-radius: 12px;
  font-size: 1.4rem;
  height: 2.4rem;
}
.oeb-panel .order-entry .slow-data-entry .size button.user-input-disabled:before {
  content: "";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(255, 255, 255, 0.6);
  pointer-events: none;
}
.oeb-panel .order-entry .slow-data-entry .size button.buy {
  background-color: var(--buy-side);
  border: 1px solid var(--buy-side-border);
}
.oeb-panel .order-entry .slow-data-entry .size button.sell {
  background-color: var(--sell-side);
  border: 1px solid var(--sell-side-border);
}
.oeb-panel .order-entry .slow-data-entry .size button.user-input-disabled {
  background-color: var(--buy-btn-bg-color);
  color: var(--content-header-text);
  border: 1px solid var(--inplace-oeb-background);
}
.oeb-panel .order-entry .slow-data-entry.wide-display .size {
  width: calc(7.5rem);
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container {
  background-color: var(--blotter-background);
  width: 7.5rem;
  height: 2.4rem;
  position: relative;
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container input {
  font-size: 1.1rem;
  background-color: var(--blotter-background);
  color: var(--blotter-text);
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container input:disabled {
  background-color: var(--disabled-blotter-background);
  color: var(--disabled-blotter-text);
  filter: brightness(--disabled-blotter-background-filter);
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container.live input {
  background-color: var(--blotter-background);
  color: var(--nudged-price-txt-at-or-behind-mid);
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container.live.ahead input {
  color: var(--nudged-price-txt-ahead-of-mid);
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container.live.active input {
  color: var(--content-text);
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container.error input {
  box-shadow: inset 0 0 5px #FF0000;
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container {
  border: 1px solid var(--inplace-oeb-group-border);
}
.oeb-panel .order-entry nudgeable-price-input div.price-nudge-container input:disabled {
  background-color: var(--blotter-background);
  color: var(--blotter-text);
}
.oeb-panel .order-entry nudgeable-price-input.user-input-disabled div.price-nudge-container:after {
  content: "";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(255, 255, 255, 0.6);
  pointer-events: none;
}
.oeb-panel:before,
.oeb-panel:after {
  position: absolute;
  content: "";
  height: 0;
  width: 0;
  border: 1em solid transparent;
}
.oeb-panel:before {
  font-size: 1.4rem;
}
.oeb-panel:after {
  font-size: 0.95rem;
}
:host(.left) .oeb-panel:before {
  right: 2rem;
}
:host(.left) .oeb-panel:after {
  right: 2.45rem;
}
:host(.right) .oeb-panel:before {
  left: 2rem;
}
:host(.right) .oeb-panel:after {
  left: 2.45rem;
}
:host(.centered) .oeb-panel:before {
  left: calc(2.3 * 6rem);
}
:host(.centered) .oeb-panel:after {
  left: calc(2.3 * 6rem + 0.45rem);
}
:host(.below) .oeb-panel:before {
  bottom: 100%;
  border-bottom-color: var(--selection);
  border-top: 0;  
}
:host(.below) .oeb-panel:after {
  bottom: 100%;
  border-bottom-color: var(--inplace-oeb-background);
  border-top: 0;
}
:host(.below) .bottom-callout-allowance {
  display: none;
}
:host(.above) .oeb-panel:before {
  top: 100%;
  border-top-color: var(--selection);
  border-bottom: 0;
}
:host(.above) .oeb-panel:after {
  top: 100%;
  border-top-color: var(--inplace-oeb-background);
  border-bottom: 0;  
}
:host(.above) .top-callout-allowance {
  display: none;
}
 .name-row {
  margin-top: 1px;
  margin-bottom: 1px;
  overflow: hidden;
  display: flex;
}
 .name-row .name {
  text-align: center;
  padding-left: 3px;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 1.6rem;
  flex: 1;
}


:host(.centreOEDB)  {
    min-width: 266px;
}

        :host(.centreOEDB) .slow-data-entry {
  justify-content: center;
  margin-bottom: 5px;
}
:host(.centreOEDB) .oeb-midprice {
  position: absolute;
  width: 100%;
  text-align: center;
}
:host(.centreOEDB) .popupXButton {
    display: none; // close (X) button unncessary 
}
:host(.centreOEDB) .oeb-panel {
    padding: 0;
}
:host(.centreOEDB) .name-row .name {
    padding-left: 0;
}
        
:host(.centreOEDB) .oeb-panel .order-entry > div {
    margin: 0;
    padding: 0;
}

:host(.centreOEDB) .oeb-panel .order-entry {
    padding: 0;            
}
:host(.centreOEDB) .oeb-panel .order-entry .slow-data-entry.buy {
     margin-right: 0;
}
:host(.centreOEDB) .oeb-panel .order-entry .slow-data-entry.sell {
    margin-left: 2px;
}

:host(.centreOEDB)  .oeb-panel .order-entry .slow-data-entry .size {
    padding: 0;
    border: 0;
}

:host(.centreOEDB.centered) .oeb-panel:after {
    left: calc(2.2 * 5rem);
}
        
:host(.centreOEDB.centered) .oeb-panel:before {
    left: calc(2.2 * 4.8rem);
}


    </style>
<div class="top-callout-allowance"></div>
<div class="oeb-panel">
    <span class="popupXButton" on-tap="hide" on-mouseenter="showCloseTooltip" on-mouseleave="hideCloseTooltip"><i
            class="fa fa-times"></i></span>
    <div class="order-entry" style="display: block; overflow: hidden">
        <div class="name-row">
            <div class="name">
                <span>{{instrument.shortName}}</span>
                <span class="strike">{{instrument.strikeString}}</span>
            </div>
        </div>
        <div id="mirrorElements">
            <div hidden="{{!showBuySide}}" style="display: flex; flex-direction: row; float: left">
                <quicksize-buttonset style="z-index: 1"  side="buy" show-sizes="show" class="inplace-order compact-buttons"></quicksize-buttonset>
                <div class="slow-data-entry buy" wide-display="{{moveableMidsEnabled}}">
                    <div class="size" side="buy">
                        <button on-click="handleBuySellButtonClick" class="buy">{{terminology.buy}}</button>
                        <size-input-control type="text" class="buy in-oeb-panel" maxlength=6
                               order-price="{{order.buyPrice}}" placeholder="{{terminology.buySizePlaceholder}}"
                               value="{{order.buySize}}" revert-value="{{order.buySize}}" class="oeb-panel"
                        ></size-input-control>
                        <span hidden="{{!order.hasCancellableBuySize}}" class="cancel-icon buy"
                              on-click="handleCancelIconClick"></span>
                            
                    </div>
                    <nudgeable-price-input side="buy" hidden="{{!moveableMidsEnabled}}"></nudgeable-price-input>
                </div>
            </div>
            <div class="oeb-midprice">{{instrument.priceDisplay}}</div>
            <div hidden="{{!showSellSide}}" style="display: flex; flex-direction: row; float: left">
                <div class="slow-data-entry sell" wide-display="{{moveableMidsEnabled}}">
                    <div class="size" side="sell">
                        <button on-click="handleBuySellButtonClick" class="sell">{{terminology.sell}}</button>
                        <size-input-control type="text" class="sell in-oeb-panel" maxlength=6
                               order-price="{{order.sellPrice}}" placeholder="{{terminology.sellSizePlaceholder}}"
                               value="{{order.sellSize}}" revert-value="{{order.sellSize}}" 
                        ></size-input-control>
                        <span hidden="{{!order.hasCancellableSellSize}}" class="cancel-icon sell"
                              on-click="handleCancelIconClick"></span>
                    </div>
                    <nudgeable-price-input side="sell" hidden="{{!moveableMidsEnabled}}"></nudgeable-price-input>
                </div>
                <quicksize-buttonset style="z-index: 1" side="sell" show-sizes="show" class="inplace-order compact-buttons"></quicksize-buttonset>
            </div>
        </div>
    </div>
</div>
<div class="bottom-callout-allowance"></div>
`;
