/* eslint-disable max-lines, max-depth, max-params, complexity, no-magic-numbers, default-case, max-statements, func-names, id-length, class-methods-use-this */
/* global BGC: false, $: false */

import {PolymerElement} from '@polymer/polymer';
import {flush} from '@polymer/polymer/lib/utils/flush';
import {mixinBehaviors} from '@polymer/polymer/lib/legacy/class';
import {dom} from '@polymer/polymer/lib/legacy/polymer.dom';
import componentTemplate from './inplace-order-entry.template';

const {view: context} = window.BGC.ui;
const {KeyCodes} = BGC.utils;

// context.OrderEntryControlsContainerBehavior

class InPlaceOrderEntry extends mixinBehaviors([context.OrderEntryControlsContainerBehavior], PolymerElement) {
  constructor () {
    super();

    this.addEventListener('SubmitQuickSize', this.handleSubmitOrderEvent.bind(this));
    this.addEventListener('SubmitValidatedSize', this.handleSubmitOrderEvent.bind(this));
    this.addEventListener('SubmitValidatedPriceAndSize', this.handleSubmitOrderEvent.bind(this));
    this.addEventListener('SubmitValidatedPrice', this.handleSubmitOrderEvent.bind(this));
    this.addEventListener('keydown', this.handleKeyDown.bind(this));
    this.addEventListener('keyup', this.handleKeyUp.bind(this));
    this.addEventListener('mouseover', this.handleMouseOver.bind(this));
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
    this.handleEscKey = this.handleEscKey.bind(this);

    this.ETradeSide = {
      eBuy : 1, eSell : 2, eBoth : 3, buy : 1, sell : 2, both : 3
    };
    this.EPosition = {
      eAbove : 1, eLeft : 2, eRight : 3, eBelow : 4, eCentered : 5
    };
    this.is = 'inplace-order-entry';
  }

  static get template () {
    return componentTemplate;
  }

  static get properties () {
    return {
      instrument : {
        type : Object,
        value () {
          return {
            shortName : '',
            strike2   : '',
            cross     : ''
          };
        }
      },

      order : {
        type : Object,
        value () {
          return {
            buySize                : '',
            sellSize               : '',
            hasCancellableBuySize  : false,
            hasCancellableSellSize : false
          };
        }
      },

      terminology : {
        type : Object,
        value () {
          return {
            buySize             : 'Buy Size',
            buySizePlaceholder  : '<Buy Sz>',
            buy                 : 'Buy',
            bought              : 'Bought',
            sellSize            : 'Sell Size',
            sellSizePlaceholder : '<Sell Sz>',
            sell                : 'Sell',
            sold                : 'Sold'
          };
        }
      },

      isOpen : {
        type  : Boolean,
        value : false
      }
    };
  }


  created () {
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
    this.handleEscKey = this.handleEscKey.bind(this);
  }


  // This function takes Plain Old JavaScript Objects,
  // so if Backbone models are in use they should be serialized before being passed in
  setData (instrument, activeOrder, callbackFunctions) {
    // NOTE: Notification required in order for sub-propery bindings to update so use set()!

    if (instrument) {
      const disableBidInput = !instrument.canUserEnterOrders || !instrument.isMoveableBidEnabled;
      const disableOfferInput = !instrument.canUserEnterOrders || !instrument.isMoveableOfferEnabled;
      let setBuySizesForMidPrice = true;
      let setSellSizesForMidPrice = true;

      if (instrument.inactive) {
        this.hide();

        return;
      }

      // First do a straight copy of instrument attributes
      this.setViewModelsAndCallbacks(instrument, activeOrder, callbackFunctions);

      // Then force the sub-property bindings to update for certain attributes
      this.set('terminology.buy', instrument.tradingTerminology.buy.toUpperCase());
      this.set('terminology.sell', instrument.tradingTerminology.sell.toUpperCase());
      this.set('terminology.buySizePlaceholder', instrument.tradingTerminology.buySizePlaceholder);
      this.set('terminology.sellSizePlaceholder', instrument.tradingTerminology.sellSizePlaceholder);

      let displayName = '';

      if (instrument.spread) {
        displayName = instrument.shortName + instrument.spread.displayPriceString;
      } else {
        displayName = instrument.name;
      }

      this.set('instrument.shortName', displayName);
      this.set('instrument.strikeString', instrument.strikeString);
      this.set('instrument.priceDisplay', instrument.priceDisplay);
      this.set('instrument.isUserInputDisabled', instrument.inactive || !instrument.canUserEnterOrders);

      // Based on the preference "swapBidAndOffer" toggle the mirror class.
      this.shadowRoot.querySelector('#mirrorElements').classList.toggle('mirror', BGC.dataStore.userSettingsStore.get('swapBidAndOffer'));

      // Now update the sub-property bindings for active order data.
      // Order sizes should be coerced to string by + "", as they will be revert values of size cells
      if (activeOrder) {
        /*
            setting buy and sell to null then the price value - this is to force the bind system to update.
            buyPrice is bound to orderPrice attribute on <size-input-control> - the template was not creating
            orderPrice, so would not allow order size changes.

         */
        this.set('order.buyPrice', null);
        this.set('order.buyPrice', activeOrder.buyOrder ? activeOrder.buyOrder.price : instrument.midPrice);
        this.set('order.buySize', activeOrder.hasBuySize ? activeOrder.buySize : null);

        const buyInput = this.shadowRoot.querySelector('size-input-control.buy').inputField;

        // this.shadowRoot.querySelector('.size input.buy').classList.toggle('no-order', !activeOrder.hasBuySize);
        // this.shadowRoot.querySelector('.size input.buy').classList.toggle('published-by-excel', activeOrder.wasBuyPublishedByExcel);
        buyInput.classList.toggle('no-order', !activeOrder.hasBuySize);
        buyInput.classList.toggle('published-by-excel', activeOrder.wasBuyPublishedByExcel);

        this.set('order.sellPrice', null);
        this.set('order.sellPrice', activeOrder.sellOrder ? activeOrder.sellOrder.price : instrument.midPrice);
        this.set('order.sellSize', activeOrder.hasSellSize ? activeOrder.sellSize : null);

        const sellInput = this.shadowRoot.querySelector('size-input-control.sell').inputField;

        sellInput.classList.toggle('no-order', !activeOrder.hasSellSize);
        sellInput.classList.toggle('published-by-excel', activeOrder.wasSellPublishedByExcel);

        this.set('order.hasCancellableBuySize', activeOrder.hasCancellableBuySize);
        this.set('order.hasCancellableSellSize', activeOrder.hasCancellableSellSize);
      } else {
        this.set('order.buyPrice', instrument.midPrice);
        this.set('order.buySize', null);

        this.set('order.sellPrice', instrument.midPrice);
        this.set('order.sellSize', null);

        this.set('order.hasCancellableBuySize', false);
        this.set('order.hasCancellableSellSize', false);

        this.shadowRoot.querySelectorAll('size-input-control').forEach(inputElem => {
          inputElem.inputField.classList.toggle('no-order', true);
          inputElem.inputField.classList.toggle('published-by-excel', false);
        });
      }

      // All callback functions are expected to be bound to a context when they are passed in.
      // This allows this component to only be aware of data attributes of a "view model"
      // rather than having expectations of the functional interface of an instrument data model.
      // Callback functions don't have to be set every time the data is updated...

      if (callbackFunctions) {
        // Set the validation callback for typed size.
        this.shadowRoot.querySelectorAll('size-input-control').forEach(sizeInput => {
          sizeInput.setValidationCallback(callbackFunctions.sizeValidationCallback);
        });

        // Set the validation callbacks for the nudgeable price controls, if in use
        if (this.moveableMidsEnabled) {
          const bidControl = this.querySelector('nudgeable-price-input[side=\'buy\']');
          const offerControl = this.querySelector('nudgeable-price-input[side=\'sell\']');

          if (bidControl) {
            if (!disableBidInput) {
              bidControl.setCallbacks(
                callbackFunctions.bidPriceValidationCallback,
                callbackFunctions.nudgeCallback,
                callbackFunctions.priceFormatter
              );
            }

            bidControl.setInstrument(instrument, disableBidInput);

            if (!disableBidInput) {
              // Set buy side quick sizes according to whatever the buy side price is
              setBuySizesForMidPrice = false;
              bidControl.dispatchEvent(new CustomEvent('price:updated', {detail : {priceText : bidControl.getValue(), side : 'buy'}}));
            }
          }

          if (offerControl) {
            if (!disableOfferInput) {
              offerControl.setCallbacks(
                callbackFunctions.offerPriceValidationCallback,
                callbackFunctions.nudgeCallback,
                callbackFunctions.priceFormatter
              );
            }

            offerControl.setInstrument(instrument, disableOfferInput);

            if (!disableOfferInput) {
              // Set sell side quick sizes according to whatever the sell side price is
              setSellSizesForMidPrice = false;
              offerControl.dispatchEvent(new CustomEvent('price:updated', {detail : {priceText : offerControl.getValue(), side : 'sell'}}));
            }
          }
        }

        this.shadowRoot.querySelectorAll('.slow-data-entry').forEach(function (column) {
          column.classList.toggle('wide-display', this.moveableMidsEnabled);
        }, this);
      }

      if (setBuySizesForMidPrice) {
        this.shadowRoot.querySelector('quicksize-buttonset[side=\'buy\']').updateSizes(instrument.quickSizes.buy);
      }
      if (setSellSizesForMidPrice) {
        this.shadowRoot.querySelector('quicksize-buttonset[side=\'sell\']').updateSizes(instrument.quickSizes.sell);
      }
    } else {
      throw new TypeError('Inplace Order Entry shown with no instrument');
    }
  }

  show (data, callbackFunctions, tradeSide, parentPriceCell, parentComponent) {
    const eTradeSide = typeof tradeSide === 'string' ? this.ETradeSide[tradeSide] : tradeSide;

    if (!BGC.dataStore.userSettingsStore.get('enableInPlaceOrderEntry') ||
      data.instrument.inactive) {
      return;
    }

    this.moveableMidsEnabled = data.moveableMidEnabled;
    this.parentPriceCell = parentPriceCell;
    this.parentComponent = parentComponent;

    this.setData(data.instrument, data.activeOrder, callbackFunctions);

    switch (eTradeSide) {
      case this.ETradeSide.eBuy:
        this.showBuySide = true;
        this.showSellSide = false;
        break;
      case this.ETradeSide.eSell:
        this.showBuySide = false;
        this.showSellSide = true;
        break;
      case this.ETradeSide.eBoth:
        this.showBuySide = true;
        this.showSellSide = true;
        break;
    }

    // Position the OEB to the cell that triggered it
    this.isOpen = true;
    this.parentPriceCell.classList.add('is-under-oeb');

    // Apply direct position for expandWindow equal true from layout rule
    if (BGC.dataStore.userSettingsStore.get('enableCentreOEDB')) {
      this.calcCentrePositioning(parentPriceCell, parentComponent);
    } else {
      this.calcPositioning(parentPriceCell, parentComponent);
    }

    flush();

    // Add handlers for clicks and key presses
    document.querySelector('body').addEventListener('mousedown', this.handleOutsideClick);
    document.querySelector('body').addEventListener('keydown', this.handleEscKey);
    this.addEventListener('mouseup', this.killEvent);

    // BUY/SELL buttons should only be enabled if there is typed size
    this.updateBuySellButtonState();
    this.enableOrderEntry(!this.instrument.isUserInputDisabled);

    // If the OEB is opened one-sided, set the focus to the size input ctrl on that side
    if (this.showBuySide !== this.showSellSide) {
      this.shadowRoot.querySelector(`size-input-control.${this.showBuySide ? 'buy' : 'sell'}`).inputField.focus();
    }

    BGC.logger.logInformation('', `In-place Order Entry Box shown for ${this.instrument.instrumentId}|${this.instrument.name}`);
  }

  hide () {
    if (this.isOpen) {
      if (this.parentPriceCell) {
        this.parentPriceCell.classList.remove('is-under-oeb');
        this.parentPriceCell = undefined;
      }

      this.style.display = 'none';

      BGC.ui.viewUtils.lastFocusedControl = undefined;
      this.enableOrderEntry(true);

      // Revert any typed text
      this.querySelectorAll('size-input-control').forEach(inputCtrl => {
        inputCtrl.revert();
      });

      // Remove handlers for all clicks and key presses
      document.querySelector('body').removeEventListener('mousedown', this.handleOutsideClick);
      document.querySelector('body').removeEventListener('keydown', this.handleEscKey);
      this.removeEventListener('mouseup', this.killEvent);

      this.isOpen = false;
    }
  }

  showCloseTooltip (event) {
    const tooltip = BGC.ui.tooltipSingleton.getInstance();
    const targetRect = event.target.getBoundingClientRect();
    const position = {
      x : targetRect.left + (targetRect.width / 2),
      y : (targetRect.top + (targetRect.height / 2)) + 12
    };

    tooltip.hide();
    tooltip.show(BGC.resources.IDS_CLOSE, position);
  }

  hideCloseTooltip () {
    BGC.ui.tooltipSingleton.getInstance().hide();
  }

  getInstrumentId () {
    return this.instrument ? this.instrument.instrumentId : undefined;
  }

  calcPositioning (parentPriceCell, parentComponent) {
    const parentElem = parentPriceCell || this.parentPriceCell;
    const parentCellComponent = parentComponent || this.parentComponent;
    const parentRect = parentElem && parentElem.getBoundingClientRect();
    const bodyRect = document.body.getBoundingClientRect();


    /* absolute WRT the doc window */
    const parentOffset = parentElem && $(parentElem).offset();

    // const scrollContainer = parentElem && parentElem.closest('.scroll-container');
    const scrollContainer = parentCellComponent.closest('.scroll-container');
    const scrollContainerRect = scrollContainer && scrollContainer.getBoundingClientRect();
    const containerRect = scrollContainerRect || bodyRect;
    let eVertPosition = null;
    let eHorzPosition = null;

    this.resetInplaceOrderEntryStyling(false);

    if (!parentElem) {
      throw new TypeError('InPlaceOrderEntry.calcPositioning: Can\'t calculate positioning without a parent Element');
    }

    if (!this.isOpen) {
      return;
    }

    // Make it invisible if its parent price cell is out of sight
    if ((parentRect.bottom < scrollContainerRect.top) || (parentRect.top > scrollContainerRect.bottom)) {
      this.style.display = 'none';
    } else {
      this.style.removeProperty('display');
    }

    // Position it above or below the cell depending on relationship to the window as a whole
    if (parentRect.top > (bodyRect.top + bodyRect.height / 2)) {
      // Parent element is in bottom half of screen so show the OEB above
      eVertPosition = this.EPosition.eAbove;
    } else {
      eVertPosition = this.EPosition.eBelow;
    }

    // If parent cell is a matrix cell, use offset positioning to left or right
    if (parentElem.parentNode.host) {
      if (parentRect.left > (containerRect.left + containerRect.width / 2)) {
        // Parent element is in RH half of screen so show the OEB to the left
        eHorzPosition = this.EPosition.eLeft;
      } else {
        // Parent element is in LH half of screen so show the OEB to the right
        eHorzPosition = this.EPosition.eRight;
      }
    } else {
      // Tile-based price cell
      eHorzPosition = this.EPosition.eCentered;
    }

    switch (eVertPosition) {
      case this.EPosition.eAbove:
        // Set styling to position the callout
        this.classList.remove('below');
        this.classList.add('above');

        // Set the absolute offset of the whole enchilada
        this.style.removeProperty('top');
        this.style.bottom = `${bodyRect.bottom - parentOffset.top}px`;
        break;
      case this.EPosition.eBelow:
        // Set styling to position the callout
        this.classList.remove('above');
        this.classList.add('below');

        // Set the absolute offset of the whole enchilada
        this.style.removeProperty('bottom');
        this.style.top = `${parentOffset.top + parentRect.height}px`;
        break;
    }

    switch (eHorzPosition) {
      case this.EPosition.eLeft:
        // Set styling to position the callout
        this.classList.remove('right');
        this.classList.remove('centered');
        this.classList.add('left');

        // Set the absolute offset of the whole enchilada
        this.style.removeProperty('left');
        this.style.right = `${(bodyRect.right - (parentOffset.left + parentRect.width)) - 2}px`;
        break;
      case this.EPosition.eRight:
        // Set styling to position the callout
        this.classList.remove('left');
        this.classList.remove('centered');
        this.classList.add('right');

        // Set the absolute offset of the whole enchilada
        this.style.removeProperty('right');
        this.style.left = `${parentOffset.left - 2}px`;
        break;
      case this.EPosition.eCentered:
        this.classList.remove('left');
        this.classList.remove('right');
        this.classList.add('centered');

        // Set the absolute offset of the whole enchilada
        this.style.removeProperty('right');
        this.style.left = `calc(${parentOffset.left}px - 11.5rem)`;
        break;
    }
  }

  // Calculate direct position for UK Inflation grids
  calcCentrePositioning (parentPriceCell, parentComponent) {
    const parentElem = parentPriceCell || this.parentPriceCell;
    const parentCellComponent = parentComponent || this.parentComponent;
    const parentRect = parentElem && parentElem.getBoundingClientRect();
    const bodyRect = document.body.getBoundingClientRect();

    /* absolute WRT the doc window */
    const parentOffset = parentElem && $(parentElem).offset();

    // const scrollContainer = parentElem && parentElem.closest('.scroll-container');
    const scrollContainer = parentCellComponent.closest('.scroll-container');
    const scrollContainerRect = scrollContainer && scrollContainer.getBoundingClientRect();

    this.resetInplaceOrderEntryStyling(true);

    if (!parentElem) {
      throw new TypeError('InPlaceOrderEntry.calcCentrePositioning: Can\'t calculate positioning without a parent Element');
    }

    if (!this.isOpen) {
      return;
    }

    // Make it invisible if its parent price cell is out of sight
    if ((parentRect.bottom < scrollContainerRect.top) || (parentRect.top > scrollContainerRect.bottom)) {
      this.style.display = 'none';
    } else {
      this.style.removeProperty('display');
    }

    // Set styling to position the callout
    this.classList.add('above');

    // Set the absolute offset of the whole enchilada
    this.style.bottom = `${bodyRect.bottom - parentOffset.top}px`;

    // Set styling to position the callout
    this.classList.add('centered');

    // Set the absolute offset of the whole enchilada
    // cell left + (popup width divide by 2 - cell width divide 2)
    const left = parentOffset.left - (this.offsetWidth / 2 - parentCellComponent.offsetWidth / 2);

    this.style.left = `${left}px`;
  }

  resetInplaceOrderEntryStyling (isCenteredOEDB = false) {
    // Remove all the pre-exist style and classList for the inplace order entry
    // By enable on and off for the centre OEDB it may left style and classList

    // in-case user has switched between centred or positioned popup
    if (isCenteredOEDB) {
      $(this).removeClass('below left bottom top ').addClass('centreOEDB');
    } else {
      $(this).removeClass('centreOEDB');
    }

    this.style.removeProperty('top');
    this.style.removeProperty('bottom');
    this.style.removeProperty('left');
    this.style.removeProperty('right');
  }

  enableOrderEntry (isEnabled) {
    this.querySelectorAll('.order-entry .size, quicksize-buttonset li').forEach(elem => {
      elem.classList.toggle('user-input-disabled', !isEnabled);
    });

    this.querySelectorAll('nudgeable-price-input').forEach(function (elem) {
      const side = elem.getAttribute('side');

      if (side === 'buy') {
        elem.classList.toggle('user-input-disabled', !isEnabled || !this.instrument.isMoveableBidEnabled);
      } else {
        elem.classList.toggle('user-input-disabled', !isEnabled || !this.instrument.isMoveableOfferEnabled);
      }
    }, this);
  }

  updateBuySellButtonState (side) {
    const buyButton = this.shadowRoot.querySelector('button.buy');
    const sellButton = this.shadowRoot.querySelector('button.sell');
    const buyInput = this.shadowRoot.querySelector('size-input-control.buy');
    const sellInput = this.shadowRoot.querySelector('size-input-control.sell');

    if (buyButton && (side === undefined || side === 'buy')) {
      buyButton.classList.toggle('user-input-disabled', buyInput.inputField.value === '');
    }

    if (sellButton && (side === undefined || side === 'sell')) {
      sellButton.classList.toggle('user-input-disabled', sellInput.inputField.value === '');
    }
  }

  handleMouseOver () {
    // If the QoS timer is running, generate the interaction metric now
    BGC.utils.generateInteractivityQoSMetric('oebActivated');
  }

  handleKeyDown (event) {
    // If the QoS timer is running, generate the interaction metric now
    BGC.utils.generateInteractivityQoSMetric('oebActivated');

    if (event.keyCode === KeyCodes.ESC) {
      this.hide();
    }
  }

  handleKeyUp () {
    // Enable/Disable the BUY/SELL buttons dependent on
    // whether their associated input control contains any text
    this.updateBuySellButtonState();
  }

  handleSubmitOrderEvent (event) {
    // Process the input and attempt to send an order.
    // If input is invalid, leave the OEB open for correction, else dismiss it
    if (this.processSubmitOrderEvent(event)) {
      this.hide();
    }
  }

  handleBuySellButtonClick (event) {
    event.stopPropagation();

    // If the QoS timer is running, generate the interaction metric now
    BGC.utils.generateInteractivityQoSMetric('oebActivated');

    const normalizedEvent = dom(event);
    const side = normalizedEvent.rootTarget.classList.contains('buy') ? 'buy' : 'sell';
    const sizeInput = this.shadowRoot.querySelector(`size-input-control.${side}`);


    // If the last focused control was the input on the other side, revert its contents.
    // We only allow the user to work on one side at a time
    if (BGC.ui.viewUtils.lastFocusedControl &&
      BGC.ui.viewUtils.lastFocusedControl.getAttribute('is') === 'size-input-control' &&
      BGC.ui.viewUtils.lastFocusedControl.side !== sizeInput.side) {
      BGC.ui.viewUtils.lastFocusedControl.revert();
    }

    sizeInput.validateAndRequestOrderSubmission(this.getPriceForSubmission(side));
  }

  handleCancelIconClick (event) {
    event.stopPropagation();

    // If the QoS timer is running, generate the interaction metric now
    BGC.utils.generateInteractivityQoSMetric('oebActivated');

    // trigger cancel of outstanding order
    this.fire('cancelActiveOrder', {
      eventSource  : 'Inplace-OEB',
      instrumentId : this.instrument.instrumentId,
      side         : event.target.className.indexOf('buy') > -1 ? 'buy' : 'sell'
    });
    this.hide();
  }

  handleOutsideClick (event) {
    // Allow for the click being within the OEB or within a validation error popup,
    // which may appear if the user types size in the free-text input controls.
    // Also ignore it if it is within the parent price cell, otherwise we end up
    // closing the OEB because of handling the click that opened it!
    const normalizedEvent = dom(event);
    const popup = normalizedEvent.rootTarget.closest('.popupDialog');

    // const inplaceOEB = normalizedEvent.rootTarget.closest('.oeb-panel');
    // March 2023 - can't do this anymore as closest doesn't work with new shadow root components.

    const $parentPriceCell = $(this.parentPriceCell);
    const parentPos = $parentPriceCell.offset();
    const parentRect = {
      top    : parentPos.top,
      left   : parentPos.left,
      width  : $parentPriceCell.outerWidth(),
      height : $parentPriceCell.outerHeight()
    };

    const isInPopup = BGC.utils.pointInRect(event.pageX, event.pageY, this.getBoundingClientRect());
    const isInPriceCell = BGC.utils.pointInRect(event.pageX, event.pageY, parentRect);


    if (!(isInPopup || isInPriceCell) && !popup) {
      this.hide();
    }

    // if (!inplaceOEB && !popup && !BGC.utils.pointInRect(event.pageX, event.pageY, parentRect)) {
    //   this.hide();
    // }
  }

  handleEscKey (event) {
    const key = event.keyCode;

    if (key === KeyCodes.ESC) {
      // If the QoS timer is running, generate the interaction metric now
      BGC.utils.generateInteractivityQoSMetric('oebActivated');

      this.hide();
    }
  }

  killEvent (event) {
    event.stopPropagation();
    event.preventDefault();

    return false;
  }
}

customElements.define('inplace-order-entry', InPlaceOrderEntry);

// context.inplaceOEB = InPlaceOrderEntry;

context.inplaceOEB = (function () {
  let instance = null;

  return {
    getInstance () {
      if (!instance) {
        // document.registerElement('inplace-order-entry', InPlaceOrderEntry);

        instance = new InPlaceOrderEntry();
        document.body.appendChild(instance);
        instance.style.display = 'none';
      }

      return instance;
    }
  };
}());
