import {html} from '@polymer/polymer/polymer-element';

// https://jira.cad.local:8443/browse/BGCVM-97

export default html`
<style>
    * { box-sizing: border-box;}
    
    :host {
        width: 100%;
        font-size: 1.1rem;
        height: auto;
        display: block;
    }

    :host(.hide-me) {
        display: none;
    }

    .progress-row {
        display: flex;
        background-color: var(--progress-control-background);
        color: var(--progress-control-text);
        padding: 0.4rem 0;
    }

    label {
        cursor: default;
        margin-left: 0.5rem;
    }

    .phaseOneProgress {
        flex: 1;
        height: 1rem;
        margin: 0.4rem 0 0.2rem 0.5rem;
        display:none;
    }

    .phaseOneProgress.proRata {
        display:flex;
        border-radius: 4px 0px 0px 4px;
    }
    
    .phaseOneProgress .phaseOneBar {
        height: 0.9rem;
        width: 0;
        border-radius: 4px 0px 0px 4px;
    }

    .phaseTwoProgress {
    flex: 1;
    height: 1rem;
    margin: 0.4rem 0.5rem 0.2rem 0.5rem;
    border-radius: 4px;
}

    .phaseTwoProgress.proRata {
    flex: 3;
    margin: 0.4rem 0.5rem 0.2rem 0.0rem;
    border-radius: 0px 4px 4px 0px;
}

    .phaseTwoProgress .phaseTwoBar {
    height: 0.9rem;
    width: 0;
    border-radius: 4px;
}

    .phaseTwoProgress.proRata .phaseTwoBar {
    height: 0.9rem;
    width: 0;
    border-radius: 0px 4px 4px 0px;
}

.message {
    font-size: 1.2rem;
    padding: 0 0 0.1rem 0.5rem;
    font-weight: normal;
    color: var(--status-overlay-message-color);
    background-color: var(--status-overlay-background-color);
}

    .phaseOneProgress {
        background-color: var(--progress-control-bar-unfilled);
        border: 1px solid var(--progress-control-border);
        border-right: none;
    }
    .phaseOneProgress .phaseOneBar {
        background-color: var(--progress-control-PhaseOne-bar-filled);
    }
    .phaseTwoProgress {
        border: 1px solid var(--progress-control-border);
    }
    .phaseTwoProgress.proRata {
        border-left: none;
    }
    .phaseTwoProgress.proRata .phaseTwoProgress.proRata .phaseTwoBar {
        background-color: var(--progress-control-PhaseTwo-bar-filled);
    }
    .phaseTwoProgress[state="zero"] {
        background-color: var(--progress-control-bar-unfilled);
    }
    .phaseTwoBar[state="normal"] {
        background-color: var(--progress-control-bar-filled);
    }
    .phaseTwoBar[state="red"] {
        background-color: var(--progress-bar-red);
    }
    .phaseTwoBar {
        transition: width 1s ease-in-out;
    }
    
    
</style>
<div class="progress-row">
    <!-- use label element to prevent rendering of progress bar stopping blinking caret -->
    <label class="time-left">00:00:00</label>
    <div class="phaseOneProgress">
        <div class="phaseOneBar"></div>
    </div>
    <div class="phaseTwoProgress">
        <div class="phaseTwoBar"></div>
    </div>
</div>
<div class="message">[[message]]</div>
`;
