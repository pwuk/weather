/* eslint-disable max-statements, func-names, no-param-reassign, no-magic-numbers, complexity, max-lines */

/* global BGC: false, $: false */

import {PolymerElement} from '@polymer/polymer';
import {isWebDeployed} from '../../bgc';
import componentTemplate from './progress-bar.template';

const {view: context} = window.BGC.ui;

const RED_THRESHOLD = 30;
const STATE = {
  RED    : 'red',
  NORMAL : 'normal',
  ZERO   : 'zero'
};

/* Calculates the progress state based on the thresholds and time remaining in seconds*/
function progressState (remainingSeconds) {
  // eslint-disable-next-line init-declarations
  let state;

  if (remainingSeconds <= 0) {
    state = STATE.ZERO;
  } else if (remainingSeconds <= RED_THRESHOLD) {
    state = STATE.RED;
  } else {
    state = STATE.NORMAL;
  }

  return state;
}

function padding (number) {
  return `00${number}`.substr(-2);
}

class ProgressBar extends PolymerElement {
  static get properties () {
    return {
      timerId : {
        type               : String,
        notify             : true,
        reflectToAttribute : false,
        value              : ''
      },

      message : {
        type  : String,
        value : ''
      },

      startTime : {
        type               : Number,
        notify             : true,
        reflectToAttribute : false,
        value              : 0
      },

      endTime : {
        type               : Number,
        notify             : true,
        reflectToAttribute : false,
        value              : 0,
        observer           : '_endTimeModified'
      },

      timeOffset : {
        type               : Number,
        notify             : true,
        reflectToAttribute : false,
        value              : 0
      },

      timeRemaining : {
        type   : Number,
        notify : false,
        value  : 0
      },

      hideWhenDone : {
        type   : Boolean,
        notify : true,
        value  : false
      },

      auctionPhase : {
        type               : String,
        notify             : true,
        reflectToAttribute : false,
        value              : ''
      },

      phaseoneendTime : {
        type               : Number,
        notify             : true,
        reflectToAttribute : false,
        value              : 0
      }
    };
  }

  disconnectedCallback () {
    super.disconnectedCallback();
    this._cancelIntervalTimer();
  }

  ready () {
    super.ready();
    this._endTimeModified();
  }

  _cancelIntervalTimer () {
    if (this.isIntervalTimerRunning) {
      BGC.logger.logInformation(`ProgressBar:${this.timerId}`, 'Stopping interval timer');
      BGC.utils.removeGloballySynchronizedTimerCallback(this.timerId, 1000);
      this.isIntervalTimerRunning = false;
    }
  }

  _endTimeModified () {
    if (!this.isIntervalTimerRunning) {
      if (this.endTime > 0) {
        this.isIntervalTimerRunning = true;
        BGC.logger.logInformation(`ProgressBar:${this.timerId}`, `Starting interval timer. StartTime:
           [${this.startTime}] EndTime: [${this.endTime}] TimeOffset: [${this.timeOffset}]`);
        BGC.utils.addGloballySynchronizedTimerCallback(this.timerId, this, this.updateProgress, 1000);
      }
    }
  }

  static get template () {
    return componentTemplate;
  }

  updateProgress (doReset) {
    let timeText = '';
    let timeRemaining = 0;
    let seconds = 0;
    let minutes = 0;
    let hours = 0;
    let duration = 0;
    const {startTime} = this;
    const {endTime} = this;
    const {timeOffset} = this;
    const clientNow = Math.floor(Date.now() / 1000);
    const wasHidden = this.classList.contains('hide-me');
    let doLogging = false;
    const {auctionPhase} = this;
    const {phaseoneendTime} = this;
    let percentageProgressWidth = 0;

    // Pro Rata Phase
    if (auctionPhase === 'prorataPhase' && phaseoneendTime !== 0) {
      this.classList.toggle('hide-me', false);

      $(this.shadowRoot).find('.phaseOneProgress').addClass('proRata');
      $(this.shadowRoot).find('.phaseTwoProgress').addClass('proRata');

      // Reset phase 2 timer to zero
      this.shadowRoot.querySelector('.phaseTwoBar').setAttribute('style', 'width:0px');

      timeRemaining = phaseoneendTime - clientNow + timeOffset;

      // calculates hours passed
      seconds = timeRemaining % 60;
      timeRemaining -= seconds;
      minutes = (timeRemaining / 60) % 60;
      timeRemaining -= minutes * 60;
      hours = timeRemaining / 60 / 60;

      timeText = `${padding(hours)}:${padding(minutes)}:${padding(seconds)}`;
      this.shadowRoot.querySelector('.time-left').textContent = timeText;

      duration = phaseoneendTime - startTime;
      percentageProgressWidth = 100 - Math.floor(((clientNow - startTime - timeOffset) * (100 / duration)) + 0.5);
      this.shadowRoot.querySelector('.phaseOneBar').setAttribute('style', `width:${percentageProgressWidth}%`);
    } else {
      if (phaseoneendTime === 0) {
        $(this.shadowRoot).find('.phaseOneProgress').removeClass('proRata');
        $(this.shadowRoot).find('.phaseTwoProgress').removeClass('proRata');
        this.shadowRoot.querySelector('.phaseOneBar').setAttribute('style', 'width:0%');
      } else if (phaseoneendTime !== 0) {
        this.shadowRoot.querySelector('.phaseOneBar').setAttribute('style', 'width:100%');
      }

      timeRemaining = endTime - clientNow + timeOffset;

      // Check this.isIntervalTimerRunning for anything other than a reset,
      // to ensure we aren't processing a queued timer event after the timer was reset.
      if ((this.isIntervalTimerRunning && timeRemaining < 0) || doReset) {
        if (doReset) {
          BGC.logger.logInformation(`ProgressBar:${this.timerId}`, 'Forced Reset of interval timer');
        } else {
          BGC.logger.logInformation(`ProgressBar:${this.timerId}`,
            `Timer expired. StartTime: [${startTime}] 
                EndTime: [${endTime}]
                TimeOffset: [${timeOffset}],
                Time remaining: [${timeRemaining}]`);
        }
        this._cancelIntervalTimer();
        this.shadowRoot.querySelector('.time-left').textContent = '00:00:00';
        this.shadowRoot.querySelector('.phaseTwoBar').setAttribute('style', 'width:0px');
        if (this.hideWhenDone) {
          this.classList.toggle('hide-me', true);
        }
      } else if (this.isIntervalTimerRunning) {
        if (isWebDeployed && (timeRemaining > (this.timeRemaining + 1))) {
          doLogging = true;
        }
        this.timeRemaining = timeRemaining;
        const state = progressState(timeRemaining);

        // calculates hours passed
        seconds = timeRemaining % 60;
        timeRemaining -= seconds;
        minutes = (timeRemaining / 60) % 60;
        timeRemaining -= minutes * 60;
        hours = timeRemaining / 60 / 60;

        // updates time left display
        timeText = `${padding(hours)}:${padding(minutes)}:${padding(seconds)}`;
        this.shadowRoot.querySelector('.time-left').textContent = timeText;
        if (doLogging) {
          BGC.logger.logInformation(`ProgressBar:${this.timerId}`,
            `StartTime: [${startTime}]
               EndTime: [${endTime}]
               TimeOffset: [${timeOffset}],
               Time remaining updated to [${timeText}]`);
        }

        // updates progress bar
        duration = endTime - startTime;
        percentageProgressWidth = 100 - Math.floor(((clientNow - startTime - timeOffset) * (100 / duration)) + 0.5);
        this.shadowRoot.querySelector('.phaseTwoBar').setAttribute('style', `width:${percentageProgressWidth}%`);
        this.shadowRoot.querySelector('.phaseTwoBar').setAttribute('state', state);
        this.classList.toggle('hide-me', false);
      }
    }


    if (wasHidden !== this.classList.contains('hide-me')) {
      this.dispatchEvent(new CustomEvent('recalcLayout', {bubbles : true, composed : true}));
    }
  }
}

customElements.define('progress-bar', ProgressBar);
context.ProgressBar = ProgressBar;
