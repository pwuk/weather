/* global BGC: false, $: false, _:false, Backbone: false */
// /////////////////////////////////////////////////////////////////////////////
// file headerview.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

// eslint-disable-next-line func-names
(function (context, dataStore) {
  // eslint-disable-next-line no-param-reassign
  context.HeaderView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#header'),

    initialize () {
      this.tooltip = BGC.ui.tooltipSingleton.getInstance();

      _.extend(this, context.NotificationFlashBehavior);

      // render view
      this.render();

      this.listenTo(this.model, 'activeInstrumentCountChanged', this.updateInstrumentCount);
      this.listenTo(this.model, 'glowCountChanged', this.updateGlowsCount);
      this.listenTo(this.model, 'tradeCountChanged', this.updateTradesCount);

      // The header is hidden until initialisation due to artefacts being seen during the intialisation process.
      $('.header').show();
    },

    render () {
      if (this.$el) {
        this.$el.off('mouseover', '[tipText]', this.showTooltip);
        this.$el.off('mouseleave click', '[tipText]', this.hideTooltip);
      }

      // render header template
      this.$el.html(this.template({
        srcFlag        : BGC.resources.srcImageMap[this.model.get('currencyId')],
        srcTitle       : BGC.resources.srcImageMap[this.model.get('titleId')],
        currencyId     : this.model.get('currencyId'),
        businessConfig : this.model.get('businessConfig'),
        instCountTip   : BGC.resources.IDS_INST_COUNT_BADGE_TIP,
        glowCountTip   : BGC.resources.IDS_INTEREST_COUNT,
        tradeCountTip  : BGC.resources.IDS_TRADE_COUNT
      }));

      this.$el.on('mouseover', '[tipText]', this, this.showTooltip);
      this.$el.on('mouseleave click', '[tipText]', this, this.hideTooltip);

      this.updateCounts();
    },

    updateCounts () {
      this.updateInstrumentCount();
      this.updateGlowsCount();
      this.updateTradesCount();
    },

    updateInstrumentCount () {
      const lastCount = this.instCount;
      const $badge = this.$el.find('.instrument-count-badge');

      // Document attribute determines whether or not instrument count is shown
      if (dataStore.userSettingsStore.get('displayInstrumentCount')) {
        this.instCount = dataStore.pageLayout.getTilesActiveInstrumentCount();
      } else {
        this.instCount = 0;
      }

      if (lastCount !== this.instCount) {
        $badge.text(this.instCount || '');
        if (this.instCount) {
          this.flashNotification(this.EFlashType.eInstrumentCount, $badge);
        }
      }
    },

    updateGlowsCount () {
      const lastCount = this.glowCount;
      const $badge = this.$el.find('.third-party-badge');

      // Total glows count only shown for tiles-only (list-based) auctions
      if (dataStore.userSettingsStore.get('retainHistory')) {
        this.glowCount = dataStore.auctions.getLiveInterestCount();
      } else if (dataStore.pageLayout.hasMatrices()) {
        this.glowCount = 0;
      } else {
        this.glowCount = dataStore.pageLayout.getTilesGlowCount();
      }

      if (lastCount !== this.glowCount) {
        $badge.text(this.glowCount || '');
        if (this.glowCount) {
          this.flashNotification(this.EFlashType.eThirdPartyInterest, $badge);
        }
      }
    },

    updateTradesCount () {
      const lastCount = this.gavelCount;
      const $badge = this.$el.find('.trade-count-badge');

      // Total gavels count only shown for tiles-only (list-based) auctions
      if (dataStore.userSettingsStore.get('retainHistory')) {
        this.gavelCount = dataStore.auctions.getLiveTradeCount();
      } else if (dataStore.pageLayout.hasMatrices()) {
        this.gavelCount = 0;
      } else {
        this.gavelCount = dataStore.pageLayout.getTilesTradeCount();
      }

      if (lastCount !== this.gavelCount) {
        $badge.text(this.gavelCount || '');
        if (this.gavelCount) {
          this.flashNotification(this.EFlashType.eTradeCount, $badge);
        }
      }
    },

    showTooltip (event) {
      // Because events are delegated, "this" is the object we are receiving the event from.
      // For this reason, when we add the listener we set the header view object
      // as the event data to include every time such an event is thrown
      const headerView = event.data;
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        // eslint-disable-next-line id-length,no-magic-numbers
        x : targetRect.left + (targetRect.width / 2),
        // eslint-disable-next-line id-length,no-magic-numbers
        y : (targetRect.top + (targetRect.height / 2)) + 12
      };

      headerView.tooltip.hide();
      headerView.tooltip.show($(this)
        .attr('tipText'), position);
    },

    hideTooltip (event) {
      const headerView = event.data;

      headerView.tooltip.hide(true);
    }
  });
}(window.BGC.ui.view, window.BGC.dataStore));
