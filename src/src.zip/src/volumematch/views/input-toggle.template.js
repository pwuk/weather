import {html} from '@polymer/polymer/polymer-element';

export default html`
<style>
    :host {
    border - radius: 0.7rem;
    padding: 0.2rem 0.5rem;
}

    :host[checked] fa-icon, :host[checked] span {
    color: yellow;
}

    .toggle {
    margin - bottom: 0.3rem;
}

    :host[checked] .toggle {
    background - color: limegreen !important;
}

    :host[checked] .toggle:before {
    background - color: green !important;
}

</style>
    <input type="checkbox" disabled="[[disabled]]" checked="[[checked]]">
        <span class="toggle"></span>
        <fa-icon icon-class$="[[icon]]"></fa-icon>
        <span>[[label]]</span>
`;
