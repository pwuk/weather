/* global $: false */
// /////////////////////////////////////////////////////////////////////////////
// file docking.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////dev

$(() => {
  // eslint-disable-next-line func-names
  $('body').on('dragover', '.drop-target-line', function (event) {
    // allows drop-target-line to receive draggable elements
    event.preventDefault();

    // changes the color of the drop-target-line
    $(this).addClass('hovered');
  });

  // eslint-disable-next-line func-names
  $('body').on('dragleave', '.drop-target-line', function () {
    $(this).removeClass('hovered');
  });

  // eslint-disable-next-line func-names
  $('body').on('drop', '.drop-target-line', function (event) {
    const source = $(`.${event.originalEvent.dataTransfer.getData('source')}`);

    // remove hovered style and hide drop target
    $(this).removeClass('hovered');
    $(this).hide();

    // insert after first drop target and before last drop target
    if ($('.drop-target-line').index(this) === 0) {
      source.insertAfter(this);
    } else {
      source.insertBefore(this);
    }
  });
});
