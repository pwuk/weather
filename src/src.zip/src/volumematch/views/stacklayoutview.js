/* eslint-disable func-names, no-param-reassign, no-plusplus */
/* global BGC: false, $: false, Backbone: false */

(function (context) {
  context.StackLayoutView = Backbone.View.extend({
    id        : 'stack-layout-view',
    className : 'scrollable-content',

    initialize (options) {
      BGC.logger.logInformation('StackLayoutView', 'Creating Stack Layout View...');

      const {
        auctions, tiles, settings, isBrokerMode
      } = options;

      // Static layout settings
      this.settings = {
        isBrokerMode,
        displayFavorites : !isBrokerMode && settings.get('displayFavorites')
      };

      this.tiles = tiles;
      this.listenTo(auctions, 'add', this.addLayout);
      this.listenTo(auctions, 'remove', this.removeLayout);
    },

    addLayout (model) {
      const {settings, tiles} = this;
      const parentNode = this.$el[0];

      // Create the new layout
      const newLayout = new context.AuctionLayout({
        model,
        tiles,
        settings
      });

      // Layouts are sorted by 'id' - the id is the unique sequential VM Session Id
      const layouts = this.$el.children('auction-layout');
      const lastLayoutId = layouts.length ? Number(layouts[layouts.length - 1].id) : 0;

      if (lastLayoutId === 0) {
        // If this is the first layout, prepend to the the container element
        this.$el.prepend(newLayout);
      } else if (model.id < lastLayoutId) {
        // If the (sequential) VM Session Id is smaller than the last layout Id, insert after the last element
        parentNode.insertBefore(newLayout, null);
      } else {
        // Otherwise, insert the new layout within the sorted list
        for (let index = 0; index < layouts.length; index++) {
          const sortId = Number(layouts[index].id);

          if (model.id > sortId) {
            parentNode.insertBefore(newLayout, layouts[index]);

            break;
          }
        }
      }

      BGC.logger.logInformation('StackLayoutView', `Adding auction layout: ${model.id}`);
    },

    removeLayout (model) {
      BGC.logger.logInformation('StackLayoutView', `Removing auction layout: ${model.id}`);

      $(`#${model.id}`).remove();
    }
  });
}(window.BGC.ui.view));
