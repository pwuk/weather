/* global BGC: false, $: false, _:false, Backbone: false */
/* eslint-disable func-names,no-param-reassign,no-magic-numbers */
// /////////////////////////////////////////////////////////////////////////////
// file tradehistoryview.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

(function (context, dataStore) {
  // auction history container view: renders each trade as a single row ordred by trade time
  context.AuctionHistoryView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#trade-history-view'),

    initialize (options) {
      this.pageLayout = options.pageLayout;
      this.parentView = options.parentView;
      this.adjustedNomenclature = {
        boughtText : BGC.resources.getAdjustedNomenclature('IDS_BOUGHT', options.pageLayout.get('nomenclature')),
        soldText   : BGC.resources.getAdjustedNomenclature('IDS_SOLD', options.pageLayout.get('nomenclature'))
      };

      // Prepare generic columns HTML for the header row
      this.genericColumnsHtml = '';
      this.genericPriceBColumnHtml = '';
      _.each(this.pageLayout.get('genericColumns'), function (columnDefinition) {
        if (columnDefinition.columnId === 'priceBDisplay') {
          this.genericPriceBColumnHtml += `<span class='${columnDefinition.columnId}'>${columnDefinition.columnName}</span>`;
        } else {
          this.genericColumnsHtml += `<span class='${columnDefinition.columnId}'>${columnDefinition.columnName}</span>`;
        }
      }, this);

      this.render();

      this.listenTo(options.parentView, 'change:activeView', this.contentHeightChanged);
      this.listenTo(dataStore.userSettingsStore, 'change:showTradesForFirm', this.requestRender);
      this.listenTo(dataStore.userSettingsStore, 'change:showTradesForExternalGroupUsers', this.requestRender);
      this.listenTo(dataStore, 'accountSelectionChanged', this.requestRender);
      this.listenTo(dataStore.userSettingsStore, 'change:isOrdersViewFixedHeight', this.requestRender);
      this.listenTo(dataStore.userSettingsStore, 'change:fixedHeightOrdersViewRowCount', this.requestRender);
      this.collection.on('add remove sort reset', this.requestRender, this);
    },

    requestRender () {
      BGC.ui.viewUtils.requestRender('HistoryView', 'Trades', this, this.render);
    },

    render () {
      const showTradesForFirm = !!dataStore.userSettingsStore.get('showTradesForFirm');
      const showOtherGroupTrades = !!dataStore.userSettingsStore.get('showTradesForExternalGroupUsers');

      // clear existing content
      this.$el.empty();

      // apply filtering according to current settings
      const trades = this.collection.filter(model => {
        const tradeType = model.get('tradeType');
        const accountId = model.get('accountId');

        // In Sales trader mode & "showOtherGroupTrades" setting is false
        // then set "selectedAccountId" to active account id, this would filter trades by selected the account
        const selectedAccountId = dataStore.isSalesTraderMode() && showOtherGroupTrades === false ? dataStore.getActiveAccountId() : accountId;

        // eslint-disable-next-line no-mixed-operators
        return tradeType === BGC.schemaValidator.OWNERSHIP_MINE && selectedAccountId === accountId ||
                    (showTradesForFirm && (tradeType === BGC.schemaValidator.OWNERSHIP_MY_FIRM)) ||
                    (showOtherGroupTrades && (tradeType === BGC.schemaValidator.OWNERSHIP_SHARED_ACCOUNT));
      });

      // Group structured trades by structureGroupingId, using parent [children] structure.
      // Where a trade is single add it to the map to preserve the order.
      const groupedTrades = new Map();

      trades.forEach((trade, index) => {
        const structureGroupingId = trade.get('structureGroupingId');

        if (structureGroupingId) {
          if (groupedTrades.has(structureGroupingId)) {
            trade.set('isParent', false);
            trade.set('isTradeLeg', true);
            trade.set('isLastLeg', false);
            groupedTrades.get(structureGroupingId).children.push(trade);
          } else {
            trade.children = [];
            trade.set('isParent', true);
            trade.set('isTradeLeg', false);
            trade.set('isLastLeg', false);
            groupedTrades.set(structureGroupingId, trade);
          }
        } else {
          // Single trade
          trade.set('isParent', false);
          groupedTrades.set(`map-key-${index}`, trade);
        }
      });

      // set last leg boolean
      trades.filter(filterTrade => filterTrade.get('structureGroupingId')).forEach(groupedTrade => {
        if (groupedTrade.children && groupedTrade.children.length > 0) {
          const lastChildTrade = groupedTrade.children[groupedTrade.children.length - 1];

          lastChildTrade.set('isLastLeg', true);
          lastChildTrade.set('isTradeLeg', true);
        }
      });

      // render template
      this.$el.html(this.template({
        resources               : BGC.resources,
        adjustedNomenclature    : this.adjustedNomenclature,
        genericColumnsHtml      : this.genericColumnsHtml,
        genericPriceBColumnHtml : this.genericPriceBColumnHtml
      }));

      // Set the visibility and fixed-height of the header row and content area
      this.$el.toggleClass('populated', trades.length > 0);
      this.$el.toggleClass('fixed-height', dataStore.userSettingsStore.get('isOrdersViewFixedHeight') === 1);

      if (trades.length > 0) {
        // render details of each trade
        const $tradeRows = this.$el.find('.trades');

        groupedTrades.forEach(function (trade) {
          $tradeRows.append(new context.TradeDetailView({
            trade,
            pageLayout : this.pageLayout
          }).$el);

          // render trade children where required
          if (trade.children && trade.children.length) {
            trade.children.forEach(childTrade => {
              $tradeRows.append(new context.TradeDetailView({
                trade      : childTrade,
                pageLayout : this.pageLayout
              }).$el);
            });
          }
        }, this);
      }

      this.contentHeightChanged();
    },

    // eslint-disable-next-line complexity,max-statements
    contentHeightChanged () {
      const scrollContainer = this.el.querySelector('.scroll-container');
      const scrollableContent = this.el.querySelector('.scrollable-content');
      const $headerRow = this.$el.find('.trade-header-row');
      const rowHeightStr = $headerRow.css('text-indent');

      let rowHeight = 11;

      // Retrieve the row height from an unneeded property then override the property
      // on the header row's children so that it doesn't affect the rendering of the DOM.
      if (rowHeightStr) {
        rowHeight = Number(rowHeightStr.slice(0, rowHeightStr.indexOf('px')));

        $headerRow.children().each(function () {
          $(this).css('text-indent', '0px');
        });
      }

      // If the scroll container is showing a vertical scrollbar,
      // we need to get rid of the right padding/margin on the contained area
      if (scrollContainer && scrollableContent) {
        const tradeRows = this.el.querySelectorAll('.trade-row');
        const isFixedHeight = dataStore.userSettingsStore.get('isOrdersViewFixedHeight') === 1;
        const isFloatOver = !!this.$el.hasClass('float-over');

        // Determine the minimum and maximum height of the scroll container
        // and scrollable content.
        if ((isFixedHeight === true) && (isFloatOver === false)) {
          // Apply the fixed height using the user configured number of rows if the
          // fixed height area is enabled.
          const totalFixedHeight = dataStore.userSettingsStore.get('fixedHeightOrdersViewRowCount') * rowHeight;

          scrollContainer.style.maxHeight = `${totalFixedHeight}px`;
          scrollableContent.style.minHeight = `${totalFixedHeight}px`;
        } else if ((tradeRows && tradeRows.length) && (isFloatOver === false)) {
          // restrict to a maximum of 10 rows before showing scroll bar
          // but only when grid is locked into the document flow (not floating)
          const totalFixedHeight = 10 * rowHeight;
          const totalRowHeight = tradeRows.length * rowHeight;

          scrollContainer.style.maxHeight = `${totalFixedHeight < totalRowHeight ? totalFixedHeight : totalRowHeight}px`;
          scrollableContent.style.minHeight = `${totalRowHeight}px`;
        } else {
          scrollContainer.style.removeProperty('max-height');
          scrollableContent.style.removeProperty('min-height');
        }

        // Sets the overflow to be scrollable/hidden based on whether the content is more than the container height.
        BGC.ui.viewUtils.updateElementVerticalOverflow(scrollContainer, scrollableContent);

        // UNLESS we are in "float-over" display mode, in which case the document flow is unaffected,
        // ...do recalc layout
        if (!(this.parentView && this.parentView.$el.hasClass('float-over'))) {
          this.$el.trigger('recalcLayout');
        }
      }
    }
  });

  // trade detail view: renders the details of single trade execution
  context.TradeDetailView = Backbone.View.extend({
    className : 'trade-row',
    template  : BGC.utils.queryTemplate('#trade-row'),

    initialize (options) {
      _.extend(this, options);

      this.adjustedNomenclature = {
        boughtText : this.trade.getAdjustedNomenclature('IDS_BOUGHT'),
        soldText   : this.trade.getAdjustedNomenclature('IDS_SOLD')
      };

      this.render();
    },

    render () {
      const accountName = this.trade.get('accountName');

      // Inject generic columns into the template for the trade row.
      this.genericColumnsHtml = '';
      this.genericPriceBColumnHtml = '';
      _.each(this.pageLayout.get('genericColumns'), function (columnDefinition) {
        if (columnDefinition.columnId === 'priceBDisplay') {
          this.genericPriceBColumnHtml += `<span class='${columnDefinition.columnId}'>${
            this.trade.get(columnDefinition.columnId)}</span>`;
        } else {
          this.genericColumnsHtml += `<span class='${columnDefinition.columnId}'>${
            this.trade.get(columnDefinition.columnId)}</span>`;
        }
      }, this);

      // render trade details template
      this.$el.html(this.template({
        instrumentName : dataStore.modelDefinitions.Instrument.getGenAttrFormattedInstrumentName(this.trade.get('instrumentName'),
          {
            straddleDisplay : this.trade.get('straddleDisplay'),
            ratioDisplay    : this.trade.get('ratioDisplay'),
            deltaDisplay    : this.trade.get('deltaDisplay')
          }),
        tradeTime               : this.trade.get('tradeTimeDisplay'),
        tradePrice              : this.trade.get('tradeDisplayPrice'),
        tradeSizeText           : this.buildTradeSizeString(this.trade.get('tradeSide'), this.trade.get('tradeSize')),
        accountShortName        : accountName,
        accountLongName         : accountName,
        counterparty            : this.trade.get('counterparty'),
        genericColumnsHtml      : this.genericColumnsHtml,
        genericPriceBColumnHtml : this.genericPriceBColumnHtml
      }));

      // apply parent trade / leg trade styling
      if (this.trade.get('isParent')) {
        this.$el.addClass('parent-trade');
      } else if (this.trade.get('isLastLeg')) {
        this.$el.addClass('last-leg-trade');
      } else if (this.trade.get('isTradeLeg')) {
        this.$el.addClass('leg-trade');
      }

      // apply 'trade for firm' styling
      if (this.trade.isSameLETrade()) {
        this.$el.addClass('same-LE-highlight');
      } else if (this.trade.isSameGroupTrade()) {
        // For sales traders we display trades for 3rd party users who are in our group(s) for shared
        // accounts in those groups. These are styled differently to distinguish them from our own trades
        this.$el.addClass('group-thirdparty-highlight');
      }
    },

    buildTradeSizeString (tradeSide, tradeSize) {
      let tradeSizeString = '';

      // build trade size string
      if (tradeSide === 'buy') {
        tradeSizeString = `${tradeSize} ${this.adjustedNomenclature.boughtText}`;
        this.$el.addClass('buy-status');
      } else if (tradeSide === 'sell') {
        tradeSizeString = `${tradeSize} ${this.adjustedNomenclature.soldText}`;
        this.$el.addClass('sell-status');
      }

      return tradeSizeString;
    },

    getInstrumentDisplayName () {
      let displayName = this.trade.get('instrumentName');
      const straddleDisplay = this.trade.get('straddleDisplay') ? `S-${this.trade.get('straddleDisplay')}` : '';
      const ratioDisplay = this.trade.get('ratioDisplay') ? `R-${this.trade.get('ratioDisplay')}` : '';
      const deltaDisplay = this.trade.get('deltaDisplay') ? `D-${this.trade.get('deltaDisplay')}` : '';

      const collatedParams = _.reduce([straddleDisplay, ratioDisplay, deltaDisplay],
        (memo, param) => (param.length > 0 ? (memo.length > 0 ? `${memo} / ` : '') + param : memo));

      if (collatedParams.length > 0) {
        displayName += ` (${collatedParams})`;
      }

      return displayName;
    }
  });
}(window.BGC.ui.view, window.BGC.dataStore));
