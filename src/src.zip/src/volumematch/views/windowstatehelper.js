/* global BGC: false */

import {getDataStore} from '../volumematch';

function broadcastAuctionWindowState (windowState = '') {
  const dataStore = getDataStore();
  const activeAuctions = dataStore.pageLayout.getActiveAuctions();
  const {userID} = dataStore.getPrimaryUserDetails();

  // eslint-disable-next-line no-restricted-syntax
  for (const auction of activeAuctions) {
    const auctionId = auction.attributes.auctionNameExt;
    const event = windowState || (document.visibilityState === 'hidden' ? 'window_min' : 'window_detached');

    BGC.ui.viewUtils.sendTraderLookingEvent(event, auctionId, null, userID);
  }
}

export default broadcastAuctionWindowState;
