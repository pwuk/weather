/* eslint-disable func-names */
/* global BGC: false, $: false */

// eslint-disable-next-line max-params
(function (context, viewUtils, utils, eventsHandler, views, resources) {
  /**
   * UI helper that manages main editing actions on given layout.
   *
   * @class LayoutEditor
   * @param {String} id - the id of the layout to edit
   * @param {String} viewId
   */
  const LayoutEditor = function (id, viewId) {
    this.id = id;
    this.viewId = viewId;
  };

  /**
   * Starts process to add a new row before the given index.
   *
   * @method
   * @param {Number} rowIndex
   * @param {String} title - title of the new row
   * @memberof LayoutEditor
   */
  LayoutEditor.prototype.createRowBefore = function (rowIndex, title) {
    this.displayRowDialog(resources.IDS_CREATE_NEW_ROW, title, this.sendInsertRow.bind(this, 'before', rowIndex));
  };

  /**
   * Starts process to add a new row after the given index.
   *
   * @method
   * @param {Number} rowIndex
   * @param {String} title = title of the new row
   * @memberof LayoutEditor
   */
  LayoutEditor.prototype.createRowAfter = function (rowIndex, title) {
    this.displayRowDialog(resources.IDS_CREATE_NEW_ROW, title, this.sendInsertRow.bind(this, 'after', rowIndex));
  };

  /**
   * Starts process to edit given row
   *
   * @method
   * @param {Number} rowIndex
   * @param {String} title - new title
   * @memberof LayoutEditor
   */
  LayoutEditor.prototype.editRow = function (rowIndex, title) {
    this.displayRowDialog(resources.IDS_EDIT_ROW, title, this.sendEditRow.bind(this, rowIndex));
  };

  /**
   * Starts process to remove given row
   *
   * @method
   * @param {Number} rowIndex
   * @param title
   * @memberof LayoutEditor
   */
  LayoutEditor.prototype.removeRow = function (rowIndex, title) {
    viewUtils.infoPopup.popup('show', {
      isError              : true,
      hasHeaderCloseButton : false,
      modal                : true,
      draggable            : false,
      title                : utils.format(resources.IDS_REMOVE_ROW, [title]),
      message              : 'Are you sure?',
      context              : {
        currentRowIndex : rowIndex
      },

      confirm : function () {
        this.sendRemoveRow(rowIndex, title);
        views.statusOverlayView.open();
      }.bind(this)
    });
  };

  /**
   * Displays a dialog used for rows modification only (inserting or editing).
   * The dialog contains an input field that accepts a new title for the modified row.
   *
   * @param {String} dialogTitle - a title to set on the dialog
   * @param {String} rowTitle - suggested or current row title, used to prepopulate input field
   * @param {Function} confirmationCallback - callback to be called when dialog action is confirmed
   * @method
   */
  LayoutEditor.prototype.displayRowDialog = function (dialogTitle, rowTitle, confirmationCallback) {
    viewUtils.rowEditingPopup.popup('show', {
      title   : dialogTitle,
      context : {
        rowTitle
      },
      confirm () {
        const newRowTitle = $(this).find('input[name=row-title]').val();

        confirmationCallback(newRowTitle);
        views.statusOverlayView.open();
      }
    });
  };

  /**
   * Sends a command to insert a new row at the given location.
   *
   * @param {String} location - location that specifies where the row should be inserted (before or after)
   * @param {Number} rowIndex - location uses this index as a relative position
   * @param {String} title - newly created row's title
   * @method
   */
  LayoutEditor.prototype.sendInsertRow = function (location, rowIndex, title) {
    // eslint-disable-next-line max-len
    BGC.logger.logKey('', utils.format('[{0} view] Modifying layout {1}. [Insert {2} index {3}][Title {4}]', [this.viewId, this.id, location, rowIndex, title]));

    this.sendEditLayout({
      type : `insert${location}`,
      row  : rowIndex,
      title
    });
  };

  /**
   * Sends a command to edit an existing row.
   *
   * @param {Number} rowIndex - index of the row to edit
   * @param {String} title - new title
   * @method
   */
  LayoutEditor.prototype.sendEditRow = function (rowIndex, title) {
    BGC.logger.logKey('', utils.format('[{0} view] Modifying layout {1}. [Edit row at index {2}][Title {3}]', [this.viewId, this.id, rowIndex, title]));

    this.sendEditLayout({
      type : 'edit',
      row  : rowIndex,
      title
    });
  };

  /**
   * Sends a command to remove given row.
   *
   * @param {Number} rowIndex - index of the row to remove
   * @param {String} title
   * @method
   */
  LayoutEditor.prototype.sendRemoveRow = function (rowIndex, title) {
    BGC.logger.logKey('', utils.format('[{0} view] Modifying layout {1}. [Remove row at index {2}][Title {3}]', [this.viewId, this.id, rowIndex, title]));

    this.sendEditLayout({
      type : 'remove',
      row  : rowIndex,
      title
    });
  };

  /**
   * Sends a command to edit layout and modify using given action.
   *
   * @param {Object} action - details of the action to perform
   * @method
   */
  LayoutEditor.prototype.sendEditLayout = function (action) {
    eventsHandler.onClick(this.viewId, 'vmEditLayout', JSON.stringify({
      action,
      layoutId : this.id
    }));
  };

  // eslint-disable-next-line no-param-reassign
  context.LayoutEditor = LayoutEditor;
}(window.BGC.ui, window.BGC.ui.viewUtils, window.BGC.utils, window.BGC.eventsHandler, window.BGC.ui.view, window.BGC.resources));
