/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */

/**
 *
 * Popup widget implemented with jQuery UI Widget Factory
 * DO NOT USE to build data-entry popups. Support for imposing tab orders etc. is now deprecated as it
 * was incredibly inefficient.
 *
 * This common popup is intended solely for use as confirmation/decision/error/warning popups
 *
 * NOTE that the popup uses jQueryUI classes in order to inherit BGC branding CSS that has been set using themeroller
 * and some slective overrides. If we ever switch to using Bootstrap or other, this code will need re-working.
 *
 * 1. Defining default options
 * 2. Internal and external events
 * 3. Usage
 * 4. Options
 * 5. Public interface
 * 6. Private interface
 * 7. Solution for navigating with the tab key
 *
 * 1. Defining default options
 *      Default options are defined in the options property. Event handlers that do not have a default implementation
 *      don't need to be defined. Default values for events can be defined in the options property. Event handlers
 *      without default implementation don't need to be added.
 *
 * 2. Internal and external events
 *      The widget triggers three events to support customized callbacks. These events are internal events, they are
 *      triggered within the widget.
 *      Arguments for internal events: (event jQuery.Event)
 *      Value of the this variable: DOMElement which the widget is attached to.
 *      Access to the widget within the handler: jQuery(event.target).data("bgc-popup")
 *
 *      The widget also supports the onKeyDown event. This is an external event; it is attached to an external element,
 *      the document object.
 *      Arguments for external events: (event jQuery.Event)
 *      Value of the this variable: DOMElement which triggered the event.
 *      Access to the widget within the handler: event.data.context (event is the jQuery.Event argument)
 *
 * 3. Usage
 *      All you have to do in the simplest case is to provide one hidden div in your HTML document
 *      e.g. <div id="genericPopup" style="display:none"></div>
 *
 *      3.1 Calling after jQuery selectors
 *          jQuery("#genericPopup").popup(createOptions);                 // creates the dialog
 *          jQuery("#genericPopup").popup("show", showOptions);           // displays the dialog
 *          jQuery("#genericPopup").popup("close");                       // closes the dialog
 *
 *      3.2 Accessing via data that is attached to the DOMElement
 *          jQuery("#genericPopup").popup(createOptions);                 // creates the dialog
 *          jQuery("#genericPopup").data("bgc-popup").show(showOptions);  // displays the dialog
 *          jQuery("#genericPopup").data("bgc-popup").close();            // closes the dialog
 *
 *          The name of the key to access the data is bgc-popup; namespace is included.
 *
 * 4. Options
 *      - modal: true if the popup needs to be a modal window
 *      - title: string that is displayed on the top of the popup
 *      - message: string that is displayed below the title
 *      - controlsHtmlContent: for popups offering selection of options rather than a simple message,
 *        providing an HTML string in this option will set the content of the dialog. This is mutually
 *        exclusive with the message option to provide message text - any message must be included in the
 *        HTML content provided by this option string.
 *      - cssClass: CSS class that is assigned to the element the widget is called on
 *      - cmdConfirmText: label on the confirm button
 *      - cmdCancelText: label on the cancel button
 *      - hasHeaderCloseButton: true if the dialog should display a Close button top right
 *      - hasCancelButton: true if there should be a Cancel button as well as an OK button
 *      - isWarning: true if a warning icon should be displayed with the message text
 *      - isError: true if an error icon should be displayed with the message text
 *      - domElements: DOM elements created during initialization for internal and external access
 *      - context: context data for confirm callback
 *      - restrictHeavyPainting: whether to restrict paint intensive operations such as animations or setting a modal background colour
 *
 *      Events that can be set in the options (JavaScript events are mostly all lowercase, not camelcase)
 *      - keydown: event handler for keydown event that is attached to the document
 *      - show: event handler which is triggered after the popup is displayed
 *      - confirm: event handler which is triggered when the popup is closed by clicking on the confirm button
 *      - cancel: event handler which is triggered when the popup is closed by clicking on the close button
 *
 * 5. Public interface
 *      - constructor (_create): creates the elements necessary to display the popup and stores references for them in
 *          the options so that other functions don't have to use yet another selector to access the same elements.
 *          The options arguments extends the default options.
 *
 *      - show: displays the dialog. Updates the title and message of the dialog if necessary, and also uses the options
 *          to determine whether or not the dialog should have cancel/close button(s) and any icons. After starting to
 *          fade in the popup dialog, it triggers the onShow event.
 *          The options argument extends the current widget options.
 *
 *      - close: closes the dialog.
 *          The isConfirmed parameter is true if the dialog is closed as a result of a confirmation. It also determines
 *          whether the onClose or onConfirm event gets triggered.
 *
 * 6. Private interface (with jQuery UI Widget Factory starting properties with underscore makes them private)
 *      - _createButton: creates a button
 *          Arguments:
 *            - id: id of button
 *            - value: label on the button
 *            - clickHandler: function to handle the click event
 *            - handleParams: array of parameters that should be passed to the click event handler
 *
 */
(function ($) {
    "use strict";

    function onKeyDown(event) {
        var context = event.data.context,
            isConfirmEnabled = true,
            handled = true;

        // Ensure we don't handle any keypresses whilst the dialog is fading out or in
        if (!context.isOnScreen) {
            return false;
        }

        switch (event.which) {
            case BGC.utils.KeyCodes.ENTER: // Enter - close with confirmation
                isConfirmEnabled = context.options.domElements.confirmButton === undefined  || !context.options.domElements.confirmButton.is(":disabled");
                BGC.logger.logKey("", context.options.title.toString() + " Dialog: " + context.options.cmdConfirmText + " button triggered with Enter key press and button state is " +  isConfirmEnabled);

                if (isConfirmEnabled) {
                    context.close(true);
                }
            break;
        case BGC.utils.KeyCodes.ESC:
            if (context.options.hasHeaderCloseButton || context.options.hasCancelButton) {
                BGC.logger.logKey("", context.options.title.toString() + " Dialog: " + context.options.cmdCancelText + " button triggered with Esc key press");

                // Escape - close without confirmation
                context.close(false);
            } else {
                // Not allowed to cancel out of this dialog
                handled = false;
            }
            break;
        default:
            handled = false;
            break;
        }

        if (handled) {
            // Trigger serialisation as dialog has been dismissed
            if (BGC.ui.automation !== undefined && BGC.ui.automation.enabled) {
                BGC.ui.automation.serialize();
            }
            event.preventDefault();
        }
    }

    $.widget("bgc.popup", {

        // default options - event handlers without default don't need to be defined
        // supported events: keydown, confirm, close, show
        options: {
            modal: true,
            draggable: true,
            title: "",
            titleElementsCount: 1,
            message: "",
            controlsHtmlContent: "",
            hasHeaderCloseButton: true,
            hasCancelButton: true,
            isWarning: false,
            isError: false,
            buttonSectionText: "",
            cssClass: "popupDialog ui-dialog",
            cmdConfirmText: "OK",
            cmdCancelText: "Cancel",
            domElements: {},
            keydown: onKeyDown,
            context: undefined,
            restrictHeavyPainting: false,
            interactivityQoSType: ""
        },

        isOnScreen: false,

        _create: function () {
            var buttonSection, dialogBody, icon,
                that = this,
                element = this.element,
                elementId = element.attr("id"),
                ids = {
                    dialogBody: elementId + "_dialogBody",
                    closeButton: elementId + "_commandClose",
                    title: elementId + "_title",
                    simpleMsgContent: elementId + "_simpleMsgContent",
                    message: elementId + "_message",
                    controlsContent: elementId + "_controlsContent",
                    commandConfirm: elementId + "_commandConfirm",
                    commandCancel: elementId + "_commandCancel",
                    buttonSection: elementId + "_buttonSection",
                    buttonSectionLabel: elementId + "_buttonSectionLabel"
                };

            element.addClass(this.options.cssClass);

            this.options.domElements.overlay = $("#popupOverlay");
            if (this.options.domElements.overlay.length === 0) {
                this.options.domElements.overlay = $("<div/>").attr("id", "popupOverlay").addClass("modalOverlay");
                $("body").append(this.options.domElements.overlay);
            }

            this.options.domElements.closeButton = element.find("#" + ids.closeButton);
            if (this.options.domElements.closeButton.length === 0) {
                this.options.domElements.closeButton = $("<a/>")
                    .attr("id", ids.closeButton)
                    .attr("href", "#")
                    .attr("title", "Close")
                    .attr("data-automation-control-type", "button")
                    .addClass("popupXButton")
                    .text("X").click(function () {
                        that.close();
                    });
                element.prepend(this.options.domElements.closeButton);
            }

            this.createTitleBar(ids);

            dialogBody = element.find("#" + ids.dialogBody);
            if (dialogBody.length === 0) {
                dialogBody = $("<div/>").addClass("ui-dialog-content ui-widget-content");
                element.append(dialogBody);
            }

            this.options.domElements.simpleMessageContent = element.find("#" + ids.simpleMsgContent);
            if (this.options.domElements.simpleMessageContent.length === 0) {
                this.options.domElements.simpleMessageContent = $("<div/>")
                    .attr("id", ids.simpleMsgContent)
                    .addClass("icon-plus-simple-message");
                dialogBody.append(this.options.domElements.simpleMessageContent);
            }

            this.options.domElements.controlsContent =  element.find("#" + ids.controlsContent);
            if (this.options.domElements.controlsContent.length === 0) {
                this.options.domElements.controlsContent = $("<div/>")
                    .attr("id", ids.controlsContent)
                    .addClass("controls-content");
                if (this.options.controlsHtmlContent) {
                    this.options.domElements.controlsContent.html(this.options.controlsHtmlContent);
                }
                dialogBody.append(this.options.domElements.controlsContent);
            }

            icon = $("<div>").addClass("warningIcon");
            this.options.domElements.simpleMessageContent.append(icon);
            icon = $("<div>").addClass("errorIcon");
            this.options.domElements.simpleMessageContent.append(icon);

            this.options.domElements.message = element.find("#" + ids.message);
            if (this.options.domElements.message.length === 0) {
                this.options.domElements.message = $("<p/>").attr("id", ids.message).html(this.options.message);
                this.options.domElements.simpleMessageContent.append(this.options.domElements.message);
            }

            buttonSection = dialogBody.find("#" + ids.buttonSection);
            if (buttonSection.length === 0) {
                buttonSection = $("<div/>").attr("id", ids.buttonSection).addClass("dialogButtonArea");
                buttonSection.append($("<label/>").text(this.options.buttonSectionText));
                dialogBody.append(buttonSection);

                this.options.domElements.confirmButton = this._createButton(ids.commandConfirm, this.options.cmdConfirmText, this.close, [true]);
                this.options.domElements.cancelButton = this._createButton(ids.commandCancel, this.options.cmdCancelText, this.close, [false]);
                buttonSection.append(this.options.domElements.cancelButton);
                buttonSection.append(this.options.domElements.confirmButton);
            }

            // Enable dragging if needed
            if (this.options.draggable) {
                this._enableDragging();
            }
        },

        createTitleBar: function (ids) {
            var titleBar, txtSpans = "", titleTxt, index;

            this.options.domElements.title = this.element.find("#" + ids.title);
            if (this.options.domElements.title.length === 0) {
                titleTxt = typeof this.options.title === "object" ? this.options.title : [this.options.title];
               
                for (index = 0; index < this.options.titleElementsCount; ++index) {
                    txtSpans += "<span id='" + ids.title + index + "' data-automation-control-type='text'>" + titleTxt[index] + "</span>";
                }
         
                titleBar = $("<div>").addClass("ui-dialog-titlebar ui-widget-header ui-corner-all").html("<span class='ui-dialog-title'>" + txtSpans + "</span>");
                this.element.prepend(titleBar);

                this.options.domElements.title = this.element.find(".ui-dialog-title").children();
            }
        },

        show: function (options) {
            var that = this,
                element = this.element;

            if (this.options) {
                this.options.isError = false;
                this.options.isWarning = false;
            }
            this.options = $.extend(this.options, options);

			// array of title strings expect when object is passed
            if (typeof this.options.title === "object") {
                this.options.title.forEach(function (title, index) {
                    this.options.domElements.title[index].innerHTML = title;
                }, this);
            } else if (typeof this.options.title === "function") {
                this.options.domElements.title.text(this.options.title.call(element));
            } else if (typeof this.options.title === "string" && this.options.title !== "") {
                this.options.domElements.title.text(this.options.title);
            }

            if (this.options.isWarning) {
                $("#" + this.element.attr("id") + " div.warningIcon").show();
            } else {
				$("#" + this.element.attr("id") + " div.warningIcon").hide();
			}
			
            if (this.options.isError) {
                $("#" + this.element.attr("id") + " div.errorIcon").show();
            } else {
				$("#" + this.element.attr("id") + " div.errorIcon").hide();
			}

            if (this.options.message) {
                this.options.domElements.message.html(this.options.message);
                this.options.domElements.simpleMessageContent.show();
                this.options.domElements.controlsContent.hide();
            } else {
                this.options.domElements.simpleMessageContent.hide();
                this.options.domElements.controlsContent.show();
            }
      
            $("#" + this.element.attr("id") + "_buttonSection label").text(this.options.buttonSectionText);

            this.options.domElements.confirmButton.innerHTML = options && options.cmdConfirmText ? options.cmdConfirmText : this.options.cmdConfirmText;

            if (this.options.hasHeaderCloseButton) {
                this.options.domElements.closeButton.show();
            } else {
				this.options.domElements.closeButton.hide();
			}

            if (this.options.hasCancelButton) {
                this.options.domElements.cancelButton.innerHTML = options && options.cmdCancelText ? options.cmdCancelText : this.options.cmdCancelText;
                this.options.domElements.cancelButton.show();
            } else {
				this.options.domElements.cancelButton.hide();
			}

            if (typeof ($.fn.fixCEFSelect) === 'function') { // The file containing fixCEFSelect is not included in the full fat Chrome version.
                // Fix CEF drop down issue when moving the window
                // - it's called here in case new select elements were added
                element.find("select").fixCEFSelect();
            }

            // Display the popup and triggers the show event
            BGC.logger.logKey("", "Showing " + this.options.title + " dialog");
            this._trigger("show", null, this.options.context);

            if (this.options.modal) {
                this.options.domElements.overlay.toggleClass("transparent", this.options.restrictHeavyPainting);

                // Display overlay and block click events
                this.options.domElements.overlay.finish().fadeIn(this.options.restrictHeavyPainting ? 0: 150, function () {

                    // NOTE: when restricting animations set a duration of 1ms to prevent a key stroke used to invoke the dialog
                    // from triggering the confirm button and thereby close it.
                    element.fadeIn(that.options.restrictHeavyPainting ? 1: 200, function () {
                        that.isOnScreen = true;

                        if (that.options.domElements.confirmButton) {
                            that.options.domElements.confirmButton.focus();
                        }
                    });
                });
                this.options.domElements.overlay.unbind("click");

                // Listen for keydown events to simulate submit and cancel button
                $(document).on("keydown", { context: this }, this.options.keydown);

            } else {
                element.fadeIn(this.options.restrictHeavyPainting ? 0 : 300, function () {
                    that.isOnScreen = true;
                });
            }

			$("body").addClass("overlaid");
        },

        close: function (isConfirmed) {
            var toContinue,
                that = this,
                element = this.element;

            if (this.options.interactivityQoSType) {
                // If the QoS timer is running, generate the interaction metric now
                BGC.utils.generateInteractivityQoSMetric(this.options.interactivityQoSType);
            }

            // Calls the appropriate event and check if it is cancelled.
            if (isConfirmed) {
                toContinue = this._trigger("confirm", null, this.options.context);
            } else {
                toContinue = this._trigger("cancel", null, this.options.context);
            }

            // Stop closing if the event handler was cancelled
            if (!toContinue) {
                return;
            }

            this._trigger("close", null, this.options.context);

            // Prevent any further calls to the close functionality
            this.isOnScreen = false;

            if (this.options.modal) {
                // Hide overlay and remove keydown event handler
                element.fadeOut(this.options.restrictHeavyPainting ? 0 : 200);
				that.options.domElements.overlay.fadeOut(this.options.restrictHeavyPainting ? 0 : 500);
                $(document).off("keydown", this.options.keydown);
            } else {
                // Hide the popup
                element.fadeOut(this.options.restrictHeavyPainting ? 0 : 300);
            }

			$("body").removeClass("overlaid");
        },

        _enableDragging: function () {
            var element = this.element,
                reactiveElements = element.add(this.options.domElements.overlay);

            element.on("mousedown", function (event) {
                if (!jQuery(event.target).is(":input")) {
                    var offset = $(element).offset(),
                        position = {
                            x: event.pageX - offset.left,
                            y: event.pageY - offset.top
                        };

                    reactiveElements.on("mouseup", function () {
                        reactiveElements.off("mousemove mouseup");
                    });

                    reactiveElements.on("mousemove", function (event) {
                        element.offset({
                            left: event.pageX - position.x,
                            top: event.pageY - position.y
                        });
                    });
                }
            });
        },

        _createButton: function (id, value, clickHandler, handlerParams) {
            var that = this,
                button = $("<input/>").button()
                    .attr("id", id)
                    .attr("type", "button")
                    .attr("data-automation-control-type", "button")                    
                    .addClass( () => {
                        let btnClass = "standardPopupButtons";
                        
                        if (id.includes("_commandConfirm"))
                        { 
                            btnClass += " confirm";
                        } else if (id.includes("_commandCancel")) {
                            btnClass += " cancel";
                        }

                        return btnClass

                    })
                    .prop("value", value)
                    .click(function () {
                        // Only handle clicks if the dialog isn't already closing
                        if (that.isOnScreen) {
                            BGC.logger.logKey("", that.options.title + " Dialog: " + value + " button clicked");

                            clickHandler.apply(that, handlerParams);
                        } else {
                            BGC.logger.logKey("", "Ignoring click event received for popup button after popup has been dismissed");
                        }
                    });
            return button;
        }

    });

}(jQuery));
