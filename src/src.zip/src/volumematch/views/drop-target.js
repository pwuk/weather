import {PolymerElement} from '@polymer/polymer/polymer-element';
import componentTemplate from './drop-target.template';


const {ui: context} = window.BGC;


class DropTarget extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  static get properties () {
    return {
      selectMsg : {
        type  : String,
        value : 'Click to Paste'
      },
      pasteMsg : {
        type  : String,
        value : 'PASTE'
      },
      collection : {
        type  : Object,
        value : null
      }
    };
  }

  constructor () {
    super();
    this.addEventListener('paste', this.onPaste.bind(this));
  }


  ready () {
    super.ready();
    this.set('caption', this.selectMsg);
  }

  onPaste (event) {
    const {clipboardData, target} = event;
    const {collection} = this;

    if (clipboardData && collection) {
      collection.import(clipboardData.getData('text'));
    }

    event.preventDefault();

    target.blur();
  }

  onTextAreaFocus () {
    this.set('caption', this.pasteMsg);
  }

  onTextAreaBlur () {
    this.set('caption', this.selectMsg);
  }
}

customElements.define('drop-target', DropTarget);
context.view.DropTarget = DropTarget;
