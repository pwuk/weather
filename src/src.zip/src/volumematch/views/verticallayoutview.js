/* global BGC: false, Backbone: false */

// eslint-disable-next-line func-names
(function (context) {
  // eslint-disable-next-line no-param-reassign
  context.VerticalLayoutView = Backbone.View.extend({
    id : 'tile-views',

    initialize (options) {
      BGC.logger.logInformation('VMVerticalLayoutView', 'Creating VerticalLayoutView...');

      this.dataStore = options.dataStore;
      this.tiles = options.tiles;
      this.listenTo(this.tiles, 'add', this.addTileView);
      this.tiles.each(this.addTileView, this);
    },

    addTileView (tile) {
      if (tile.get('layoutType') === 'outright') {
        BGC.logger.logInformation('VMVerticalLayoutView', `Adding outright tile[${tile.get('tileId')}].`);

        this.$el.append(new context.InstrumentTileView({model : tile, pageLayout : this.model, dataStore : this.dataStore}));
      }
    }
  });
}(window.BGC.ui.view));
