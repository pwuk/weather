/* global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */

import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './size-input-control.template';

const {view: context} = window.BGC.ui;
const {KeyCodes} = BGC.utils;

class SizeInputControl extends PolymerElement {

  constructor() {
    super();
    this.is = 'size-input-control';
    this.onFocusChanging = this.onFocusChanging.bind(this);
    this.revert = this.revert.bind(this);
    this.onBlur = this.onBlur.bind(this);
    this.onFocus = this.onFocus.bind(this);

    this.onClick =   this.onClick.bind(this)
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.handleDragStart = this.handleDragStart.bind(this);
  }

  ready () {
    super.ready();

    const [inputField] = $(this.shadowRoot).find('input');
    this.inputField = inputField;
    this.inputField.addEventListener('mousedown', this.onClick);
    this.inputField.addEventListener('mouseup', this.onClick);
    this.inputField.addEventListener('keydown', this.handleKeyDown);
    this.inputField.addEventListener('focus', this.onFocus);
    this.inputField.addEventListener('focusout', this.onFocusChanging);
    this.inputField.addEventListener('blur', this.onBlur);
    this.inputField.addEventListener('dragstart', this.handleDragStart);

    inputField.classList.add(...this.getAttribute('class').split(' '));

    if (this.classList.contains('buy')) {
      this.side = 'buy';
    } else if (this.classList.contains('sell')) {
      this.side = 'sell';
    }

  }

  // allow access from outside web component as this used to be a native input tag.
  get value () {
    return this.inputField && typeof this.inputField.value !== 'undefined' ? this.inputField.value : undefined;
  }

  set value (newValue) {
    if(this.inputField) this.inputField.value = newValue;
  }


  static get properties () {
    return {
      placeholder : {
        type  : String,
        value : ''
      },
      maxlength : {
        type  : String,
        value : ''
      },

      side : {
        type  : String,
        value : 'buy'
      },

      revertValue : {
        type     : String,
        value    : '',
        observer : 'revert'
      },

      orderPrice : {
        type               : Number,
        value              : 0.0,
        reflectToAttribute : true
      }
    };
  }

  // <input is="size-input-control"
  // class="buy"
  // id="order-entry-bar-buy-input"
  // maxlength=6
  // placeholder="<%= terminology.buySizePlaceholder %>"
  // value="<%= order && order.hasBuySize ? order.buySize : '' %>"
  // revert-value="<%= order && order.hasBuySize ? order.buySize : '' %>"
  // order-price="<%= buyPrice %>" />

  static get template () {
    return componentTemplate;
  }

  setValidationCallback (callback) {
    this.validationCallback = callback;
  }

  // eslint-disable-next-line class-methods-use-this
  onClick () {
    // If the QoS timer is running, generate the interaction metric now
    BGC.utils.generateInteractivityQoSMetric('oebActivated');
  }

  // eslint-disable-next-line complexity
  handleKeyDown (event) {
    // If the QoS timer is running, generate the interaction metric now
    BGC.utils.generateInteractivityQoSMetric('oebActivated');

    switch (event.keyCode) {
      case KeyCodes.ENTER:
        event.stopPropagation();
        BGC.logger.logUserInteraction(event);
        this.validateAndRequestOrderSubmission();
        break;

      case KeyCodes.ESC:
        this.isInvalidInput = false;
        this.revert();
        this.blur();

        return;

      case KeyCodes.F6:
        if (this.side === 'buy') {
          event.stopPropagation();
          BGC.logger.logUserInteraction(event);
          this.validateAndRequestOrderSubmission();
        }
        break;

      case KeyCodes.F7:
        if (this.side === 'sell') {
          event.stopPropagation();
          BGC.logger.logUserInteraction(event);
          this.validateAndRequestOrderSubmission();
        }
        break;

      case KeyCodes.LEFT:
      case KeyCodes.RIGHT:
      case KeyCodes.UP:
      case KeyCodes.DOWN:
        event.stopPropagation();
        break;

      case KeyCodes.TAB:
        this.onFocusChanging(event);
        break;
    }
  }

  // If size control is non-empty, validate content and return 0 if invalid.
  // If control is empty, return defaultSize if supplied or 0 otherwise
  validateAndGetSizeToSubmit (price, defaultSize) {
    if (this.inputField.value) {
      if (price !== undefined) {
        this.orderPrice = price;
      }

      if (typeof this.validationCallback === 'function' &&
          !(this.orderPrice === undefined || isNaN(this.orderPrice))) {
        const validationResult = this.validate();

        if (validationResult.valid) {
          return validationResult;
        }
      }

      return {valid : false, numericValue : 0};
    }

    return defaultSize ? {valid : true, numericValue : defaultSize} : {valid : false, numericValue : 0};
  }

  validateAndRequestOrderSubmission (price) {
    if (price !== undefined) {
      this.orderPrice = price;
    }

    if (typeof this.validationCallback === 'function' &&
        // eslint-disable-next-line no-restricted-globals
        !(this.orderPrice === undefined || isNaN(this.orderPrice))) {
      if (this.inputField.value !== '') {
        const validationResult = this.validate();

        if (validationResult.valid) {
          this.dispatchEvent(
              new CustomEvent('SubmitValidatedSize', {
                bubbles  : true,
                composed : true,
                detail   : {
                  size : validationResult.numericValue,
                  side : this.side
                }
              })
          );
          // this.fire('SubmitValidatedSize', {size : validationResult.numericValue, side : this.side});
        }
      }
    }
  }

  validate (suppressErrorDisplay) {
    if (typeof this.validationCallback === 'function' &&
        // eslint-disable-next-line no-restricted-globals
        !(this.orderPrice === undefined || isNaN(this.orderPrice))) {
      // Set the input control as the place to return focus to
      // after any validation error popup is displayed
      BGC.ui.viewUtils.lastFocusedControl = this;

      // Set the validated flag to prevent reversion of the input text
      // if the display of an error message causes a change of focus
      this.hasBeenValidated = true;
      const validationResult = this.validationCallback(this.inputField.value, this.side, this.orderPrice, suppressErrorDisplay);

      if (validationResult.valid) {
        this.isInvalidInput = false;
      }

      if (!suppressErrorDisplay && this.isInvalidInput) {
        // If validation failed, show input background in error colour
        this.classList.add('validation-error');
      } else if (!this.isInvalidInput) {
        // We can clear it if there is no error, regardless of error display suppression
        this.classList.remove('validation-error');
      }

      return validationResult;
    }
  }

  // eslint-disable-next-line class-methods-use-this
  handleDragStart (event) {
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  onFocus (event) {
    // Hide cancel icon
    if (this.inputField.nextElementSibling && this.inputField.nextElementSibling.classList.contains('cancel-icon')) {
      this.inputField.nextElementSibling.style.display = 'none';
    }

    // Select all the text in the input, for error correction by the user
    this.inputField.select();

    // Assume input is invalid until proved otherwise
    this.hasBeenValidated = false;
    this.isInvalidInput = true;

    // If the last focused control was the input on the other side, revert its contents.
    // We only allow the user to work on one side at a time
    if (BGC.ui.viewUtils.lastFocusedControl &&
        BGC.ui.viewUtils.lastFocusedControl.is=== 'size-input-control' &&
        BGC.ui.viewUtils.lastFocusedControl.side !== this.side) {
      BGC.ui.viewUtils.lastFocusedControl.revert();
    }

    // Catch mouse events that may move focus away from the control, before they do anything else
    document.addEventListener('mousedown', this.onFocusChanging, true);
    BGC.hasFocus = true;
  }

  onBlur (event) {
    if (!BGC.hasFocus || !document.hasFocus()) {
      this.revert();
    } else {
      // Validate but don't display errors
      this.validate(true);

      // Reinstate any cancel icon that was hidden when the input was activated
      if (this.inputField.nextElementSibling && this.inputField.nextElementSibling.classList.contains('cancel-icon')) {
        this.inputField.nextElementSibling.style.display = '';
      }
    }
    document.removeEventListener('mousedown', this.onFocusChanging, true);
  }

  onFocusChanging (event) {
    // We use this function, amongst other things, to prevent mouse down elsewhere
    // from changing the selection if validation fails - in that case we want to stay in edit mode.
    // But we don't want to do anything here if the mouse down is within this control.
    if (event.type === 'mousedown' && event.target === this.inputField) {
      return;
    }

    /**
     * March'23 - I have left this as a comment for reference.
     * it's a bit of logic that seems to use the dom position as a kind of state.
     * So, if there's a bug I left it for reference. (it's in git I know, but this is clearer, I think)

    // If trigger is a mouse down event, do validation if it is in a control
    // on the same side as us, otherwise simply revert.
    let doValidation = event.type !== 'mousedown' ||
			(event.target.closest('.buy, [side=\'buy\']') && this.classList.contains('buy')) ||
			(event.target.closest('.sell, [side=\'sell\']') && this.classList.contains('sell'));

    if ((event.target.closest('.buy, [side=\'buy\']') && this.classList.contains('buy') && this.classList.contains('vmtile-instrument-row')) ||
        (event.target.closest('.sell, [side=\'sell\']') && this.classList.contains('sell') && this.classList.contains('vmtile-instrument-row'))) {
      doValidation = false;
    }
     **/
    const {parentElement} = this;
    const side = parentElement.getAttribute('side');
    const isBuy = side.toLowerCase() === 'buy';
    const isSell = side.toLowerCase() === 'sell';

    let doValidation = event.type !== 'mousedown' ||
        (isBuy && this.classList.contains('buy')) ||
        (isSell && this.classList.contains('sell'));

    if ((isBuy && this.classList.contains('buy') && this.classList.contains('vmtile-instrument-row')) ||
        (isSell && this.classList.contains('sell') && this.classList.contains('vmtile-instrument-row'))) {
      doValidation = false;
    }

    // If event is triggered from vm tile instrument row, then we dont have to validate the input on buy side OR Sell side size input cell if this cell losses the focus by any mean.

    if (doValidation && this.inputField.value && Number(this.inputField.value) !== Number(this.revertValue)) {
      document.removeEventListener('mousedown', this.onFocusChanging, true);
      if (!this.hasBeenValidated && !this.validate().valid) {
        document.addEventListener('mousedown', this.onFocusChanging, true);
        event.preventDefault();
        event.stopPropagation();
      }
    } else {
      this.revert();
    }
  }

  revert () {
    // HACK, due to the order of event. ready methdd
    if(!this.inputField && this.shadowRoot) {
      const [inputField] = $(this.shadowRoot).find('input');
      if(inputField) {
        this.inputField = inputField;
      }
    }

    if(this.inputField) {
      this.inputField.value = this.revertValue;
      this.inputField.classList.remove('validation-error');

      // Reinstate any cancel icon that was hidden when the input was activated
      if (this.inputField.nextElementSibling && this.inputField.nextElementSibling.classList.contains('cancel-icon')) {
        this.inputField.nextElementSibling.style.display = '';
      }
    }
  }
}
customElements.define('size-input-control', SizeInputControl);
context.SizeInputControl = SizeInputControl;
