import {html} from '@polymer/polymer';

export default html`
      <style>
        * { box-sizing: border-box;}
        input.no-order {
          text-align: center;
          font-weight: normal;
        }
        input.no-order::-webkit-input-placeholder {
          color: var(--bg-sensitive-text-color-for-order-entry);
        }
        input {
          width: 100%;
          height: 100%;
          font-weight: inherit;
          font-size: 1.1rem;
          border: none;
          background-color: var(--blotter-background);
          color: var(--blotter-text);
          display: block;
            
        }
        :host(.in-oeb-panel) input {
            height: 2rem;
        }
        
        :host(.buy) input {
            padding-left: 0.5rem;
            text-align: left;
        }
        :host(.sell) input {
            padding-right: 0.5rem;
            text-align: right;
        }
        :host(.no-order) input {
            text-align: center;
            font-weight: normal;
        }
        :host(.no-order::-webkit-input-placeholder) input {
          color: var(--bg-sensitive-text-color-for-order-entry);
        }
        :host(.published-by-excel) input {
          background-color: var(--excel-green);
        }
        :host:disabled input {
          background-color: var(--disabled-blotter-background);
          color: var(--disabled-blotter-text);
        }
        input:disabled {
            background-color: var(--disabled-blotter-background);
            color: var(--disabled-blotter-text);
        }
      </style>
      <input class="{{class}}"
          type="{{type}}"
          maxlength="{{maxlength}}"
          placeholder="{{placeholder}}"
          value="{{value}}"
          side="{{side}}"
          disabled="{{disabled}}"
      />
`;
