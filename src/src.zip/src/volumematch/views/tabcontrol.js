/* eslint-disable no-param-reassign, max-lines, func-names, max-len, no-magic-numbers, id-length */
/* global BGC: false, $: false, _:false, Backbone: false */

// /////////////////////////////////////////////////////////////////////////////
// file tabcontrol.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

(function (context) {
  /*
       new TabControlView()
       Responsibility: Container control for tab buttons and tab pages
   */
  context.TabControlView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#tab-control'),
    events   : {
      'mouseenter .tab-button' : 'onMouseEnterTabButton',
      'mouseleave .tab-button' : 'onMouseLeaveTabButton',
      'click .tab-button'      : 'onClickTabButton',
      dragstart                : 'onDragStart',
      dragend                  : 'onDragEnd'
    },

    initialize (options) {
      _.extend(this, context.NotificationFlashBehavior);

      this.dataStore = options.dataStore;

      this.tooltip = BGC.ui.tooltipSingleton.getInstance();

      // render view
      this.render();

      // initialize view attributes
      this.$tabButtons = this.$el.find('.tab-button');
      this.$tabPages = this.$el.find('.tab-page');
      this.activePage = -1;
      this.savedActivePage = -1;

      // Set the initial collapsed/expanded state as collapsed
      this.setCollapsed(true);

      this.attachTooltipMouseEvents(this.$el);

      // Hide all pages then select any default page as the "active" page/tab
      // selectTab() shows the page if the tab control is expanded, but not if it is collapsed
      this.$tabPages.hide();
      if (typeof options.activePage === 'number') {
        this.selectTab(options.activePage);
      }


      this.listenTo(this.dataStore.userSettingsStore, 'change:activeTab', this.handleTabSelectionChanged);

      // Allow tab control to show/hide a visual cue of important information
      // if the corresponding page tells it to
      this.$tabPages.on('update:notificationBadges', null, this, this.onUpdateNotificationBadges);
    },

    render () {
      const {pageLayout} = this.dataStore;
      const tabs = pageLayout.get('tabsLayout');
      const tabNames = {
        oredersTabName   : tabs.find(tab => tab.ID === 'tab-control-view-your-orders-tab') ? tabs.find(tab => tab.ID === 'tab-control-view-your-orders-tab').DisplayName : BGC.resources.IDS_YOUR_ORDERS,
        favoritesTabName : tabs.find(tab => tab.ID === 'tab-control-view-my-favorites-tab') ? tabs.find(tab => tab.ID === 'tab-control-view-my-favorites-tab').DisplayName : BGC.resources.IDS_MY_FAVORITES,
        portfolioTabName : tabs.find(tab => tab.ID === 'tab-control-view-portfolio-tab') ? tabs.find(tab => tab.ID === 'tab-control-view-portfolio-tab').DisplayName : BGC.resources.IDS_PORTFOLIO,
        tardersTabName   : tabs.find(tab => tab.ID === 'tab-control-view-your-trades-tab') ? tabs.find(tab => tab.ID === 'tab-control-view-your-trades-tab').DisplayName : BGC.resources.IDS_YOUR_TRADES
      };

      // render tab control
      this.$el.html(this.template({
        tabs : tabNames
      }));
    },

    installToolbar (toolbar) {
      this.toolbar = toolbar;
      this.$el.show();
      this.updateControlsVisibility();
    },

    updateControlsVisibility () {
      if (this.dataStore.isActiveBrokerMode()) {
        this.toolbar.showOrdersAndTradesControls(true);

        const pageIndex = this.dataStore.userSettingsStore.get('activeTab');

        if (this.$tabPages.length && pageIndex !== -1) {
          this.handleTabSelectionChanged();
        }
      } else if (this.dataStore.isBrokerMode()) {
        this.hideTabs();
        this.toolbar.showOrdersAndTradesControls(false);
      } else {
        this.showTabs();
        this.toolbar.showOrdersAndTradesControls(true);
        this.handleTabSelectionChanged();
      }
    },

    showTabs () {
      const pageIndex = this.dataStore.userSettingsStore.get('activeTab');

      this.$tabButtons.show();
      if (this.$tabPages.length && pageIndex !== -1) {
        this.selectTab(pageIndex);
      }
    },

    hideTabs () {
      this.$tabButtons.hide();
      this.$tabPages.hide();
    },

    // Either check the state of the toggle button or the state of the user setting
    isCollapsed () {
      return this.isInCollapsedState || false;
    },

    setCollapsed (isCollapsed) {
      this.isInCollapsedState = isCollapsed;
      this.onExpandCollapseStateChanged();
    },

    onMouseEnterTabButton (event) {
      const pageIndex = this.$tabButtons.index($(event.target.closest('.tab-button')));

      if (this.isCollapsed() && $(this.$tabPages[pageIndex]).hasClass('populated')) {
        // After a hover period of one second, select the tab and pop it down in float-over mode
        this.hoverTimer = setTimeout(this.onHoverTabButton.bind(this, $(event.target.closest('.tab-button'))), 1000);
      }
    },

    onMouseLeaveTabButton () {
      if (this.hoverTimer) {
        clearTimeout(this.hoverTimer);
        this.hoverTimer = null;
      }

      if (this.isCollapsed()) {
        // In collapsed state. Cancel any "float-over" mode when the mouse moves away.
        $(this.$tabPages[this.activePage]).hide();
        this.cancelFloatingMode();
      }
    },

    onHoverTabButton ($button) {
      // Timeout is completed, hover mode is official, time for action!
      this.hoverTimer = null;
      this.invokeFloatingMode(this.$tabButtons.index($button));
    },

    onClickTabButton (event) {
      let activeTab = -1;
      const pageIndex = this.$tabButtons.index($(event.target.closest('.tab-button')));

      // If we have clicked then we are no longer just hovering
      if (this.hoverTimer) {
        clearTimeout(this.hoverTimer);
        this.hoverTimer = null;
      }

      // if any page is being shown in float-over mode then kill it
      this.cancelFloatingMode();

      // If active page button is clicked, deselect it and collapse,
      // else select it and expand
      if (pageIndex === this.activePage) {
        this.selectTab(-1);
        this.setCollapsed(true);
      } else {
        activeTab = pageIndex;
        if (this.$tabPages[pageIndex].classList.contains('active-orders-view')) {
          this.stopFlashing(this.EFlashType.eMyTradeCount, this.$el.find('.notifications .my-trade-count-badge'));
        }
      }
      this.dataStore.userSettingsStore.set('activeTab', activeTab);
    },

    handleTabSelectionChanged () {
      const pageIndex = this.dataStore.userSettingsStore.get('activeTab');

      this.selectTab(-1);
      if (pageIndex === -1) {
        this.setCollapsed(true);
      } else {
        this.selectTab(pageIndex);
        this.setCollapsed(false);
        if (this.$tabPages[pageIndex].classList.contains('active-orders-view')) {
          // Now we've seen the data we don't need the alert any more
          this.stopFlashing(this.EFlashType.eMyTradeCount, this.$el.find('.notifications .my-trade-count-badge'));
        }
      }
    },

    onExpandCollapseStateChanged () {
      this.cancelFloatingMode();

      if (this.isCollapsed()) {
        $(this.$tabPages[this.activePage]).hide();
      } else {
        $(this.$tabPages[this.activePage]).show();
        this.trigger('change:activeView');
      }

      this.$el.trigger('recalcLayout');
    },

    onUpdateNotificationBadges (event, notificationParams) {
      const tabControlView = event.data;

      if (notificationParams.badgeType === 'tradeCount') {
        const tradeCountBadgeElement = tabControlView.$el.find('.notifications .my-trade-count-badge');

        if (tradeCountBadgeElement !== undefined) {
          tradeCountBadgeElement.text(notificationParams.count || '');
          if (notificationParams.flash) {
            const infiniteFlash = tabControlView.isCollapsed() ||
              tabControlView.activePage === -1 ||
              tabControlView.$tabPages[tabControlView.activePage] !== notificationParams.view;

            tabControlView.flashNotification(tabControlView.EFlashType.eMyTradeCount, tradeCountBadgeElement, infiniteFlash);
          }
        }
      } else if (notificationParams.badgeType === 'orderCount') {
        const orderCountBadgeElement = tabControlView.$el.find('.notifications .my-order-count-badge');

        if (orderCountBadgeElement !== undefined) {
          orderCountBadgeElement.text(notificationParams.count || '');
        }
      }
    },

    showTooltip (event) {
      const tipText = this.isCollapsed() ? BGC.resources.IDS_EXPAND : BGC.resources.IDS_COLLAPSE;
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        x : targetRect.left + (targetRect.width / 2),
        y : (targetRect.top + (targetRect.height / 2)) + 12
      };

      this.tooltip.hide();
      this.tooltip.show(tipText, position);
    },

    hideTooltip () {
      this.tooltip.hide();
    },

    invokeFloatingMode (tabIndex) {
      if (this.isCollapsed()) {
        // select page in temporary mode
        this.selectTab(tabIndex, true);

        // display active page in "float-over" mode
        $(this.$tabPages[tabIndex]).show();
        this.$tabPages.addClass('float-over');
        this.$tabPages.css('width', $('#tab-control-orders-trades').outerWidth(true));

        // Cancel flashing visual "my trades" alert if the displayed page is "My Orders"
        if (this.$tabPages[tabIndex].classList.contains('active-orders-view')) {
          this.stopFlashing(this.EFlashType.eMyTradeCount, this.$el.find('.notifications .my-trade-count-badge'));
        }

        this.trigger('change:activeView');
      }
    },

    cancelFloatingMode () {
      this.$tabPages.removeClass('float-over');
      this.$tabPages.css('width', '');

      // If the floating page was not the official active page, then restore the previous page selection.
      if (this.activePage !== this.savedActivePage) {
        this.selectTab(this.savedActivePage);
      }
    },

    // eslint-disable-next-line consistent-return
    onDragStart (event) {
      const dragHandler = $(event.target);
      const container = this.$el;
      const offset = BGC.utils.getRelativeOffset(dragHandler, container);

      // <img> elements seem to be draggable by default. We don't want that!
      // We also want to suppress any drag on a div that immediately contains an input
      // so that the input can become active and use mouse movement to select text.
      if (event.target.tagName === 'IMG' || event.target.tagName === 'INPUT' ||
        (event.target.tagName === 'DIV' && $(event.target).find('> input').length)) {
        return false;
      }

      event.originalEvent.dataTransfer.setData('source', 'tab-control');
      event.originalEvent.dataTransfer.setDragImage(container[0], event.originalEvent.offsetX + offset.left, event.originalEvent.offsetY + offset.top);

      // hide drop-target-line above the element
      $('.drop-target-line').show();
      $('.drop-target-line').eq($('.draggable-block').index(this.el)).hide();
    },

    onDragEnd () {
      $('.drop-target-line').hide();

      // Am I now docked at bottom or top of page?
      const myPos = this.$el.offset();
      const header = $('header');
      const headerPos = header.offset();

      // Consider tab control to be docked at top if within 20 px of the header
      const dockedAtTop = (myPos.top - (headerPos.top + header.outerHeight(true))) < 20;

      if (dockedAtTop) {
        this.$el.removeClass('docked-bottom').addClass('docked-top');
      } else {
        this.$el.removeClass('docked-top').addClass('docked-bottom');
      }
    },

    selectTab (pageIndex, isTemporarySelection) {
      // hide current page
      if (this.activePage !== -1) {
        $(this.$tabPages[this.activePage]).hide();
        $(this.$tabButtons[this.activePage]).removeClass('active');
      }

      this.activePage = pageIndex;

      // save its index as backup against temporary float-over selection
      if (!isTemporarySelection) {
        this.savedActivePage = this.activePage;
      }

      if (pageIndex !== -1) {
        // activate the new page
        $(this.$tabButtons[pageIndex]).addClass('active');
      }

      if (!this.isCollapsed() && pageIndex !== -1) {
        // Tab content is expanded - show the new page
        $(this.$tabPages[pageIndex]).show();
        if (this.$tabPages[pageIndex].classList.contains('active-orders-view')) {
          this.stopFlashing(this.EFlashType.eMyTradeCount, this.$el.find('.notifications .my-trade-count-badge'));
        }
        this.trigger('change:activeView');
      }
    },

    isTabActive (tabIndex) {
      return this.activePage === tabIndex;
    },

    glowTab (tabIndex) {
      const tabButton = $(this.$tabButtons[tabIndex]);

      // timeout value is taken from main.less:.tab-control section and equals to transition length
      const timeout = 300;

      if (tabButton) {
        tabButton.addClass('glow');
        _.delay(() => {
          tabButton.removeClass('glow');
        }, timeout);
      }
    },

    getTab (tabIndex) {
      return this.$tabButtons[tabIndex];
    }
  });

  BGC.utils.createEnumeration(context, 'TabPages', [
    'myOrders',
    'myFavorites',
    'myTrades'
  ]);
}(window.BGC.ui.view));
