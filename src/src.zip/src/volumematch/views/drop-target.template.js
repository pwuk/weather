import {html} from '@polymer/polymer/polymer-element';

export default html`
<style>
    :host {
        display: inline-block;
        background-color: var(--content-header-background);
        border-color: var(--content-header-border);
        margin: 1rem 0 1rem 0;
    }
     textarea:hover {
        border-color: darkorange !important;
    }
     textarea:focus {
        border-color: orange !important;
        background-color: orange;
    }

    textarea {
        resize : none;
        padding : 0;
        text-align : center;
        vertical-align: middle;
        font-size : 1.4rem;
        border-radius: 1rem;
        font-weight: bold;
        border: 3px solid #3976c0;
        outline: none;
    }
</style>
        <textarea class="drop-target" on-focus="onTextAreaFocus" on-blur="onTextAreaBlur"
                  readOnly cols="11" rows="2">{{caption}}</textarea>
`;
