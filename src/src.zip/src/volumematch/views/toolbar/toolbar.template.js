/* eslint-disable max-lines, max-len */
// noinspection CssUnknownTarget

import {html} from '@polymer/polymer';

export default html`
<style>
    * { box-sizing: border-box;}
    *[hidden] { display: none !important; }
    
    .waiting-for-vm {
        margin-right: auto;
        display: inline;
        line-height: 2.4rem;
        margin-left: 0.5rem;
        font-size: 1.2rem;
        color: var(--content-text);
    }

    :host {
        margin-left: auto;
    }

    @font-face {
        font-family: 'FontAwesome';
        src: url('../fonts/fontawesome-webfont.eot?v=4.0.3');
        src: url('../fonts/fontawesome-webfont.eot?#iefix&v=4.0.3') format('embedded-opentype'), url('../fonts/fontawesome-webfont.woff?v=4.0.3') format('woff'), url('../fonts/fontawesome-webfont.ttf?v=4.0.3') format('truetype'), url('../fonts/fontawesome-webfont.svg?v=4.0.3#fontawesomeregular') format('svg');
        font-weight: normal;
        font-style: normal;
    }
    .fa {
        display: inline-block;
        font-family: FontAwesome;
        font-style: normal;
        font-weight: normal;
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    .fa-times:before {
        content: "\\f00d";
    }

    :host {
        height: 100%;
        margin-left: 0.5rem;
    }
    
    > * {
        display: inline-block;
        height: 100%;
        font-size: 1.6rem;
        padding: 0 1rem 0 1rem;
        color: var(--header-text);
        float: left;
    }
    i:hover {
        color: var(--highlight-text);
    }
    .excel-add-in {
        padding-top: 0.4rem;
        border-left: 1px solid var(--header-border);
        display: none;
    }
    .excel-add-in.enabled {
        display: inline-block;
        border-left: 1px solid var(--header-border);
    }
    :host .excel-add-in button {
        vertical-align: middle;
        background-color: transparent;
        padding: 0;
        border: none;
        float: left;
        margin: 0 0.5rem;
    }
    :host  .excel-add-in button img {
        vertical-align: middle;
        height: 1.6rem;
    }

    .toolbar #showTradesForFirm,
    .toolbar #showTradesForExternalGroupUsers {
        display: inline-block;
        line-height: 2.4rem;
        vertical-align: top;
        font-size: 1.1rem;
        padding: 0 0.7rem 0 0.25rem;
        color: var(--content-label-text);
        float: right;
        font-size: 1.1em;
    }
    .toolbar #showTradesForFirm input,
    .toolbar #showTradesForExternalGroupUsers input {
        margin: 0 5px 0 5px;
        vertical-align: middle;
        font-size: 1.1em;
        color: var(--content-text);
    }
    .toolbar .cancel-all {
        position: relative;
        float: right;
        font-size: 1.2rem;
        overflow: hidden;
        background-color: var(--cancel-all-button-background);
        color: white;
        height: 2rem;
        margin-right: 1.5rem;
        border: 1px solid var(--cancel-all-button-border);
        margin-top: 4px;
        text-transform: uppercase;
        font-weight: lighter;
        padding: 0;
    }
    .toolbar .cancel-all[disabled] {
        pointer-events: none;
        opacity: 0.5;
    }
    .toolbar .cancel-all:hover:not([disabled]) {
        border: 1px solid var(--cancel-all-button-highlight);
    }
    .toolbar .cancel-all:hover:not([disabled]) span {
        border-left: 1px solid var(--cancel-all-button-highlight);
    }
    .toolbar .cancel-all i {
        text-align: center;
        width: calc(2rem - 2px);
        height: calc(2rem - 2px);
        line-height: calc(2rem - 2px);
        background-color: var(--cancel-all-icon-background);
    }
    .toolbar .cancel-all span {
        padding: 0 0.5rem 1px 0.5rem;
        font-weight: 600;
        height: calc(2rem - 2px);
        line-height: calc(2rem - 2px);
        border-left: 1px solid var(--cancel-all-button-border);
    }
    .toolbar .cancel-all:after {
        clear: right;
    }
    .toolbar .submit-button {
        position: relative;
        float: right;
        margin-top: 4px;
        margin-right: 4px;
        padding: 0 0.5rem 1px 0.5rem;
        height: 2rem;
        font-size: 1.2rem;
        font-weight: 600;
        text-transform: uppercase;
        color: white;
        background-color: var(--submit-button-background);
        border: 1px solid var(--submit-button-background-lighter10);
        overflow: hidden;
    }
    .toolbar .submit-button:hover:not(:disabled) {
        border-color: var(--submit-button-background-lighter10);
    }
    .toolbar .submit-button[disabled] {
        pointer-events: none;
        opacity: 0.5;
    }
    .toolbar .submit-button .counter {
        display: inline-block;
        text-align: right;
        color: var(--submit-button-highlight-text);
        min-width: 10px;
    }
    .toolbar .submit-button .fa {
        font-size: 1.1rem;
        color: var(--submit-button-highlight-text);
    }
    
    
    .menu-bar {
        width: 100%;
        display: flex;
        color: var(--menubar-text);
        background-color: var(--menubar-background);
        height: 1.6rem;
        font-size: 1rem;
    }
    .menu-bar .menu {
        display: flex;
        padding: 0 1rem 0 1rem;
    }
    .menu-bar i:hover {
        color: var(--highlight-text);
    }
    #showTradesForFirm,
    #showTradesForExternalGroupUsers {
        display: inline-block;
        line-height: 2.4rem;
        vertical-align: top;
        font-size: 1.1rem;
        padding: 0 0.7rem 0 0.25rem;
        color: var(--content-label-text);
        float: right;
        font-size: 1.1em;
    }
    #showTradesForFirm input,
    #showTradesForExternalGroupUsers input {
        margin: 0 5px 0 5px;
        vertical-align: middle;
        font-size: 1.1em;
        color: var(--content-text);
    }
    .cancel-all {
        position: relative;
        float: right;
        font-size: 1.2rem;
        overflow: hidden;
        background-color: var(--cancel-all-button-background);
        color: white;
        height: 2rem;
        margin-right: 1.5rem;
        border: 1px solid var(--cancel-all-button-border);
        margin-top: 4px;
        text-transform: uppercase;
        font-weight: lighter;
        padding: 0;
    }
    .cancel-all[disabled] {
        pointer-events: none;
        opacity: 0.5;
    }
    .cancel-all:hover:not([disabled]) {
        border: 1px solid var(--cancel-all-button-highlight);
    }
    .cancel-all:hover:not([disabled]) span {
        border-left: 1px solid var(--cancel-all-button-highlight);
    }
    .cancel-all i {
        text-align: center;
        width: calc(2rem - 2px);
        height: calc(2rem - 2px);
        line-height: calc(2rem - 2px);
        background-color: var(--cancel-all-icon-background);
    }
    .cancel-all span {
        padding: 0 0.5rem 1px 0.5rem;
        font-weight: 600;
        height: calc(2rem - 2px);
        line-height: calc(2rem - 2px);
        border-left: 1px solid var(--cancel-all-button-border);
    }
    .cancel-all:after {
        clear: right;
    }
    .submit-button {
        position: relative;
        float: right;
        margin-top: 4px;
        margin-right: 4px;
        padding: 0 0.5rem 1px 0.5rem;
        height: 2rem;
        font-size: 1.2rem;
        font-weight: 600;
        text-transform: uppercase;
        color: white;
        background-color: var(--submit-button-background);
        border: 1px solid var(--submit-button-background-lighter10);
        overflow: hidden;
    }
    .submit-button:hover:not(:disabled) {
        border-color: var(--submit-button-background-lighter10);
    }
    .submit-button[disabled] {
        pointer-events: none;
        opacity: 0.5;
    }
    .submit-button .counter {
        display: inline-block;
        text-align: right;
        color: var(--submit-button-highlight-text);
        min-width: 10px;
    }
    .submit-button .fa {
        font-size: 1.1rem;
        color: var(--submit-button-highlight-text);
    }

    .switch {
        display: block;
    }
    .switch input[type=checkbox] {
        display: none;
    }
    .switch .toggle {
        display: inline-block;
        height: 1.5em;
        width: 2.6em;
        vertical-align: middle;
        border-radius: 1em;
        background-color: var(--switch-background);
        margin-right: 0.2em;
        will-change: background;
        transition: background 0.3s;
    }
    .switch .toggle:before {
        content: "";
        height: 1.1em;
        width: 1.1em;
        vertical-align: top;
        background-color: var(--switch-toggle-background);
        display: inline-block;
        border-radius: 50%;
        will-change: transform;
        transition: transform 0.3s ease;
        transform: translate3d(0, 0, 0);
        margin: 2px 0 0 2px;
    }
    .switch input[type=checkbox]:checked + .toggle {
        background-color: var(--switch-on-background);
    }
    .switch input[type=checkbox]:checked + .toggle:before {
        transform: translate3d(100%, 0, 0);
        background-color: var(--switch-on-toggle-background);
    }
    .low-bandwidth .switch .toggle,
    .low-bandwidth .switch .toggle:before {
        transition: none;
    }

    :host(.auction-active) .waiting-for-vm {
        display: none;
    }

    .orders-and-trades-controls {
        display: none;
    }

    :host(.auction-active) .orders-and-trades-controls {
        display: inline;
    }
    

</style>
<span class="waiting-for-vm">[[waitingText]]</span>
<div id="orders-and-trades-controls" class="orders-and-trades-controls" hidden$="[[!areOrdersAndTradesControlsShown]]">
    <button class="cancel-all" disabled$="[[disableCancelButton]]">
        <i class="fa fa-times"></i>
        <span>[[cancelAllText]]</span>
    </button>
    <fa-count-button
            class="submit-button"
            click="onClickSubmit" 
            id="submit-button" 
            hidden$="[[hideSubmitButton]]">
    </fa-count-button>
</div>
`;
