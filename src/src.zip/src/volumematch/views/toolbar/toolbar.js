/* eslint-disable no-magic-numbers */
/* global BGC: false, $: false, _:false, Backbone: false */


import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './toolbar.template';

const {ui: {view: context}, resources} = window.BGC;

class OrdersAndTradesToolbar extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor (options) {
    super();
    this.classOptions = options;
    this.dataStore = this.classOptions.dataStore;
    this.classOptions.el.appendChild(this);
  }

  connectedCallback () {
    super.connectedCallback();
    _.extend(this, Backbone.Events);

    // Listen to Cancel All requests
    this.cancelAllButton = this.shadowRoot.querySelector('.cancel-all');

    // this.listen(this.cancelAllButton, 'tap', 'onClickCancelAll');
    this.cancelAllButton.addEventListener('click', this.onClickCancelAll.bind(this));

    // Initialize the cancel all second look
    const that = this;
    const $secondLook = $('#confirmCancelAllEffect');

    this.secondLook = $secondLook.popup({
      modal                : true,
      title                : resources.IDS_CANCEL_ALL,
      hasHeaderCloseButton : false,

      confirm () {
        let cancelOwn = true;
        let cancelPeers = false;
        const $cancelType = $('#confirmCancelAllEffect_selectEffect');

        if ($cancelType.val() === 'peer') {
          cancelOwn = false;
          cancelPeers = true;
        } else if ($cancelType.val() === 'all') {
          cancelPeers = true;
        }

        that.dataStore.cancelAllOrders(cancelOwn, cancelPeers);
      },

      controlsHtmlContent : _.template($('#confirmCancelAllEffect_template').html(), {resources})
    });

    this.listenTo(this.dataStore.orderStore, 'ordersCanBeCancelled', this.handleOrdersCanBeCancelledEvent);
    this.listenTo(this.dataStore.userSettingsStore, 'change:activeTab', this.handleTabSelectionChanged);

    this.waitingText = BGC.utils.format(resources.IDS_MSG_WAITING_FOR_NEXT, [this.dataStore.pageLayout.get('vmTerminology')]);
    this.cancelAllText = resources.IDS_CANCEL_ALL;
  }

  ready () {
    super.ready();
    this.areOrdersAndTradesControlsShown = false;
    this.disableCancelButton = true;

    this.submitButton = this.$['submit-button'];
  }

  attached () {
    super.attached();
    this.listenTo(this.dataStore.orderStore, 'ordersCanBeCancelled', this.handleOrdersCanBeCancelledEvent);
    this.listenTo(this.dataStore.userSettingsStore, 'change:activeTab', this.handleTabSelectionChanged);

    this.waitingText = BGC.utils.format(resources.IDS_MSG_WAITING_FOR_NEXT, [this.dataStore.pageLayout.get('vmTerminology')]);
    this.cancelAllText = resources.IDS_CANCEL_ALL;
  }

  render () {
    // if favorites tab is hidden, then hide Submit Favorites button either
    this.hideSubmitButton = !this.dataStore.userSettingsStore.get('displayFavorites') ||
        this.dataStore.userSettingsStore.get('disableBatchSubmission');

    // if there is SettingsSwitch already, then remove it
    const settingsSwitch = this.shadowRoot.querySelector('.switch');

    if (settingsSwitch) {
      this.shadowRoot.removeChild(settingsSwitch);
    }

    if (this.areOrdersAndTradesControlsShown) {
      // If we are a Sales Trader, filter is for orders/trades by anyone on shared accounts
      if (this.dataStore.isSalesTraderMode()) {
        this.shadowRoot.appendChild(new context.SettingsSwitch({
          model : this.dataStore.userSettingsStore,
          id    : 'showTradesForExternalGroupUsers',
          title : resources.IDS_TRADES_FOR_GROUP
        }).render().$el[0]);
      } else {
        // Otherwise, it's a same LE filter
        this.shadowRoot.appendChild(new context.SettingsSwitch({
          model : this.dataStore.userSettingsStore,
          id    : 'showTradesForFirm',
          title : resources.IDS_TRADES_FOR_FIRM
        }).render().$el[0]);
      }
    }

    this.handleTabSelectionChanged();
  }

  showOrdersAndTradesControls (show) {
    if (show) {
      this.areOrdersAndTradesControlsShown = true;
      this.render();
    } else {
      this.areOrdersAndTradesControlsShown = false;
      this.render();
    }
  }

  handleTabSelectionChanged () {
    const isFavoritesTabSelected = this.dataStore.userSettingsStore.get('activeTab') === 1;

    this.submitButton.disabled = !(isFavoritesTabSelected && this.submitButton.count > 0);

    if (isFavoritesTabSelected) {
      this.submitButton.removeAttribute('hidden');
    } else {
      this.submitButton.setAttribute('hidden', '');
    }
  }

  handleOrdersCanBeCancelledEvent () {
    this.disableCancelButton = !this.dataStore.orderStore.hasCancellableOrders;
  }

  onClickCancelAll () {
    // If some orders that we are allowed to cancel belong to other users as well as ouselves,
    // display second look to ask user if they want to cancel their own orders, peer orders, or both
    const {dataStore} = this;
    const {orderStore} = dataStore;
    const showTradesForFirm = !!dataStore.userSettingsStore.get('showTradesForFirm');
    const foundPeer = showTradesForFirm && !!orderStore.find(order => order.hasCancellableSize() && order.isCancellationBuddyOrder());

    if (foundPeer) {
      this.secondLook.popup('show');
    } else {
      dataStore.cancelAllOrders(true, false);
    }

    return false;
  }
}
customElements.define('orders-and-trades-toolbar', OrdersAndTradesToolbar);
context.OrdersAndTradesToolbar = OrdersAndTradesToolbar;
