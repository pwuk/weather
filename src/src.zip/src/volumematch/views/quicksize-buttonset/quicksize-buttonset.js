/* global BGC: false, $: false, _:false, Backbone: false */


import {PolymerElement} from '@polymer/polymer';
import {flush} from '@polymer/polymer/lib/utils/flush';
import componentTemplate from './quicksize-buttonset.template';

const {view: context} = window.BGC.ui;

class QuickSizeButtonSet extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor () {
    super();
    _.extend(this, Backbone.Events);
  }

  /**
   * updateSizeCalledBeforeShadowRoot
   * This is used as sometimes (order entry spread view) templates containing QuickSizeButtonSets are created
   * programmatically.
   * Then immediately accessed calling updateSizes(), which attempts to access the template/shadowRoot element -
   * at this point the component template has not yet been created, so we store the size array.
   * When the template is ready(), updateSizes() is then called correctly applying buy/sell side classes.
   */
  ready () {
    super.ready();

    if (this.updateSizeCalledBeforeShadowRoot) {
      this.updateSizeCalledBeforeShadowRoot = false;
      this.updateSizes(this.sizesArray);
    }
  }

  static get properties () {
    return {
      side : {
        type   : String,
        value  : 'buy',
        notify : true
      },

      sizes : {
        type   : Array,
        value  : ['', '', ''],
        notify : true
      },

      showSizes : {
        type   : String,
        value  : '',
        notify : true
      }
    };
  }

  created () {
    _.extend(this, Backbone.Events);
  }

  updateSizes (sizesArray) {
    // Polymer 'splice' functionality leads to issues when the layout is detached from the DOM
    // during recalcLayout for vertically snaking tile layout, so simply clear the array
    // and build again from scratch rather than trying to replace existing array entries
    this.sizes = [];

    this.sizesArray = sizesArray;
    if (!this.shadowRoot) {
      this.updateSizeCalledBeforeShadowRoot = true;

      return;
    }

    // eslint-disable-next-line func-names
    _.each(sizesArray, function (sizeVal) {
      this.push('sizes', this.showSizes === 'show' ? sizeVal : ' ');
    }, this);

    $(this.shadowRoot).find('ul')
      .toggleClass('buy', this.side === 'buy')
      .toggleClass('sell', this.side === 'sell')
      .toggleClass('no-instrument', this.showSizes !== 'show');

    // Force synchronous update to the DOM
    flush();
  }

  onClickSizeButton (event) {
    event.stopPropagation();

    // Log it here, since it won't now make its way up to the body where clicks are normally logged
    BGC.logger.logUserInteraction(event);

    // If the QoS timer is running, generate the interaction metric now
    BGC.utils.generateInteractivityQoSMetric('oebActivated');

    // Use jQuery event so it bubbles
    const order = {
      size : parseFloat(event.target.textContent),
      side : this.side
    };

    this.dispatchEvent(
      new CustomEvent('SubmitQuickSize', {
        bubbles  : true,
        composed : true,
        detail   : order
      })
    );
  }
}
customElements.define('quicksize-buttonset', QuickSizeButtonSet);
context.QuickSizeButtonSet = QuickSizeButtonSet;
