import {html} from '@polymer/polymer/polymer-element';
export default html`
    <style>
        ul.buy li {
            background-color: var(--buy-side);
            border: 1px solid var(--buy-side-border);
        }
        ul.sell li {
            background-color: var(--sell-side);
            border: 1px solid var(--sell-side-border);
        }
        ul.sell li:hover {
            color: var(--sell-hover-text-color);
            font-weight: bold;
        }
        ul.buy li:hover {
            color: var(--buy-hover-text-color);
            font-weight: bold;
        }
        ul {
            list-style: none;
            margin: 0;
            width: 100%;
            display: flex;
            padding: 0;
            height: auto;
        }
        li {
            margin: 0 2px 0 2px;
            flex: 1;
            min-width: 6rem;
            cursor: default;
            text-align: center;
            border-radius: 12px;
            font-weight: bold;
            position: relative;
        }

        /*:host(.inplace-order)  ul li {*/
        /*    transform: rotateY(180deg);*/
        /*}*/

        :host(.inplace-order) {
            margin: 0;
            width: 100%;
            height: 100%;
            display: inline-flex;
            padding: 0 1px 0 1px;
            font-size: 1.1rem;
            flex: 1;
            max-width: none;
            line-height: 2.4rem;
            font-size: 1.5rem;
        }
        :host(.inplace-order)  ul {
            list-style: none;
            margin: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            padding: 0;
            width: auto;
        }
        :host(.inplace-order) ul li {
            margin: 0 2px 0 2px;
            flex: 1;
            min-width: 6rem;
            cursor: default;
            text-align: center;
            border-radius: 12px;
            font-weight: bold;
            position: relative;
            margin-bottom: 7px;
            height: 2.4rem;
        }
        :host(.inplace-order.compact-buttons) ul li {
            min-width: 5rem;
            margin: 0 1px 7px 1px;
            border: none;
        }
        
    </style>
    <ul>
        <dom-repeat items="{{sizes}}">
        <template>
                <li on-click="onClickSizeButton">{{item}}</li>
            </template>
        </dom-repeat>
    </ul>
`;
