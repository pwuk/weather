import {html} from '@polymer/polymer/polymer-element';

export default html`
<style> * { 
    box-sizing: border-box;
}
:host {
     display: flex;
     margin-right: 1.5rem
 }
.portfolio-bar {
    display: flex;
    flex-direction: column;
    font-size: 1.4rem;
    padding: 0.5rem;
}

.publish {
    display: flex;
    padding: 0 0.5rem;
    border-radius: 0.7rem;
    margin: 0 auto 0 1rem;
}

.publish span {
    align-self : center;
}

.periods {
    display: flex;
}

button {
    border: none;
    border-radius: 0.7rem;
    font-size: inherit;
    padding: 0.2rem 1rem;
}

button:disabled {
    opacity: 0.2;
}

input-toggle {
    margin: 0 0.25rem;
}

input-toggle[disabled] {
    opacity: 0.3;
}

.portfolio-bar {
    background-color: var(--content-header-background);
}
.portfolio-bar button,
.portfolio-bar input-toggle {
    background-color: var(--submit-button-background);
    color: var(--submit-button-text);
    margin-top: 0.5rem;
}
.portfolio-bar button:hover:not(:disabled),
.portfolio-bar input-toggle:hover:not(:disabled) {
    border-color: var(--submit-button-background-lighter30);
}
.portfolio-bar .publish {
    background-color: var(--submit-button-background);
    color: var(--submit-button-text);
    /*
        --portfolio-view-publish-display: flex|none, is controlled via business-specific.less
        Using this method : 
            1) The required shadow root element is Not visible to high level CSS
            2) The ::part() pseudo selector is not available in Chromium v64
        This works as it's a simple requirement: Just toggling display flex or none 
        
        var(--portfolio-view-publish-display, flex)   
     */
    display: none
}
   
    
</style>
    <portfolio-grid></portfolio-grid>
    <div class="portfolio-bar" ">
        <div class="publish">
            <span>[[IDS_GOOD_TILL]]</span>
            <div class="periods">
                <input-toggle
                        id="gt-end-of-day"
                        class="switch"
                        icon="fa-sun-o"
                        label="[[timer.periods.1.label]]"
                        checked="{{timer.periods.1.running}}"
                        disabled="[[computeIsTimerInactive(timer.currentPeriod, 1)]]"
                        on-tap="onTapGTEndOfDay">
                </input-toggle>
                <input-toggle
                        id="gt-end-of-night"
                        class="switch"
                        icon="fa-moon-o"
                        label="[[timer.periods.0.label]]"
                        checked="{{timer.periods.0.running}}"
                        disabled="[[computeIsTimerInactive(timer.currentPeriod, 0)]]"
                        on-tap="onTapGTOvernight">
                </input-toggle>
            </div>
        </div>
        <drop-target collection="[[portfolio]]" select-msg="[[IDS_MSG_PORTFOLIO_SELECT_TARGET]]"
                     paste-msg="[[IDS_MSG_PORTFOLIO_PASTE_TARGET]]">
        </drop-target>
        <button id="portfolio-clear" class="submit-button" type="button" on-click="onTapClearButton">
            [[IDS_CLEAR]]
        </button>
        <button id="portfolio-submit" class="submit-button" type="button" on-click="onTapSubmitButton">
            [[IDS_SUBMIT_FAVORITES]]
        </button>
    </div>
`;
