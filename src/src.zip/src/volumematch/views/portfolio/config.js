/* eslint-disable no-param-reassign, func-names, no-nested-ternary */

(function (context, resources) {
  // Page -> business
  const pageBusiness = {
    // EGB
    LM_DOCUMENT_VM_BGC_EGB_ALL     : 'EGB',
    LM_DOCUMENT_VM_BGC_EGB_CORE    : 'EGB',
    LM_DOCUMENT_VM_BGC_EGB_NOMINAL : 'EGB',

    // GILTS
    LM_DOCUMENT_VM_GILTS : 'GILTS',

    // IRO
    LM_DOCUMENT_VM_IRO_EUR : 'IRO',
    LM_DOCUMENT_VM_IRO_GBP : 'IRO',
    LM_DOCUMENT_VM_IRO_USD : 'IRO',
    LM_DOCUMENT_VM_IRO_JPY : 'IRO',
    LM_DOCUMENT_VM_IRO_AUD : 'IRO',

    // UST
    LM_DOCUMENT_VM_US_TREASURY_SWAPS : 'UST',

    // TIPS
    LM_DOCUMENT_VM_US_INFLATION_ALL : 'TIPS',

    // NDF
    LM_DOCUMENT_VM_GFI_PEN_NDF : 'NDF',
    LM_DOCUMENT_VM_GFI_CLP_NDF : 'NDF',
    LM_DOCUMENT_VM_GFI_COP_NDF : 'NDF',

    // NDF Combine Grid
    LM_DOCUMENT_VM_GFI_LATM_NDF : 'NDF'
  };

  // Business -> portfolio lookup type
  const businessPortfolioType = {
    UST   : 'cusip',
    TIPS  : 'cusip',
    GILTS : 'isin',
    EGB   : 'isin',
    IRO   : 'matrix',
    NDF   : 'linkedMatrix'
  };

  const getNumeric = text => ({
    text,
    numeric : Number(text)
  });

  const columns = {
    EGB : [{
      id   : 'id',
      name : resources.IDS_ISIN,
      get  : text => text
    }, {
      id   : 'size',
      name : resources.IDS_SIZE,
      get  : text => Math.abs(Number(text))
    }, {
      id   : 'limit',
      name : resources.IDS_LIMIT,
      get  : getNumeric
    }, {
      id         : 'side',
      calculated : 1,
      get        : text => {
        const sign = Math.sign(Number(text));

        return sign === 1 ? 'sell' : sign === -1 ? 'buy' : '';
      }
    }],
    GILTS : [{
      id   : 'id',
      name : resources.IDS_ISIN,
      get  : text => text
    }, {
      id   : 'size',
      name : resources.IDS_SIZE,
      get  : text => Math.abs(Number(text))
    }, {
      id   : 'limit',
      name : resources.IDS_LIMIT,
      get  : getNumeric
    }, {
      id         : 'side',
      calculated : 1,
      get        : text => {
        const sign = Math.sign(Number(text));

        return sign === 1 ? 'sell' : sign === -1 ? 'buy' : '';
      }
    }],
    IRO : [{
      id   : 'id',
      name : 'Lookup',
      get  : text => text
    }, {
      id   : 'side',
      name : 'Side',
      get  : text => {
        if (text.match(/^b$|^buy$/i)) {
          return 'buy';
        }

        if (text.match(/^s$|^sell$/i)) {
          return 'sell';
        }

        return '';
      }
    }, {
      id   : 'size',
      name : resources.IDS_SIZE,
      get  : text => Math.abs(Number(text))
    }, {
      id   : 'limit',
      name : `${resources.IDS_LIMIT} A`,
      get  : getNumeric
    }, {
      id   : 'limitB',
      name : `${resources.IDS_LIMIT} B`,
      get  : getNumeric
    }],
    UST : [{
      id   : 'id',
      name : resources.IDS_CUSIP,
      get  : text => text
    }, {
      id   : 'size',
      name : resources.IDS_SIZE,
      get  : text => Math.abs(Number(text))
    }, {
      id   : 'limit',
      name : resources.IDS_LIMIT,
      get  : getNumeric
    }, {
      id         : 'side',
      calculated : 1,
      get        : text => {
        const sign = Math.sign(Number(text));

        return sign === 1 ? 'sell' : sign === -1 ? 'buy' : '';
      }
    }],
    NDF : [{
      id   : 'id',
      name : 'Lookup',
      get  : text => text
    }, {
      id   : 'side',
      name : 'Side',
      get  : text => {
        if (text.match(/^b$|^buy$/i)) {
          return 'buy';
        }

        if (text.match(/^s$|^sell$/i)) {
          return 'sell';
        }

        return '';
      }
    }, {
      id   : 'size',
      name : resources.IDS_SIZE,
      get  : text => Math.abs(Number(text))
    }, {
      id   : 'limit',
      name : `${resources.IDS_LIMIT} A`,
      get  : getNumeric
    }, {
      id   : 'limitB',
      name : `${resources.IDS_LIMIT} B`,
      get  : getNumeric
    }]
  };

  // Returns 'business' for given page Id
  context.getBusiness = function (pageId) {
    return pageBusiness[pageId];
  };

  // Returns portfolio columns for a given page Id
  context.getPortfolioColumns = function (businessId) {
    return Reflect.has(columns, businessId) ? columns[businessId] : [];
  };

  // Returns portfolio lookup type (e.g. CUSIP, ISIN etc.) for a given business
  context.getPortfolioLookupType = function (businessId) {
    return businessPortfolioType[businessId];
  };
}(window.BGC.dataStore, window.BGC.resources));
