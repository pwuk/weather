import {html} from '@polymer/polymer/polymer-element';

export default html`
    <style>
        :host {
            display: block;
        }
        .side {
            font-weight: bold;
        }
        
        .table-row {
            color: var(--content-text);
            display: flex;
            align-items: center;
            /*border-right: 1px solid;*/
            font-size: 1rem;
            line-height: 1rem;;
            height: 1.6rem;
            min-width: 6rem;
            justify-content: center;
            /*border-right : 1px solid;*/
            /*border-color : inherit;*/
            padding : 0 0.1rem;
        }
        .table-row_cell {
            color: var(--content-text);
            padding : 0 0.5rem;
            line-height: 1.6rem;
            width: 6rem;
            border-color : var(--content-border) !important;
            border-right: 1px solid;
            border-bottom: 1px solid;
            height: 1.6rem;
            display: flex;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis ;
            align-items: center;
        }
        .name, .status {
            flex: 1;
        }
        .status {
            display: flex;
            justify-content: space-between;
        }
        .executed, .side {
            font-weight: bold;
        }
        :host(.buy) .status,
        :host(.buy) .side {
            color: var(--buy-status-executed);
        }
        :host(.sell) .status,
        :host(.sell) .side {
            color: var(--sell-status-executed);
        }
        .delete-action {
            color: var(--content-text);
        }
    </style>
    <div class="table-row">
        <div class="table-row_cell name">[[row.description]]</div>
        <template is="dom-repeat" items="[[row.props]]">
            <div class$="table-row_cell [[item.name]]">[[item.value]]</div>
        </template>
        <div class="table-row_cell status">
            [[row.status]]
            <fa-icon icon-class="fa-trash-o"  style="color: var(--content-text)" on-click="onClickRemoveRow"></fa-icon>
        </div>
    </div>
`;
