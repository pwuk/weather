/* eslint-disable func-names, max-lines, no-param-reassign, class-methods-use-this, complexity, max-statements */

import {PolymerElement} from '@polymer/polymer/polymer-element';
import componentTemplate from './row.template';

// window.BGC.ui, window.BGC.dataStore
const {
  ui: context, dataStore
} = window.BGC;

class PortfolioRow extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  ready () {
    super.ready();
    const {model} = this.row;
    const {side} = model.attributes;

    if (side) {
      this.classList.add(side);
    }

    model.on('change', this._updateRow, this);

    this._updateRow(model);
  }

  onClickRemoveRow () {
    const {model} = this.row;

    model.remove();
  }

  _updateRow (model) {
    const {attributes} = model;
    const {totalFill} = attributes;

    this.set('row.description', model.getDescription());
    this.set('row.status', this._buildStatusMsg(model));

    // Styling
    this.classList.toggle('executed', Boolean(totalFill));
  }

  _buildStatusMsg (model) {
    const {state, totalFill, status} = model.attributes;
    const {
      UNKNOWN, INVALID, LOADED, PENDING, HELD, REJECTED, SUBMITTED, ACTIVE, MATCHED, CANCELLED
    } = dataStore.PortfolioStates;

    let msg = 'Invalid State';

    if (state === UNKNOWN) {
      msg = 'Unknown Instrument';
    } else if (state === MATCHED) {
      msg = 'Multiple matches found';
    } else if (state === INVALID) {
      msg = status;
    } else if (totalFill) {
      msg = this._buildOrderStatus(model);
    } else if (state === LOADED) {
      msg = 'Loaded';
    } else if (state === PENDING) {
      msg = 'Waiting for Match';
    } else if (state === HELD) {
      msg = 'Match Price outside Limit';
    } else if (state === REJECTED) {
      msg = status;
    } else if (state === SUBMITTED) {
      msg = 'Submitting Order ...';
    } else if (state === ACTIVE) {
      msg = this._buildOrderStatus(model);
    } else if (state === CANCELLED) {
      msg = 'Cancelled: Lock Price Changed';
    }

    return msg;
  }

  _buildOrderStatus (model) {
    const {totalFill, totalSize, side} = model.attributes;
    const sideIndicator = side === 'buy' ? 'Bought' : 'Sold';

    if (totalSize > totalFill) {
      return `${totalFill} of ${totalSize} ${sideIndicator}`;
    }

    return `${totalFill} ${sideIndicator}`;
  }
}


customElements.define('portfolio-row', PortfolioRow);
context.view.PortfolioRow = PortfolioRow;
