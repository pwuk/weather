/* eslint-disable func-names, max-lines, no-param-reassign, class-methods-use-this, complexity, max-statements, no-magic-numbers */
/* globals _ */

import {PolymerElement} from '@polymer/polymer/polymer-element';
import componentTemplate from './view.template';


const {ui: context, resources, logger} = window.BGC;

class PortfolioView extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  constructor (options) {
    super(options);

    const {portfolio, settingsStore} = options;

    // Bind static resources
    _.extend(this, _.pick(resources,
      'IDS_GOOD_TILL',
      'IDS_SUBMIT_FAVORITES',
      'IDS_CLEAR',
      'IDS_MSG_PORTFOLIO_SELECT_TARGET',
      'IDS_MSG_PORTFOLIO_PASTE_TARGET'));

    // Bind the portfolio
    this.portfolio = portfolio;
    this.settingsStore = settingsStore;

    // Expiry timers - ordered by end hour
    this.timer = {
      currentPeriod : 0,
      periods       : [{
        endHour : 7,
        label   : '7:00 am',
        icon    : 'fa-moon-o',
        running : false
      }, {
        endHour : 17,
        label   : '5:00 pm',
        icon    : 'fa-sun-o',
        running : false
      }]
    };

    const nowHours = new Date().getHours();
    const {periods} = this.timer;
    const nextPeriod = periods.findIndex(period => period.endHour > nowHours);

    // Get the current local time and enable the next expiry period
    if (nextPeriod !== -1) {
      this.set('timer.currentPeriod', nextPeriod);
    }

    // Start the expiry timer
    setInterval((() => {
      let nextDay = false;

      return () => {
        const {timer} = this;
        const {currentPeriod} = timer;
        const period = timer.periods[currentPeriod];
        const nowHour = new Date().getHours();

        if (nextDay && nowHour === 0) {
          timer.nextDay = false;
        }

        const endHour = timer.nextDay ? period.endHour + 24 : period.endHour;

        if (nowHour === endHour) {
          // If the timer is running, clear the portfolio and reset 'Single-shot' submission
          if (period.running) {
            this.set(`timer.periods.${currentPeriod}.running`, false);

            this.portfolio.clear();

            this.portfolio.isSingleShot = true;

            logger.logInformation(
              'PortfolioView::setInterval',
              `${period.label} GT timer has been triggered - clearing portfolio and reverting state to single-shot submission`,
              true
            );
          }

          // Get the next period
          const nextPeriodTime = currentPeriod < timer.periods.length - 1 ? currentPeriod + 1 : 0;
          const {endHour : nextHour} = nextPeriodTime;

          nextDay = nextHour < nowHour;

          // Activate next period
          this.set('timer.currentPeriod', nextPeriodTime);
        }
      };
    })(), 500);
  }

  onTapGTOvernight () {
    // Ensure only one timer is running
    this.set('timer.periods.1.running', false);

    this.portfolio.isSingleShot = !this.timer.periods[0].running;
  }

  onTapGTEndOfDay () {
    // Ensure only one timer is running
    this.set('timer.periods.0.running', false);

    this.portfolio.isSingleShot = !this.timer.periods[1].running;
  }

  computeIsTimerInactive (currentPeriod, periodIndex) {
    return periodIndex !== 0 && currentPeriod !== periodIndex;
  }

  onTapSubmitButton () {
    const {portfolio} = this;

    portfolio.submitAll(true);
  }

  onTapClearButton () {
    const {portfolio} = this;

    portfolio.clear();
  }
}


customElements.define('portfolio-view', PortfolioView);
context.view.PortfolioView = PortfolioView;
