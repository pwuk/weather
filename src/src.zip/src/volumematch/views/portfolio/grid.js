/* eslint-disable func-names, max-lines, no-param-reassign, class-methods-use-this, complexity */

import {PolymerElement} from '@polymer/polymer/polymer-element';
import componentTemplate from './grid.template';

const {
  ui: context, resources, dataStore
} = window.BGC;
const SCROLL_MARGIN = 1.5;
const HEADER_HEIGHT = 22;
const ROW_HEIGHT = 17.6;
const MAX_FIXED_COUNT = 30;

class PortfolioGrid extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  connectedCallback () {
    super.connectedCallback();
    const {portfolio, userSettingsStore : settings} = dataStore;
    const {models = [], columns = []} = portfolio;

    // Add mandatory (Description and Status) and optional Columns
    this.columns = [{
      id   : 'name',
      name : resources.IDS_DESCRIPTION
    }].concat(columns.filter(col => !col.calculated)).concat([{
      id      : 'status',
      name    : resources.IDS_STATUS,
      colSpan : 2
    }]);

    // Add rows
    this._resetRows(models);

    // Bind collection change handlers
    portfolio.on('reset', this._resetRows, this);
    portfolio.on('add', this._addRow, this);
    portfolio.on('remove', this._removeRow, this);

    // Listen for changes to the view bounds
    settings.on('change:isOrdersViewFixedHeight', this._updateViewBounds, this);
    settings.on('change:fixedHeightOrdersViewRowCount', this._updateViewBounds, this);
  }

  _resetRows (models) {
    this.rows = [];

    models.forEach(model => this._addRow(model));

    this._updateViewBounds();
  }

  _addRow (model) {
    this.push('rows', {
      model,
      props : model.attributes.fields
    });

    this._updateViewBounds();
  }

  _removeRow (model) {
    this.splice('rows', this.rows.findIndex(row => row.model === model), 1);

    this._updateViewBounds();
  }

  _updateViewBounds () {
    const {userSettingsStore : settings} = dataStore;
    const {length : rowCount} = this.rows;

    const scrollableContent = this.shadowRoot.querySelector('.scrollable-content');
    const isFixedHeight = settings.get('isOrdersViewFixedHeight') === 1;
    const fixedRowCount = isFixedHeight ? settings.get('fixedHeightOrdersViewRowCount') : MAX_FIXED_COUNT;
    const fixedHeight = (ROW_HEIGHT * fixedRowCount) + HEADER_HEIGHT;

    // Set a fixed maximum grid height
    this.style.maxHeight = `${fixedHeight}px`;

    // If we are scrolling allow for a scroll margin
    scrollableContent.style.marginRight = rowCount > fixedRowCount ? '0' : `${SCROLL_MARGIN}rem`;

    if (isFixedHeight) {
      // Set a fixed minimum height on the scrollable content
      scrollableContent.style.minHeight = `${fixedHeight}px`;
      scrollableContent.style.maxHeight = `${fixedHeight}px`;
    } else {
      scrollableContent.style.removeProperty('min-height');
      scrollableContent.style.removeProperty('max-height');
    }

    this.dispatchEvent(new CustomEvent('recalcLayout', {
      bubbles  : true,
      composed : true
    }));
  }
}

customElements.define('portfolio-grid', PortfolioGrid);

context.view.PortfolioGrid = PortfolioGrid;
