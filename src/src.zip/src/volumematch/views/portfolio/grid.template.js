import {html} from '@polymer/polymer/polymer-element';

export default html`
    <style>
        :host {
            display: block;
            flex: 1;
            overflow-y: auto;
        }

        .portfolio-bar {
            background-color: var(--content-header-background);
        }
        .portfolio-bar button,
        .portfolio-bar input-toggle {
            background-color: var(--submit-button-background);
            color: var(--submit-button-text);
            margin-top: 0.5rem;
        }
        .portfolio-bar button:hover:not(:disabled),
        .portfolio-bar input-toggle:hover:not(:disabled) {
            border-color: var(--submit-button-background-lighter30);
        }
        .portfolio-bar .publish {
            background-color: var(--submit-button-background);
            color: var(--submit-button-text);
        }
        :host {
            background-color: var(--content-background);
        }
        .scrollable-content {
            background-color: background-color: var(--favorites-even-row-inactive-background);
        }
        .table-header {
            position: sticky;
            top: 0;
            box-shadow: 0 1px 0 0 var(--content-header-border), 0 -1px 0 0 var(--content-header-border);
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
                
        .table-header_cell {
            color: var(--content-header-text);
            background-color: var(--content-header-background);
            border-color: var(--content-header-border) !important;
            border-right: 1px solid;
            min-width: 6rem;
            display: flex;
            align-items: center;
            text-overflow: ellipsis ;
            white-space: nowrap;
            overflow: hidden;
            padding : 0.2rem 0.5rem;
        }
        .table-header_row {
            display: flex;
            align-items: center;
            line-height: 1.6rem;
        }
        .table-body {
            border-color: var(--content-border) !important;
        }
        
        portfolio-row:nth-child(odd) {
            background-color: var(--favorites-odd-row-inactive-background);
        }
        portfolio-row:nth-child(even) {
            background-color: var(--favorites-even-row-inactive-background);
        }
        .executed {
            font-weight: bold;
        }
        .buy .status,
        .buy .side {
            color: var(--buy-status-executed);
        }
        .sell .status,
        .sell .side {
            color: var(--sell-status-executed);
        }
        
        .name, .status {
            flex: 1;
        }
        .delete-icon {
            width: 2rem;
        }
    </style>
    <div class="scrollable-content">
        <div class="table">
            <div class="table-header">
                <div class="table-header_row">
                    <template is="dom-repeat" items="[[columns]]">
                        <div class$="table-header_cell [[item.id]]" colspan$="[[item.colSpan]]">[[item.name]]</div>
                    </template>
                </div>
            </div>    
            <div class="table-body">
                <template is="dom-repeat" items="[[rows]]">
                    <portfolio-row row=[[item]]></portfolio-row>
                </template>
            </div>
        </div>
    </div>
    
`;
