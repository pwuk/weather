import {html} from '@polymer/polymer/polymer-element';


export default html`
    <style>
    :host {
        display: inline-table;
        flex-shrink: 0;
        white-space: nowrap;
        position: relative;
        height: 2.4rem;
        line-height: calc(2.4rem - 4px);
        font-size: 1.1rem;
        background-color: var(--command-background);
        border-top: solid 2px var(--command-border);
        border-bottom: solid 2px var(--command-border);
        margin-right: 1.5rem;
        margin-bottom: 2px;
    }
    
    .accounts-bar {
        padding-left: 3px;
        display: flex;
        flex-wrap: wrap;
        gap: 0 3px;
    }
    
    </style>
    <div id="accountsContainer" class="accounts-bar"></div>
`;
