/* eslint-disable func-names */
/* global BGC: false, $: false, _:false */

import {PolymerElement} from '@polymer/polymer/polymer-element';
import componentTemplate from './accounts-bar.template';

const {view: context} = window.BGC.ui;

class AccountsBar extends PolymerElement {
  constructor (options) {
    super();
    this.dataStore = options.dataStore;
    this.dataStore.addAccountsObserver(this, this.onAccountAdded, this.onFavoritesChanged);

    // this.initialRender(); moved this as the template isn't ready
  }

  static get template () {
    return componentTemplate;
  }

  ready () {
    super.ready();
    this.initialRender();
  }

  initialRender () {
    const accounts = this.dataStore.getFavouriteAccountsOrdered();
    const $accountsContainer = $(this.$.accountsContainer);
    const isLayoutRecalculationRequired = accounts.length && !this.shadowRoot.querySelector('account-button');

    accounts.forEach(function (account) {
      $accountsContainer.append(this.createAccountButton(account));
    }, this);

    if (isLayoutRecalculationRequired) {
      this.dispatchEvent(new CustomEvent('recalcLayout', {bubbles : true}));
    }

    // This may be a full refresh, so there may have already been a selection
    const $buttons = $accountsContainer.find('account-button');

    _.each($buttons, button => {
      button.onAccountSelectionChanged();
    });
  }

  onFavoritesChanged () {
    this.stopListening(null, 'remove');
    const $accountsContainer = $(this.$.accountsContainer);

    $accountsContainer.html('');
    this.initialRender();
  }

  createAccountButton (accountModel) {
    const button = new BGC.ui.view.AccountButton({model : accountModel, container : this});

    this.listenTo(accountModel, 'remove', this.onAccountRemoved);

    return $(button);
  }

  onAccountAdded (accountModel) {
    const displayIndex = accountModel.get('displayIndex');
    const $accountsContainer = $(this.$.accountsContainer);

    // Unlikely that we will ever have an account added individually that is already in the favourites
    // (i.e. has a display ordering value != -1) but just in case, handle it here
    if (displayIndex === -1) {
      return;
    }

    const $buttons = $accountsContainer.find('account-button');

    if ($buttons.length <= displayIndex) {
      $accountsContainer.append(this.createAccountButton(accountModel));
    } else {
      $($buttons[displayIndex]).insertBefore(this.createAccountButton(accountModel));
    }
  }

  onAccountRemoved (accountModel) {
    this.stopListening(accountModel);
    $(this.$.accountsContainer).remove(`[invariant-account-id='${accountModel.get('invariantId')}']`);
  }
}
customElements.define('accounts-bar', AccountsBar);
context.AccountsBar = AccountsBar;
