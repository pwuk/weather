import {html} from '@polymer/polymer/polymer-element';

export default html`
    <style>
        * {box-sizing: border-box;}
        
    button.account-button {
        border-radius: 0;
        background-color: var(--obo-button-background);
        color: var(--app-button-text);
        border: 1px solid var(--obo-button-border);
    }
    button.account-button.broker {
        background-color: #2d5e99;
        border-color: #4d82ce;
    }
    button.account-button.active-trader-logged-in {
        background-color: #a41123;
        border-color: #d40018;
    }
    button.account-button.sales-trader-account-active {
        background-color: var(--obo-button-background);
        filter: brightness(85%);
    }
    button.account-button:focus {
        outline: none;
    }
    button.account-button.selected {
        border-color: yellow;
        color: yellow;
    }
    button.account-button:hover {
        color: var(--tab-text-inactive-hover-highlight);
    }
    button.account-button.sales-trader-account-inactive,
    button.account-button .active-trader-logged-out {
        background-color: var(--app-button-background-disabled);
        color: var(--app-button-text-disabled);
        filter: brightness(var(--app-button-text-disabled));
        border: 1px solid var(--app-button-background-disabled);
        pointer-events: none;
    }
    </style>
    <button title="{{title}}" hidden="{{!isDisplayed}}" class$="account-button {{styling}}">{{displayText}}</button>
`;
