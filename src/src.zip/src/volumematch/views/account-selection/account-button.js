/* eslint-disable max-statements, complexity */
/* global BGC: false, $: false, _:false, Backbone: false */

import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './account-button.template';

const {view: context} = window.BGC.ui;

class AccountButton extends PolymerElement {
  constructor (options) {
    super();
    this.model = options.model;
    this.container = options.container;

    // This sets the attribute value on the host element, allowing it to be addressed in a selector using its ID
    this.invariantAccountId = this.model.get('invariantId');
    this.isEnabled = options.model.get('enabled');
    this.isDisplayed = true;
    this.isSelected = false;
    this.displayText = options.model.get('shortName') || options.model.get('fullName');
    this.title = options.model.get('fullName');
    this.setAttribute('account-name', this.displayText);

    const accountType = this.model.EAccountType[this.model.get('accountType')];

    switch (accountType) {
      case this.model.EAccountType.eBroker:
        this.styling = 'broker';
        break;
      case this.model.EAccountType.eActiveTrader:
        this.styling = this.isEnabled ? 'active-trader-logged-in' : 'active-trader-logged-out';
        break;
      case this.model.EAccountType.ePassiveTrader:
        this.styling = 'passive-trader';
        break;
      case this.model.EAccountType.eSalesTraderAccount:
        this.styling = this.isEnabled ? 'sales-trader-account-active' : '';
        break;
      default:
        this.styling = '';
    }

    // Listen for updates
    _.extend(this, Backbone.Events);
    this.listenTo(this.model, 'change', this.onAccountUpdated);
    this.listenTo(this.model, 'remove', this.onAccountRemoved);
    this.listenTo(BGC.dataStore, 'accountSelectionChanged', this.onAccountSelectionChanged);
    this.addEventListener('click', this.onButtonClick.bind(this));
  }

  static get template () {
    return componentTemplate;
  }

  static get properties () {
    return {
      invariantAccountId : {
        type               : String,
        notify             : false,
        reflectToAttribute : true,
        value () {
          return '';
        }
      }
    };
  }

  onButtonClick () {
    if (!this.isSelected) {
      BGC.dataStore.setActiveAccountById(this.model.get('invariantId'));
    }
  }

  onAccountUpdated () {
    this.isEnabled = this.model.get('enabled');
    this.displayText = this.model.get('shortName') || this.model.get('fullName');
    this.setAttribute('account-name', this.displayText);

    // Broker accounts and their managed passive accounts will never change enabled state.
    // Managed active trader accounts and Sales Trader style accounts may.
    const EAccountTypes = this.model.EAccountType;

    if (EAccountTypes[this.model.get('accountType')] === EAccountTypes.eActiveTrader) {
      this.styling = this.isEnabled ? 'active-trader-logged-in' : 'active-trader-logged-out';
      if (this.isSelected) {
        this.styling += ' selected';
      }
    } else if (EAccountTypes[this.model.get('accountType')] === EAccountTypes.ePassiveTrader) {
      // Passive trader would use the same stlyling as sales trader because in
      // CreditMatch sales trader is same as passive trader
      this.styling = this.isEnabled ? 'sales-trader-account-active' : '';
      if (this.isSelected) {
        this.styling += ' selected';
      }
    } else if (EAccountTypes[this.model.get('accountType')] === EAccountTypes.eSalesTraderAccount) {
      this.styling = this.isEnabled ? 'sales-trader-account-active' : '';
      if (this.isSelected) {
        this.styling += ' selected';
      }
    }
  }

  onAccountRemoved () {
    this.isDisplayed = false;
    if (BGC.dataStore.getActiveAccountId() === this.model.get('id')) {
      BGC.dataStore.setActiveAccountById('');
    }

    this.stopListening(this.model);
    this.stopListening(BGC.dataStore);
  }

  onAccountSelectionChanged () {
    if (BGC.dataStore.getActiveAccountId() === this.model.get('id')) {
      this.isSelected = true;
      $(this.shadowRoot).find('button').addClass('selected');

      if (context.mainView) {
        context.tabControlView.updateControlsVisibility();
        context.mainView.ShowHideTabControlForActiveAccountType();
      }
    } else {
      this.isSelected = false;
      $(this.shadowRoot).find('button').removeClass('selected');
    }
  }
}
customElements.define('account-button', AccountButton);
context.AccountButton = AccountButton;
