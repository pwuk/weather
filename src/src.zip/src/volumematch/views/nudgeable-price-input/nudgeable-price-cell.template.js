import {html} from '@polymer/polymer/polymer-element';
import {} from '@polymer/polymer/lib/elements/dom-repeat';

export default html`
<style>
    :host div.price-nudge-container {
        float: left;
        width: 6rem;
        height: 100%;
        color: inherit;
        border: none;
        vertical-align: top;
        padding: 0 0 0 0.4rem;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        padding: 0;
        position: relative;
    }
    :host div input {
        width: 100%;
        height: 100%;
        border: none;
    }
    :host div input.buy {
        padding-left: 0.4rem;
    }
    :host div input.sell {
        padding-right: 0.4rem;
        text-align: right;
    }

    :host div img {
        position: absolute;
        top: 50%;
        margin-top: -0.55rem;
        width: 1.1rem;
    }
    :host .price-nudge-container {
        position: absolute;
    }
    :host .price-nudge-up,
    :host .price-nudge-dn {
        position: absolute;
        visibility: hidden;
        top: 50%;
        color: #3f91be; /* blueish icon colour */
        background-color: white; /* Gives white on blue effect instead of transparency */
        line-height: 0.9rem; /* limits the white from bleeding around the icon */
        font-size: 1.5rem;
        border: none;
    }
    :host .price-nudge-dn {
        left: 1px;
        padding: 0;
        transform: translateY(-50%);
    }
    :host .price-nudge-up {
        padding: 0;
        right: 2px;
        transform: translateY(-50%);
    }
    :host .live .price-nudge-dn,
    :host .active .price-nudge-dn,
    :host .live .price-nudge-up,
    :host .active .price-nudge-up {
        visibility: visible;
    }
    :host .live .price-nudge-dn.hide,
    :host .active .price-nudge-dn.hide,
    :host .live .price-nudge-up.hide,
    :host .active .price-nudge-up.hide {
        visibility: hidden;
    }
    :host .live .price-nudge-dn,
    :host .live .price-nudge-up {
        opacity: 1;
        color: #919293; /* disabled grey color */
        background-color: #d3d4d4;
    }

    :host .live.instant-live-nudge .price-nudge-dn,
    :host .live.instant-live-nudge .price-nudge-up {
        opacity: 1;
        color: #3f91be;
        background-color: white; /* Gives white on blue effect instead of transparency on blue */
    }

    :host .active .price-nudge-dn,
    :host .active .price-nudge-up {
        opacity: 1;
        color: #3f91be;
    }

    :host .active .price-nudge-dn.flash,
    :host .live .price-nudge-dn.flash,
    :host .active .price-nudge-up.flash,
    :host .live .price-nudge-up.flash {
        opacity: 1;
        visibility: visible;
        color: #ffff00;
        background-color: black; /* changes the minus or plus so it shows up on yellow flash */
    }

    :host input {
        height: inherit;
        outline: none;
        text-align: center;
        position: absolute;
        width: 100%;
        padding: 2px 0;
    }
    :host input:focus {
        outline: -webkit-focus-ring-color auto 5px;
    }
    :host input {
        font-weight: normal;
    }
    :host .live input {
        font-weight: bold;
    }
    :host .live.active input {
        font-weight: normal;
    }
    :host .error input {
        box-shadow: inset 0 0 5px #FF0000;
    }

</style>



<div on-click="onClick" class="price-nudge-container" on-blur="onBlur" draggable="false">
    <input placeholder="{{placeholder}}" type="text" class="nudge" side="{{side}}"
           on-keydown="onKeyDown" on-keyup="onKeyUp" on-focus="onFocus" draggable="false">
    <i class="fa fa-minus-square price-nudge-dn" on-mouseover="onNudgeIconMouseOver" on-mouseout="onNudgeIconMouseOut" draggable="false"></i>
    <i class="fa fa-plus-square price-nudge-up" on-mouseover="onNudgeIconMouseOver" on-mouseout="onNudgeIconMouseOut" draggable="false"></i>
</div>
`;
