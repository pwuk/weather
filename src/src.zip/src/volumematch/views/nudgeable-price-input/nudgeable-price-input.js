// IDEA - flash top or bottom red line on input or something to indicate max or min reached????
// FUTURE - Link to formatter method for formatting the price display - so can add 32nd's 128th's support, etc
// TEST - enter size in input, no price and hit return
// TEST - click size button, no price
// TEST - nudge footprint, click size button
// TEST - nudge footpring, click and enter val in size input, press return
// TEST - nudge live price
// TEST - live price, don't nudge it, click size button
// TEST - live price, don't nudge it, enter diff size, press return
// TEST - live price of 2, click and enter 2.001 (or other valid num) and then click in size input - price looked live and if click size button then cancel it still shows the new price
// TEST - live price of 2, click and enter 2.001 and then click in size inputyou enter size and hit return
// TEST - make sure orders show up in both post and pre-trade vm's
// TEST - make sure second look check happens (if turned on) for both price entry and nudge
// TEST - no use price, enter a number, then hit esc. Also enter or nudge a price then hit esc in size field...
// TEST - no user price, enter a number then click outside box - should stay if valid number
// TEST - no user price, enter a number then click in size - should submit if valid number
// TEST - enter bad price and click size button - should warn and not submit
// TEST - enter bad price and click outside input - should reset
// TEST - tab back and forth
// TEST - tab with one side disabled?
// TEST - modify input then tab out
// TEST - nudge non-live price then tab to size and submit?
// TEST - nudge live price then tab to size and submit

/*
    13th Mar '03
    This component has been converted but not refactored.
    (it's import has been removed from volume-match.js)

    Conversion process:
    Convert from P1 functional methods declaration to P3 class declaration.
    Look for jQuery usage $(this) - replace with $(this.shadowRoot)
    P3 template is extracted from the (less compiled) css
 */


import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './nudgeable-price-cell.template';

const context = window.BGC;
const INVALID_NUMBER = 9007199254740991;
let theTooltip = BGC.ui.tooltipSingleton.getInstance();

class NudgeablePriceInput extends PolymerElement {
  static get template () {
    return componentTemplate;
  }

  connectedCallback () {
    super.connectedCallback();
  }

  static get properties () {
    return {
      documentClickBlurEventAttached : {
        type  : Boolean, // blur on document click event attached already
        value : false
      },
      side : {
        type   : String, // buy|sell
        notify : true
      },
      placeholder : {
        type : String // text that is shown in input when it's blank
      },
      min : {
        type  : Number,
        value : -INVALID_NUMBER
      },
      max : {
        type  : Number,
        value : INVALID_NUMBER
      },
      localPriceNumeric : {
        type : Number // numeric value of typed value
      },
      localPriceString : {
        type  : String, // typed value
        value : ''
      },
      pickGiveSymbol : {
        type  : String, // +/- indicator for PickUp/GiveUp
        value : ''
      },
      serverPriceFormatted : { // formatted numeric value of server price
        type  : String,
        value : ''
      },
      serverPriceNumeric : { // numeric price from server
        type : Number
      },
      isEditMode : { // user has clicked once to make it actionable...
        type  : Boolean,
        value : false
      },
      isLiveOrder : { // user has live order?
        type  : Boolean,
        value : false
      },
      isModified : { // user has changed it with keyboard
        type  : Boolean,
        value : false
      },
      instrument : {
        type : Object
      },
      increment : {
        type  : Number,
        value : 0.05
      },
      defaultNomenclature : {
        type  : String,
        value : 'bidOffer'
      }
    };
  }

  attached () {
    theTooltip = BGC.ui.tooltipSingleton.getInstance();
    if (this.side == 'buy') {
      this.placeholder = context.resources.getAdjustedNomenclature('IDS_OEB_BUY_PLACEHOLDER', this.defaultNomenclature);
    } else {
      this.placeholder = context.resources.getAdjustedNomenclature('IDS_OEB_SELL_PLACEHOLDER', this.defaultNomenclature);
    }
  }

  /** get value from input control */
  getValue () {
    return this.getPriceStringFromInputControl();
  }


  /**
     * set instrument used for the input validation, formatting, etc
     * @param instrument
     * @param disable - disabled - if broker, or no range supplied, etc, display should show but be disabled
     */
  setInstrument (instrument, disable, showLiveNudge) {
    const priceNudgeContainer = this.$$('.price-nudge-container');
    let temp;

    this.classList.toggle('user-input-disabled', disable);
    this.instrument = instrument;
    this.$$('input').disabled = disable; // disable and style input
    if (instrument) {
      /** set value, min/max and increment? */
      const side = this.side === 'buy' ? 'Bid' : 'Offer';

      this.min = Number(this.instrument[`min${side}Price`]);
      this.max = Number(this.instrument[`max${side}Price`]);
      this.increment = Number(this.instrument.priceIncrement);

      // if user has an order and size is UNfilled - use it and make input active right away. Otherwise use the mid
      const hasOwnOrder = instrument.ownOrder !== undefined;
      const activeOrder = instrument.ownOrder;

      this.activeOrder = activeOrder ? activeOrder[`${this.side}Order`] : undefined;
      this.isModified = false;
      this.isEditMode = false;
      this.isLiveOrder = false;
      priceNudgeContainer.classList.remove('instant-live-nudge');
      if (this.activeOrder && this.activeOrder[`${this.side}Size`]) {
        this.localPriceString = this.activeOrder.priceDisplay;
        this.localPriceNumeric = this.activeOrder.price;
        this.isLiveOrder = this.side === 'buy' ? this.activeOrder.isLiveBuy : this.activeOrder.isLiveSell;
        if (this.isLiveOrder && showLiveNudge) {
          priceNudgeContainer.classList.add('instant-live-nudge');
          this.isEditMode = true;
        }
      } else {
        this.isLiveOrder = false;
        this.localPriceString = this.instrument.priceDisplay;
        this.localPriceNumeric = this.instrument.midPrice;
      }

      // Allow for pick/give spreads, and the way that +ive/-ive prices are used to indicate pick/give
      const pickGivePrefix = this.instrument.pickGiveSymbol[this.side];

      if (pickGivePrefix === '+') {
        this.placeholder = context.resources.IDS_OEB_PICKUP_PLACEHOLDER;

        // Ensure price is positive
        this.localPriceNumeric = Math.abs(this.localPriceNumeric);
      } else if (pickGivePrefix === '-') {
        this.placeholder = context.resources.IDS_OEB_GIVEUP_PLACEHOLDER;

        // Ensure price is negative
        this.localPriceNumeric = -Math.abs(this.localPriceNumeric);
      } else if (this.side == 'buy') {
        this.placeholder = context.resources.getAdjustedNomenclature('IDS_OEB_BUY_PLACEHOLDER', this.defaultNomenclature);
      } else {
        this.placeholder = context.resources.getAdjustedNomenclature('IDS_OEB_SELL_PLACEHOLDER', this.defaultNomenclature);
      }

      // ahead or at/behind mid?
      let isAhead = false;

      if (this.side === 'buy') {
        if (this.instrument.isHigherBidBetter) {
          isAhead = BGC.utils.compareFPNumGT(this.localPriceNumeric, this.instrument.midPrice);
        } else {
          isAhead = BGC.utils.compareFPNumLT(this.localPriceNumeric, this.instrument.midPrice);
        }
      } else if (this.instrument.isLowerOfferBetter) {
        isAhead = BGC.utils.compareFPNumLT(this.localPriceNumeric, this.instrument.midPrice);
      } else {
        isAhead = BGC.utils.compareFPNumGT(this.localPriceNumeric, this.instrument.midPrice);
      }
      this.$$('.price-nudge-container').classList.toggle('ahead', isAhead);
    }
    if (!instrument || disable) {
      // No instrument or nudgeable prices disabled
      this.isLiveOrder = false;
      this.localPriceString = '';
      this.localPriceNumeric = NaN;
    }

    // If this isn't a live order, pick/give may have caused us to change the sign of the price
    // for this side, in which case we need to change the string representation as well
    if (!disable && this.instrument && this.instrument.isSignFlippedForPickGive[this.side]) {
      this.localPriceString = this.formatPrice(this.localPriceNumeric);
    }

    // store the sent price - used when an edit is reset
    this.serverPriceNumeric = this.localPriceNumeric;
    this.serverPriceFormatted = this.localPriceString;

    // show price
    this.setPriceStringToInputControl(this.localPriceString);

    // set icons and active/live/error display...
    this.applyStyles(this.isLiveOrder, true);

    // reset
    this.isModified = false;
  }

  /** Ensure that a price string has any appropriate pick/give formatting before setting the content of the input */
  setPriceStringToInputControl (priceString) {
    let formattedString = priceString;
    const firstChar = priceString.charAt(0);
    const validatedPrice = this.validationCallback ? this.validationCallback(priceString) : {valid : false};

    if (this.instrument && this.instrument.isPickGivePriced && priceString) {
      if (validatedPrice.valid && BGC.utils.compareFPNumEQ(validatedPrice.numericValue, 0)) {
        // Show +0 or -0 depending on whjether this side is pick or give by default
        if (firstChar === '-' || firstChar === '+') {
          formattedString = formattedString.slice(1);
        }
        formattedString = this.instrument.pickGiveSymbol[this.side] + formattedString;
      } else {
        // Add '+' (pick) sign prefix to a price string that doesn't start with '-'
        // This makes the display clearer as to what is pick and what is give
        // because sign is always explicit
        if (firstChar === '+') {
          formattedString = formattedString.slice(1);
        }
        if (firstChar !== '-') {
          formattedString = `+${formattedString}`;
        }
      }
    }
    this.$$('input').value = formattedString;
  }

  /** Get the content of the input control without any added pick/give formatting so we can validate it */
  getPriceStringFromInputControl () {
    let output = this.instrument ? this.$$('input').value : '';
    const firstChar = output && output.charAt(0);

    if (!this.instrument || !this.instrument.pickGiveSymbol[this.side]) {
      return output;
    }

    // Remove any '+' prefix that may have been added for 'pick up' display clarity
    if (firstChar === '+') {
      output = output.slice(1);
    }

    return output;
  }

  setCallbacks (validationCallback, nudgeCallback, priceFormatter) {
    this.setValidationCallback(validationCallback);
    this.setNudgeCallback(nudgeCallback);
    this.setPriceFormatterCallback(priceFormatter);
  }

  setValidationCallback (callback) {
    this.validationCallback = callback;
  }

  setNudgeCallback (callback) {
    this.nudgePriceCallback = callback;
  }

  setPriceFormatterCallback (callback) {
    this.formatPrice = callback;
  }

  /**
     * nudge value changed
     * @param val
     */
  valueChanged (val) {
    const validatedNum = this.validationCallback ? this.validationCallback(val) : {valid : false};

    if (!validatedNum.valid || !this.instrument) {
      this.localPriceNumeric = null;
      this.localPriceString = '';
      this.toggleNudgeIcons(false);

      return;
    }

    this.localPriceNumeric = validatedNum.numericValue;
    this.localPriceString = this.formatPrice(this.localPriceNumeric);

    this.setPriceStringToInputControl(this.localPriceString);
    this.applyStyles(true, validatedNum.valid);
    this.dispatchEvent(new CustomEvent('price:updated', {
      detail : {
        priceText : this.localPriceString,
        side      : this.side
      }
    }));
  }

  /**
     * Handles click event for element
     * @param event
     */
  onClick (event) {
    const _this = this;

    // If the QoS timer is running, generate the interaction metric now

    BGC.utils.generateInteractivityQoSMetric('oebActivated');
    theTooltip.hide();
    const el = event.target; // what was clicked?
    // allows click OUTSIDE of container to blur but on or inside to continue as normal....

    event.stopImmediatePropagation();
    if (!this.instrument) {
      this.onBlur();

      return;
    }
    if (BGC.utils.compareFPNumEQ(this.min, this.max)) {
      return; // mid is not moveable...
    }
    if (el.classList.contains('price-nudge-dn')) {
      if (this.isEditMode) {
        this.nudgeDown(event, false);
      } else {
        this.onNudgeIconMouseOver(event, true);
      }
    } else if (el.classList.contains('price-nudge-up')) {
      if (this.isEditMode) {
        this.nudgeUp(event, false);
      } else {
        this.onNudgeIconMouseOver(event, true);
      }
    } else if (el.tagName === 'INPUT') {
      if (!this.documentClickBlurEventAttached) {
        document.addEventListener('click', () => {
          _this.onBlur();
        }, false);
        this.documentClickBlurEventAttached = true;
      }
      this.focusAndSelect();
    }
    this.isEditMode = true;
    if (this.isLiveOrder) {
      this.$$('.price-nudge-container').classList.add('instant-live-nudge');
    }
  }

  /**
     * tooltip on icon mouseover when in edit mode- says 'Nudge to 1.9995'
     * @param event
     */
  onNudgeIconMouseOver (event, overrideEditModeCheck) {
    if (overrideEditModeCheck === void 0) {
      overrideEditModeCheck = false;
    }
    if (this.isEditMode || overrideEditModeCheck) {
      const elem = event.target;
      const isUpTick = elem.classList.contains('price-nudge-up');
      const targetRect = elem.getBoundingClientRect();
      const position = {
        x : targetRect.left + (targetRect.width / 2),
        y : (targetRect.top + (targetRect.height / 2)) + 12
      };
      const nudgeVal = this.formatPrice(isUpTick ? this.localPriceNumeric + this.increment : this.localPriceNumeric - this.increment);
      const tipFormatStr = this.isLiveOrder ? context.resources.IDS_OEB_NUDGE_LIVE : context.resources.IDS_OEB_NUDGE;
      const tipNudgeStr = isUpTick ? context.resources.IDS_OEB_NUDGE_UP : context.resources.IDS_OEB_NUDGE_DN;

      theTooltip.show(BGC.utils.format(tipFormatStr, [tipNudgeStr, nudgeVal]), position, this);
    }
  }

  /**
     * show a tooltip error if user tries to submit invalid input
     */
  showTooltipError () {
    const targetRect = this.$$('input').getBoundingClientRect();
    const targetRectHeight = targetRect.bottom - targetRect.top;
    const position = {x : targetRect.left + targetRect.width + 5, y : targetRect.top + targetRectHeight + 2}; // place below input

    theTooltip.show(context.resources.IDS_OEB_INVALID_ENTRY, position, this, null, theTooltip.ETooltipType.eValidationError); // error style
  }

  /**
     * hide tooltip
     * @param event
     */
  onNudgeIconMouseOut (event) {
    theTooltip.hide();
  }

  onFocus () {
    this.$$('.price-nudge-container').classList.add('active');
    const oppSide = this.side === 'buy' ? 'sell' : 'buy';
    const nudgeInput = $(`nudgeable-price-input[side='${oppSide}']`)[0]; // if you clicked on bid then offer nudge bid display didn't reset

    nudgeInput.resetValuesAfterBlur(false); // this param seems like it should be true but when you enter a bad value the focus is set back and if it's true the tooltip never shows
    this.toggleNudgeIcons(true);
  }

  /**
     * select all on focus
     */
  focusAndSelect () {
    if (!this.instrument) {
      return;
    }
    this.$$('.price-nudge-container').classList.add('active');
    this.$$('input').select();
    this.$$('input').focus();
  }

  /**
     *  clear values and blur - called from esc key
     *  @param hideTooltip - hide tooltip or not
     */
  resetValuesAfterBlur (hideTooltip) {
    this.isModified = false;
    this.isEditMode = false;
    this.onBlur();
    this.resetValues(hideTooltip);
  }

  /**
     *  reset values in input to either empty or server sent value
     *  @param hideTooltip - hide tooltip or not
     */
  resetValues (hideTooltip) {
    this.localPriceNumeric = this.serverPriceNumeric;
    this.localPriceString = this.serverPriceFormatted;
    this.setPriceStringToInputControl(this.localPriceString);
    this.applyStyles(true, true);
    if (this.isModified || hideTooltip) {
      theTooltip.hide();
    }
    this.dispatchEvent(new CustomEvent('price:updated', {
      detail : {
        priceText : this.localPriceString,
        side      : this.side
      }
    }));
  }

  /** blur the input and reset values and display */
  onBlur () {
    const validatedNum = this.validationCallback ? this.validationCallback(this.getPriceStringFromInputControl()) : {
      valid        : false,
      numericValue : NaN,
      stringValue  : this.getPriceStringFromInputControl()
    };

    // if it hasn't been modified and the user doesn't have a live order OR it's not a valid # then reset it...

    if ((!this.isModified && !this.isLiveOrder) || !validatedNum.valid) {
      // clear out
      this.resetValues(false);
    }

    // if valid or empty input remove error style
    if (validatedNum.valid || this.$$('input').value === '') {
      this.$$('.price-nudge-container').classList.remove('error');
    }

    // if not modified and not live order remove active styling
    if (!this.isModified) {
      this.$$('.price-nudge-container').classList.remove('active');
    }
    this.$$('input').blur();
  }

  /**
     * put red box around input if invalid
     * @param showIcons
     * @param isValid
     */
  applyStyles (showIcons, isValid) {
    const container = this.$$('.price-nudge-container');

    container.classList.toggle('error', !isValid);
    container.classList.toggle('live', this.isLiveOrder);
    this.toggleNudgeIcons(showIcons);
  }

  /**
     * Updates display of nudge up and down icons
     * @param show
     */
  toggleNudgeIcons (show) {
    const validatedNum = this.validationCallback ? this.validationCallback(this.getPriceStringFromInputControl()) : {valid : false};

    if (!validatedNum.valid) {
      show = false;
    }

    // When nudging up/down button is invisible in the price cell, hide the nudging information tooltip,
    // regardless of whether the ticking is a mouse event or a keyboard event.
    // Don't hide the tooltip if it is currently showing an error display rather than nudging info.
    if (theTooltip.getType() !== theTooltip.ETooltipType.eValidationError &&
          (!show || BGC.utils.compareFPNumEQ(this.max, validatedNum.numericValue) || BGC.utils.compareFPNumEQ(validatedNum.numericValue, this.min))) {
      theTooltip.hide();
    }
    this.toggleNudgeUpIconDisplay(show, validatedNum.numericValue);
    this.toggleNudgeDownIconDisplay(show, validatedNum.numericValue);
  }

  /**
     * Toggle up icon visibility
     * @param show
     * @param currentVal
     */
  toggleNudgeUpIconDisplay (show, currentVal) {
    this.$$('.price-nudge-up').classList.toggle('hide', !(show && BGC.utils.compareFPNumGT(this.max, currentVal)));
  }

  /**
     * Toggle down icon visibility
     * @param show
     * @param currentVal
     */
  toggleNudgeDownIconDisplay (show, currentVal) {
    this.$$('.price-nudge-dn').classList.toggle('hide', !(show && BGC.utils.compareFPNumGT(currentVal, this.min)));
  }

  /**
     * Nudge a value up
     */
  nudgeUp (event, isKeyboardEvent) {
    this.nudgeValue(event, true, isKeyboardEvent);
  }

  /**
     * Nudge a value down
     */
  nudgeDown (event, isKeyboardEvent) {
    this.nudgeValue(event, false, isKeyboardEvent);
  }

  /**
     * Nudge a value
     * @param event - comes from mouse or keyboard
     * @param nudgeUp true if up, false if nudge down
     */
  nudgeValue (event, nudgeUp, isKeyboardEvent) {
    event.stopImmediatePropagation();
    const sendToServer = this.isLiveOrder && !isKeyboardEvent; // send to b/end (live order update) or just nudge here?

    this.isModified = true;
    const validPrice = this.nudgePriceCallback(this.getPriceStringFromInputControl(), this.side, nudgeUp, sendToServer); // setting this to true causes possible error when nudging non-live price and hitting min/max. Pressing return to confirm popup warning submits price then. So only check if sending to b/end
    // send to b/end??

    if (validPrice.valid) {
      // flash nudge icon yellow & send to b/end
      if (sendToServer) {
        // submit an order at the instrument's smallest valid size,
        // unless there is an existing unfilled order,
        // in which case ENTER or nudge should submit at the current order size.
        const size = this.activeOrder && this.activeOrder[`${this.side}Size`] > 0 ? this.activeOrder[`${this.side}Size`] : this.instrument.quickSizes[this.side][0];

        this.fire('SubmitValidatedPriceAndSize', {
          size,
          side          : this.side,
          price         : validPrice.numericValue,
          flashSelector : `nudgeable-price-input[side=${this.side}] .price-nudge-${nudgeUp ? 'up' : 'dn'}`
        });
      } else { // just update input value so user can hit return if they want to submit....
        this.valueChanged(validPrice.stringValue);
        this.$$('input').focus();
        this.$$('input').select();
      }
    }

    // update tooltip info if user ticking with mouse on icon
    if (!isKeyboardEvent) {
      this.onNudgeIconMouseOver(event, true);
    } else if (theTooltip.getType() !== theTooltip.ETooltipType.eValidationError) {
      theTooltip.hide();
    }
  }

  /**
     * Key pressed - Validate display after change...
     */
  onKeyUp (event) {
    const str = this.getPriceStringFromInputControl();

    if (str.length === 0 || !str.trim()) {
      this.$$('input').value = ''; // display should be empty
      this.toggleNudgeIcons(false);
      if (this.serverPriceString !== '') {
        this.isModified = true;
      }
    } else {
      const validatedNum = this.validationCallback(str);

      if (validatedNum.valid) {
        this.localPriceNumeric = validatedNum.numericValue;
        this.localPriceString = str;
      }
      this.applyStyles(true, validatedNum.valid);
      this.isModified = !validatedNum.valid || !BGC.utils.compareFPNumEQ(this.serverPriceNumeric, validatedNum.numericValue);
    }
  }

  /**
     * Allow only certain keypresses - there is a pattern property on inputs plus can have number type but it
     * allows some odd things like e,E, etc and this just simplifies things since it's all in one place
     * @param event
     */
  onKeyDown (event) {
    let allowKey = false;
    let handleLocally = true;
    const that = this;

    // 0-9 keys

    if ((event.keyCode > 47 && event.keyCode < 58) ||
          (event.keyCode > 95 && event.keyCode < 106)) {
      allowKey = true;
    }
    switch (event.key || event.keyCode) {
      case 'Tab':
      case 9: // tab key
      case 'ArrowUp':
      case 38:
      case 'ArrowDown':
      case 40:
        allowKey = true;
        handleLocally = false;
        setTimeout(() => {
          that.onBlur();
        }, 0); // otherwise blur fires before tabbing can happen properly
        break;
      case '-':
      case 109:
      case 189:
        allowKey = true;
        break;
      case '+':
      case 107:
      case 187:
        if (event.keyCode === 187 && event.shiftKey) {
          allowKey = true; // + above =
        } else if (event.keyCode !== 187) {
          allowKey = true; // + Numpad key
        }
        break;
      case '.':
      case 110:
      case 190:
        allowKey = true;
        break; // decimal
      case 'ArrowRight':
      case 39:
        allowKey = true;
        break; // arrow right moves within the edit text
      case 'ArrowLeft':
      case 37:
        allowKey = true;
        break; // arrow left moves within the edit text
      case 'Backspace':
      case 8:
        allowKey = true;
        break; // backspace
      case 'Delete':
      case 46:
        allowKey = true;
        break; // delete key
      case 'Escape':
      case 27:
        this.resetValuesAfterBlur(true);
        break; // esc key - reset
      case 'Enter':
      case 13: // return key
        allowKey = true;
        if (this.validationCallback) {
          const str = this.getPriceStringFromInputControl();
          const validatedInput = this.validationCallback(str);

          if (validatedInput.valid) {
            this.fire('SubmitValidatedPrice', {
              side  : this.side,
              price : validatedInput.numericValue
            });
          } else {
            this.showTooltipError(); // invalid entry - show an error tooltip and put focus on it...
            this.focusAndSelect();
          }
        }
        break;
    }
    if (handleLocally) {
      event.stopPropagation();
    } else if (!allowKey) {
      event.preventDefault();
    }
  }
}

customElements.define('nudgeable-price-input', NudgeablePriceInput);
