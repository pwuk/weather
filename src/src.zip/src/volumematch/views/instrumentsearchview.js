/* eslint-disable func-names, no-plusplus */
/* global BGC: false,  $: false, _:false, Backbone: false */
(function (context) {
  const KeyCodes = {
    ENTER : 13
  };

  // eslint-disable-next-line no-param-reassign
  context.InstrumentSearchView = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#instrument-search-view'),
    events   : {
      'keydown input'      : 'onKeydownInput',
      autocompleteselect   : 'onMenuSelection',
      autocompleteresponse : 'onSearch',
      autocompleteopen     : 'onOpen'
    },

    initialize () {
      $.ui.autocomplete.filter = function (array, term) {
        const matcher = new RegExp(`^${$.ui.autocomplete.escapeRegex(term)}`, 'i');


        return $.grep(array, value => matcher.test(value.label || value.value || value));
      };
      $(window).bind('resize', _.bind(this.resizeMenu, this));

      this.searchedItem = null;

      this.buildInstrumentNames = this.buildInstrumentNames.bind(this, false);
      // eslint-disable-next-line no-magic-numbers
      this.coalescedBuildInstrumentNames = _.debounce(this.buildInstrumentNames, 100);

      this.model.get('cells').forEach(function (column) {
        column.forEach(function (instrumentModel) {
          instrumentModel.on('change:inactive', this.coalescedBuildInstrumentNames, this);
        }, this);
      }, this);

      // list of active instrument names.
      this.buildInstrumentNames(true);

      // don't set the template inside render as it will reset the edit control which could wipe user typed data.
      this.$el.html(this.template({resources : BGC.resources}));

      this.render();
    },

    requestRender () {
      BGC.ui.viewUtils.requestRender('InstrumentSearch', '', this, this.render);

      return this;
    },

    render () {
      // render the list of built names.
      const $searchEdit = this.$el.find('.instrument-search-edit');

      $searchEdit.autocomplete({appendTo : $searchEdit.parent(), source : this.instrumentNamesList, autoFocus : true});

      this.delegateEvents();

      return this;
    },

    buildInstrumentNames (isInitialise) {
      this.instrumentNamesList = [];
      const rowLength = this.model.get('cells')[0].length;

      for (let rowIndex = 0; rowIndex < rowLength; ++rowIndex) {
        for (let columnIndex = 0; columnIndex < this.model.get('cells').length; ++columnIndex) {
          const model = this.model.get('cells')[columnIndex][rowIndex];

          if (model.isInAuction() && !model.get('spread')) {
            // store the label and the instrument
            this.instrumentNamesList.push({label : model.get('shortName'), data : model});
          }
        }
      }

      if (!isInitialise) {
        if (this.instrumentNamesList.length === 0) {
          this.$el.find('.instrument-search-edit').autocomplete('close');
        }
        this.requestRender();
      }
    },

    onOpen () {
      this.resizeMenu();
    },

    resizeMenu () {
      const $autoCompleteMenu = this.$el.find('.ui-autocomplete');
      const inputControl = this.$el.find('.instrument-search-edit');
      const windowHeight = $(window).height();

      // eslint-disable-next-line no-magic-numbers
      $autoCompleteMenu.css('max-height', `${windowHeight - inputControl.height() - inputControl.offset().top - 10}px`);
    },

    onKeydownInput () {
      // eslint-disable-next-line no-restricted-globals
      if (event.keyCode === KeyCodes.ENTER) {
        if (this.$el.find('.instrument-search-edit').data().uiAutocomplete.selectedItem === null) {
          // eslint-disable-next-line no-restricted-globals
          this.searchComplete(this.searchedItemId, event);
        }
      }
      // eslint-disable-next-line no-restricted-globals
      event.stopPropagation();
    },

    onMenuSelection (event, ui) {
      event.stopPropagation();
      this.searchComplete(ui.item.data, event);
    },

    onSearch (event, ui) {
      if (ui.content.length === 1) {
        this.searchedItem = ui.content[0].data;
      }
    },

    searchComplete (dataItem, event) {
      if (dataItem) {
        $(event.target).val('');

        BGC.logger.logKey('Instrument Search Ctrl', `Searched and found instrument [${dataItem.getLogDescStr()}]`);
        this.$el.trigger('searchInstrument', [dataItem]);
      }

      // force a close as losing focus on the menu will cause the menu not to close on enter.
      this.$el.find('.instrument-search-edit').autocomplete('close');
      this.searchedItem = null;
    }
  });
}(window.BGC.ui.view));
