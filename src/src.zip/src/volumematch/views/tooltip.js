/* eslint-disable func-names, no-param-reassign, max-statements, id-length, no-magic-numbers, complexity, max-params */

/* global BGC: false, $: false */
// /////////////////////////////////////////////////////////////////////////////
// file tooltip.js
// Fading tooltip implemented as a div that displays stylable HTML content.
// Fading implemented using jQuery.
// Singleton implementation adapted from http://addyosmani.com/resources/essentialjsdesignpatterns/book/#singletonpatternjavascript
// /////////////////////////////////////////////////////////////////////////////

import lodashTemplate from 'lodash/template';

$(document).mouseleave(() => {
  // Hide the tooltip when the mouse leaves the page.
  BGC.ui.tooltipSingleton.getInstance().hide();

  // Let others handle this event if required.
  return true;
});

// eslint-disable-next-line no-shadow-restricted-names
(function (context, undefined) {
  // Function returns singleton object
  context.tooltipSingleton = (function () {
    // Single instance of Tooltip
    let instance = null;

    // Private static
    const maxOpacity = 0.95;

    // Constructor
    const Tooltip = function () {
      BGC.utils.createEnumeration(this, 'ETooltipType', ['eStandard', 'eValidationError']);

      // Private instance members
      let tooltipDiv = null;
      let fadingIn = false;
      let fadingOut = false;
      let timerId = 0;
      let tipType = this.ETooltipType.eStandard;

      if (!(this instanceof Tooltip)) {
        throw new Error('Constructor called as a function.');
      }

      context.RenderObject.call(this, 'theTooltip');

      // Public instance members
      this.isShowing = false;
      this.owner = undefined;
      this.elem = undefined;
      this.disabled = false;
      this.automationElement = null;
      this.keyValueTooltipTemplate = lodashTemplate($('#key-value-tooltip').html());


      // Private instance methods
      function fadeIn () {
        if ((tooltipDiv.css('opacity') < maxOpacity) && !fadingIn) {
          fadingIn = true;
          timerId = 0;
          this.isShowing = true;
          if (this.owner !== undefined) {
            this.owner.isDirty = true;
            BGC.ui.view.startRenderLoop();
          }
          tooltipDiv.stop(true, true).fadeTo('fast', maxOpacity, () => {
            fadingIn = false;
          });
        }
      }

      Tooltip.prototype.showKeyValueTooltip = function (values, tooltipPlacement, pos) {
        this.show(this.keyValueTooltipTemplate({
          values,
          tooltipPlacement
        }), pos, undefined, undefined, this.ETooltipType.eStandard, true);
      };

      // Public instance methods
      // Show tooltip with specified HTML content at specified mouse location and optional width.
      // Location will be in page coordinates
      // Owner should be passed if display of tooltip must be linked with change to underlying page display
      // tooltipType - ETooltipType - apply type appropriate styling
      // eslint-disable-next-line consistent-return
      Tooltip.prototype.show = function (content, pos, owner, width, tooltipType, customStyling) {
        const offset = {x : 10, y : 10};

        if (this.disabled) {
          return this;
        }

        if (tooltipType === undefined) {
          tipType = this.ETooltipType.eStandard;
        } else {
          tipType = tooltipType;
        }

        // Create tooltip div if not previously created
        if (!tooltipDiv) {
          $(`body:not(:has(#${this.id}))`).append(`<div id='${this.id}'/>`);
          tooltipDiv = $(`#${this.id}`);

          tooltipDiv.css('display', 'block').css('opacity', 0).css('pointer-events', 'none');

          if (BGC.ui.automation !== undefined && BGC.ui.automation.enabled) {
            this.createAutomationElement();
          }
        }

        if (customStyling) {
          tooltipDiv.removeClass('defaultStyling');
        } else {
          tooltipDiv.addClass('defaultStyling');
        }

        if (owner !== undefined && owner.isDirty !== undefined && typeof owner.isDirty === 'boolean') {
          this.owner = owner;
        } else {
          this.owner = undefined;
        }

        if (!fadingOut) {
          tooltipDiv.html(content);
          // eslint-disable-next-line no-negated-condition
          tooltipDiv.css('width', width !== undefined ? `${width}px` : 'auto');
        }

        if (timerId === 0 && !fadingIn && !this.isShowing) {
          // Optionally offset the position slightly away from the mouse pointer
          // This can be achieved by calling setOffset in advance or passing the offset in "pos"
          if (typeof pos.xOffset === 'number' && typeof pos.yOffset === 'number') {
            offset.x = pos.xOffset;
            offset.y = pos.yOffset;
          }

          let tooltipTop = pos.y;
          let tooltipLeft = pos.x;
          const tooltipWidth = parseInt(tooltipDiv.css('width'), 10);
          const tooltipHeight = parseInt(tooltipDiv.css('height'), 10);

          if (pos.x > window.innerWidth / 2) {
            // Pointer is in left hand side of window. Display the tooltip to the right of the pointer.
            tooltipLeft = (pos.x - tooltipWidth) - offset.x;
          } else {
            // Pointer is in right hand side of window. Display the tooltip to the left of the pointer.
            tooltipLeft = pos.x + offset.x;
          }

          // Move it up if it's off the bottom.
          if (pos.y + offset.y + tooltipHeight > window.innerHeight) {
            tooltipTop = (window.innerHeight - tooltipHeight) - offset.y;
          }

          tooltipDiv.css('top', `${tooltipTop}px`);
          tooltipDiv.css('left', `${tooltipLeft}px`);
          timerId = window.setTimeout(fadeIn.bind(this), 500);
        }
        tooltipDiv.toggleClass('input-validation-error', tooltipType === this.ETooltipType.eValidationError);
      };

      Tooltip.prototype.fadeOut = function () {
        const that = this;

        if ((tooltipDiv.css('opacity') > 0) && !fadingOut) {
          fadingOut = true;
          tooltipDiv.stop(true, false).fadeTo('slow', 0, () => {
            fadingOut = false;
            that.isShowing = false;
          });
        }
      };

      Tooltip.prototype.hide = function (withFading) {
        if (tooltipDiv) {
          if (timerId !== 0) {
            window.clearTimeout(timerId);
            timerId = 0;
          }
          if (this.isShowing) {
            fadingIn = false;
            if (withFading) {
              this.fadeOut();
            } else {
              tooltipDiv.stop(true, false).css('opacity', 0);
              fadingOut = false;
              this.isShowing = false;
            }
          }
        }
      };

      Tooltip.prototype.getType = function () {
        return tipType;
      };

      Tooltip.prototype.createAutomationElement = function () {
        if (!tooltipDiv) {
          throw new Error('createAutomationElement() called before tooltip jQuery object has been created.');
        }

        this.automationElement = new BGC.ui.automation.AutomationElement('tooltip', tooltipDiv);
        this.automationElement.automationControlType = 'toolTip';

        this.automationElement.serializeJQuery = function (json) {
          BGC.ui.automation.AutomationElement.prototype.serializeJQuery.call(this, json);
          json.value = this.automationObject.html();
        };
      };
    };

    Tooltip.prototype = Object.create(context.RenderObject.prototype);

    return {
      getInstance () {
        if (!instance) {
          instance = new Tooltip();
        }

        return instance;
      }
    };
  }());
}(window.BGC.ui));
