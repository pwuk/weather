/* eslint-disable func-names, max-lines, max-statements, no-param-reassign, max-len, id-length, no-magic-numbers */
/* global BGC: false, $: false, _:false, Backbone: false */

import {logger} from '@core-tech/web-api';
import {isWebDeployed} from '../bgc';
import getApp from '../index';


(function (context, viewUtils) {
  /**
   * Implements switch/checkbox view for the
   * settings dropdown.
   *
   * @class SettingsSwitch
   */
  context.SettingsSwitch = Backbone.View.extend({
    className : 'switch',
    tagName   : 'label',
    events    : {
      'change input' : 'updateSetting'
    },

    template : BGC.utils.queryTemplate('#settings-switch'),

    initialize (options) {
      this.title = options.title;
      this.id = options.id;
      this.listenTo(this.model, 'change', this.updateInput);
    },

    render () {
      this.$el.html(this.template({
        value : this.model.get(this.id),
        title : this.title,
        id    : this.id
      }));

      return this;
    },

    /**
     * Updates settings with the value from the checkbox.
     *
     * @method
     * @private
     */
    updateSetting () {
      this.model.set(this.id, Number(this.el.querySelector('input').checked));

      // In the case where the app is running withiin BGC Trader,
      // we don't have control of the Always on Top state of our own window,
      // so we must utilise BGC Trader's own general settngs mechanism.
      if (this.id === 'vmAlwaysOnTop' && !isWebDeployed) {
        BGC.eventsHandler.onUpdateGeneralSetting('GridView', 'vmChangeAOT', JSON.stringify({
          aot : Number(this.el.querySelector('input').checked)
        }));
      } else if (this.id === 'pinned') {
        this.$el.trigger('recalcLayout');
      }
    },

    /**
     * Updates checkbox with the value from the settings model.
     *
     * @method
     * @private
     */
    updateInput () {
      this.$el.find('input').prop('checked', this.model.get(this.id));
    }
  });

  /**
   * Implements zoom control with buttons to increase and decrease
   * current application zoom level. (75% - 150%)
   *
   * @class ZoomControl
   */
  const ZoomControl = Backbone.View.extend({
    className : 'zoom-control',
    events    : {
      'click .increase' : 'increaseZoomLevel',
      'click .decrease' : 'decreaseZoomLevel'
    },
    template : BGC.utils.queryTemplate('#zoom-control'),

    initialize (options) {
      this.dataStore = options.dataStore;
      this.title = options.title;
      this.ZOOM_STEP = 12.5;
      this.ZOOM_MAX_LEVEL = 150;
      this.ZOOM_MIN_LEVEL = 75;

      this.listenTo(this.dataStore.userSettingsStore, 'change:zoomLevel', this.render);
    },

    render () {
      this.$el.html(this.template({
        title               : this.title,
        zoomLevel           : this.dataStore.userSettingsStore.get('zoomLevel'),
        zoomIncreaseEnabled : this.dataStore.userSettingsStore.get('zoomLevel') !== this.ZOOM_MAX_LEVEL,
        zoomDecreaseEnabled : this.dataStore.userSettingsStore.get('zoomLevel') !== this.ZOOM_MIN_LEVEL
      }));

      return this;
    },

    increaseZoomLevel () {
      if (this.dataStore.userSettingsStore.get('zoomLevel') === this.ZOOM_MAX_LEVEL) {
        return;
      }

      this.dataStore.userSettingsStore.set('zoomLevel', this.dataStore.userSettingsStore.get('zoomLevel') + this.ZOOM_STEP);
    },

    decreaseZoomLevel () {
      if (this.dataStore.userSettingsStore.get('zoomLevel') === this.ZOOM_MIN_LEVEL) {
        return;
      }

      this.dataStore.userSettingsStore.set('zoomLevel', this.dataStore.userSettingsStore.get('zoomLevel') - this.ZOOM_STEP);
    }
  });

  /**
   * Implements control that manages upsizing mode.
   *
   * @class UpsizeControl
   */
  const UpsizeControl = Backbone.View.extend({
    className : 'upsizing-control',
    events    : {
      'change select' : 'onUpsizingChanged'
    },
    template : BGC.utils.queryTemplate('#upsizing-control'),

    initialize (options) {
      this.title = options.title;
      this.resources = options.resources;

      // we need to build element before Backbone attaches DOM event listeners,
      // otherwise the element triggers change event on render an notifies back-end
      // forcing to change upsizing mode to default value in the select element
      // which is incremental
      this.buildElement();

      this.listenTo(this.model, 'change:upsizingMode', this.updateUpsizingWidget);
      this.listenTo(this.model, 'change:isExcelAddInEnabled', this.excelAddInStateChanged);
    },

    buildElement () {
      this.$el.html(this.template({
        resources : this.resources
      }));
      this.$el.find('select').val(this.model.get('upsizingMode'));
      this.$el.find('select').fixCEFSelect();
    },

    render () {
      return this;
    },

    onUpsizingChanged () {
      this.model.set('upsizingMode', parseInt(this.$el.find('select').val(), 10));

      logger.info(`Changing upsizing mode to ${this.model.get('upsizingMode') === 0 ? 'incremental' : 'total'}`);
    },

    updateUpsizingWidget () {
      this.$el.find('select').val(this.model.get('upsizingMode'));
    },

    excelAddInStateChanged () {
      this.$el.find('select').attr('disabled', this.model.get('isExcelAddInEnabled'));
    }
  });

  const ThemeChangeControl = Backbone.View.extend({
    className : 'theme-change-control',
    events    : {
      'change select' : 'onThemeChanged'
    },
    template : BGC.utils.queryTemplate('#theme-change-control'),

    initialize (options) {
      this.title = options.title;
      this.themes = BGC.ui.theme.Volumematch.getSupportedThemes();

      // we need to build element before Backbone attaches DOM event listeners,
      // otherwise the element triggers change event on render an notifies back-end
      // forcing to change to default value in the select element
      this.buildElement();

      this.listenTo(this.model, 'change:themeSelected', this.updateThemeSelectedWidget);
    },

    buildElement () {
      this.$el.html(this.template({
        title  : this.title,
        themes : this.themes
      }));
      this.$el.find('select').val(this.model.get('themeSelected'));
      this.$el.find('select').fixCEFSelect();
    },

    render () {
      return this;
    },

    onThemeChanged () {
      this.model.set('themeSelected', parseInt(this.$el.find('select').val(), 10));
    },

    updateThemeSelectedWidget () {
      const selectedTheme = this.model.get('themeSelected');

      this.$el.find('select').val(selectedTheme);
    }

  });

  const LogLevelControl = Backbone.View.extend({
    className : 'loglevel-change-control',
    events    : {
      'change select' : 'onLogLevelChange'
    },

    initialize () {
      this.listenTo(this.model, 'change:loglevel', this.onLogLevelChange);
    },

    onLogLevelChange () {
      const selectedLogLevel = this.model.get('loglevel');

      logger.changeLogLevel(selectedLogLevel);
      this.model.set('loglevel', selectedLogLevel);
    }
  });

  /**
   * Implements control that enables excel links toggling.
   *
   * @class ExcelControl
   */
  context.ExcelControl = Backbone.View.extend({
    className : 'excel-control',
    template  : BGC.utils.queryTemplate('#excel-control'),
    events    : {
      'click button' : 'toggleLinks'
    },

    initialize (options) {
      this.title = options.title;
      this.resources = options.resources;
      this.listenTo(this.model, 'change:isExcelAddInEnabled', this.render);
      this.listenTo(this.model, 'change:areAllExcelLiveLinksEnabled', this.render);
    },

    render () {
      const title = this.model.get('areAllExcelLiveLinksEnabled') ? this.resources.IDS_DISABLE_ALL_EXCEL_LIVE_LINKS : this.resources.IDS_ENABLE_ALL_EXCEL_LIVE_LINKS;

      this.$el.html(this.template({
        title
      }));

      this.$el.toggle(this.model.get('isExcelAddInEnabled'));
      this.$el.toggleClass('live', !!this.model.get('areAllExcelLiveLinksEnabled'));

      return this;
    },

    toggleLinks () {
      this.model.toggleExcelLiveLinksAll('excel-live-link-all');
    }
  });

  /**
   * Implements maximum quantity view
   *
   * @class MaxQuantityControl
   */
  const MaxQuantityControl = Backbone.View.extend({
    className : 'spinner-control',
    events    : {
      'change input'     : 'onUpdateSetting',
      'blur input'       : 'onBlur',
      'keydown input'    : 'onKeyDownInput',
      'mouseover .title' : 'onMouseOverMaxSpan',
      'mouseout .title'  : 'onMouseOutMaxSpan'
    },

    template : BGC.utils.queryTemplate('#spinner-control'),

    initialize (options) {
      this.listenTo(this.model, 'change:maxQuantityMultiplier', this.updateInput);
      this.min = 0;
      this.max = 100;
      this.step = 1;
      this.id = options.id;
    },

    tooltip : BGC.ui.tooltipSingleton.getInstance(),

    render () {
      this.$el.html(this.template({
        value : Number(this.model.get(this.id)),
        title : BGC.resources.IDS_MAXIMUM_QUANTITY,
        min   : this.min,
        max   : this.max,
        step  : this.step,
        id    : this.id
      }));

      return this;
    },

    onUpdateSetting () {
      // only validate the setting value don't send this change yet.
      const maxQuantityMultiplier = this.$el.find('input').val().trim();
      // eslint-disable-next-line no-restricted-globals
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        x : targetRect.left + (targetRect.width * 2),
        y : targetRect.top + targetRect.height
      };

      this.hideErrorTooltip();

      // valid input number value using standard web api.
      if (maxQuantityMultiplier !== '' && !this.$el.find('input')[0].checkValidity()) {
        if ($('#settings-view').hasClass('is-open')) {
          // if the config panel is displayed, display the error-tooltip if the multipler is invalid
          this.tooltip.show(BGC.resources.IDS_INVALID_ENTRY_AND_REVERT, position, this, null, this.tooltip.ETooltipType.eValidationError);
        } else {
          // if the config panel is already closed, display the message box if the multipler is invalid
          // SettingsView.closeDropdown() was called before this function. Make sure user aware off the reverting.
          BGC.ui.viewUtils.displayErrorMessage(BGC.resources.IDS_INVALID_MAX_MULTIPLE_ENTRY, BGC.resources.IDS_MSG_INVALID_ENTRY_AND_REVERT);
        }

        // revert invalid entry
        this.$el.find('input').val(this.model.get(this.id));
      }
    },

    onBlur () {
      // send the change when the input has been completed.
      const maxQuantityMultiplier = this.$el.find('input').val().trim();

      // valid input number value using standard web api.
      if (maxQuantityMultiplier !== '' && this.$el.find('input')[0].checkValidity()) {
        if (Number(maxQuantityMultiplier) !== Number(this.model.get(this.id))) {
          this.model.set(this.id, Number(maxQuantityMultiplier));

          // send a message to the server to sync this settings with the fat client setting as well.
          BGC.eventsHandler.onUpdateGeneralSetting('SettingsView', 'vmChangeMaximumQuantity', JSON.stringify({
            maximumQuantity : maxQuantityMultiplier
          }));
        }
      }
      this.hideErrorTooltip();
    },

    onKeyDownInput () {
      if (this.tooltip.isShowing) {
        this.tooltip.hide();
      }
    },

    onMouseOverMaxSpan () {
      // When mouse over "Max Quantity Multiple", do not change error-tooltip display state
      if ((this.tooltip.getType() === this.tooltip.ETooltipType.eValidationError) && this.tooltip.isShowing) {
        return;
      }

      // eslint-disable-next-line no-restricted-globals
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        x : targetRect.left + targetRect.width,
        y : targetRect.top + targetRect.height
      };

      this.tooltip.show(BGC.resources.IDS_MAX_QUANTITY_MULTIPLIER, position);
    },

    onMouseOutMaxSpan () {
      this.tooltip.hide();
    },

    hideErrorTooltip () {
      if (this.tooltip.isShowing && this.tooltip.getType() === this.tooltip.ETooltipType.eValidationError) {
        this.tooltip.hide();
      }
    },

    updateInput () {
      if (!this.$el.find('input').is(':focus')) {
        this.$el.find('input').val(this.model.get(this.id));
      }
    }
  });

  /**
   * Implements order animation duration control.
   *
   * @class OrderAnimationDurationControl
   */
  const OrderAnimationDurationControl = Backbone.View.extend({
    className : 'spinner-control',
    events    : {
      'change input'     : 'onUpdateSettings',
      'blur input'       : 'onBlur',
      'keydown input'    : 'onKeyDownInput',
      'mouseover .title' : 'onMouseOverMaxSpan',
      'mouseout .title'  : 'onMouseOutMaxSpan'
    },
    template : BGC.utils.queryTemplate('#spinner-control'),
    tooltip  : BGC.ui.tooltipSingleton.getInstance(),

    initialize (options) {
      const ANIMATION_CONST = viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION;

      this.listenTo(this.model, 'change:orderAnimationDuration', this.updateInput);

      this.min = ANIMATION_CONST.MIN;
      this.max = ANIMATION_CONST.MAX;
      this.step = ANIMATION_CONST.STEP;
      this.id = options.id;
      this.title = options.title;
    },

    render () {
      this.$el.html(this.template({
        value : Number(this.model.get(this.id)),
        title : this.title,
        min   : this.min,
        max   : this.max,
        step  : this.step,
        id    : this.id
      }));

      return this;
    },

    onUpdateSettings () {
      const animationDuration = this.$el.find('input').val().trim();
      // eslint-disable-next-line no-restricted-globals
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        x : targetRect.left + (targetRect.width * 2),
        y : targetRect.top + targetRect.height
      };

      this.hideErrorTooltip();

      // valid input number value using standard web api.
      if (this.$el.find('input')[0].checkValidity()) {
        // set the new value
        this.model.set(this.id, Number(animationDuration));
      } else if (animationDuration !== '') {
        if ($('#settings-view').hasClass('is-open')) {
          // if the config panel is displayed, display the error-tooltip if the row count is invalid
          this.tooltip.show(BGC.resources.IDS_INVALID_ENTRY_AND_REVERT, position, this, null, this.tooltip.ETooltipType.eValidationError);
        } else {
          // if the config panel is already closed, display the message box if the row count is invalid
          // SettingsView.closeDropdown() was called before this function. Make sure user aware off the reverting.
          BGC.ui.viewUtils.displayErrorMessage(BGC.resources.IDS_INVALID_ORDER_ANIMATION_DURATION_ENTRY, BGC.resources.IDS_MSG_ORDER_ANIMATION_COUNT_INVALID_ENTRY_AND_REVERT);
        }

        // revert invalid entry
        this.$el.find('input').val(this.model.get(this.id));
      }
    },

    onBlur () {
      this.hideErrorTooltip();
    },

    onKeyDownInput () {
      if (this.tooltip.isShowing) {
        this.tooltip.hide();
      }
    },

    onMouseOverMaxSpan () {
      // When mouse over "Active order animation duration", do not change error-tooltip display state
      if ((this.tooltip.getType() === this.tooltip.ETooltipType.eValidationError) && this.tooltip.isShowing) {
        return;
      }

      // eslint-disable-next-line no-restricted-globals
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        x : targetRect.left + targetRect.width,
        y : targetRect.top + targetRect.height
      };

      this.tooltip.show(BGC.resources.IDS_MSG_ORDER_ANIMATION_DURATION_TOOLTIP, position);
    },

    onMouseOutMaxSpan () {
      this.tooltip.hide();
    },

    hideErrorTooltip () {
      if (this.tooltip.isShowing && this.tooltip.getType() === this.tooltip.ETooltipType.eValidationError) {
        this.tooltip.hide();
      }
    },

    updateInput () {
      if (!this.$el.find('input').is(':focus')) {
        this.$el.find('input').val(this.model.get(this.id));
      }
    }
  });

  /**
   * Implements fixed height order row count view
   *
   * @class FixedHeightOrderRowCountControl
   */
  const FixedHeightOrderRowCountControl = Backbone.View.extend({
    className : 'spinner-control',
    events    : {
      'change input'     : 'onUpdateSetting',
      'blur input'       : 'onBlur',
      'keydown input'    : 'onKeyDownInput',
      'mouseover .title' : 'onMouseOverMaxSpan',
      'mouseout .title'  : 'onMouseOutMaxSpan'
    },

    template : BGC.utils.queryTemplate('#spinner-control'),

    initialize (options) {
      this.listenTo(this.model, 'change:isOrdersViewFixedHeight', this.updateEnable);
      this.listenTo(this.model, 'change:fixedHeightOrdersViewRowCount', this.updateInput);
      this.min = options.min;
      this.max = 20;
      this.step = 1;
      this.id = options.id;
      this.title = options.title;
    },

    tooltip : BGC.ui.tooltipSingleton.getInstance(),

    render () {
      this.$el.html(this.template({
        value : Number(this.model.get(this.id)),
        title : this.title,
        min   : this.min,
        max   : this.max,
        step  : this.step,
        id    : this.id
      }));

      this.updateEnable();

      return this;
    },

    onUpdateSetting () {
      // get the new value
      const rowCount = this.$el.find('input').val().trim();
      // eslint-disable-next-line no-restricted-globals
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        x : targetRect.left + (targetRect.width * 2),
        y : targetRect.top + targetRect.height
      };

      this.hideErrorTooltip();

      // valid input number value using standard web api.
      if (this.$el.find('input')[0].checkValidity()) {
        // set the new value
        this.model.set(this.id, Number(rowCount));
      } else if (rowCount !== '') {
        if ($('#settings-view').hasClass('is-open')) {
          // if the config panel is displayed, display the error-tooltip if the row count is invalid
          this.tooltip.show(BGC.resources.IDS_INVALID_ENTRY_AND_REVERT, position, this, null, this.tooltip.ETooltipType.eValidationError);
        } else {
          // if the config panel is already closed, display the message box if the row count is invalid
          // SettingsView.closeDropdown() was called before this function. Make sure user aware off the reverting.
          BGC.ui.viewUtils.displayErrorMessage(BGC.resources.IDS_INVALID_FIXED_HEIGHT_ORDERS_ROW_COUNT_ENTRY, BGC.resources.IDS_MSG_FIXED_HEIGHT_ORDERS_ROW_COUNT_INVALID_ENTRY_AND_REVERT);
        }

        // revert invalid entry
        this.$el.find('input').val(this.model.get(this.id));
      }
    },

    onBlur () {
      this.hideErrorTooltip();
    },

    onKeyDownInput () {
      if (this.tooltip.isShowing) {
        this.tooltip.hide();
      }
    },

    onMouseOverMaxSpan () {
      // When mouse over "Number of order rows", do not change error-tooltip display state
      if ((this.tooltip.getType() === this.tooltip.ETooltipType.eValidationError) && this.tooltip.isShowing) {
        return;
      }

      // eslint-disable-next-line no-restricted-globals
      const targetRect = event.target.getBoundingClientRect();
      const position = {
        x : targetRect.left + targetRect.width,
        y : targetRect.top + targetRect.height
      };

      this.tooltip.show(BGC.resources.IDS_MSG_FIXED_HEIGHT_ORDERS_ROW_COUNT_TOOLTIP, position);
    },

    onMouseOutMaxSpan () {
      this.tooltip.hide();
    },

    hideErrorTooltip () {
      if (this.tooltip.isShowing && this.tooltip.getType() === this.tooltip.ETooltipType.eValidationError) {
        this.tooltip.hide();
      }
    },

    updateEnable () {
      const $inputElem = this.$el.find('input');

      // Enable/disable the control depending on whether the fixed height row area setting is turned on.
      if (!this.model.get('isOrdersViewFixedHeight') !== ($inputElem.attr('disabled') === 'disabled')) {
        if (this.model.get('isOrdersViewFixedHeight')) {
          $inputElem.removeAttr('disabled');
        } else {
          $inputElem.attr('disabled', 'true');
        }
      }
    },

    updateInput () {
      if (!this.$el.find('input').is(':focus')) {
        this.$el.find('input').val(this.model.get(this.id));
      }
    }
  });

  /**
   * Implements Change password link
   *
   * @class ChangePassword
   */
  // eslint-disable-next-line no-unused-vars
  const ChangePassword = Backbone.View.extend({
    className : 'change-password',
    events    : {
      'click #change-pwd' : 'changePassword'
    },
    template : BGC.utils.queryTemplate('#change-password'),

    initialize (options) {
      this.title = options.title;
      const $secondLook = $('#secondLook');

      this.secondLook = $secondLook.popup({
        modal                : true,
        title                : BGC.resources.IDS_CHANGE_PASSWORD,
        message              : BGC.resources.IDS_CHANGE_PASSWORD_CONFIRM,
        hasHeaderCloseButton : false,

        confirm () {
          window.location.href = '/reset';
        }
      });
    },

    render () {
      this.$el.html(this.template({
        title : this.title
      }));

      return this;
    },

    changePassword () {
      this.secondLook.popup('show');

      return false;
    }
  });

  /**
   * Implements live mode drop down view
   *
   * @class ShowLiveModeControl
   */
  context.ShowLiveModeControl = Backbone.View.extend({
    template : BGC.utils.queryTemplate('#tile-filter-control'),
    events   : {
      'change select' : 'onLiveModeChanged'
    },

    initialize (options) {
      this.listenTo(this.model, 'change:brokerLiveMode change:traderLiveMode', this.updateSelectionFromModel);
      this.listenTo(this.model, 'change:tileAuctionState', this.handleAuctionStateChanged);
      this.dataStore = options.dataStore;
      this.resources = options.resources;
      this.updateFilterOptionForActiveUser();
    },

    buildElement () {
      this.render();

      this.updateSelectionFromModel();
      this.handleAuctionStateChanged();
    },

    updateFilterOptionForActiveUser () {
      this.filterClasses = this.dataStore.isBrokerMode() ? ['show-all', 'live-and-glows'] : ['show-all', 'live-and-glows', 'live-only'];
      this.optionsText = this.dataStore.isBrokerMode() ? [this.resources.IDS_LIVE_MODE_SHOW_ALL, this.resources.IDS_LIVE_MODE_GLOWS_AND_TRADES] : [this.resources.IDS_LIVE_MODE_SHOW_ALL, this.resources.IDS_LIVE_MODE_MINE_AND_GLOWS, BGC.resources.IDS_LIVE_MODE_MINE_ONLY];
      this.buildElement();
    },

    handleAuctionStateChanged () {
      const {userSettingsStore} = this.dataStore;
      const showMe = userSettingsStore.get('retainHistory') || this.model.hasTileWithShowInterestGlows();

      if (showMe !== this.showMe) {
        this.showMe = showMe;
        if (this.showMe) {
          this.$el.show();
        } else {
          this.$el.hide();
        }
      }
    },

    render () {
      this.$el.html(this.template({
        title   : this.resources.IDS_LIVE_MODE_TITLE,
        options : this.optionsText
      }));
      this.$el.addClass('show-live');

      return this;
    },

    onLiveModeChanged () {
      this.model.setLiveModeForActiveUser(parseInt(this.$el.find('select').val(), 10));
    },

    updateSelectionFromModel () {
      this.$el.find('select').val(this.model.getLiveModeForActiveUser());
    }

  });

  /**
   * Implements drop down settings menu containing
   * general setting of the VM application.
   *
   * @class SettingsView
   */
  context.SettingsView = Backbone.View.extend({
    className : 'settings-view',
    id        : 'settings-view',
    tagName   : 'span',
    template  : BGC.utils.queryTemplate('#settings-view'),
    events    : {
      'mouseup i.fa-cog' : 'toggleDropdown'
    },

    initialize (options) {
      this.settingViews = options.settingViews;
      this.title = options.title;
    },

    /**
       * Opens the dropdown menu.
       *
       * @method
       * @private
       */
    toggleDropdown () {
      this.$el.toggleClass('is-open');

      if (this.$el.hasClass('is-open')) {
        $('html').on('mousedown', {
          context : this
        }, this.onBodyEvent);
        $('html').on('keydown', {
          context : this
        }, this.onBodyEvent);
        this.$el.on('mouseup', '.toggle', {
          context : this
        }, this.onToggleSwitchOperated);
      } else {
        $('html').off('mousedown', this.onBodyEvent);
        $('html').off('keydown', this.onBodyEvent);
        this.$el.off('mouseup', '.toggle', this.onToggleSwitchOperated);
      }

      $('main .auction-view').trigger('recalcLayout');
    },

    /**
       * Closes the dropdown menu.
       *
       * @method
       * @private
       */
    closeDropdown () {
      this.$el.removeClass('is-open');

      $('html').off('mousedown', this.onBodyEvent);
      $('html').off('keydown', this.onBodyEvent);
      this.$el.off('mouseup', '.toggle', this.onToggleSwitchOperated);

      $('main .auction-view').trigger('recalcLayout');
    },

    onToggleSwitchOperated (event) {
      event.data.context.closeDropdown();
    },

    /**
       * Ensures the settings view closes if a click or ESC keypress happens outside the view
       *
       * @method
       */
    onBodyEvent (event) {
      const settingsView = event.data.context;
      const $panelElement = settingsView.$el.find('.dropdown-panel');
      const $triggerElement = settingsView.$el.find('i');
      const panelPos = $panelElement.offset();
      const panelRect = {
        top    : panelPos.top,
        left   : panelPos.left,
        width  : $panelElement.outerWidth(),
        height : $panelElement.outerHeight()
      };
      const triggerPos = $triggerElement.offset();
      const triggerRect = {
        top    : triggerPos.top,
        left   : triggerPos.left,
        width  : $triggerElement.outerWidth(),
        height : $triggerElement.outerHeight()
      };
      const $mouseTargetSettingsPanelParent = event.type === 'mousedown' && $(event.target).closest('.dropdown-panel');
      const isTargetInSettingsPanel = BGC.utils.pointInRect(event.pageX, event.pageY, panelRect) ||
            ($mouseTargetSettingsPanelParent.length && $mouseTargetSettingsPanelParent[0] === $panelElement[0]);
      const isTargetInTriggerElement = BGC.utils.pointInRect(event.pageX, event.pageY, triggerRect);

      if (event.type === 'mousedown' && settingsView.$el.hasClass('is-open') &&
          !(isTargetInSettingsPanel || isTargetInTriggerElement)) {
        settingsView.closeDropdown();
      } else if (event.type === 'keydown') {
        if (event.which === BGC.utils.KeyCodes.ESC) {
          settingsView.closeDropdown();
        }
      }
    },

    render () {
      this.$el.html(this.template({
        title : this.title || ''
      }));

      const dropdownElement = this.$el.find('.dropdown-panel');

      // add options to the view
      this.settingViews.forEach(settingsView => {
        dropdownElement.append(settingsView.render().$el);
      });

      return this;
    }
  },

  {
    /**
       * Creation method that creates and populates default settings view.
       *
       * @static
       * @method
       */
    // eslint-disable-next-line complexity
    createView (options) {
      const hasDashboard = window.BGC.ui.theme.getBrandId() === 'BGCIRO';
      const {settingsCollection} = options;
      const {pageLayout} = options;
      const {dataStore} = options;
      const app = getApp();

      let settingViews = [
        // in-place order entry option
        new context.SettingsSwitch({
          id    : 'enableInPlaceOrderEntry',
          title : BGC.resources.IDS_SETTINGS_ENABLE_IN_PLACE_ORDER_ENTRY,
          model : settingsCollection.volumeMatch
        }),

        // force second look dialog option
        new context.SettingsSwitch({
          id    : 'forceSecondLook',
          title : BGC.resources.IDS_SETTINGS_SECOND_LOOK,
          model : settingsCollection.volumeMatch
        }),

        // spreads second look option
        new context.SettingsSwitch({
          id    : 'displaySpreadSecondLook',
          title : dataStore.isBrokerMode() ? BGC.resources.IDS_SETTINGS_SPREAD_SECOND_LOOK : BGC.resources.IDS_SETTINGS_SPREAD_AND_ORDER_SECOND_LOOK,
          model : settingsCollection.volumeMatch
        }),

        // Centre OEDB
        new context.SettingsSwitch({
          id    : 'enableCentreOEDB',
          title : BGC.resources.IDS_SETTINGS_CENTRE_OEDB,
          model : settingsCollection.volumeMatch
        }),

        // "Pin" option to fix window top-left, disable auto expansion, allow user vertical drag resize
        new context.SettingsSwitch({
          id    : 'pinned',
          title : BGC.resources.IDS_PIN_WINDOW,
          model : settingsCollection.volumeMatch
        }),

        // Favorites second look option
        new context.SettingsSwitch({
          id    : 'displayFavoritesSecondLook',
          title : BGC.resources.IDS_SETTINGS_FAVORITES_SECOND_LOOK,
          model : settingsCollection.volumeMatch
        }),

        // Always on Top option
        new context.SettingsSwitch({
          id    : 'vmAlwaysOnTop',
          title : BGC.utils.format(BGC.resources.IDS_VM_ALWAYS_ON_TOP, [pageLayout.get('vmTerminology')]),
          model : settingsCollection.volumeMatch
        }),

        new context.SettingsSwitch({
          id    : 'enableOCO',
          title : BGC.resources.IDS_ENABLE_OCO,
          model : settingsCollection.volumeMatch
        }),

        new context.SettingsSwitch({
          id    : 'ocoBidAndOfferSpecific',
          title : BGC.resources.IDS_OCO_BID_OFFER_SPECIFIC,
          model : settingsCollection.volumeMatch
        }),

        new context.SettingsSwitch({
          id    : 'displayFavoritesSizeButtons',
          title : BGC.resources.IDS_SETTINGS_FAVORITE_SIZE_BUTTONS,
          model : settingsCollection.volumeMatch
        }),

        // allow broker reprice option
        new context.SettingsSwitch({
          id    : 'AllowBrokerRepriceLiveVM',
          title : BGC.resources.IDS_SETTINGS_ALLOW_BROKER_REPRICE,
          model : settingsCollection.volumeMatch
        }),

        // fixed height orders/trades views option
        new context.SettingsSwitch({
          id    : 'isOrdersViewFixedHeight',
          title : BGC.resources.IDS_SETTINGS_FIXED_HEIGHT_ORDERS_VIEW,
          model : settingsCollection.volumeMatch
        }),

        // fixed height orders/trades views row count option
        new FixedHeightOrderRowCountControl({
          id    : 'fixedHeightOrdersViewRowCount',
          title : BGC.resources.IDS_SETTINGS_FIXED_HEIGHT_ORDERS_ROW_COUNT,
          model : settingsCollection.volumeMatch,
          min   : pageLayout.get('tabsLayout').find(tab => tab.ID === 'tab-control-view-portfolio-tab') ? 7 : 2

        }),

        // order animation duration option
        new OrderAnimationDurationControl({
          id    : 'orderAnimationDuration',
          title : BGC.resources.IDS_SETTINGS_ORDER_ANIMATION_DURATION,
          model : settingsCollection[pageLayout.get('linkId')]
        }),

        // maximum quantity multiplier (overlimit) option
        new MaxQuantityControl({
          id    : 'maxQuantityMultiplier',
          model : settingsCollection.global
        }),

        // zoom option
        new ZoomControl({
          id    : 'zoom',
          title : BGC.resources.IDS_ZOOM,
          dataStore
        }),

        // upsizing option
        new UpsizeControl({
          id        : 'upsize',
          title     : BGC.resources.IDS_ZOOM,
          model     : settingsCollection.global,
          resources : BGC.resources
        })
      ];

      if (!hasDashboard) {
        settingViews.push(new ThemeChangeControl({
          id        : 'themeSelected',
          title     : BGC.resources.IDS_THEMECHANGE,
          model     : settingsCollection.volumeMatch,
          resources : BGC.resources
        }));

        // add log level backbone model here
        settingViews.push(new LogLevelControl({
          id        : 'loglevel',
          title     : BGC.resources.IDS_LOG_LEVEL,
          model     : settingsCollection.volumeMatch,
          resources : BGC.resources
        }));
      }

      // If this is a native browser, hide the 'always on top' settings as this API is not supported by desktop browsers
      if (!app.isEmbedded) {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'vmAlwaysOnTop'
        }));
      }

      // Some settings aren't valid to make on a matrix-focused layout
      if (pageLayout.hasMatrices()) {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'VmTileViewsUseCompactLayout'
        }), _.findWhere(settingViews, {
          id : 'pinned'
        }));
      }

      if (!(dataStore.userSettingsStore.get('allowVMOCO') && pageLayout.hasMatrices())) {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'enableOCO'
        }));

        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'ocoBidAndOfferSpecific'
        }));
      }

      // Hide 'Enable Centre OEDB' from settings
      if (!dataStore.userSettingsStore.get('centreOEDB')) {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'enableCentreOEDB'
        }));
      }


      // Hide 'Active order animation duration'
      if (dataStore.isBrokerMode() || dataStore.userSettingsStore.get('orderAnimationDuration') === viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION.DISABLED) {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'orderAnimationDuration'
        }));
      }

      // Hide 'My Favorite' settings when footprint persistence is switched off
      if (dataStore.isBrokerMode() || !dataStore.userSettingsStore.get('displayFavorites')) {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'displayFavoritesSizeButtons'
        }));
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'displayFavoritesSecondLook'
        }));
      }

      if (pageLayout.get('tabsLayout').find(tab => tab.ID === 'tab-control-view-portfolio-tab')) {
        // Set 'isOrdersViewFixedHeight' toggle to true as even though this setting is removed, it has dependency
        // on 'FixedHeightOrderRowCountControl' spin control setting to work
        settingsCollection.volumeMatch.set('isOrdersViewFixedHeight', 1);

        // Remove 'isOrdersViewFixedHeight' setting
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'isOrdersViewFixedHeight'
        }));
      }

      if (dataStore.isBrokerMode()) {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'forceSecondLook'
        }));
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'upsize'
        }));
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'maxQuantityMultiplier'
        }));
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'isOrdersViewFixedHeight'
        }));
      } else {
        settingViews = _.without(settingViews, _.findWhere(settingViews, {
          id : 'AllowBrokerRepriceLiveVM'
        }));

        const spreadSecondLookSetting = _.findWhere(settingViews, {
          id : 'displaySpreadSecondLook'
        });

        const showHideSecondLookSetting = function () {
          if (pageLayout.get('allowSpreadCreation')) {
            spreadSecondLookSetting.$el.show();
          } else {
            spreadSecondLookSetting.$el.hide();
          }
        };

        showHideSecondLookSetting();

        spreadSecondLookSetting.listenTo(pageLayout, 'change:allowSpreadCreation', showHideSecondLookSetting);
      }

      return new context.SettingsView({
        settingViews,
        title : BGC.resources.IDS_SETTINGS
      });
    }
  });
}(window.BGC.ui.view, window.BGC.ui.viewUtils));
