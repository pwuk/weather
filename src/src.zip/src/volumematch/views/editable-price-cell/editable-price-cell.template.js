import {html} from '@polymer/polymer/polymer-element';
import {} from '@polymer/polymer/lib/elements/dom-repeat';

// <ul style="list-style: none" className="style-scope quicksize-buttonset buy no-instrument no-order">
//     <li className="style-scope quicksize-buttonset"></li>
//     <li className="style-scope quicksize-buttonset"></li>
//     <li className="style-scope quicksize-buttonset"></li>
//     <template is="dom-repeat" className="style-scope quicksize-buttonset"></template>
// </ul>

export default html`
    <style>
        :host {
            display: inline-block;
            vertical-align: middle;
            cursor: default;
        }

        :host input {
            display: none;
            text-align: center;
            font-size: 1em;
            border-width: 0;
            outline: 0;
            padding: 0;
            margin: 0;
            -webkit-appearance: none;
        }

        :host input::-webkit-outer-spin-button,
        :host input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        :host .click-overlay,
        :host input {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        :host .click-overlay {
            cursor: text;
        }

        :host.is-editing input {
            display: block;
        }
        :host .no-instrument {
            background-color: red;
        }
        
    </style>
    <span class="value">{{price}}</span>
    <template is="dom-if" if="{{editable}}">
        <span class="click-overlay" on-click="startEditing"></span>
        <input type="text" id="price-field" on-blur="cancelEditing" on-keydown="processInputKeyDown"/>
    </template>
`;
