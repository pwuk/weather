/* global BGC: false, $: false */

import {PolymerElement} from '@polymer/polymer';
import componentTemplate from './editable-price-cell.template';

const {ESCAPE_CODE, ENTER_CODE} = BGC.utils.KeyCodes;

class EditablePriceCell extends PolymerElement {
  static get properties () {
    return {
      editable   : Boolean,
      price      : String,
      inputValue : String
    };
  }

  static get template () {
    return componentTemplate;
  }

  created () {
    this.registerKeyHandlers();
  }

  /**
   * Registers event handlers that respond to specified key codes
   * within component.
   */
  registerKeyHandlers () {
    this.keyHandlers = {};
    this.keyHandlers[ESCAPE_CODE] = this.cancelEditing.bind(this);
    this.keyHandlers[ENTER_CODE] = this.processPrice.bind(this);
  }

  /**
   * Puts component into editing state.
   * */
  startEditing () {
    const inputField = $(this.shadowRoot).$$('input');

    this.classList.add('is-editing');
    inputField.value = this.price;
    inputField.focus();
    inputField.select();
  }

  /**
   * Cancels editing state on component.
   */
  cancelEditing () {
    this.classList.remove('is-editing');
    this.classList.remove('invalid');
  }

  /**
   * Processes key event code from input element.
   *
   * @param {Event} event
   */
  processInputKeyDown (event) {
    // eslint-disable-next-line no-unused-expressions,no-prototype-builtins
    this.keyHandlers.hasOwnProperty(event.keyCode) && this.keyHandlers[event.keyCode]();
    event.stopPropagation();
  }

  /**
   * Processes current price value ( submits ).
   */
  processPrice () {
    const enteredPrice = this.$$('input').value;
    const isSameAsOriginal = enteredPrice === this.price;

    this.cancelEditing();

    if (!isSameAsOriginal) {
      this.dispatchEvent(new CustomEvent('price:updated', {detail : {priceText : enteredPrice}}));
    }
  }
}
customElements.define('editable-price-cell', EditablePriceCell);
