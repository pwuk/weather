/* eslint-disable no-magic-numbers, func-names, no-plusplus, no-param-reassign */
/* global BGC: false */

(function (context) {
  const INSTRUMENT_ROW_SELECTOR = '.tile-instrument-row';

  /**
   * Adds arrow key navigation between inputs for an instruments/orders grid.
 */
  // eslint-disable-next-line no-param-reassign
  context.GridViewNavigationMixin = {
    // This property allows the mixin to be used with Polymer components
    listeners : {
      keydown : 'onKeyDown'
    },

    onKeyDown (event) {
      let nextElementToFocus = null;
      const isCurrentCellInEditMode = this.isFocusedInputTextInEditMode();

      // eslint-disable-next-line default-case
      switch (event.keyCode) {
        case BGC.utils.KeyCodes.UP:
          nextElementToFocus = this.getPreviousRowCell();
          break;
        case BGC.utils.KeyCodes.DOWN:
          nextElementToFocus = this.getNextRowCell();
          break;
        case BGC.utils.KeyCodes.LEFT:
          nextElementToFocus = !isCurrentCellInEditMode && this.getPreviousCell();
          break;
        case BGC.utils.KeyCodes.RIGHT:
          nextElementToFocus = !isCurrentCellInEditMode && this.getNextCell();
          break;
      }

      event.stopPropagation();

      if (nextElementToFocus) {
        event.preventDefault();
        nextElementToFocus.focus().select();
      }
    },

    getNextRowCell () {
      const nextRow = this.getNextRow();
      const currentCellRelativeIndex = this.getCurrentCellElementRelativeIndex();

      return nextRow.find('input').eq(currentCellRelativeIndex);
    },

    getPreviousRowCell () {
      const previousRow = this.getPreviousRow();
      const currentCellRelativeIndex = this.getCurrentCellElementRelativeIndex();

      return previousRow.find('input').eq(currentCellRelativeIndex);
    },

    getNextCell () {
      const allCells = this.getAllCellElements();
      let currentCellIndex = allCells.index(this.getCurrentCellElement());

      currentCellIndex = this.getNextIndexIn(allCells, currentCellIndex);

      return allCells.eq(currentCellIndex);
    },

    getPreviousCell () {
      const allCells = this.getAllCellElements();
      let currentCellIndex = allCells.index(this.getCurrentCellElement());

      currentCellIndex = this.getPreviousIndexIn(allCells, currentCellIndex);

      return allCells.eq(currentCellIndex);
    },

    getNextRow () {
      return this.getAllRowElements().eq(this.getNextIndexIn(this.getAllRowElements(), this.getCurrentRowElementIndex()));
    },

    getPreviousRow () {
      return this.getAllRowElements().eq(this.getPreviousIndexIn(this.getAllRowElements(), this.getCurrentRowElementIndex()));
    },

    getCurrentCellElement () {
      return this.$el.find('input:focus');
    },

    getCurrentCellElementRelativeIndex () {
      return this.getCurrentRowElement().find('input').index(this.getCurrentCellElement());
    },

    getAllCellElements () {
      return this.$el.find('input');
    },

    getCurrentRowElement () {
      return this.getCurrentCellElement().parents(INSTRUMENT_ROW_SELECTOR);
    },

    getCurrentRowElementIndex () {
      return this.getAllRowElements().index(this.getCurrentRowElement());
    },

    getAllRowElements () {
      return this.$el.find(INSTRUMENT_ROW_SELECTOR);
    },

    getNextIndexIn (list, currentIndex) {
      return currentIndex < (list.length - 1) ? ++currentIndex : 0;
    },

    getPreviousIndexIn (list, currentIndex) {
      return currentIndex > 0 ? --currentIndex : list.length - 1;
    },

    isFocusedInputTextInEditMode () {
      const currentCell = this.getCurrentCellElement().get(0);
      let isTextSelected = false;
      let isEmpty = false;

      if (currentCell) {
        isTextSelected = currentCell.selectionStart === 0 && currentCell.selectionEnd === currentCell.value.length;
        isEmpty = !currentCell.value;
      }

      return !isEmpty && !isTextSelected;
    }
  };
}(window.BGC.ui.view));
