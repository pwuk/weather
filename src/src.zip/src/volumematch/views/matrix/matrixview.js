/* eslint-disable no-magic-numbers, func-names, no-plusplus, no-param-reassign, max-lines, id-length , max-statements, max-params, complexity, max-len */
/* global BGC: false, $: false, _:false, Backbone: false */

// /////////////////////////////////////////////////////////////////////////////
// file gridview.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

(function (context, resources, dataStore) {
  const {KeyCodes} = BGC.utils;
  const conditions = {};

  conditions[KeyCodes.LEFT] = {
    applies (cell) {
      return cell.x > 0;
    },
    nextPos (cell) {
      return {
        x : cell.x - 1,
        y : cell.y
      };
    }
  };

  conditions[KeyCodes.UP] = {
    applies (cell) {
      return cell.y > 0;
    },
    nextPos (cell) {
      return {
        x : cell.x,
        y : cell.y - 1
      };
    }
  };

  conditions[KeyCodes.RIGHT] = {
    applies (cell, cellViewCache) {
      return cell.x < cellViewCache.length - 1;
    },
    nextPos (cell) {
      return {
        x : cell.x + 1,
        y : cell.y
      };
    }
  };

  conditions[KeyCodes.DOWN] = {
    applies (cell, cellViewCache) {
      return cell.y < cellViewCache[0].length - 1;
    },
    nextPos (cell) {
      return {
        x : cell.x,
        y : cell.y + 1
      };
    }
  };

  function isSelectedCellOutsideScrollArea (cell) {
    const cellRect = cell.getBoundingClientRect();
    const containerRect = cell.offsetParent.getBoundingClientRect();

    // Allow part of cell (3px) to be outside without complaining
    const TOLERANCE = 3;

    if (((cellRect.bottom - containerRect.bottom) > TOLERANCE) ||
            ((containerRect.top - cellRect.top) > TOLERANCE) ||
            ((containerRect.left - cellRect.left > TOLERANCE) ||
            ((cellRect.right - containerRect.right) > TOLERANCE))) {
      return true;
    }

    return false;
  }

  /**
     * A view providing alternative way to select currently loaded linked matrices.
     *
     * @class
     */
  const MatrixSelectorView = Backbone.View.extend({
    template  : BGC.utils.queryTemplate('#matrix-selector'),
    className : 'matrix-selector',

    events : {
      'click button' : 'onSelectMatrix'
    },

    initialize (matrices, defaultLinkedMatrixIndex) {
      _.extend(this, context.NotificationFlashBehavior);
      this.matrices = matrices;
      this.currentMatrix = this.matrices[defaultLinkedMatrixIndex];

      this.thirdPartyInterests = this.matrices.map(matrix => ({
        matrixId           : matrix.matrixId,
        thirdPartyInterest : 0
      }));

      this.trades = this.matrices.map(matrix => ({
        matrixId    : matrix.matrixId,
        tradedCount : 0
      }));

      this.counter = 0;
    },

    render () {
      this.$el.html(this.template({
        matrices      : this.matrices,
        currentMatrix : this.currentMatrix
      }));

      this.$el.find(`[matrix-id=${this.currentMatrix.matrixId}]`)
        .addClass('active');

      this.thirdPartyInterests.forEach(function (matrixInterest) {
        const selector = this.$el.find(`[matrix-id=${matrixInterest.matrixId}]`);

        selector.find('.third-party-badge').text(matrixInterest.thirdPartyInterest || '');
      }, this);

      this.trades.forEach(function (trade) {
        const selector = this.$el.find(`[matrix-id=${trade.matrixId}]`);

        selector.find('.trade-count-badge').text(trade.tradedCount || '');
      }, this);

      return this;
    },

    updateThirdPartyInterest (matrixId, interestCount) {
      const matrixInterest = _.find(this.thirdPartyInterests, interest => interest.matrixId === matrixId);

      if (matrixInterest) {
        const matrixSelectorElement = this.$el.find(`[matrix-id=${matrixId}]`);
        const interestElement = matrixSelectorElement.find('.third-party-badge');

        // Update the interest count
        matrixInterest.thirdPartyInterest = interestCount;
        interestElement.text(interestCount || '');

        // And flash the notification
        this.flashNotification(this.EFlashType.eThirdPartyInterest, interestElement);
      }
    },

    updateTradeCount (matrixId, tradeCount) {
      const trade = _.find(this.trades, tradeItem => tradeItem.matrixId === matrixId);

      if (trade) {
        const matrixSelectorElement = this.$el.find(`[matrix-id=${matrixId}]`);
        const tradeCountElement = matrixSelectorElement.find('.trade-count-badge');

        // Update the trade count
        trade.tradedCount = tradeCount;
        tradeCountElement.text(tradeCount || '');

        // Flash the notification
        if (tradeCount > 0) {
          this.flashNotification(this.EFlashType.eTradeCount, tradeCountElement);
        }
      }
    },

    /**
         * Sets the currently selected linked matrix, so widget could
         * visually highlight it.
         *
         * @param {String} matrixId - id of the selected matrix
         * @method
         * @public
         */
    setCurrentMatrix (matrixId) {
      this.currentMatrix = _.findWhere(this.matrices, {
        matrixId
      });

      this.render();
    },

    /**
         * Handles internal event when a linked matrix is selected from
         * the widget itself.
         *
         * @method
         * @private
         */
    onSelectMatrix (event) {
      const matrixId = event.target.getAttribute('matrix-id');

      this.selectMatrix(matrixId);
    },

    selectMatrix (matrixId) {
      this.setCurrentMatrix(matrixId);
      this.trigger('selectMatrix', matrixId);
    }
  });

  /*
        new MatrixView({ model: new Matrix })
        Responsibility:
        - Render and manages matrix view
        - Handle communication between cell and in-place order entry view
    */
  context.MatrixView = Backbone.View.extend({
    template             : BGC.utils.queryTemplate('#matrix'),
    headerColumnTemplate : BGC.utils.queryTemplate('#matrix-header-columns'),
    className            : 'matrix',
    events               : {
      'click li.has-linked-matrix' : 'onHeaderColumnClicked',
      'click .collapse-toggle'     : 'toggleCollapsedState',
      'click .axis.x li .oco'      : 'toggleOCOState',
      'click .axis.y li .oco'      : 'toggleOCOState'
    },

    getAnimationDuration (animationFrequency) {
      const ANIMATION_CONST = BGC.ui.viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION;

      if (animationFrequency === ANIMATION_CONST.MAX) {
        return 1000;
      }

      return (ANIMATION_CONST.MAX - animationFrequency) * 1000;
    },

    /**
         * Retrieve all the cells that have an active order.
     * */
    getCellsWithActiveOrders (cellViewCache) {
      return _.filter(_.flatten(cellViewCache), item => item.cellHasActiveOrder());
    },

    /**
         * Whenever the user changes the animation frequency setting from the
         * settings panel, this function will be called. Debounce it in case
         * the user agresively changes it. It will retrieve all cells with
         * active orders and update the active order animation.
         */
    updateAnimations : _.debounce(function () {
      const cellsWithActiveOrders = this.getCellsWithActiveOrders(this.cellViewCache);
      const {length} = cellsWithActiveOrders;
      const currentAnimationFrequency = dataStore.userSettingsStore.get('orderAnimationDuration');

      for (let i = 0; i < length; i += 1) {
        cellsWithActiveOrders[i].updateAnimation(currentAnimationFrequency);
      }
    }, 100),

    /**
         * Function used to sychronize all the animations. Retrieves all the
         * cells with active order, iterate through all of them calling the
         * syncAnimation function (for more details take a look @vm-cell-view.js)
         * passing the previous cell.
         */
    syncAnimations : _.debounce(function () {
      const cellsWithActiveOrders = this.getCellsWithActiveOrders(this.cellViewCache);
      const {length} = cellsWithActiveOrders;

      for (let i = 0; i < length; i += 1) {
        const sibling = cellsWithActiveOrders[i - 1] || cellsWithActiveOrders[cellsWithActiveOrders.length - 1];

        if (cellsWithActiveOrders[i] !== sibling) {
          cellsWithActiveOrders[i].syncAnimation(sibling);
        }
      }
    }, 100),

    initialize (options) {
      _.extend(this, context.NotificationFlashBehavior);

      // set matrix id for DOM reference
      this.$el.attr('id', `matrix-view-${this.model.get('matrixId')}`);

      // set matrix attributes
      this.dataStore = options.dataStore;
      this.pageLayout = options.pageLayout;
      this.auctionId = this.model.auction.get('auctionId');

      // listen for changes in model attributes
      // this.model.on("change:active", this.activate, this);
      this.model.auction.on('change:runningState', this.updateActiveState, this);
      this.model.auction.on('change:showInterestAndTradeCount', this.showNotificationBadges, this);
      this.model.auction.on('change:startTime change:endTime change:timeOffset change:auctionPhase  change:phaseoneEndtime', this.updateProgress, this);

      if (dataStore.userSettingsStore.get('dynamicGridView')) {
        this.pageLayout.get('auctions').on('add', auction => {
          auction.on('change:runningInstrumentCount', this.enableDynamicGrid.bind(this));
        });
      }

      // this.pageLayout.on("change:contentState", this.activate, this);
      this.model.on('matrixHasInterest', this.onMatrixInterest, this);
      this.model.on('matrixInstrumentTraded', this.onMatrixInstrumentTraded, this);
      this.pageLayout.on('closeAllInstrumentViews', this.onCloseAll, this);
      this.model.on('orderExecutedOnMatrixInstrument', this.onOrderExecutedOnMatrixInstrument, this);

      dataStore.userSettingsStore.on('change:orderAnimationDuration', this.updateAnimations, this);
      dataStore.userSettingsStore.on('change:enableOCO', this.enableOCOBehaviour, this);

      dataStore.userSettingsStore.on('change:enableCentreOEDB', this.handleUserSettingChangeCentreOEDB, this);
      this.handleUserSettingChangeCentreOEDB();


      this.attachTooltipMouseEvents(this.$el);

      // render and activate the view
      this.render();
      this.onMatrixInterest();
      this.onMatrixInstrumentTraded();
      this.updateActiveState();
      this.enableOCOBehaviour();

      // disable drag and drop in broker mode
      if (this.pageLayout.get('isEditable')) {
        this.$el.find('.axis.x').attr('draggable', false);

        // create context menu on header rows in broker mode only
        this.createRowsContextMenu();
      }
    },

    render () {
      const gridElement = this.$el.find('.grid');

      // render matrix template
      this.$el.html(this.template(this.model.toJSON()));
      gridElement.prepend(this.getHeaderHtmlElementForMatrix(this.model));

      // build matrix cell views
      this.cellViewCache = this.buildCellViewMatrix(this.model.getCells(), this);
      gridElement.append(this.getDataHtmlElementForMatrix(this.model));

      // if the matrix has linked triangle matrices
      if (this.hasLinkedMatrices()) {
        // display the first linked matrix by default
        this.openFirstLinkedMatrix();

        // if there are multiple linked matrices, create a selector view
        if (this.model.get('linkedMatrices').length > 1) {
          this.createMatrixSelector();
        }

        this.appendRowHeadersToLinkedMatrices();
      }

      $('body').on('keydown', {
        gridViewContext : this
      }, this.onBodyKeyDown);
    },

    updateActiveState () {
      const progressBar = this.el.querySelector('progress-bar');
      const runningState = this.model.auction.get('runningState');
      const shouldBeOpen = this.model.auction.get('runningState') !== this.model.auction.EContentState.eNone;

      if (runningState !== this.model.auction.get('prevRunningState')) {
        if (shouldBeOpen) {
          progressBar.setAttribute('message', this.model.auction.get('orderPhaseText'));
          progressBar.updateProgress();

          this.openMatrix();
        } else {
          progressBar.setAttribute('message', '');
          this.closeMatrix();
        }
      }

      if (runningState) {
        this.$el.addClass('is-active');
      } else {
        this.$el.removeClass('is-active');
      }

      this.showNotificationBadges();
      this.onMatrixInterest();
      this.onMatrixInstrumentTraded();

      this.$el.trigger('recalcLayout');
    },

    hasLinkedMatrices () {
      return this.model.get('linkedMatrices').length;
    },

    showNotificationBadges () {
      this.$el.toggleClass('no-notifications', !this.model.auction.get('showInterestAndTradeCount'));
    },

    updateProgress () {
      const progressBar = this.el.querySelector('progress-bar');

      if (progressBar) {
        progressBar.setAttribute('start-time', this.model.auction.get('startTime'));
        progressBar.setAttribute('end-time', this.model.auction.get('endTime'));
        progressBar.setAttribute('time-offset', this.model.auction.get('timeOffset'));
        progressBar.setAttribute('auction-Phase', this.model.auction.get('auctionPhase'));
        progressBar.setAttribute('phaseoneend-time', this.model.auction.get('phaseoneEndtime'));
      }
    },

    /**
         * Creates a view containing custom buttons to select currently loaded linked matrices.
         */
    createMatrixSelector () {
      /**
             * Simplifies domain model to parameters that are only needed
             * in the matrix selector view.
             */
      function transformToSelectorModel (matrices) {
        return matrices.filter(matrix => !_.isUndefined(matrix.get('columnLinkIndex')))
          .map(matrix => ({
            title    : matrix.get('matrixName'),
            matrixId : matrix.get('matrixId')
          }));
      }

      const matrixSelector = new MatrixSelectorView(transformToSelectorModel(this.model.get('linkedMatrices')), this.model.get('defaultLinkedMatrixIndex'));

      // add view element to the matrix grid just before the first linked matrix element
      matrixSelector.render().$el.insertBefore(this.$el.find('.linked-matrix-triangle').eq(0));

      // change the currently selected linked matrix in the main matrix grid when an event comes
      // from the selector widget
      matrixSelector.on('selectMatrix', function (matrixId) {
        const linkedMatrix = this.model.get('linkedMatrices').findWhere({
          matrixId
        });

        if (linkedMatrix) {
          this.openLinkedMatrixForColumn(this.$el.find(`[data-link-index='${linkedMatrix.get('columnLinkIndex')}']`));
        }
      }, this);

      // change the currently selected matrix in the selector view when a linked matrix is selected in the main matrix grid
      // by clicking on an outright column header
      this.on('linkedMatrixSelected', matrixId => {
        matrixSelector.setCurrentMatrix(matrixId);
      });

      // Update interest count for each matrix selector
      this.model.on('matrixHasInterest', thirdPartyInterests => {
        thirdPartyInterests.forEach(matrixInterest => {
          matrixSelector.thirdPartyInterests.forEach(currentMatrixInterest => {
            if (matrixInterest.matrixId === currentMatrixInterest.matrixId && matrixInterest.thirdPartyInterest !== currentMatrixInterest.thirdPartyInterest) {
              matrixSelector.updateThirdPartyInterest(matrixInterest.matrixId, matrixInterest.thirdPartyInterest);
            }
          });
        });
      });

      this.model.on('matrixInstrumentTraded', trades => {
        trades.forEach(matrixTrade => {
          matrixSelector.trades.forEach(currentMatrixTrade => {
            if (matrixTrade.matrixId === currentMatrixTrade.matrixId && matrixTrade.tradedCount !== currentMatrixTrade.tradedCount) {
              matrixSelector.updateTradeCount(matrixTrade.matrixId, matrixTrade.tradedCount);
            }
          });
        });
      });

      this.on('openLinkedMatrix', matrixId => {
        matrixSelector.selectMatrix(matrixId);
      });

      // insert empty column header for the matrix selector
      $('<div/>', {
        class : 'empty-header-column matrix-selector-header'
      }).insertAfter(this.$el.find('.axis.x .main-matrix-header').eq(0));

      // Force initial update of interest and trade counts in the selector
      this.model.trigger('matrixHasInterest', this.model.getInterestCountForLinkedMatrices());
      this.model.trigger('matrixInstrumentTraded', this.model.getTradedCountForLinkedMatrices());
    },

    /**
         * Add row headers containing the same content as the main matrix row headers to linked matrices.
         */
    appendRowHeadersToLinkedMatrices () {
      const emptyColumn = $('<div/>', {
        class : 'empty-column'
      });
      const mainMatrixRowHeaders = this.model.get('y');

      // For standard triangle layouts, add row header element to the empty column that gets injected
      // into every linked matrix and contains header of the first row
      if (!this.model.isInvertedTriangleLayout()) {
        emptyColumn.append($('<div/>', {
          class : 'cell row-header',
          html  : mainMatrixRowHeaders[0]
        }));
      }

      // add headers for the empty columns
      this.$el.find('.linked-matrix-header').prepend($('<div/>', {
        class : 'empty-header-column'
      }));

      // add empty column to all linked matrices
      this.$el.find('.linked-matrix-triangle').prepend(emptyColumn);

      if (this.model.isInvertedTriangleLayout()) {
        // If this an inverted triangle, style the last empty cells in each column as row headers
        this.$el.find('.linked-matrix-triangle .column vm-cell-view.empty:has( + vm-cell-view:not( .empty ) )')
          .addClass('row-header');
      } else {
      // Otherwise, this is a standard triangle, style empty cells that are below the last not empty instrument cells as row headers
        this.$el.find('.linked-matrix-triangle .column vm-cell-view:not( .empty ) + vm-cell-view.empty')
          .addClass('row-header');
      }
    },

    /**
         * Creates html element containing column headers for the given matrix and
         * it's linked matrices.
         */
    getHeaderHtmlElementForMatrix (matrix) {
      const matrixHeader = this.$el.find('.axis.x');
      // eslint-disable-next-line consistent-this
      const self = this;

      // first add header columns of the main matrix
      matrixHeader.append($(this.headerColumnTemplate({
        x : matrix.get('x')
      })));

      // use flex to set proportion of header taken by the 'main matrix'
      matrixHeader.find('ul').addClass('main-matrix-header').css('flex', matrix.get('x').length.toString());

      // then append header columns of all linked matrices to the end of the matrix header element
      matrix.get('linkedMatrices').each(linkedMatrix => {
        const linkColumnIndex = linkedMatrix.get('columnLinkIndex');
        const linkedMatrixHeader = $(self.headerColumnTemplate({
          x : linkedMatrix.get('x')
        }));

        linkedMatrixHeader.addClass('linked-matrix-header')

        // this data attribute is a helper that allows querying the element by link column index from the
        // parent DOM tree
          .attr('data-linked-to-index', linkColumnIndex)

        // use flex to set proportion of header taken by each 'linked matrix'
          .css('flex', String(linkedMatrix.get('x').length + 1));

        matrixHeader.append(linkedMatrixHeader);

        matrixHeader.find('ul:not( .linked-matrix-header ) li').eq(linkColumnIndex)

        // this data attribute tells which column index is assigned to the column
          .attr('data-link-index', linkColumnIndex)
          .addClass('has-linked-matrix');
      });

      // assign column classes
      matrixHeader.find('li').each(function (index) {
        $(this).addClass(`tick-${index}`);
      });

      return matrixHeader;
    },

    /**
         * Creates html element containing data columns for the given matrix
         * and it's linked matrices.
         */
    getDataHtmlElementForMatrix (matrix) {
      const dataElement = this.$el.find('.data');
      let currentColumIndex = 0;
      // eslint-disable-next-line consistent-this
      const self = this;
      const getColumnElement = function (column) {
        const columnElement = $('<div/>', {
          class : `column column-${currentColumIndex}`
        });
        const cellsForColumn = column.map((cell, cellIndex) => self.cellViewCache[currentColumIndex][cellIndex]);

        columnElement.html(cellsForColumn);
        currentColumIndex++;

        return columnElement;
      };

      // first add columns of the main matrix
      matrix.get('cells').forEach(column => {
        dataElement.append(getColumnElement(column));
      });

      // then append data columns of all linked matrices
      matrix.get('linkedMatrices').each(linkedMatrix => {
        const linkColumnIndex = linkedMatrix.get('columnLinkIndex');
        const linkedMatrixGrid = $('<div/>', {
          class : 'linked-matrix-triangle'
        });

        // this data attribute is a helper that allows querying the element by link column index from the parent DOM tree
        linkedMatrixGrid.attr('data-linked-to-index', linkColumnIndex);

        dataElement.find('.column').eq(linkColumnIndex)

        // this data attribute tells which column index is assigned to the column
          .attr('data-link-index', linkColumnIndex)
          .addClass('has-linked-matrix');

        linkedMatrix.get('cells').forEach(column => {
          linkedMatrixGrid.append(getColumnElement(column));
        });

        // use flex to set proportion of main matrix taken by each 'linked matrix'
        linkedMatrixGrid.css('flex', String(linkedMatrix.get('x').length + 1));

        dataElement.append(linkedMatrixGrid);
      });
    },

    buildCellViewMatrix (cells, gridView) {
      const matrixColumnHeaders = this.model.get('y');
      const linkedMatricesCount = this.hasLinkedMatrices();
      const outrightProducts = this.model.get('x');

      return cells.map((column, columnIndex) => column.map((cell, cellIndex) => {
        let matrixColumnHeader = null;

        // This code (which was added for the Polymer 3 upgrade) is attempting to mark the header cells. We need to refactor this design as it does not
        // extend well to the multiple matrix or inverted layout use cases.

        // Header cells are positioned diagonally, above or below the data cells, depending upon whether the layout is inverted.
        if (linkedMatricesCount === 1) {
          if (this.model.isInvertedTriangleLayout()) {
            if (columnIndex === cellIndex + 1) {
              matrixColumnHeader = matrixColumnHeaders[cellIndex];
            }
          } else if (cellIndex > 0 && columnIndex === cellIndex) {
            matrixColumnHeader = matrixColumnHeaders[cellIndex];
          }
        } else if (linkedMatricesCount > 1) {
          // multi triangle matrix outright products - does not support inverted layout
          if (cellIndex > 0) {
            // First outright product, outrightProducts effect the beginning of the spread header column
            // columnIndex start from 0, therefore add back 1
            if (cellIndex === columnIndex - outrightProducts.length + 1) {
              matrixColumnHeader = matrixColumnHeaders[cellIndex];
            } else if (columnIndex > matrixColumnHeaders.length) {
              // Handle other outright product
              if (cellIndex === (columnIndex - outrightProducts.length + linkedMatricesCount) % matrixColumnHeaders.length) {
                matrixColumnHeader = matrixColumnHeaders[cellIndex];
              }
            }
          }
        }

        return new context.VmCellView({
          model       : cell,
          gridView,
          x           : columnIndex,
          y           : cellIndex,
          cellContent : matrixColumnHeader
        });
      }, this), this);
    },

    onHeaderColumnClicked (event) {
      this.openLinkedMatrixForColumn($(event.currentTarget));
    },

    openFirstLinkedMatrix () {
      this.openLinkedMatrixForColumn(this.$el.find('.axis.x .has-linked-matrix').eq(0));
    },

    openLinkedMatrixForColumn (columnElement) {
      const linkIndex = columnElement.attr('data-link-index');
      const linkedMatrix = this.model.get('linkedMatrices').findWhere({
        columnLinkIndex : parseInt(linkIndex, 10)
      });

      // close current linked matrix and open new one
      this.$el.find('.is-open:not(.layout)').removeClass('is-open');
      this.$el.find(`[data-link-index='${linkIndex}']`).addClass('is-open');
      this.$el.find(`[data-linked-to-index='${linkIndex}']`).addClass('is-open');

      // notify interested subscribers about linked matrix being selected
      this.trigger('linkedMatrixSelected', linkedMatrix.get('matrixId'));
    },

    highlightCell (x, y) {
      const cellComponent = this.$el.find('.column').eq(x).find('vm-cell-view').eq(y);
      const cellToHighlight = $(cellComponent[0].shadowRoot).find('.cell .tile');
      const previousCellComponent = this.$el.find('.is-selected').removeClass('is-selected');

      if (previousCellComponent.length === 1) {
        $(previousCellComponent[0].shadowRoot).find('.cell .tile').removeClass('is-selected cell-highlight cell-selection');
      }

      // make sure that any previously applied selection style to any cell is removed
      cellToHighlight.addClass('is-selected cell-highlight cell-selection');
      cellComponent.addClass('is-selected');

      // clear existing axis highlights
      this.$el.find('.axis li').removeClass('highlighted-axis');
      this.$el.find('.row-header').removeClass('highlighted-axis');

      // highlight row and column headers of selected cell
      this.$el.find('.axis.x li').eq(x).addClass('highlighted-axis');
      this.$el.find('.axis.y li').eq(y).addClass('highlighted-axis');
      this.$el.find('.axis.y.second-y-ax li').eq(y).addClass('highlighted-axis');

      cellComponent.parents('.linked-matrix-triangle').find('.row-header').eq(y).addClass('highlighted-axis');
    },

    highlightDraggedCellHeaders (x, y) {
      this.clearDraggingStyles();
      this.$el.find('.axis.x li').eq(x).addClass('highlighted-dragover-axis');
      this.$el.find('.axis.y li').eq(y).addClass('highlighted-dragover-axis');
    },

    clearDraggingStyles () {
      this.$el.find('.cell-dragover').removeClass('cell-dragover');
      this.$el.find('.axis li').removeClass('highlighted-axis highlighted-dragover-axis');

      // restore selected cell highlight row and column headers
      if (this.selectedCell) {
        this.$el.find('.axis.x li').eq(this.selectedCell.x).addClass('highlighted-axis');
        this.$el.find('.axis.y li').eq(this.selectedCell.y).addClass('highlighted-axis');
      }
    },

    selectCell (x, y, displayOEB, ensureCellIsVisible) {
      const inPlaceOrderEntry = context.inplaceOEB.getInstance();

      if (inPlaceOrderEntry.isOpen) {
        inPlaceOrderEntry.hide();
      }

      BGC.ui.viewUtils.setSelectionLockedFlag(this.$el[0], true);

      // select and highlight cell
      this.selectedCell = this.cellViewCache[x][y];

      if (ensureCellIsVisible) {
        // ensure the matrix tile is open.
        this.openMatrix();
        this.$el.trigger('recalcLayout');

        const matrix = this.model.get('linkedMatrices').findWhere({
          matrixId : this.selectedCell.model.get('tileId')
        });

        if (matrix) {
          // select the linked matrix: trigger a event to be hd by the matrix selector widget.
          this.trigger('openLinkedMatrix', matrix.get('matrixId'));
        }

        // attempt this call after the recalcLayout timeout.
        this.scrollToSelectedCell();
      }

      this.highlightCell(x, y);

      // If the current selection is owned by us, we don't need to react to "selectionChanging" when we set
      // the new selection, because we are handling all that ourselves already
      if (BGC.ui.selectionManager.getSelectedView() === this) {
        this.stopListening(BGC.ui.selectionManager, 'selectionChanging');
      }

      // trigger tile instrument selection change
      this.$el.trigger('selectInstrument', [this, this.selectedCell.model]);

      // and listen for de-selection event
      this.listenToOnce(BGC.ui.selectionManager, 'selectionChanging', this.clearSelection);

      if (displayOEB) {
        this.openOEBPopup(this.selectedCell);
      }
    },

    scrollToSelectedCell () {
      // attempt to scroll to the instrument row after the recalclayout which invalidates the current scroll position.
      if (this.pageLayout.get('isLayoutRecalcPending')) {
        this.pageLayout.once('change:isLayoutRecalcPending', function () {
          window.setTimeout(() => {
            if (this.selectedCell && this.selectedCell.model.isInAuction()) {
              this.selectedCell.scrollIntoView();
            }
          }, 200);
        }, this);
      } else {
        this.selectedCell.scrollIntoView();
      }
    },

    selectInstrument (instrument, suppressOEB) {
      this.selectCell(instrument.get('xIndex'), instrument.get('yIndex'), !suppressOEB);
    },

    clearSelection (lockSelection) {
      const inplaceOEB = context.inplaceOEB.getInstance();

      // remove selected cell highlighting
      this.$el.find('.cell-highlight').removeClass('cell-highlight');
      this.$el.find('.cell-selection').removeClass('cell-selection');
      this.$el.find('.axis li').removeClass('highlighted-axis');
      this.$el.find('.cell .tile').removeClass('is-selected');

      // clear selected cell
      if (this.selectedCell) {
        if (inplaceOEB.isOpen && inplaceOEB.getInstrumentId() === this.selectedCell.model.get('instrumentId')) {
          inplaceOEB.hide();
        }
        this.selectedCell = undefined;
      }

      // lock selection
      if (lockSelection) {
        BGC.ui.viewUtils.setSelectionLockedFlag(this.$el[0], true);
      }
    },

    openOEBPopup (cellView, side) {
      const instrument = cellView.model.serialize();
      const inPlaceOrderEntry = context.inplaceOEB.getInstance();

      inPlaceOrderEntry.show({
        instrument,
        activeOrder        : instrument.ownOrder,
        moveableMidEnabled : this.pageLayout.isMoveableMidEnabled(),
        grid               : this
      }, {
        sizeValidationCallback       : cellView.model.validateSize.bind(cellView.model),
        bidPriceValidationCallback   : cellView.model.validateBidPrice.bind(cellView.model),
        offerPriceValidationCallback : cellView.model.validateOfferPrice.bind(cellView.model),
        nudgeCallback                : cellView.model.nudgePriceWithRangeValidation.bind(cellView.model),
        priceFormatter               : cellView.model.formatPrice.bind(cellView.model)
      },
      side ? inPlaceOrderEntry.ETradeSide[side] : inPlaceOrderEntry.ETradeSide.eBoth,
      cellView.el.cell,
      cellView);
    },

    /**
         * Gets coordinates of the given cell and marks it as selected in the grid.
         */
    selectCellByElement (cell, displayOEB, ensureCellIsVisible) {
      this.selectCell(cell.x, cell.y, displayOEB, ensureCellIsVisible);
    },

    /**
         * Functions below have an event context, the gridView can be accessed
         * via event.data.gridViewContext
         */
    // eslint-disable-next-line consistent-return
    onBodyKeyDown (event) {
      const gridView = event.data.gridViewContext;
      let nextElement = null;
      let nextElemPos = null;

      if (gridView === undefined || gridView.selectedCell === undefined || $('body').hasClass('overlaid')) {
        return true;
      }

      const cell = gridView.selectedCell;

      switch (event.keyCode) {
        case KeyCodes.LEFT:
        case KeyCodes.UP:
        case KeyCodes.RIGHT:
        case KeyCodes.DOWN:
          if (conditions[event.keyCode].applies(cell, gridView.cellViewCache)) {
            nextElemPos = conditions[event.keyCode].nextPos(cell);
            nextElement = gridView.cellViewCache[nextElemPos.x][nextElemPos.y];

            // Select the next cell WITHOUT re-displaying any open OEB
            gridView.selectCellByElement(nextElement);

            if (!isSelectedCellOutsideScrollArea(cell)) {
              event.preventDefault();
            }
          }
          break;
        case KeyCodes.F6:
          if (!gridView.selectedCell.model.get('inactive') && gridView.selectedCell.model.get('canUserEnterOrders')) {
            gridView.openOEBPopup(gridView.selectedCell, 'buy');
          }
          event.preventDefault();
          break;
        case KeyCodes.F7:
          if (!gridView.selectedCell.model.get('inactive') && gridView.selectedCell.model.get('canUserEnterOrders')) {
            gridView.openOEBPopup(gridView.selectedCell, 'sell');
          }
          event.preventDefault();
          break;
        case KeyCodes.ENTER:
          if (!gridView.selectedCell.model.get('inactive') && gridView.selectedCell.model.get('canUserEnterOrders')) {
            gridView.openOEBPopup(gridView.selectedCell);
          }
          event.preventDefault();
          break;
        default:
          break;
      }
    },

    toggleCollapsedState () {
      this.$el.find('.layout').toggleClass('is-open');
      this.$el.trigger('recalcLayout');
    },

    openMatrix () {
      this.$el.find('.layout').addClass('is-open');
      this.$el.trigger('recalcLayout');
    },

    closeMatrix () {
      this.$el.find('.layout').removeClass('is-open');
      this.$el.trigger('recalcLayout');
    },

    onCloseAll (exceptInstrument) {
      if (exceptInstrument) {
        if (!this.model.findInstrumentById(exceptInstrument.get('instrumentId'))) {
          this.closeMatrix();
        }
      } else {
        this.closeMatrix();
      }
    },

    onMatrixInterest () {
      const interestCount = this.model.getInterestCount();
      const interestCountText = interestCount ? interestCount.toString() : '';
      const badge = this.$el.find('.axis.y .notifications .third-party-badge');

      if (this.interest !== interestCountText) {
        this.interest = interestCountText;
        badge.text(interestCountText);

        if (interestCount) {
          this.flashNotification(this.EFlashType.eThirdPartyInterest, badge);
        }
      }
    },

    handleUserSettingChangeCentreOEDB () {
      // Add centreOEDB class to body, main and InplaceOrderEntry to apply different css styling to support


      if (this.dataStore.userSettingsStore.get('centreOEDB') && this.dataStore.userSettingsStore.get('enableCentreOEDB')) {
        $(document.body).addClass('centreOEDB');
        $('.main').addClass('centreOEDB');
      } else {
        $(document.body).removeClass('centreOEDB');
        $('.main').removeClass('centreOEDB');
      }
    },

    enableOCOBehaviour () {
      if (this.dataStore.userSettingsStore.get('allowVMOCO')) {
        // Show-Hide Row OCO button
        this.$el.find('.axis.y li .oco').toggleClass('enableOCO', !!this.dataStore.userSettingsStore.get('enableOCO'));

        // Show-Hide Col OCO button
        this.$el.find('.axis.x li .oco').toggleClass('enableOCO', !!this.dataStore.userSettingsStore.get('enableOCO'));

        // Adjust min width for col header to accomodate "OCO" button
        this.$el.find('.axis.x li').toggleClass('flex-for-oco', !!this.dataStore.userSettingsStore.get('enableOCO'));
        this.$el.find('.axis.x .empty-header-column').toggleClass('flex-for-oco', !!this.dataStore.userSettingsStore.get('enableOCO'));
      }
    },

    toggleOCOState (event) {
      this.$el.find(event.currentTarget).toggleClass('selected');
    },

    onOrderExecutedOnMatrixInstrument (instrument) {
      if (this.dataStore.userSettingsStore.get('allowVMOCO') && this.dataStore.userSettingsStore.get('enableOCO') && instrument && instrument.length !== 0) {
        // column OCO button
        // View indexing is diffrent than data model indexing, So "+1" has to add to get the correct view index
        const colOCOBtnSelector = `.axis.x li.tick-${instrument.get('xIndex') + 1} .oco`;
        const hasColOCOBtnSelected = this.$el.find(colOCOBtnSelector).hasClass('selected');

        // row OCO button
        const rowOCOBtnSelector = `.axis.y li.tick-${instrument.get('yIndex')} .oco`;
        const hasRowOCOBtnSelected = this.$el.find(rowOCOBtnSelector).hasClass('selected');

        // Check if change event is for "order execution"
        const executionOrderDetails = this.hasOrderExecuted(instrument);

        // Execute OCO for BUY or SELL or both ,If instrument change event is for "Order execution" and OCO btn is toggled on.
        if (executionOrderDetails.hasOrderExecuted && (hasColOCOBtnSelected || hasRowOCOBtnSelected)) {
          BGC.logger.logInformation('MatrixView', `Order cancel order (OCO) event triggerd for instrument [${instrument.getLogDescStr()}].`);

          // Get all instruments on the row & col to execute OCO Excluding instrument on which order is exeucted
          this.model.getInstruments().filter(inst => {
            const executeColOCO = hasColOCOBtnSelected && inst.get('xIndex') === instrument.get('xIndex');
            const executeRowOCO = hasRowOCOBtnSelected && inst.get('yIndex') === instrument.get('yIndex');

            return (executeColOCO || executeRowOCO) && inst.get('instrumentId') !== instrument.get('instrumentId');
          }).forEach(rowInstrument => {
            if (this.dataStore.userSettingsStore.get('ocoBidAndOfferSpecific')) {
              if (executionOrderDetails.hasBuyOrderExecuted) {
                rowInstrument.sendCancelOrder('OCO', 'buy');
              } else {
                rowInstrument.sendCancelOrder('OCO', 'sell');
              }
            } else {
              rowInstrument.sendCancelOrder('OCO', 'buy');
              rowInstrument.sendCancelOrder('OCO', 'sell');
            }
          });
        }
      }
    },

    // Below function determines if the change event on instrument model is because of instrument traded in auction.
    // So any of the listener on instrument change event can call this function to determine if change event is for instrument traded in auction.
    // On change event backbone provides previous attributes state and new attributes state, So using this data below code determines if instrument is traded or not.
    hasOrderExecuted (instrument) {
      let hasOrderExecuted = false;
      let hasBuyOrderExecuted = false;

      if (instrument.getActiveOrder()) {
        const {buy, sell} = instrument.getActiveOrder().attributes;

        // Check if order executed on Buy side
        const prevBuy = buy ? buy.previousAttributes() : undefined;

        if (buy && prevBuy && (buy.get('boughtSize') !== 0 && buy.get('boughtSize') > prevBuy.boughtSize)) {
          hasOrderExecuted = true;
          hasBuyOrderExecuted = true;
        }

        // Check if order executed on Sell side
        const prevSell = sell ? sell.previousAttributes() : undefined;

        if (sell && prevSell && (sell.get('soldSize') !== 0 && sell.get('soldSize') > prevSell.soldSize)) {
          hasOrderExecuted = true;
          hasBuyOrderExecuted = false;
        }
      }

      return {hasOrderExecuted, hasBuyOrderExecuted};
    },

    onMatrixInstrumentTraded () {
      const tradeCount = this.model.getTradedCount();
      const tradeCountText = tradeCount ? tradeCount.toString() : '';
      const tradeCountElement = this.$el.find('.axis.y .trade-count-badge');

      if (this.tradeCount !== tradeCountText) {
        this.tradeCount = tradeCountText;
        tradeCountElement.text(tradeCountText);

        this.flashNotification(this.EFlashType.eTradeCount, tradeCountElement);
      }
    },

    /**
         * Creates a context menu and attaches it to row headers.The menu contains following actions:
         * - insert a row before
         * - insert a row after
         * - edit row
         * - remove row
         *
         * @method
         */
    createRowsContextMenu () {
      const matrixEditor = new BGC.ui.LayoutEditor(this.model.get('matrixId'), 'Matrix');
      const disableRemoveItem = this.model.get('y').length < 3;
      const rowHeaderSelector = '.axis.y li';

      // creates a menu item element containing font awesome icon
      const createElementWithIcon = function (icon) {
        return function (trigger, id, item) {
          const itemTemplate = _.template($('#menu-item-with-icon').html())({
            icon,
            title : item.name
          });

          item.$node.html(itemTemplate);
        };
      };

      // executes given callback with row details returned by menu item callback
      const executeWithRowDetails = function (actionCallback) {
        return function (key, options) {
          const rowIndex = options.$trigger.attr('data-row-index');
          const rowTitle = options.$trigger.text().replace('OCO', '');

          return actionCallback(rowIndex, rowTitle);
        };
      };

      this.$el.contextMenu({
        selector : rowHeaderSelector,
        items    : {
          before : {
            name     : resources.IDS_MENU_ITEM_INSERT_BEFORE,
            icon     : createElementWithIcon('toggle-up'),
            callback : executeWithRowDetails(matrixEditor.createRowBefore.bind(matrixEditor))
          },

          after : {
            name     : resources.IDS_MENU_ITEM_INSERT_AFTER,
            icon     : createElementWithIcon('toggle-down'),
            callback : executeWithRowDetails(matrixEditor.createRowAfter.bind(matrixEditor))
          },

          edit : {
            name     : resources.IDS_MENU_ITEM_EDIT_ROW,
            icon     : createElementWithIcon('edit'),
            callback : executeWithRowDetails(matrixEditor.editRow.bind(matrixEditor))
          },

          remove : {
            name     : resources.IDS_MENU_ITEM_REMOVE_ROW,
            icon     : createElementWithIcon('minus-circle'),
            disabled : disableRemoveItem,
            callback : executeWithRowDetails(matrixEditor.removeRow.bind(matrixEditor))
          }
        }
      });
    },

    enableDynamicGrid : _.debounce(function () {
      const runningState = this.model.auction.get('runningState');

      if (runningState && BGC.dataStore.userSettingsStore.get('dynamicGridView')) {
        // Monitor auction status to update instruments cell styling
        this.resetInactiveInstrumentsStyling();

        // Monitor auction status to update instruments cell styling
        this.hideInactiveInstruments();
      } else {
        this.resetInactiveInstrumentsStyling();
      }
      this.$el.trigger('recalcLayout');
    }, 250),

    hideInactiveInstruments : _.debounce(function () {
      const outrightInstruments = this.model.get('cells');
      const outrightProducts = this.model.get('x');
      const linkedMatrices = this.model.get('linkedMatrices');
      const activeInstruments = [];
      const inactiveInstruments = [];
      const matrixElements = document.getElementsByClassName('matrix');

      // Filter activeInstruments and inactiveInstruments for outrightInstruments in different outright section
      // To determine an outright as inactiveInstruments require instruments with the same tenor state is inactive in all outright section
      // To determine an outright as activeInstruments require either one or more instrument with same trnor state is active
      outrightInstruments[0].forEach((outright, idx) => {
        const outrightGroupByTenor = [];

        for (let outrightSection = 0; outrightSection < linkedMatrices.length; outrightSection++) {
          outrightGroupByTenor.push(outrightInstruments[outrightSection][idx]);
        }

        const inactiveOutrightInstruments = outrightGroupByTenor.filter(instrument => instrument.attributes.state === 'inactive');

        if (inactiveOutrightInstruments.length === linkedMatrices.length) {
          inactiveInstruments.push(outright);
        } else {
          activeInstruments.push(outright);
        }
      });

      matrixElements[0].classList.add('instrument-highlight');

      // If matrix has less than 8 rows we are hiding the spread title based on not enough space
      if (activeInstruments.length <= 8) {
        const spreadTitleElements = document.getElementsByClassName('matrix-selector');

        spreadTitleElements[0].classList.add('remove-title');
      }

      // Pick up the inactive outright instrumnets to add inactive class to hide the row and column
      inactiveInstruments.forEach(instrument => {
        const {attributes} = instrument;
        const {yIndex : instrumentIdx} = attributes;
        const outrightHeaderElements = document.getElementsByClassName(`tick-${instrumentIdx}`);

        // Hide inactive outright matrix header
        outrightHeaderElements[0].classList.add('inactive-cell');
        outrightHeaderElements[2].classList.add('inactive-cell');

        // Hide inactive outright matrix instruments
        for (let rowIdx = 0; rowIdx < outrightProducts.length; rowIdx++) {
          const rowClasses = document.getElementsByClassName(`cell-x-${rowIdx}`);

          rowClasses[instrumentIdx].classList.add('inactive-cell');
        }

        // Called hideInactiveSpreadMatrixInstruments to handle the spread matrix instruments
        this.hideInactiveSpreadMatrixInstruments(instrumentIdx);
      });
    }, 250),

    hideInactiveSpreadMatrixInstruments (instrumentIdx) {
      const outrightInstruments = this.model.get('cells');
      const outrightProducts = this.model.get('x');
      const linkedMatricesCount = this.hasLinkedMatrices();
      const columnLength = outrightInstruments[0].length * linkedMatricesCount;

      // instrumentIdx 0 refering to empty column amd header on spread matrix class name
      if (instrumentIdx === 0) {
        const activeInstruments = outrightInstruments[0].filter(instrument => instrument.attributes.state === 'active');
        const emptyColumnElements = document.getElementsByClassName('empty-column');
        const firstActiveInstrument = activeInstruments[0];
        const yIndex = firstActiveInstrument ? firstActiveInstrument.attributes.yIndex : 1;

        // Add "inactive-cell" to all linked matrices empty column
        for (let linkedMatrixIdx = 0; linkedMatrixIdx < emptyColumnElements.length; linkedMatrixIdx++) {
          emptyColumnElements[linkedMatrixIdx].classList.add('inactive-cell');
        }

        // instrumentIdx 0 have no header, therefore we need to inactive the first active header
        for (let linkedMatrixIdx = 0; linkedMatrixIdx < linkedMatricesCount; linkedMatrixIdx++) {
          const spreadInstrumentIdx = yIndex + linkedMatricesCount + ((outrightInstruments[0].length - 1) * linkedMatrixIdx);
          const firstMatrixHeaderElements = document.getElementsByClassName(`tick-${spreadInstrumentIdx}`);

          // Add inactive outright header on matrix grid
          if (spreadInstrumentIdx < outrightInstruments[0].length) {
            firstMatrixHeaderElements[1].classList.add('inactive-cell');
          } else {
            firstMatrixHeaderElements[0].classList.add('inactive-cell');
          }
        }
      } else {
        for (let linkedMatrixIdx = 0; linkedMatrixIdx < linkedMatricesCount; linkedMatrixIdx++) {
          // instrumentIdx refering to outright matrix, therefore need to add linkedMatricesCount to get the correct spread matrix index value
          const spreadInstrumentIdx = instrumentIdx + linkedMatricesCount + ((outrightInstruments[0].length - 1) * linkedMatrixIdx);
          const matrixHeaderElements = document.getElementsByClassName(`tick-${spreadInstrumentIdx}`);
          const columnElements = document.getElementsByClassName(`column-${spreadInstrumentIdx}`);

          // Add inactive outright header on matrix grid
          if (spreadInstrumentIdx < outrightInstruments[0].length) {
            matrixHeaderElements[1].classList.add('inactive-cell');
          } else {
            matrixHeaderElements[0].classList.add('inactive-cell');
          }

          // Add "inactive-cell" to spread column - spread instrument start with the inactive outright
          columnElements[0].classList.add('inactive-cell');
        }
      }

      // Hide inactive spread instrument on matrix grid
      for (let rowIdx = outrightProducts.length; rowIdx <= columnLength; rowIdx++) {
        const rowElements = document.getElementsByClassName(`cell-x-${rowIdx}`);

        // Last outright instrument row do not have spread instruments
        if (instrumentIdx < outrightInstruments[0].length - 1) {
          rowElements[instrumentIdx].classList.add('inactive-cell');
        }
      }
    },

    resetInactiveInstrumentsStyling () {
      // When auction end collect all the class that include "inactive-cell"
      // Remove "inactive-cell" from the classList to reset the cell styling to display the whole grid
      $('.matrix .inactive-cell').removeClass('inactive-cell');
      $('.matrix').removeClass('instrument-highlight');
      $('.matrix .remove-title').removeClass('remove-title');
    }
  });
}(window.BGC.ui.view, window.BGC.resources, window.BGC.dataStore));
