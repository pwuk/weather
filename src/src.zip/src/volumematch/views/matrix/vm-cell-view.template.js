/* eslint-disable max-lines */

import {html} from '@polymer/polymer/polymer-element';

export default html`
<style> * { 
    box-sizing: border-box;
}
:host {
    display: block;
    overflow: hidden;
    color: var(--content-text);
}
.cell {
    position: relative;
    height: var(--vm-cell-view-height);
    line-height: var(--vm-cell-view-height);
    border-right: var(--vm-cell-view-border-right, 1px solid var(--content-border));
    border-bottom: var(--vm-cell-view-border-bottom, 1px solid var(--content-border));
    border-top: var(--vm-cell-view-border-top, none);
    border-left: var(--vm-cell-view-border-left, none)
}
:host(.empty) .cell {
    border: none;
}


/*https://css-tricks.com/the-hidden-attribute-is-visibly-weak/*/
[hidden] { 
    display:none !important;
}

.tile .mid-price {
    text-align: center;
    position: relative;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.tile .mid-price .price-direction {
    visibility: hidden;
}

.tile .mid-price.price-direction-down .price-direction,
.tile .mid-price.price-direction-up .price-direction {
    position: absolute;
    top: 50%;
    margin-top: -0.35rem;
    right: 0.1rem;
    background-image: url('../images/price-direction-up.png'), none;
    background-size: 0.7rem;
    background-position: center;
    background-repeat: no-repeat;
    height: 0.7rem;
    width: 0.7rem;
    visibility: visible;
}
.tile .mid-price.price-direction-down .price-direction {
    background-image: url(../images/price-direction-down.png), none;
}
.tile .size {
    background-color: var(--content-background);
    line-height: calc(1.5rem - 2px);
    height: calc(1.5rem - 1px);
    text-align: center;
}
.tile.has-active-order {
    -webkit-perspective: 100;
    perspective: 100;
    will-change: transform;
    height: inherit;
}

.tile.has-active-order .mid-price,
.tile.has-active-order .order {
    backface-visibility: hidden;
    transform-style: preserve-3d;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
.tile.has-active-order .mid-price {
    transform: rotate3d(0, 0, 0, 0);
    z-index: 2;
    background-color: var(--tile-cell-background);
}
.tile.has-active-order .order {
    transform: rotate3d(1, 0, 0, -180deg);
    background-color: var(--tile-cell-background);
    display: flex;
    align-items: center;
    justify-content: center;
}
.tile.has-active-order .order .order-item {
    display: flex;
    align-items: center;
    width: 100%;
    padding: 0 4px;
    justify-content: space-between;
}
.tile.has-active-order .order .order-size {
    order: 2;
    height: calc(1.5rem - 2px);
    line-height: calc(1.5rem - 2px);
}
.tile.has-active-order .order .cancel-icon {
    width: 1rem;
    order: 3;
}
.tile.has-active-order .order .cancel-icon.cancel-buy {
    margin-left: 5px;
}
.tile.has-active-order .order .cancel-icon.cancel-sell {
    margin-right: 5px;
    order: 1;
}
.tile.show-order-size:hover .mid-price {
    transform: rotate3d(1, 0, 0, 180deg);
}
.tile.show-order-size:hover .order {
    transform: rotate3d(0, 0, 0, 0);
}
.tile [draggable="false"] {
    transition: 0.6s;
    transform-style: preserve-3d;
    position: relative;
    height: inherit;
}
.tile .mid-price.flash-500ms,
.tile.cell-highlight .mid-price.flash-500ms {
    background-color: var(--new-price-flash-bg);
    color: var(--new-price-flash-fg);
}
.tile.cell-highlight .mid-price,
.tile.cell-highlight .order {
    background-color: var(--highlight-background);
    border-color: var(--highlight-background);
}
:host(.cell-dragover) .tile.cell-dragover .mid-price,
:host(.cell-dragover) .tile.cell-selection .mid-price,
:host(.cell-dragover) .tile.cell-dragover .order,
:host(.cell-dragover) .tile.cell-selection .order {
    background-color: var(--highlight-background);
    border-color: var(--selection);
}
.tile.is-selected .mid-price,
.tile.is-selected .order {
    box-shadow: inset 0 0 0 1px var(--selection);
}
.tile.hidden-buy-size .mid-price,
.tile.hidden-buy-size .order {
    box-shadow: inset 0 0 0 2px var(--hidden-buy-cell-border);
}
.tile.hidden-sell-size .mid-price,
.tile.hidden-sell-size .order {
    box-shadow: inset 0 0 0 2px var(--hidden-sell-cell-border);
}
.tile.hidden-buy-size.hidden-sell-size .mid-price,
.tile.hidden-buy-size.hidden-sell-size .order {
    box-shadow: inset 0 0 0 2px var(--hidden-buysell-cell-border);
}
.tile.hidden-buy-size.hidden-sell-size .order {
    justify-content: space-between;
}
.tile.hidden-buy-size.hidden-sell-size .order .order-item {
    max-width: 50%;
    padding: 0 2px;
}
.tile.hidden-buy-size.hidden-sell-size .order .order-item.buy {
    padding-left: 4px;
}
.tile.hidden-buy-size.hidden-sell-size .order .order-item.sell {
    padding-right: 4px;
}
.tile.mirror .order .cancel-icon.cancel-buy {
    margin: 0px;
    order: 1;
}

.tile.mirror .order .cancel-icon.cancel-sell {
    margin: 0px;
    order: 3;
}
.tile.third-party-interest .mid-price,
.tile.third-party-interest .order {
    font-weight: var(--font-weight-matrix-cell-data);
    background-image: linear-gradient(to right, var(--thirdparty-glow), var(--thirdparty-glow));
    color: var(--thirdparty-glow-text);
}
.tile.third-party-interest.below-market-size .mid-price,
.tile.third-party-interest.below-market-size .order {
    background-image: linear-gradient(to right, var(--thirdparty-glow), var(--content-background), var(--content-background), var(--thirdparty-glow));
    color: var(--thirdparty-glow-text);
}
.tile.behind-mid .mid-price,
.tile.behind-mid .order {
    background-image: linear-gradient(to right, var(--behind-mid-glow), var(--behind-mid-glow));
    color: var(--thirdparty-glow-text);
}
.tile.ahead-of-mid .mid-price,
.tile.ahead-of-mid .order {
    background-image: linear-gradient(to right, var(--ahead-of-mid-glow), var(--ahead-of-mid-glow));
    color: var(--thirdparty-glow-text);
}
.tile.le-buy-interest .mid-price:before {
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    border-top: none;
    border-bottom: calc(1.6rem * 0.8) solid transparent;
    border-left: calc(1.6rem * 0.8) solid var(--same-le-glow);
    content: '';
    display: block;
    opacity: 0.7;
}
.tile.le-sell-interest .mid-price:after {
    position: absolute;
    top: 0;
    right: 0;
    width: 0;
    height: 0;
    border-top: none;
    border-bottom: calc(1.6rem * 0.8) solid transparent;
    border-right: calc(1.6rem * 0.8) solid var(--same-le-glow);
    content: '';
    display: block;
    opacity: 0.7;
}
.tile.buy-size,
.tile.sell-size {
    font-weight: var(--font-weight-buy-sell-size);
}
.tile.buy-size .mid-price,
.tile.sell-size .mid-price {
    height: calc(1.5rem - 2px);
    line-height: calc(1.5rem - 2px);
}
.tile.buy-size .quick-cancel,
.tile.sell-size .quick-cancel {
    position: absolute;
    width: 1rem;
    height: 1rem;
    margin-top: 1px;
}
.tile.buy-size .size,
.tile.sell-size .size {
    border-width: 1px;
    border-style: solid;
    position: relative;
}
.tile.sell-size .quick-cancel.sell {
    left: 0;
}
.tile.sell-size .size.sell {
    color: var(--content-text);
    border-color: var(--sell-side-border);
    text-align: right;
    padding-right: 1px;
    background-color: var(--in-place-sell-bg);
}
.tile.buy-size .quick-cancel.buy {
    right: 0;
}
.tile.buy-size .size.buy {
    color: var(--content-text);
    border-color: var(--buy-side-border);
    text-align: left;
    padding-left: 1px;
    background-color: var(--in-place-buy-bg);
}
.tile.buy-size.sell-size .size.buy,
.tile.buy-size.sell-size .size.sell {
    width: 50%;
}
.tile.buy-size.sell-size .size.buy {
    float: left;
}
.tile.buy-size.sell-size .size.sell {
    float: right;
}
.tile.traded .mid-price .gavel {
    background-image: var(--gavel-image);
    background-repeat: no-repeat;
    background-size: calc(1rem + 2px);
    display: inline-block;
    width: calc(1rem + 2px);
    height: calc(1rem + 2px);
    vertical-align: middle;
    margin-bottom: 3px;
}
.tile .traded.trade-confirm-request:hover {
    cursor: pointer !important;
}
.tile.highlighted-cell:not(.inactive) {
    background-color: var(--content-background);
    border: solid 1px var(--in-place-nudge-border);
}
.tile.indicative .order,
.tile.indicative .mid-price {
    color: var(--indicative-mid-price);
    font-style: italic;
}
.tile.buy-published-by-excel .order,
.tile.buy-published-by-excel .size.buy {
    background-color: var(--excel-green);
}
.tile.sell-published-by-excel .order,
.tile.sell-published-by-excel .size.sell {
    background-color: var(--excel-green);
}
.tile.orderEntryDisabled {
    cursor: default;
}
.tile.inactive {
    cursor: default;
    font-style: oblique;
    font-weight: normal;
}
.tile.inactive > div {
    display: none;
    background-color: var(--tile-cell-inactive);
    border-color: var(--tile-cell-inactive);
}
:host(.row-header) .tile.inactive > div {
    display: block;
    font-style: normal;
}

</style>
<div class$="{{cellClassList}}">
<div class$="[[tileCssClassList]]" draggable="true">
    <div draggable="false">
        <div class$="[[midPriceCssClassList]]">
            <span on-click="onGavelClick"
                on-mouseover="onGavelMouseEnter"
                on-mouseout="onGavelMouseLeave"
                class$="[[gavelCssClassList]]"
                hidden="[[!displayGavel]]">
            </span>
            <span>[[priceDisplay]] [[cellContent]]</span>
            <div class="price-direction"></div>
        </div>
        <div class="order" hidden="[[!hasActiveOrder]]" data-order-count$="[[orderCount]]">
            <div class="order-item buy" hidden="[[!hasLiveBuyOrder]]">
                <span class="order-size">[[buySize]]</span>
                <img on-click="onCancelOrderClick" class="cancel-icon cancel-buy"
                     src="./assets/images/cancel.png">
            </div>
            <div class="order-item sell" hidden="[[!hasLiveSellOrder]]">
                <span class="order-size">[[sellSize]]</span>
                <img on-click="onCancelOrderClick" class="cancel-icon cancel-sell"
                     src="./assets/images/cancel.png">
            </div>
        </div>
    </div>
</div>
</div>
`;
