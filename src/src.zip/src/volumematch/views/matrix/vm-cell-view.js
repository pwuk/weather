/* eslint-disable func-names, max-lines, no-param-reassign, class-methods-use-this, complexity, id-length, max-statements, consistent-this, no-magic-numbers */
/* globals $, _, Backbone, BGC */

import {PolymerElement} from '@polymer/polymer/polymer-element';
import {mixinBehaviors} from '@polymer/polymer/lib/legacy/class';
import componentTemplate from './vm-cell-view.template';
import {isWebDeployed} from '../../bgc';

const {view: context, viewUtils} = window.BGC.ui;
const {dataStore} = window.BGC;

class VmCellView extends mixinBehaviors([context.NotificationFlashBehavior], PolymerElement) {
  constructor (options) {
    super();
    _.extend(this, Backbone.Events);

    this.model = options.model;
    this.gridView = options.gridView;
    this.x = options.x;
    this.y = options.y;
    this.cellContent = options.cellContent;

    this.model.on('change', this.render.bind(this), this);

    this.model.on('requestSelection', this.updateParentSelection.bind(this), this);

    this.gridView.model.auction.on('change:runningState', this.handleMatrixRunningStateChanged.bind(this), this);
    this.gridView.pageLayout.on('change:upsizingMode', this.updateOEB.bind(this), this);

    this.setCellClassList();
    this.listenTo(dataStore.userSettingsStore, 'change:swapBidAndOffer', this.requestRender.bind(this));
    this.tooltip = BGC.ui.tooltipSingleton.getInstance();
  }

  requestRender () {
    BGC.ui.viewUtils.requestRender(this.model.get('instrumentId'), 'CellView', this, this.render.bind(this));
  }

  isPriceDirectionBetter (priceDirection) {
    return priceDirection === 'better';
  }

  isPriceDirectionWorse (priceDirection) {
    return priceDirection === 'worse';
  }

  handleMatrixRunningStateChanged () {
    this.setViewClasses();
  }

  ready () {
    super.ready();
    const that = this;

    this.setCellClassList();
    this.tileCssClassList = 'tile';
    this.midPriceCssClassList = 'mid-price';
    this.hasActiveOrder = false;
    this.hasLiveBuyOrder = false;
    this.hasLiveSellOrder = false;

    // this.priceDisplay = '';
    this.buySize = '';
    this.sellSize = '';

    this.render = this.render.bind(this);

    this.el = (function () {
      const $this = $(that.shadowRoot);
      const $cell = $this.find('.cell');
      const $tile = $this.find('.tile');
      const $price = $this.find('.mid-price');
      const $order = $this.find('.order');

      return {
        $cell,
        $tile,
        $price,
        $order,

        cell  : $cell[0],
        tile  : $tile[0],
        price : $price[0],
        order : $order[0]
      };
    }());
  }

  render () {
    const serializedModel = this.model.serialize();
    const inplaceOEB = context.inplaceOEB.getInstance();

    this.priceDisplay = serializedModel.priceDisplay;
    this.hasActiveOrder = this.cellHasActiveOrder();
    this.hasLiveBuyOrder = this.model.hasLiveBuyOrder();
    this.hasLiveSellOrder = this.model.hasLiveSellOrder();

    this.displayGavel = serializedModel.showTradeIndicators && serializedModel.hasTradedAtMidPrice;

    this.setViewClasses(serializedModel);

    if (this.hasActiveOrder) {
      this.buySize = this.model.getBuySize();
      this.sellSize = this.model.getSellSize();
    }

    if (this.gridView.selectedCell === this && serializedModel.inactive) {
      this.gridView.clearSelection();
    }

    if (inplaceOEB.isOpen && inplaceOEB.getInstrumentId() === serializedModel.instrumentId) {
      this.updateOEB();
    }
  }

  created () {
    // _.extend(this, Backbone.Events);
    this.addEventListener('mousedown', this.handleCellClick.bind(this));
    this.addEventListener('mouseenter', this.onCellMouseEnter.bind(this));
    this.addEventListener('mouseleave', this.onCellMouseLeave.bind(this));
    this.addEventListener('dragover', this.onCellDragOver.bind(this));
    this.addEventListener('dragstart', this.onCellDragStart.bind(this));
    this.addEventListener('drop', this.onCellDrop.bind(this));
    this.addEventListener('dragend', this.onCellDragEnd.bind(this));
    this.addEventListener('dragleave', this.onCellDragLeave.bind(this));
  }

  setCellClassList () {
    const template = 'cell cell-x-{x} cell-y-{y}';
    const hasNoId = typeof this.model.get === 'function' ? !this.model.get('instrumentId') : false;

    if (hasNoId) {
      this.classList.add('empty');
    }

    this.cellClassList = template.supplant({
      x : this.x,
      y : this.y
    });
    this.classList.add(...this.cellClassList.split(' ').slice(1));
  }


  static get properties () {
    return {
      model : {
        type  : Object,
        value : {}
      },

      // https://jira.cad.local:8443/browse/BGCVM-972
      cellContent : {
        type  : String,
        value : ''
      },
      cellClassList : {
        type  : String,
        value : ''
      },
      animationDuration : {
        type  : Number,
        value : 10000
      },
      x : {
        type  : Number,
        value : -1
      },
      y : {
        type  : Number,
        value : -1
      },
      priceDisplay : {
        type  : Number,
        value : undefined
      },
      orderSize : {
        type  : Number,
        value : undefined
      },
      hasActiveOrder : {
        type     : Boolean,
        value    : false,
        observer : 'hasActiveOrderChanged'
      },
      keyframes : {
        type  : Object,
        value : {
          webdeploy : {
            price : [
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0.3},
              {transform : 'rotate3d(1, 0, 0, 180deg)', offset : 0.4},
              {transform : 'rotate3d(1, 0, 0, 180deg)', offset : 0.6},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0.7},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 1}
            ],
            order : [
              {transform : 'rotate3d(1, 0, 0, -180deg)', offset : 0},
              {transform : 'rotate3d(1, 0, 0, -180deg)', offset : 0.3},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0.4},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0.6},
              {transform : 'rotate3d(1, 0, 0, -180deg)', offset : 0.7},
              {transform : 'rotate3d(1, 0, 0, -180deg)', offset : 1}
            ],
            priceOffset : 0.5
          },
          citrix : {
            price : [
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0.6999},
              {transform : 'rotate3d(1, 0, 0, 180deg)', offset : 0.7},
              {transform : 'rotate3d(1, 0, 0, 180deg)', offset : 1}
            ],
            order : [
              {transform : 'rotate3d(1, 0, 0, -180deg)', offset : 0},
              {transform : 'rotate3d(1, 0, 0, -180deg)', offset : 0.6999},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 0.7},
              {transform : 'rotate3d(0, 0, 0, 0)', offset : 1}
            ],
            priceOffset : 0.85
          }
        }
      }
    };
  }

  static get template () {
    return componentTemplate;
  }

  handleCellClick (event) {
    const inPlaceOrderEntry = context.inplaceOEB.getInstance();
    const instModel = this.model;
    const spreadModel = instModel.get('spread');
    const instType = spreadModel ? 'Spread' : 'Outright';
    const instName = instModel.getLogDescStr();
    const self = this;

    // Because the handleCellClick handler is executed before
    // onCancelOrderClick, return in case the target of the
    // event was the cancel order button, because in that case
    // we don't want the inplaceOEB being displayed.
    if (_.include(event.target.classList, 'cancel-icon')) {
      // Stop the propagation of the event, because we don't want
      // the @inplace-order-entry::handleOutsideClick to get executed.
      // If @inplace-order-entry::handleOutsideClick executes, it will
      // close the inplaceOEB (if any it is opened) when the user
      // cancels an order. If there is an inplaceOEB opened on some
      // cell and the users hovers over another cell with active order
      // and click the cancel-icon image, we want to keep the inplaceOEB
      // opened on that other cell.
      event.stopPropagation();

      return;
    }

    if (this.model.get('inactive')) {
      return;
    }

    if (BGC.ui.view.spreadView && BGC.ui.view.spreadView.isPopulated()) {
      BGC.ui.viewUtils.infoPopup.popup('show', {
        modal                 : true,
        draggable             : true,
        title                 : BGC.resources.IDS_SPREADS_BAR_ACTIVE,
        message               : BGC.resources.IDS_MSG_CLEAR_SPREADS_BAR,
        hasHeaderCloseButton  : false,
        hasCancelButton       : true,
        isWarning             : true,
        isError               : false,
        buttonSectionText     : '',
        cssClass              : 'popupDialog ui-dialog',
        restrictHeavyPainting : !isWebDeployed,
        cmdConfirmText        : BGC.resources.IDS_YES,
        cmdCancelText         : BGC.resources.IDS_NO,
        confirm () {
          // Clear the spreads bar
          BGC.ui.view.spreadView.$el.trigger('collapseOrderEntry');

          // Recurse
          self.handleCellClick(event);
        }
      });

      return;
    }

    BGC.utils.startInteractivityQoSTimer('instrumentClick', instType, instName);

    if (this.gridView.selectedCell !== this) {
      // Lock the grid and change the selected cell
      BGC.ui.viewUtils.setSelectionLockedFlag(this.el.cell, true);
      this.gridView.selectCell(this.x, this.y);
    }

    if (event.button === 0 && !inPlaceOrderEntry.isOpen) {
      this.gridView.openOEBPopup(this);
    }
  }

  onCellMouseEnter (event) {
    const activeOrder = this.model.getActiveOrder();
    const animationFrequency = dataStore.userSettingsStore.get('orderAnimationDuration');
    const isAnimationEnabled = animationFrequency !== viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION.DISABLED;

    // First, stop any running hover tooltip timer
    if (this.tooltipTimer) {
      clearTimeout(this.tooltipTimer);
      this.tooltipTimer = null;
    }

    /**
         * If instrument has an active order with unfilled size and the active
         * order animation is not enabled, start a 0.3s hover timer to show
         * tooltip with active order details.
         */
    if (activeOrder && (activeOrder.hasUnfilledSize('buy') || activeOrder.hasUnfilledSize('sell')) && !isAnimationEnabled) {
      this.tooltipTimer = setTimeout(this.displayActiveOrderTooltip.bind(this, event), 300);
    }

    // Pause animation
    if (this.hasActiveOrder) {
      this.pauseAnimation();
    }
  }

  hasActiveOrderChanged (hasActiveOrder) {
    if (hasActiveOrder) {
      /**
             * The cell has an active order, define the animation
             * and sync it with the rest of existing animations
             */
      this.attachAndStartAnimation();
    } else {
      /**
             * If there is an animation defined, when the cell
             * does no longer have an active order, cancel the
             * existing animations
             */
      this.cancelAnimation();
    }
  }

  onCellMouseLeave () {
    const animationFrequency = dataStore.userSettingsStore.get('orderAnimationDuration');
    const isAnimationEnabled = animationFrequency !== viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION.DISABLED;

    if (this.tooltipTimer) {
      clearTimeout(this.tooltipTimer);
      this.tooltipTimer = null;
    }

    if (!isAnimationEnabled) {
      this.tooltip.hide();
    }

    /**
         * Because when hovering over a cell with an active order, the animation
         * is cancelled, when the user leaves the cell, the animations need to
         * get back in sync (the cell animation is reset, and it has to be in
         * sync with the rest). We don't have an API to determine the state of
         * an animation, so we trigger a rerender of all the cells with an
         * active order.
         */
    if (this.hasActiveOrder) {
      this.playAndSyncAnimation();
    }
  }

  onCellDragOver (event) {
    const srcInstrumentID = context.VmCellView.dragInstrument ? context.VmCellView.dragInstrument.instrumentID : null;
    const isValidTarget = !(srcInstrumentID === this.model.get('instrumentId')) && this.model.isInAuction();

    if (this.srcDragInstrument && isValidTarget) {
      // Use the cached source instrument object to prevent an instrument lookup every few milliseconds.
      event.preventDefault();
    } else if (srcInstrumentID && isValidTarget) {
      event.preventDefault();

      // Highlight the headers
      this.gridView.highlightDraggedCellHeaders(this.x, this.y);

      // Highlight the cell
      this.el.$tile.addClass('cell-dragover');
      this.classList.add('cell-dragover');

      this.srcDragInstrument = BGC.dataStore.getInstrumentById(srcInstrumentID);

      $(this).trigger('selectSpread', ['previewSelection', [this.srcDragInstrument, this.model]]);
    }
  }

  onCellDragEnd (event) {
    // Clean up dragging state
    this.gridView.clearDraggingStyles();

    this.srcDragInstrument = undefined;
    context.VmCellView.dragInstrument = {
      instrumentID : null
    };

    // Cancelled drop
    if (event.dataTransfer.dropEffect === 'none') {
      BGC.logger.logKey('Cell Drag-Drop', 'Cancelled');

      $(this).trigger('selectSpread', ['cancelSelection', undefined]);
    }
  }

  onCellDrop () {
    if (this.srcDragInstrument) {
      BGC.logger.logKey('Cell Drag-Drop',
        `Dropped: Instrument [${this.srcDragInstrument.getLogDescStr()}] dropped onto instrument [${this.model.getLogDescStr()}]`);

      $(this).trigger('selectSpread', ['selection', [this.srcDragInstrument, this.model]]);

      this.srcDragInstrument = undefined;
      context.VmCellView.dragInstrument = {
        instrumentID : null
      };

      this.gridView.clearDraggingStyles();
    }
  }


  onCellDragStart (event) {
    // Kill any running interactivity timer started by the down-click before the drag
    BGC.utils.cancelInteractivityQoSTimer('instrumentClick');

    /**
         * Due to the way that capture/bubbling works, and the way that the OEB popup
         * (installed as the child of a price cell) may also generate bubbling drag events,
         * we can only know the true origin of this event by hit testing.
         * If the event originated within the area of this cell, we should act on it,
         * otherwise kill it.
         */
    const cellCoords = this.el.$cell.offset();
    const cellRect = {
      top    : cellCoords.top,
      left   : cellCoords.left,
      width  : this.el.$cell.outerWidth(),
      height : this.el.$cell.outerHeight()
    };

    // Enable drag and drop feature for manage account, broker and trader who allow spread creation
    if ((this.model.get('canUserEnterOrders') || BGC.dataStore.isBrokerMode() || BGC.dataStore.isSalesTraderMode()) &&
            this.model.isInAuction() && this.gridView.pageLayout.get('allowSpreadCreation') &&
            BGC.utils.pointInRect(event.pageX, event.pageY, cellRect)) {
      BGC.logger.logKey('Cell Drag-Drop', `Dragging instrument [${this.model.getLogDescStr()}]`);

      // Lock the selection to the dragging cell
      BGC.ui.viewUtils.setSelectionLockedFlag(this.el.cell, true);

      this.gridView.selectCell(this.x, this.y);

      // Center the drag image.
      event.dataTransfer.setDragImage(this.el.tile, this.el.$tile.width() / 2, this.el.$tile.height() / 2);

      context.VmCellView.dragInstrument = {
        instrumentID : this.model.get('instrumentId')
      };
    } else {
      event.preventDefault();
    }

    event.stopPropagation();
  }

  onCellDragLeave () {
    this.srcDragInstrument = undefined;

    this.gridView.clearDraggingStyles();
  }

  cellHasActiveOrder () {
    const hasActiveOrder = this.model.hasActiveOrder();
    const animationDuration = dataStore.userSettingsStore.get('orderAnimationDuration');
    const isAnimationEnabled = animationDuration !== viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION.DISABLED;

    return hasActiveOrder && isAnimationEnabled;
  }


  // Updates the parent's (matrix) selection (cell)
  updateParentSelection (suppressActivation) {
    this.gridView.selectCell(this.x, this.y, !suppressActivation, !suppressActivation);
  }


  displayActiveOrderTooltip (event) {
    const activeOrder = this.model.getActiveOrder();
    const position = {
      x       : event.pageX,
      y       : event.pageY,
      xOffset : 10,
      yOffset : 10
    };

    this.statusHoverTimer = null;

    this.tooltip.hide();

    if (activeOrder) {
      this.tooltip.show(activeOrder.buildTipText(), position);
    }
  }

  setViewClasses (serializedModel) {
    if (!serializedModel) {
      serializedModel = this.model.serialize();
    }

    this.setCellClassList();
    this.tileCssClassList = this.getTileCssClassList(serializedModel);
    this.midPriceCssClassList = this.getMidPriceCssClassList(serializedModel);
    this.gavelCssClassList = this.getGavelCssClassList(serializedModel);
  }

  getTileCssClassList (serializedModel) {
    const order = serializedModel.ownOrder;
    const {tile} = this.el;

    const TILE_CSS_CLASSES = {
      TILE                    : 'tile',
      HIDDEN_BUY_SIZE         : 'hidden-buy-size',
      HIDDEN_SELL_SIZE        : 'hidden-sell-size',
      BUY_PUBLISHED_BY_EXCEL  : 'buy-published-by-excel',
      SELL_PUBLISHED_BY_EXCEL : 'sell-published-by-excel',
      HAS_ACTIVE_ORDER        : 'has-active-order',
      SHOW_ORDER_SIZE         : 'show-order-size',
      TRADED                  : 'traded',
      INDICATIVE              : 'indicative',
      INACTIVE                : 'inactive',
      MIRROR                  : 'mirror'
    };

    // tileCssClassList needs to be initialized also here for the
    // case when the instrument is inactive.
    let tileCssClassList = [TILE_CSS_CLASSES.TILE];
    const thirdPartyInterest = serializedModel.showThirdPartyInterestGlows ? serializedModel.thirdPartyInterest : 'none';

    if (serializedModel.newPrice) {
      this.flashNotification(this.EFlashType.eNewPrice, this.el.$price);
    }

    // eslint-disable-next-line no-negated-condition
    if (!serializedModel.inactive) {
      // Interest glows
      viewUtils.applyThirdPartyInterestGlows(thirdPartyInterest, [tile]);
      viewUtils.applySameLEInterestGlows(!!serializedModel.hasSameLeBuyInterest, !!serializedModel.hasSameLeSellInterest, [tile]);

      // Because there are CSS classes that are being added to the
      // cell tile from outside (from matrix view, classes like
      // is-selected, cell-highlight etc.), we need to preserve those
      // each time we are re-rendering the cell-view. In order to do
      // that, just compute the difference of the existing class list
      // and the classes that are being manipulated by the cell view.
      const existingClassList = tile.classList || [TILE_CSS_CLASSES.TILE];

      // Omit the TILE class from the TILE_CSS_CLASSES object. Otherwise, the
      // _.difference call would remove it.
      const tileClassesAsArray = _.values(_.omit(TILE_CSS_CLASSES, 'TILE'));

      tileCssClassList = _.difference(existingClassList, tileClassesAsArray);

      // Buy and/or sell order
      if (order) {
        if (this.model.hasLiveBuyOrder()) {
          tileCssClassList.push(TILE_CSS_CLASSES.HIDDEN_BUY_SIZE);
        }

        if (this.model.hasLiveSellOrder()) {
          tileCssClassList.push(TILE_CSS_CLASSES.HIDDEN_SELL_SIZE);
        }

        if (order.wasBuyPublishedByExcel) {
          tileCssClassList.push(TILE_CSS_CLASSES.BUY_PUBLISHED_BY_EXCEL);
        }

        if (order.wasSellPublishedByExcel) {
          tileCssClassList.push(TILE_CSS_CLASSES.SELL_PUBLISHED_BY_EXCEL);
        }

        const hasOrder = (order.hasBuySize || order.hasSellSize) && this.isAnimationEffectEnabled();

        if (hasOrder) {
          tileCssClassList.push(TILE_CSS_CLASSES.HAS_ACTIVE_ORDER);

          if (this.isAnimationEnabledButZero()) {
            tileCssClassList.push(TILE_CSS_CLASSES.SHOW_ORDER_SIZE);
          }

          if (dataStore.userSettingsStore.get('swapBidAndOffer')) {
            tileCssClassList.push(TILE_CSS_CLASSES.MIRROR);
          }
        }
      }

      this.displayGavel = serializedModel.hasTradedAtMidPrice;
      if (serializedModel.hasTradedAtMidPrice) {
        tileCssClassList.push(TILE_CSS_CLASSES.TRADED);
      }
    } else {
      this.displayGavel = false;

      /**
             * Don't show indicative prices if auction is running,
             * just leave cell blank if this instrument not in auction
             */
      if (serializedModel.isMidPriceIndicative && !this.gridView.pageLayout.areAnyInstrumentsInAuction()) {
        tileCssClassList.push(TILE_CSS_CLASSES.INDICATIVE);
      } else {
        tileCssClassList.push(TILE_CSS_CLASSES.INACTIVE);
      }
    }

    // While this should never happen, use _.uniq for sanity
    return _.uniq(tileCssClassList).join(' ');
  }

  isAnimationEffectEnabled () {
    const animationFrequency = dataStore.userSettingsStore.get('orderAnimationDuration');

    return animationFrequency !== viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION.DISABLED;
  }

  isAnimationEnabledButZero () {
    const animationFrequency = dataStore.userSettingsStore.get('orderAnimationDuration');

    return animationFrequency === 0;
  }

  getMidPriceCssClassList (serializedModel) {
    const midPriceCssClassList = ['mid-price'];

    if (this.isPriceDirectionBetter(serializedModel.priceDirection)) {
      midPriceCssClassList.push('price-direction-up');
    }

    if (this.isPriceDirectionWorse(serializedModel.priceDirection)) {
      midPriceCssClassList.push('price-direction-down');
    }

    return midPriceCssClassList.join(' ');
  }

  isTradeConfirmRequestAllowed (model, serializedModel) {
    return model.canRequestTradeConfirms() && serializedModel.showTradeIndicators;
  }

  getGavelCssClassList (serializedModel) {
    const cssClassTemplate = 'gavel traded {tradeConfirmRequest}';

    return cssClassTemplate.supplant({
      tradeConfirmRequest : this.isTradeConfirmRequestAllowed(this.model, serializedModel) ? 'trade-confirm-request' : ''
    }).trim();
  }

  getAnimationKeyframes () {
    return this.keyframes[isWebDeployed ? 'webdeploy' : 'citrix'];
  }

  onCancelOrderClick (event) {
    this.model.sendCancelOrder('GridCell', event.target.className.indexOf('buy') > -1 ? 'buy' : 'sell');

    event.stopPropagation();

    this.cancelAnimation();
  }

  /**
     * Used to define and start a new animation on the cell. After defining
     * the animation, we also need to set the playback rate, because the
     * animation duration is always 10s, but the user animation frequency
     * setting is the one which dictates the actual duration.
     */
  attachAndStartAnimation () {
    const whichKeyframes = this.getAnimationKeyframes();
    const animationDuration = this.getAnimationDuration();
    const animationProperties = this.getAnimationProperties(this.animationDuration);

    if (this.shouldAttachAnimations()) {
      this.priceAnimation = this.el.price.animate(whichKeyframes.price, animationProperties);
      this.orderAnimation = this.el.order.animate(whichKeyframes.order, animationProperties);

      this.priceAnimation.playbackRate = this.animationDuration / animationDuration;
      this.orderAnimation.playbackRate = this.animationDuration / animationDuration;

      this.gridView.syncAnimations();
    }
  }

  getAnimationProperties (animationDuration) {
    return {
      easing     : 'cubic-bezier(0.27, 0.01, 0.77, 1)',
      duration   : animationDuration,
      iterations : Infinity
    };
  }

  shouldAttachAnimations () {
    const animationFrequency = dataStore.userSettingsStore.get('orderAnimationDuration');
    const ANIMATION_CONST = viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION;

    return animationFrequency !== ANIMATION_CONST.MIN;
  }

  getAnimationDuration () {
    const animationFrequency = dataStore.userSettingsStore.get('orderAnimationDuration');
    const ANIMATION_CONST = viewUtils.CONSTANTS.ACTIVE_ORDER_ANIMATION;


    if (animationFrequency === ANIMATION_CONST.MAX) {
      return 1000;
    }

    return (ANIMATION_CONST.MAX - animationFrequency) * 1000;
  }

  /**
     * Always determine the playback rate based on the fixed and immutable
     * animation duration of 10.000 ms. Retrieve the actual animation duration
     * based on the user frequency setting and determine the playback rate.
     */
  updateAnimationPlaybackRate () {
    const newPlaybackRate = this.animationDuration / this.getAnimationDuration();

    this.priceAnimation.playbackRate = newPlaybackRate;
    this.orderAnimation.playbackRate = newPlaybackRate;
  }

  /**
     * If the cell has animations define, cancel them and set
     * the class proprties to null.
     */
  cancelAnimation () {
    if (this.priceAnimation && this.orderAnimation) {
      this.priceAnimation.cancel();
      this.orderAnimation.cancel();

      this.priceAnimation = null;
      this.orderAnimation = null;
    }
  }

  /**
     * Function used to resume and resynchronize the animations.
     */
  playAndSyncAnimation () {
    if (this.priceAnimation && this.orderAnimation) {
      this.priceAnimation.play();
      this.orderAnimation.play();

      this.gridView.syncAnimations();
    }
  }

  /**
     * When user is hovering over an cell with an active animation, we need
     * to pause existing animation and show the order size. In order to display
     * the order size, we need to determine where in the animation timeline
     * is the offset when the order is facing the user. The way to achieve
     * it is by inspecting the keyframes definition, determine the offset
     * where the order size is being displayed and use it in combination with
     * the current animation duration and the playback rate.
     */
  pauseAnimation () {
    if (this.priceAnimation && this.orderAnimation) {
      const orderTimeOffset = this.getOrderPositionInAnimationTimeline() * this.priceAnimation.playbackRate;

      this.priceAnimation.pause();
      this.orderAnimation.pause();

      this.priceAnimation.currentTime = orderTimeOffset;
      this.orderAnimation.currentTime = orderTimeOffset;
    }
  }

  getOrderPositionInAnimationTimeline () {
    const whichKeyframes = this.getAnimationKeyframes();
    const animationDuration = this.getAnimationDuration();
    const offset = whichKeyframes.priceOffset;

    return animationDuration * offset;
  }

  /**
     * Used to update the animations. Deals with the following scenario:
     *     1. Cell has an active animation and new frequency > 0 => update playback rate
     *     2. Cell has an active animation but frequency = 0 => cancel animation
     *     3. Cell has no active animation and frequency > 0 => attach & start animation
     */
  updateAnimation (animationFrequency) {
    const hasAnimation = this.priceAnimation && this.orderAnimation;

    // If the cell has an animation (price & order) and the new animation frequency
    // is different than 0, means we have to update the playback rate, the user had
    // nugded up/down the setting
    if (hasAnimation && animationFrequency > 0) {
      this.updateAnimationPlaybackRate();
    } else if (hasAnimation && animationFrequency === 0) {
      // If the cell has an animation (price & order) and the new animation frequency
      // is 0, we need to cancel the animations
      this.cancelAnimation();
    } else if (!hasAnimation && animationFrequency > 0) {
      // If cell has no animation (price & order) and the new animation frequency
      // is greater than 0, we need to re-attach and start the animations
      this.attachAndStartAnimation();
    }
  }

  /**
     * Synchronize animation currentTime and playbackRate based on a sibling
     * cell animation.
     */
  syncAnimation (siblingCell) {
    if (this.priceAnimation && siblingCell && siblingCell.priceAnimation) {
      this.priceAnimation.currentTime = siblingCell.priceAnimation.currentTime;
      this.orderAnimation.currentTime = siblingCell.orderAnimation.currentTime;

      this.priceAnimation.playbackRate = siblingCell.priceAnimation.playbackRate;
      this.orderAnimation.playbackRate = siblingCell.orderAnimation.playbackRate;
    }
  }

  updateOEB () {
    const instrument = this.model.serialize();
    const inplaceOEB = context.inplaceOEB.getInstance();

    if (inplaceOEB.isOpen && inplaceOEB.getInstrumentId() === instrument.instrumentId) {
      // If open OEB is attached to this cell, update it
      inplaceOEB.setData(instrument, instrument.ownOrder);
    }
  }
}

customElements.define('vm-cell-view', VmCellView);

// elementBehaviors.define('vm-cell-view', VmCellView);
context.VmCellView = VmCellView;
export default {};
