/* eslint-disable no-magic-numbers, func-names, max-lines, no-param-reassign, complexity, max-statements */
/* global Polymer: false */

(function (context, resources, dataStore) {
  context.view.AuctionLayout = Polymer({
    is : 'auction-layout',

    sortFunc (group1, group2) {
      return group1.sortIndex - group2.sortIndex;
    },

    factoryImpl (options) {
      const {model, tiles, settings} = options;

      this.tiles = [];
      this.model = model;
      this.settings = settings;
      this.selectedRow = null;
      this.classList.add('is-open');
      this.genericColumns = model.getGenericColumns();
      this.title = model.get('auctionId');
      this.setAttribute('id', model.id);

      // Build the initial layout
      this.updateProgressBar(model);
      this.updateLayout(model.get('instruments'), tiles);

      // Bind layout update handlers
      model.on('change', this.updateProgressBar, this);
      model.on('change:instruments', items => {
        this.updateLayout(items, tiles);
      });

      // Maintain the selected row
      this.addEventListener('rowselected', this.updateSelection);

      // Deactivate the view when the auction ends
      // eslint-disable-next-line no-shadow
      model.on('change:runningState', (model, runningState) => {
        if (runningState === model.EContentState.eNone) {
          this.deactivateView(model);
        }
      });
    },

    updateProgressBar (model) {
      const progressBar = this.querySelector('progress-bar');

      if (progressBar) {
        progressBar.timerId = model.get('auctionId');
        progressBar.message = model.get('orderPhaseText');
        progressBar.setAttribute('start-time', model.get('startTime'));
        progressBar.setAttribute('end-time', model.get('endTime'));
        progressBar.setAttribute('time-offset', model.get('timeOffset'));
        progressBar.setAttribute('auction-Phase', model.get('auctionPhase'));
        progressBar.setAttribute('phaseoneend-time', model.get('phaseoneEndtime'));
      }
    },

    updateLayout (items, groups) {
      // Get updated meta  items
      const metaItems = dataStore.instruments.filter(item => item.get('isLockInstrument'));

      items.forEach(item => {
        // Group instruments by 'tileId'
        const groupId = item.get('tileId');
        let groupIndex = this.tiles.findIndex(group => group.id === groupId);

        if (groupIndex === -1) {
          // Add new tile group
          groupIndex = this.addGroup(groups.get(groupId), item.get('tileIndex'));

          // Assuming only one lock instrument per tile, add that row when unique group is created
          const metaItem = metaItems.find(metaRow => metaRow.get('tileId') === groupId);

          if (metaItem) {
            this.addRow(groupIndex, metaItem);
          }
        }

        // Add instrument row to existing group
        this.addRow(groupIndex, item);
      });

      this.fire('recalcLayout');
    },

    // Adds a tile group - binding properties from the given backbone tile model
    addGroup (tile, sortIndex) {
      const instruments = tile.get('instruments');
      const displayCounters = this.model.get('showInterestAndTradeCount');
      const thirdParty = displayCounters && instruments.filter(item => item.get('thirdPartyInterest') !== 'none');
      const tradeCount = displayCounters && instruments.filter(item => item.get('hasTradedInAuction'));
      const {pageLayout} = dataStore;

      // Add new 'tile' group view model
      this.push('tiles', {
        sortIndex,
        model            : tile,
        id               : tile.id,
        displayName      : tile.get('tileName'),
        displayFavorites : this.settings.displayFavorites && !tile.get('excludeFromFavorites'),
        filter           : pageLayout.getLiveModeForActiveUser(),
        buyLabel         : tile.getAdjustedNomenclature('IDS_BUY_SIZE'),
        sellLabel        : tile.getAdjustedNomenclature('IDS_SELL_SIZE'),
        priceLabel       : resources.IDS_PRICE,
        statusLabel      : resources.IDS_TRADE_STATUS,
        thirdParty       : thirdParty.length || '',
        tradeCount       : tradeCount.length || '',
        genericColumns   : this.genericColumns,
        displayCounters,
        rows             : []
      });

      return this.tiles.length - 1;
    },

    // Adds an instrument row - binding properties from the given backbone instrument model
    addRow (groupIndex, instrument) {
      const orderModel = instrument.getActiveOrder();
      const activeOrder = orderModel && orderModel.serialize();
      const buyOrder = activeOrder && activeOrder.buyOrder;
      const sellOrder = activeOrder && activeOrder.sellOrder;
      const midPrice = instrument.get('midPrice');
      const {pageLayout} = dataStore;

      this.push(`tiles.${groupIndex}.rows`, {
        model               : instrument,
        displayName         : instrument.get('name'),
        buySize             : buyOrder && buyOrder.hasBuySize ? String(buyOrder.buySize) : '',
        buyPrice            : buyOrder ? buyOrder.price : midPrice,
        sellSize            : sellOrder && sellOrder.hasSellSize ? String(sellOrder.sellSize) : '',
        sellPrice           : sellOrder ? sellOrder.price : midPrice,
        displayCancelBuy    : Boolean(buyOrder && buyOrder.hasCancellableBuySize),
        displayCancelSell   : Boolean(sellOrder && sellOrder.hasCancellableSellSize),
        buyStatus           : orderModel ? orderModel.buildStatusString('buy', true) : '',
        sellStatus          : orderModel ? orderModel.buildStatusString('sell', true) : '',
        readOnly            : !instrument.get('canUserEnterOrders') || instrument.get('isLockInstrument'),
        favoriteState       : instrument.get('footprint') ? 1 : 0,
        disableFavoriteIcon : Boolean(buyOrder || sellOrder),
        displayGlows        : this.model.get('showThirdPartyInterestGlows') || instrument.get('isShowGlowAlwaysEnabled'),
        genericFields       : this.genericColumns.map(column => ({
          id    : column.columnId,
          value : instrument.get(column.columnId) || ''
        })),
        priceCellOptions : {
          model : instrument,
          order : activeOrder || {dummy : true},
          grid  : null,
          pageLayout
        }
      });
    },

    // Invoked when an auction ends to put the view into an inactive read-only state
    deactivateView () {
      // Close and mark the view as inactive
      this.classList.remove('is-open');
      this.classList.add('inactive');
      this.set('inactive', true);
      this.set('endTime', new Date().toLocaleTimeString());

      // Clear any selection
      if (this.selectedRow) {
        this.selectedRow.classList.remove('selected');

        context.selectionManager.setSelection(this, null);
      }

      this.removeEventListener('rowselected', this.updateSelection);

      this.fire('recalcLayout');
    },

    // Maintains single row selection
    updateSelection (event) {
      const {row, model} = event.detail;

      if (this.selectedRow === row) {
        return;
      }

      if (this.selectedRow) {
        // Clear existing selection
        this.selectedRow.classList.remove('selected');
      }

      // Select new row
      this.selectedRow = row;
      row.classList.add('selected');

      // Publish global instrument selection change
      context.selectionManager.setSelection(this, model);
    },

    onTapToggleContent () {
      this.toggleClass('is-open');

      this.fire('recalcLayout');
    },

    onTapRemoveView () {
      dataStore.auctions.remove(this.model);

      this.fire('recalcLayout');
    }
  });
}(window.BGC.ui, window.BGC.resources, window.BGC.dataStore));
