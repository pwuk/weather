/* eslint-disable no-magic-numbers, func-names, max-lines, no-param-reassign, complexity, max-statements */
/* global BGC: false, Polymer: false */


(function (context, dataStore) {
  context.AuctionGroup = Polymer({
    is : 'auction-group',

    behaviors : [context.NotificationFlashBehavior],

    observers : [
      'deactivateObserver(inactive)'
    ],

    sortFunc (row1, row2) {
      return row1.model.get('index') - row2.model.get('index');
    },

    ready () {
      const {model, displayCounters} = this.tile;
      const {pageLayout, userSettingsStore} = dataStore;

      if (displayCounters) {
        model.on('tileHasInterest', this._updateInterestCount, this);
        model.on('instrumentTraded', this._updateTradeCount, this);
      }

      pageLayout.on('change:brokerLiveMode change:traderLiveMode', this._updateFilter, this);

      // Setting a default buy sell labels and attching a listner for swapBidAndOffer change event

      this.swapSides();
      userSettingsStore.on('change:swapBidAndOffer', this.swapSides, this);
    },

    swapSides () {
      const {userSettingsStore} = dataStore;

      this.shouldMirror = userSettingsStore.get('swapBidAndOffer') ? 'mirror' : '';

      // Setting a buy sell labels
      this.buyLabel = userSettingsStore.get('swapBidAndOffer') ? this.tile.sellLabel : this.tile.buyLabel;
      this.sellLabel = userSettingsStore.get('swapBidAndOffer') ? this.tile.buyLabel : this.tile.sellLabel;
    },

    deactivateObserver () {
      const {model, rows} = this.tile;
      const {pageLayout} = dataStore;

      // Clear the interest count
      this.set('tile.thirdParty', '');

      // Restore the max trade count
      this.set('tile.tradeCount', rows.filter(row => row.hasTraded).length || '');

      // Open the tile
      this.toggleClass('is-open', true);
      this.querySelector('.collapse-toggle').classList.toggle('is-open', true);

      // Trigger glow count changed event for header's global count update
      model.trigger('glowCountChanged');

      // Trigger trade count changed event for header's global count update
      model.trigger('tradeCountChanged');

      // Remove the model listeners
      model.off('tileHasInterest', this._updateInterestCount, this);
      model.off('instrumentTraded', this._updateTradeCount, this);
      pageLayout.off('change:brokerLiveMode change:traderLiveMode', this._updateFilter, this);
    },

    _updateInterestCount (count) {
      const {model} = this.tile;

      this.set('tile.thirdParty', count || '');

      // Trigger glow count changed event for header's global count update
      model.trigger('glowCountChanged');

      this.flashNotification(this.EFlashType.eThirdPartyInterest);
    },

    _updateTradeCount (newTradeCount) {
      const {tradeCount, model} = this.tile;

      this.set('tile.tradeCount', newTradeCount || '');

      // Trigger trade count changed event for header's global count update
      model.trigger('tradeCountChanged');

      // If the trade count is increasing (i.e. it's not a re-price), flash the trade count indicator
      if (newTradeCount > tradeCount) {
        this.flashNotification(this.EFlashType.eTradeCount);
      }
    },

    _displayFavIcon (tile, row) {
      const {model} = row;


      return tile.displayFavorites && !model.get('isLockInstrument');
    },

    _updateFilter () {
      const {pageLayout} = dataStore;
      const liveMode = pageLayout.getLiveModeForActiveUser();
      const {eShowAll} = BGC.enums.EVMShowLiveMode;

      this.set('tile.filter', liveMode);

      this.toggleClass('is-open', true);
      this.querySelector('.collapse-toggle').classList.toggle('is-open', liveMode === eShowAll);

      this.fire('recalcLayout');
    },

    onTapCollapseToggle (event) {
      const {currentTarget} = event;
      const {eShowAll} = BGC.enums.EVMShowLiveMode;
      const filter = dataStore.pageLayout.getLiveModeForActiveUser();

      // Toggle the open/close symbol
      currentTarget.classList.toggle('is-open');

      if (filter === eShowAll) {
        // If no filter, toggle open/close tile
        this.toggleClass('is-open');
      } else if (currentTarget.classList.contains('is-open')) {
        // Remove the tile filter
        this.set('tile.filter', eShowAll);
      } else {
        // Reinstate the tile filter
        this.set('tile.filter', filter);
      }

      this.fire('recalcLayout');
    },

    onTapRow (event) {
      const {currentTarget} = event;
      const {model} = currentTarget.row;

      this.dispatchEvent(new CustomEvent('rowselected', {
        bubbles  : true,
        composed : true,
        detail   : {
          row : currentTarget,
          model
        }
      }));
    }
  });
}(window.BGC.ui.view, window.BGC.dataStore));
