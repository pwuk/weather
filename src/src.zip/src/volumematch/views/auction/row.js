/* eslint-disable no-magic-numbers, func-names, max-lines, no-param-reassign, complexity, max-statements */
/* global BGC: false, $: false, Polymer: false */


(function (context, dataStore, utils) {
  context.AuctionRow = Polymer({
    is : 'auction-row',

    listeners : {
      SubmitValidatedSize : 'onSubmitValidatedSize'
    },

    observers : [
      'deactivateObserver(inactive)',
      'filterObserver(filter)'
    ],

    behaviors : [context.NotificationFlashBehavior],

    properties : {
      dormant : {
        type               : Boolean,
        value              : false,
        reflectToAttribute : true
      },
      hidden : {
        type               : Boolean,
        value              : false,
        reflectToAttribute : true
      },
      inputBuySize : {
        type  : String,
        value : ''
      },
      inputSellSize : {
        type  : String,
        value : ''
      },
      isLockRow : {
        type               : Boolean,
        reflectToAttribute : true,
        value              : false
      }
    },

    ready () {
      this.$el = $(this);

      const {model} = this.row;
      const orderModel = model.getActiveOrder();
      const activeOrder = orderModel && orderModel.serialize();

      // Locked instrument
      this.isLockRow = model.get('isLockInstrument');

      // Set input sizes from order sizes
      this.inputBuySize = this.row.buySize;
      this.inputSellSize = this.row.sellSize;

      // Apply interest/order styling
      this._applyClassStyles(activeOrder);

      // Listen for model state change
      model.on('change', this.onModelChange, this);

      // Bind instrument size validators to the input controls
      this.querySelectorAll('input').forEach(input => {
        input.setValidationCallback(model.validateSize.bind(model));
      });
    },

    onModelChange () {
      const {model} = this.row;
      const {changed} = model;
      const {inactive, volume, newPrice} = changed;

      if (inactive) {
        this._deactivateRow();
      } else if (newPrice) {
        this.flashNotification(this.EFlashType.eNewPrice, this.$el.find('.mid-price'));
      } else if (!model.get('inactive')) {
        this._updateRow();
      }

      if (volume && utils.compareFPNumGT(volume, 0)) {
        this.flashNotification(this.EFlashType.eVolume, this.$el.find('.volume'));
      }
    },

    // Invoked when the parent view becomes 'inactive'
    deactivateObserver () {
      const {model} = this.row;
      const midPriceCell = this.querySelector('vm-midprice-cell');

      // Deactivate the row
      this._deactivateRow();

      // Remove model change listener
      model.off('change', this.onModelChange, this);

      midPriceCell.set('options.model', null);
      this.set('hidden', false);
    },

    filterObserver () {
      const {filter} = this;

      this.set('hidden', !this._filterRow(filter));
    },

    _filterRow (filter) {
      const {model, displayGlows} = this.row;
      const orderModel = model.getActiveOrder();
      const {eShowAll, eShowMyOrdersAndGlows} = BGC.enums.EVMShowLiveMode;

      if (filter === eShowAll || model.get('hasTradedAtMidPrice') || Boolean(orderModel) || model.hasSameLeInterest()) {
        return true;
      }

      if (filter === eShowMyOrdersAndGlows) {
        return displayGlows && model.get('thirdPartyInterest') !== 'none';
      }

      return false;
    },

    _updateRow () {
      const {model, genericFields = []} = this.row;

      const orderModel = model.getActiveOrder();
      const activeOrder = orderModel && orderModel.serialize();
      const buyOrder = activeOrder && activeOrder.buyOrder;
      const sellOrder = activeOrder && activeOrder.sellOrder;
      const midPrice = model.get('midPrice');
      const midPriceCell = this.querySelector('vm-midprice-cell');
      const buySize = buyOrder && buyOrder.hasBuySize ? String(buyOrder.buySize) : '';
      const sellSize = sellOrder && sellOrder.hasSellSize ? String(sellOrder.sellSize) : '';
      const hasTraded = model.get('hasTradedAtMidPrice');
      const {hidden = false} = this;
      const isHidden = !this._filterRow(this.filter);

      this.set('hidden', isHidden);
      this.set('dormant', model.get('inactive'));
      this.set('inputBuySize', buySize);
      this.set('inputSellSize', sellSize);
      this.set('row.readOnly', !model.canEnterSize() || model.get('isLockInstrument'));
      this.set('row.buySize', buySize);
      this.set('row.buyPrice', buyOrder ? buyOrder.price : midPrice);
      this.set('row.sellSize', sellSize);
      this.set('row.sellPrice', sellOrder ? sellOrder.price : midPrice);
      this.set('row.displayCancelBuy', Boolean(buyOrder && buyOrder.hasCancellableBuySize));
      this.set('row.displayCancelSell', Boolean(sellOrder && sellOrder.hasCancellableSellSize));
      this.set('row.disableFavoriteIcon', Boolean(buyOrder || sellOrder));
      this.set('row.priceCellOptions.order', activeOrder || {dummy : true});
      this.set('row.buyStatus', orderModel ? orderModel.buildStatusString('buy', true) : '');
      this.set('row.sellStatus', orderModel ? orderModel.buildStatusString('sell', true) : '');
      this.set('row.hasTraded', hasTraded);
      this.set('row.favoriteState', model.get('footprint') ? 1 : 0);
      this.set('isLockRow', model.get('isLockInstrument'));

      genericFields.forEach((fld, index) => {
        this.set(`row.genericFields.${index}.value`, model.get(fld.id));
      });

      midPriceCell.set('priceDisplay', model.get('priceDisplay'));
      midPriceCell.set('displayGavel', hasTraded);

      // Apply interest/order styling
      this._applyClassStyles(activeOrder);

      if (hidden !== isHidden) {
        this.fire('recalcLayout');
      }
    },

    _deactivateRow () {
      const interestCells = this.querySelectorAll('.mid-price, .name');

      // Clear live order details, persist order status + gavel
      this.set('row.readOnly', true);
      this.set('row.displayCancelBuy', false);
      this.set('row.displayCancelSell', false);
      this.set('row.buySize', '');
      this.set('row.sellSize', '');

      // Set the 'dormant' attribute. An 'active' view may contain dormant rows.
      this.set('dormant', true);

      // Clear live styling
      BGC.ui.viewUtils.applySameLEInterestGlows(false, false, interestCells);
      BGC.ui.viewUtils.applyThirdPartyInterestGlows('none', interestCells);

      this.classList.remove('buy-blotter-published-by-excel', 'sell-blotter-published-by-excel', 'executed');
    },

    _applyClassStyles (order) {
      const {model, displayGlows} = this.row;
      const thirdPartyInterest = displayGlows ? model.get('thirdPartyInterest') : 'none';
      const interestCells = this.querySelectorAll('.mid-price, .name');

      // Apply Third-party and 'Same LE' interest to price and instrument cells
      BGC.ui.viewUtils.applySameLEInterestGlows(model.get('hasSameLeBuyInterest'), model.get('hasSameLeSellInterest'), interestCells);
      BGC.ui.viewUtils.applyThirdPartyInterestGlows(thirdPartyInterest, interestCells);

      // Apply order styling
      this.classList.toggle('executed', Boolean(order && (order.hasBoughtSize || order.hasSoldSize)));
      this.classList.toggle('buy-blotter-published-by-excel', Boolean(order && order.wasBuyPublishedByExcel));
      this.classList.toggle('sell-blotter-published-by-excel', Boolean(order && order.wasSellPublishedByExcel));
    },


    computeStatusSeparator (buyStatus, sellStatus) {
      return buyStatus && sellStatus ? '/' : '';
    },

    onTapFavoriteIcon (event) {
      const {model} = this.row;

      // Prevent registration of a favorite footprint when the user has an order
      if (model.hasOwnOrder()) {
        return;
      }

      // If the favorite icon is being 'checked', register the new footprint, otherwise remove it
      if (event.currentTarget.state) {
        dataStore.footprints.add(new dataStore.modelDefinitions.Footprint({}, {instrument : model}));
      } else {
        dataStore.footprints.remove(model.get('footprint'));
      }
    },

    onTapOrderCancel (event) {
      const {target} = event;
      const {model} = this.row;

      model.sendCancelOrder('Auction Row', target.classList.contains('cancel-buy') ? 'buy' : 'sell');
    },

    onSubmitValidatedSize (event) {
      event.stopPropagation();

      let priceToSubmit = null;
      const {model} = this.row;
      const {detail, type, target} = event;
      const {side, size, price} = detail;

      if (type === 'SubmitValidatedPriceAndSize') {
        priceToSubmit = price;
      } else {
        priceToSubmit = model.get('midPrice');
        if (model.isSignFlippedForPickGive(side)) {
          priceToSubmit = -priceToSubmit;
        }
      }

      // Trigger submission of an order in response to size entry
      this.dispatchEvent(new CustomEvent('submitOrder', {
        detail : {
          eventSource  : 'Auction Instrument Row',
          instrumentId : model.get('instrumentId'),
          price        : priceToSubmit,
          size,
          side
        },
        bubbles : true
      }));

      target.blur();
    }
  });
}(window.BGC.ui.view, window.BGC.dataStore, window.BGC.utils));
