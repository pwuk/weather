/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */
///////////////////////////////////////////////////////////////////////////////
// file renderobject.js
// Render Object module implementation.
///////////////////////////////////////////////////////////////////////////////

(function (context, undefined) {
    "use strict";

    // RenderObject.
    context.RenderObject = function (id) {
        if (!(this instanceof context.RenderObject)) {
            throw new Error("Constructor called as a function.");
        }

        // Not ready until we say so (private member)
        var isInitialized = false;

        // Public access to private initialization state
        this.setInitialized = function () {
            isInitialized = true; // Can't be uninitialized once we are initialized!
        };

        this.getInitialized = function () {
            return isInitialized;
        };

        // Identifier.
        this.id = id;
        // Bounding rect.
        this.rect = { left: 0, top: 0, width: 0, height: 0 };
        // Resize flag
        this.resizeNeeded = false;

        this.automationElement = {};
    };

    // Called by automation framework
    context.RenderObject.prototype.serialize = function (json) {
        var screenRect = BGC.ui.view.renderer.viewToScreen(this.rect);
        json.rect = {
            left: Math.floor(screenRect.left),
            top: Math.floor(screenRect.top),
            width: Math.floor(screenRect.width),
            height: Math.floor(screenRect.height)
        };
    };

    // Placeholders to allow generic canvas view element-handling code.
    // Elements held at view level and derived from RenderObject should override these functions

    context.RenderObject.prototype.doMouseDown = function (viewPos, event) {
        return false;
    };

    context.RenderObject.prototype.doMouseUp = function (viewPos, event) {
        return false;
    };

    context.RenderObject.prototype.doMouseDblClick = function (viewPos, event) {
        return false;
    };

    context.RenderObject.prototype.doMouseOver = function (viewPos, event) {
        return false;
    };

    context.RenderObject.prototype.doMouseLeave = function (viewPos, event) {
        return false;
    };

    context.RenderObject.prototype.onKeyDown = function (event) {
        return false;
    };

    context.RenderObject.prototype.onKeyUp = function (event) {
        return false;
    };

    // Has something happened to the data or as a result of UI interaction that means the object needs resizing?
    context.RenderObject.prototype.isResizeNeeded = function () {
        return this.resizeNeeded;
    };
    context.RenderObject.prototype.setResizeNeeded = function (resize) {
        this.resizeNeeded = resize;
    };

    // Stub for object resizing function can be passed view dimension(s) by view resize code
    // Any other parameters can be added for specific types of object
    context.RenderObject.prototype.calcSize = function (viewWidth) {
        var o = {}; o.i = 0; // Function currently unused - prevent JSLint from objecting
    };

    // Update colors in the object based on the current theme
    context.RenderObject.prototype.updateElementColors = function () {
        var o = {}; o.i = 0; // Function currently unused - prevent JSLint from objecting
    };

    // cancel any current user interaction with the object.
    context.RenderObject.prototype.resetUI = function () {
        var o = {}; o.i = 0; // Function currently unused - prevent JSLint from objecting
    };

}(window.BGC.ui));
