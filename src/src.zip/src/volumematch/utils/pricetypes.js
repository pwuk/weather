/* eslint-disable max-lines, max-statements, func-names, no-restricted-globals, no-magic-numbers, no-bitwise, no-param-reassign, max-len, prefer-rest-params, default-case */
/* global _ */

// /////////////////////////////////////////////////////////////////////////////
// file pricestypes.js
// /////////////////////////////////////////////////////////////////////////////

(function (utils, namespace) {
  /**
   * @method sign
   */
  function sign (value) {
    return value / Math.abs(value);
  }

  /**
   * @method round
   */
  function round (value) {
    return sign(value) * Math.round(Math.abs(value)) || 0;
  }

  /**
   * @method roundToNth
   */
  function roundToNth (value, nth) {
    return value ? round(value * nth) / nth : 0;
  }

  /**
   * @method getWhole
   */
  function getWhole (value) {
    return Math.abs(value) | 0;
  }

  /**
   * @method getFraction
   */
  function getFraction (value) {
    return Number(`0.${(String(value).split('.') || [])[1] || '00'}`);
  }

  /**
   * @class Price
   */
  function Price (price) {
    if (typeof price === 'string') {
      this.initializeFromString(price);
      if (isNaN(this.numericValue)) {
        this.stringValue = 'NaN';
      }
    } else if (typeof price === 'number') {
      this.initializeFromNumber(price);
    } else {
      this.stringValue = 'NaN';
    }
  }

  Price.prototype.initializeFromNumber = function (price) {
    this.numericValue = price;
    this.stringValue = this.getStringPriceFromNumber(price);
  };

  Price.prototype.initializeFromString = function (price) {
    this.stringValue = price;
    this.numericValue = this.getNumericPriceFromString(price);
  };

  Price.prototype.valueOf = function () {
    return this.numericValue;
  };

  Price.prototype.toString = function () {
    return this.stringValue;
  };


  Price.prototype.isValid = function () {
    return true;
  };

  Price.prototype.fixedToNth = function (price, nth) {
    const whole = (String(price).split('.') || [])[0] || 0;
    const fraction = (String(price).split('.') || [])[1] || '00';

    return `${whole}.${fraction.substr(0, nth)}`;
  };

  /**
   * @class PriceRegexMatcher
   */
  function PriceRegexMatcher (regex) {
    this.priceRegex = regex;
  }

  PriceRegexMatcher.prototype.isValid = function () {
    const matched = this.getRegexResults();


    return matched && (matched[0] === matched.input);
  };

  PriceRegexMatcher.prototype.getRegexResults = function () {
    return this.stringValue.match(this.priceRegex);
  };

  /**
   * @class GivePickUpEnabled
   */
  function GivePickUpEnabled (enabled) {
    this.givepickUpEnabled = enabled;
  }

  GivePickUpEnabled.prototype.getGivePickUpEnabled = function () {
    return this.givepickUpEnabled;
  };

  /**
   * @class PriceWith32nd
   */
  function PriceWith32nd () {
    return this;
  }

  PriceWith32nd.prototype.getNumericPriceFromString = function () {
    if (!this.isValid()) {
      return 'NaN';
    }

    const matches = this.getRegexResults();


    // eslint-disable-next-line no-bitwise
    return Number((matches[1] || '') + (~~matches[2] + ((matches[3] || 0) / 32) + this.getNumericFrom256th()));
  };

  PriceWith32nd.prototype.getStringPriceFromNumber = function (price) {
    const fraction = roundToNth(getFraction(price), 256);
    const fraction32 = (fraction * 32) | 0;
    const fraction256 = Math.abs(fraction * 256 - fraction32 * 8);
    let priceString = '';

    priceString = (sign(price) * (getWhole(price) + fraction32 / 100)).toFixed(2) + this.getStringFrom256th(fraction256);

    if (this.customDecimalSeparator) {
      priceString = priceString.replace('.', this.customDecimalSeparator);
    }

    return priceString;
  };

  PriceWith32nd.prototype.getStringFrom256th = function () {
    return '';
  };

  PriceWith32nd.prototype.getNumericFrom256th = function () {
    return 0;
  };

  /**
   * @class PriceWithTick
   */
  function PriceWithTick () {
    return this;
  }

  PriceWithTick.prototype.getStringPriceFromNumber = function (price) {
    const tick = 0.0025;
    const nTicks = round(Math.abs(price) / tick);
    const wholeTicks = ~~(nTicks / 4) * 4;
    const fractionTicks = ~~Math.abs(nTicks - wholeTicks);
    const priceSign = sign(price) < 0 ? '-' : '';

    return priceSign + (wholeTicks * tick).toFixed(2) + this.getStringFromTick(fractionTicks);
  };

  PriceWithTick.prototype.getNumericPriceFromString = function () {
    if (!this.isValid()) {
      return 'NaN';
    }

    const matches = this.getRegexResults();


    return Number((matches[1] || '') + (Number(matches[2]) + this.getNumericFromTick(matches[3])));
  };

  PriceWithTick.prototype.getStringFromTick = function () {
    return '';
  };

  PriceWithTick.prototype.getNumericFromTick = function () {
    return 0;
  };

  /**
   * @class PriceWithDecimal
   */
  function PriceWithDecimal (decimalPlaces, minDecimalPlaces) {
    this.decimalPlaces = decimalPlaces;
    this.minDecimalPlaces = minDecimalPlaces;
  }

  PriceWithDecimal.prototype.getStringPriceFromNumber = function (price) {
    return String(this.getNumericPriceFromString(price));
  };

  PriceWithDecimal.prototype.getNumericPriceFromString = function (price) {
    return Number(price).toFixed(this.decimalPlaces);
  };

  PriceWithDecimal.prototype.isValid = function () {
    return utils.isValidFloat(this.stringValue);
  };

  PriceWithDecimal.prototype.getTickNumberInDecimals = function (price, nth) {
    return `.${round(getFraction(price) * nth)}`;
  };

  /**
   * @class PriceWithCbot
   */
  function PriceWithCbot (divisor, decimalPlaces) {
    this.divisor = divisor;
    this.decimalPlaces = decimalPlaces;
  }

  PriceWithCbot.prototype.getStringPriceFromNumber = function (price) {
    return (price / this.divisor).toFixed(this.decimalPlaces);
  };

  PriceWithCbot.prototype.getNumericPriceFromString = function (price) {
    return Number((price * this.divisor).toFixed(this.decimalPlaces));
  };

  PriceWithCbot.prototype.isValid = function () {
    return utils.isValidFloat(this.stringValue);
  };

  // All price types
  namespace.ETypes = {
    // Valid price types
    ePriceTypeDecimal            : 'priceTypeDecimal',
    ePriceType32nd               : 'priceTypeF32',
    ePriceTypeDecimalF64         : 'priceTypeF64',
    ePriceTypeDecimalF128        : 'priceTypeF128',
    ePriceTypeDecimalF2568th32nd : 'priceTypeF256',
    ePriceTypeDecimalF16OfF32    : 'priceTypeF512',

    // All other price types have been deprecated - they are not supported by the UI server
    ePriceTypeVulgarF8            : 'priceVulgarF8',
    ePriceTypeDecimalD0           : 'priceDecimalD0',
    ePriceTypeDecimalD1           : 'priceDecimalD1',
    ePriceTypeDecimalD2           : 'priceDecimalD2',
    ePriceTypeDecimalD2Plus       : 'priceDecimalD2Plus',
    ePriceTypeDecimalD3           : 'priceDecimalD3',
    ePriceTypeDecimalF4           : 'priceDecimalF4',
    ePriceTypeDecimalF8           : 'priceDecimalF8',
    ePriceTypeDecimalF16          : 'priceDecimalF16',
    ePriceTypeDecimalF32          : 'priceDecimalF32',
    ePriceTypeDecimalF256         : 'priceDecimalF256',
    ePriceTypeDecimalD4Plus       : 'priceDecimalD4Plus',
    ePriceTypeDecimalDVar         : 'priceDecimalDVar',
    ePriceTypeDecimalD2Bill       : 'priceDecimalD2Bill',
    ePriceTypeTBill               : 'priceTBill',
    ePriceTypeDecimalD2Bill256    : 'priceDecimalD2Bill256',
    ePriceTypeDecimalD2Wi         : 'priceDecimalD2Wi',
    ePriceTypeCxSpread            : 'priceCxSpread',
    ePriceTypeCbot32nd            : 'priceCbot32nd',
    ePriceTypeCbot64th            : 'priceCbot64th',
    ePriceTypeCbotHalf32nd        : 'priceCbotHalf32nd',
    ePriceTypeCbotQtr32nd         : 'priceCbotQtr32nd',
    ePriceTypeCbotHalf64th        : 'priceCbotHalf64th',
    ePriceTypeCbotFourths         : 'priceCbotFourths',
    ePriceTypeCbotEighths         : 'priceCbotEighths',
    ePriceTypeDecimalFutureF32    : 'priceDecimalFutureF32',
    ePriceTypeDecimalFutureF64    : 'priceDecimalFutureF64',
    ePriceTypeDecimalFutureF128   : 'priceDecimalFutureF128',
    ePriceTypeFutureForFutureF64  : 'priceFutureForFutureF64',
    ePriceTypeFutureForFutureF128 : 'priceFutureForFutureF128',
    ePriceTypeCbot3dHalves        : 'priceCbot3dHalves',
    ePriceTypeCbotHalves          : 'priceCbotHalves',
    ePriceTypeCbotModFourths      : 'priceCbotModFourths',
    ePriceTypeCbotTenths          : 'priceCbotTenths',
    ePriceTypeCbotTwentieths      : 'priceCbotTwentieths',
    ePriceTypeCbotModFortieths    : 'priceCbotModFortieths',
    ePriceTypeCbotHundredths      : 'PriceCbotHundredths',
    ePriceTypeCbotHalfHundredths  : 'priceCbotHalfHundredths',
    ePriceTypeDecimalD3Short      : 'priceDecimalD3Short'
  };

  /**
   * @method getPriceObject
   * @param  ePriceType    :{namespace.ETypes} the valid price type the price represents.
   * @param  price         :{Number or String} the price value
   * @param  priceOptions  :{Object} price options to be passed to the price object
   *                          option : priceDecimalDVarMinMaxDecimalPlaces {Object} attributes {min, max}
   *                          option : priceWith32ndCustomDecimalSeparator {String} string to replace decimal point in formatted price
   * @return: returns price object corresponding to the ePricetype parameter
   */
  namespace.getPriceObject = function (ePriceType, price, priceOptions) {
    let priceObject;

    switch (ePriceType) {
      // Valid price types
      case namespace.ETypes.ePriceTypeDecimal:
        priceObject = new namespace.PriceDecimalDVar(price, false, priceOptions.priceDecimalDVarMinMaxDecimalPlaces);
        break;
      case namespace.ETypes.ePriceType32nd:
        priceObject = new namespace.Price32nd(price, false, priceOptions.priceWith32ndCustomDecimalSeparator);
        break;
      case namespace.ETypes.ePriceTypeDecimalF64:
        priceObject = new namespace.PriceDecimalF64(price, priceOptions.priceWith32ndCustomDecimalSeparator);
        break;
      case namespace.ETypes.ePriceTypeDecimalF128:
        priceObject = new namespace.PriceDecimalF128(price, priceOptions.priceWith32ndCustomDecimalSeparator);
        break;
      case namespace.ETypes.ePriceTypeDecimalF2568th32nd:
        priceObject = new namespace.PriceDecimalF2568th32nd(price, priceOptions.priceWith32ndCustomDecimalSeparator);
        break;
      case namespace.ETypes.ePriceTypeDecimalF16OfF32:
        priceObject = new namespace.PriceDecimalF16OfF32(price, priceOptions.priceWith32ndCustomDecimalSeparator);
        break;

      // All other price types have been deprecated - they are not supported by the UI server
      case namespace.ETypes.ePriceTypeVulgarF8:
        priceObject = new namespace.PriceVulgarF8(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD0:
        priceObject = new namespace.PriceDecimalD0(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD1:
        priceObject = new namespace.PriceDecimalD1(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD2:
        priceObject = new namespace.PriceDecimalD2(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD2Plus:
        priceObject = new namespace.PriceDecimalD2Plus(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD3:
        priceObject = new namespace.PriceDecimalD3(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD4:
        priceObject = new namespace.PriceDecimalD4(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalF4:
        priceObject = new namespace.PriceDecimalF4(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalF8:
        priceObject = new namespace.PriceDecimalF8(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalF16:
        priceObject = new namespace.PriceDecimalF16(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalF32:
        priceObject = new namespace.PriceDecimalF32(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalF256:
        priceObject = new namespace.PriceDecimalF256(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD4Plus:
        priceObject = new namespace.PriceDecimalD4Plus(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD2Bill:
        priceObject = new namespace.PriceDecimalD2Bill(price);
        break;
      case namespace.ETypes.ePriceTypeTBill:
        priceObject = new namespace.PriceTBill(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD2Bill256:
        priceObject = new namespace.PriceDecimalD2Bill256(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD2Wi:
        priceObject = new namespace.PriceDecimalD2Wi(price);
        break;
      case namespace.ETypes.ePriceTypeCxSpread:
        priceObject = new namespace.PriceCxSpread(price);
        break;
      case namespace.ETypes.ePriceTypeCbot32nd:
        priceObject = new namespace.PriceCbot32nd(price);
        break;
      case namespace.ETypes.PriceCbot64th:
        priceObject = new namespace.PriceCbot64th(price);
        break;
      case namespace.ETypes.ePriceTypeCbotHalf32nd:
        priceObject = new namespace.PriceCbotHalf32nd(price);
        break;
      case namespace.ETypes.ePriceTypeCbotQtr32nd:
        priceObject = new namespace.PriceCbotQtr32nd(price);
        break;
      case namespace.ETypes.ePriceTypeCbotHalf64th:
        priceObject = new namespace.PriceCbotHalf64th(price);
        break;
      case namespace.ETypes.ePriceTypeCbotFourths:
        priceObject = new namespace.PriceCbotFourths(price);
        break;
      case namespace.ETypes.ePriceTypeCbotEighths:
        priceObject = new namespace.PriceCbotEighths(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalFutureF32:
        priceObject = new namespace.PriceDecimalFutureF32(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalFutureF64:
        priceObject = new namespace.PriceDecimalFutureF64(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalFutureF128:
        priceObject = new namespace.PriceDecimalFutureF128(price);
        break;
      case namespace.ETypes.ePriceTypeFutureForFutureF64:
        priceObject = new namespace.PriceFutureForFutureF64(price);
        break;
      case namespace.ETypes.ePriceTypeFutureForFutureF128:
        priceObject = new namespace.PriceFutureForFutureF128(price);
        break;
      case namespace.ETypes.ePriceTypeCbot3dHalves:
        priceObject = new namespace.PriceCbot3dHalves(price);
        break;
      case namespace.ETypes.ePriceTypeCbotHalves:
        priceObject = new namespace.PriceCbotHalves(price);
        break;
      case namespace.ETypes.ePriceTypeCbotModFourths:
        priceObject = new namespace.PriceCbotModFourths(price);
        break;
      case namespace.ETypes.ePriceTypeCbotTenths:
        priceObject = new namespace.PriceCbotTenths(price);
        break;
      case namespace.ETypes.ePriceTypeCbotTwentieths:
        priceObject = new namespace.PriceCbotTwentieths(price);
        break;
      case namespace.ETypes.ePriceTypeCbotModFortieths:
        priceObject = new namespace.PriceCbotModFortieths(price);
        break;
      case namespace.ETypes.ePriceTypeCbotHundredths:
        priceObject = new namespace.PriceCbotHundredths(price);
        break;
      case namespace.ETypes.ePriceTypeCbotHalfHundredths:
        priceObject = new namespace.PriceCbotHalfHundredths(price);
        break;
      case namespace.ETypes.ePriceTypeDecimalD3Short:
        priceObject = new namespace.PriceDecimalD3Short(price);
        break;
    }

    return priceObject;
  };


  /**
   * @class Price32nd		CFETI_PRICETYPE_32ND	price type
   */
  namespace.Price32nd = function (price, enabled, customDecimalSeparator) {
    this.customDecimalSeparator = customDecimalSeparator;
    const separator = this.customDecimalSeparator || '[\.-]';

    PriceRegexMatcher.call(this, new RegExp(`^(-|\\+)?(\\d+)?(?:${separator}((?:[0-2][0-9]|3[0-1])$))?`));
    GivePickUpEnabled.call(this, enabled);
    Price.apply(this, arguments);
  };

  _.extend(namespace.Price32nd.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype, GivePickUpEnabled.prototype);

  namespace.Price32nd.prototype.getStringPriceFromNumber = function (price) {
    let priceString = '';

    if (this.getGivePickUpEnabled()) {
      let givePick = 'G ';

      if (price > 0) {
        givePick = 'P ';
      }

      priceString = givePick + (getWhole(price) + roundToNth(getFraction(price), 256) * 0.32).toFixed(2);
    } else {
      priceString = (sign(price) * (getWhole(price) + roundToNth(getFraction(price), 256) * 0.32)).toFixed(2);
    }


    if (this.customDecimalSeparator) {
      priceString = priceString.replace('.', this.customDecimalSeparator);
    }

    return priceString;
  };

  namespace.Price32nd.prototype.getNumericPriceFromString = function () {
    if (!this.isValid()) {
      return 'NaN';
    }
    const matches = this.getRegexResults();


    return Number(~~matches[2] + ((matches[3] ? matches[3] : 0) / 32));
  };

  /**
   * @class PriceDecimalF4  CFETI_PRICETYPE_DECIMAL_F4 price type
   */
  namespace.PriceDecimalF4 = function () {
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF4.prototype, Price.prototype, PriceWithDecimal.prototype);

  namespace.PriceDecimalF4.prototype.getStringPriceFromNumber = function (price) {
    if (price >= 0) {
      return `+${this.fixedToNth(price, 2)}`;
    }

    return this.fixedToNth(price, 2);
  };

  /**
   * @class PriceDecimalF8  CFETI_PRICETYPE_DECIMAL_F8 price type
   */
  namespace.PriceDecimalF8 = function () {
    PriceWithDecimal.call(this, 1);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF8.prototype, Price.prototype, PriceWithDecimal.prototype);

  namespace.PriceDecimalF8.prototype.getStringPriceFromNumber = function (price) {
    return String(sign(price) * (getWhole(price) + this.getTickNumberInDecimals(price, 8)));
  };

  /**
   * @class PriceDecimalF16  CFETI_PRICETYPE_DECIMAL_F16 price type
   */
  namespace.PriceDecimalF16 = function () {
    PriceWithDecimal.call(this, 2);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF16.prototype, Price.prototype, PriceWithDecimal.prototype);

  namespace.PriceDecimalF16.prototype.getStringPriceFromNumber = function (price) {
    return String(sign(price) * (getWhole(price) + this.getTickNumberInDecimals(price, 16)));
  };

  /**
   * @class PriceDecimalF32  CFETI_PRICETYPE_DECIMAL_F32 price type
   */
  namespace.PriceDecimalF32 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.((?:[0-2][0-9]|3[0-1])$))?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF32.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalF32.prototype.getNumericPriceFromString = function (price) {
    if (!this.isValid()) {
      return 'NaN';
    }
    const matches = this.getRegexResults();


    return sign(price) * (~~matches[2] + matches[3] / 32);
  };

  /**
   * @class PriceDecimalF64  CFETI_PRICETYPE_DECIMAL_F64 price type
   */
  namespace.PriceDecimalF64 = function (price, customDecimalSeparator) {
    this.customDecimalSeparator = customDecimalSeparator;
    const separator = this.customDecimalSeparator || '[.-]';

    PriceRegexMatcher.call(this, new RegExp(`^(-|\\+)?(\\d+)?(?:${separator}((?:[0-2][0-9]|3[0-1]))(4|\\+)?$)?`));
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF64.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalF64.prototype.getStringFrom256th = function (n256s) {
    if (n256s > 3 && n256s < 8) {
      return '+';
    }

    return '';
  };

  namespace.PriceDecimalF64.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();


    return matches[4] ? 4 / 32 / 8 : 0;
  };

  /**
   *
   * @class PriceDecimalF128 CFETI_PRICETYPE_DECIMAL_F128 price type
   */
  namespace.PriceDecimalF128 = function (price, customDecimalSeparator) {
    this.customDecimalSeparator = customDecimalSeparator;
    const separator = this.customDecimalSeparator || '[.-]';

    PriceRegexMatcher.call(this, new RegExp(`^(-|\\+)?(\\d+)?(?:${separator}((?:[0-2][0-9]|3[0-1]))(2|4|\\+|6)?$)?`));
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF128.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalF128.prototype.getStringFrom256th = function (n256s) {
    if (n256s >= 2 && n256s < 4) {
      return '2';
    }

    if (n256s >= 4 && n256s < 6) {
      return '+';
    }

    if (n256s >= 6 && n256s < 8) {
      return '6';
    }

    return '';
  };

  namespace.PriceDecimalF128.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();


    return matches[4] ? (Number(matches[4]) || 4) / 32 / 8 : 0;
  };

  /**
   *
   * @class PriceDecimalF256 CFETI_PRICETYPE_DECIMAL_F256 price type
   */
  namespace.PriceDecimalF256 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.((?:[0-2][0-9]|3[0-1]))(2|4|\+|6)?$)?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF256.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalF256.prototype.getStringPriceFromNumber = function (price) {
    const ticks = round(price * 800);
    const wholeTicks = ticks >= 0 ? Math.floor(ticks / 8) * 8 : Math.ceil(ticks / 8) * 8;

    return (wholeTicks / 800).toFixed(2) + this.getStringFrom256th(Math.abs(ticks - wholeTicks));
  };

  namespace.PriceDecimalF256.prototype.getStringFrom256th = function (n256s) {
    if (n256s === 4) {
      return '+';
    }
    if (n256s > 0 && n256s < 8) {
      return String(n256s);
    }

    return '';
  };

  namespace.PriceDecimalF256.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();


    return matches[4] ? (Number(matches[4]) || 4) / 32 / 8 : 0;
  };

  /**
   *
   * @class PriceDecimalD2Bill CFETI_PRICETYPE_DECIMAL_D2_BILL price type
   */
  namespace.PriceDecimalD2Bill = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+?(?:\.\d{2})?)([1-3]|\+)?$/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD2Bill.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWithTick.prototype);

  namespace.PriceDecimalD2Bill.prototype.getStringFromTick = function (fractionTicks) {
    let lastCharacter = '';

    switch (fractionTicks) {
      case 1:
        lastCharacter = '1';
        break;
      case 2:
        lastCharacter = '+';
        break;
      case 3:
        lastCharacter = '3';
        break;
    }

    return lastCharacter;
  };

  namespace.PriceDecimalD2Bill.prototype.getNumericFromTick = function (fractionTicks) {
    return fractionTicks ? String((Number(fractionTicks) || 2) * 25) : 0;
  };

  /**
   *
   * @class PriceDecimalD2Bill256 CFETI_PRICETYPE_DECIMAL_D2_BILL_256 price type
   */
  namespace.PriceDecimalD2Bill256 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+?(?:\.\d{2})?)([1-3]|\+)?$/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD2Bill256.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWithTick.prototype);

  namespace.PriceDecimalD2Bill256.prototype.getStringFromTick = function (fractionTicks) {
    let lastCharacter = '';

    switch (fractionTicks) {
      case 0:
        lastCharacter = ' ';
        break;
      case 1:
        lastCharacter = '1';
        break;
      case 2:
        lastCharacter = '+';
        break;
      case 3:
        lastCharacter = '3';
        break;
    }

    return lastCharacter;
  };

  /**
   *
   * @class PriceDecimalD2Wi
   */
  namespace.PriceDecimalD2Wi = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+?(?:\.\d{2})?)(2|\+|4|6)?$/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD2Wi.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWithTick.prototype);

  namespace.PriceDecimalD2Wi.prototype.getStringFromTick = function (fractionTicks) {
    let lastCharacter = '';

    switch (fractionTicks) {
      case 1:
        lastCharacter = '2';
        break;
      case 2:
        lastCharacter = '+';
        break;
      case 3:
        lastCharacter = '6';
        break;
    }

    return lastCharacter;
  };

  namespace.PriceDecimalD2Wi.prototype.getNumericFromTick = function (fractionTicks) {
    return fractionTicks ? String((Number(fractionTicks) || 4) / 2 * 25) : 0;
  };

  /**
   *
   * @class PriceDecimalD2Bill256
   */
  namespace.PriceDecimalD2Bill256 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+?(?:\.\d{2})?)(1|\+|3)?$/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD2Bill256.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWithTick.prototype);

  namespace.PriceDecimalD2Bill256.prototype.getStringFromTick = function (fractionTicks) {
    let lastCharacter = '';

    switch (fractionTicks) {
      case 1:
        lastCharacter = '1';
        break;
      case 2:
        lastCharacter = '+';
        break;
      case 3:
        lastCharacter = '3';
        break;
    }

    return lastCharacter;
  };

  namespace.PriceDecimalD2Bill256.prototype.getNumericFromTick = function (fractionTicks) {
    // eslint-disable-next-line no-mixed-operators
    return fractionTicks ? String((Number(fractionTicks) || 4) / 2 * 25) : 0;
  };

  /**
   *
   * @class PriceDecimalF2568th32nd CFETI_PRICETYPE_DECIMAL_F256_8TH_32ND price type
   */
  namespace.PriceDecimalF2568th32nd = function (price, customDecimalSeparator) {
    this.customDecimalSeparator = customDecimalSeparator;
    const separator = this.customDecimalSeparator || '[.-]';

    PriceRegexMatcher.call(this, new RegExp(`^(-|\\+)?(\\d+)?(?:${separator}((?:[0-2][0-9]|3[0-1]))([1-7]|\\+)?$)?`));
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF2568th32nd.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalF2568th32nd.prototype.getStringFrom256th = function (n256s) {
    if (n256s === 4) {
      return '+';
    }
    if (n256s > 0 && n256s < 8) {
      return String(n256s);
    }

    return '';
  };

  namespace.PriceDecimalF2568th32nd.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();


    return matches[4] ? (Number(matches[4]) || 4) / 32 / 8 : 0;
  };

  /**
   *
   * @class PriceDecimalFutureF32 CFETI_PRICETYPE_DECIMAL_FUTURE_F32 price type
   */
  namespace.PriceDecimalFutureF32 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.((?:[0-2][0-9]|3[0-1])$))?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalFutureF32.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  /**
   *
   * @class PriceDecimalFutureF64 CFETI_PRICETYPE_DECIMAL_FUTURE_F64 price type
   */
  namespace.PriceDecimalFutureF64 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.((?:[0-2][0-9]|3[0-1]))(\+)?$)?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalFutureF64.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalFutureF64.prototype.getStringFrom256th = function (n256s) {
    if (n256s >= 4 && n256s < 8) {
      return '+';
    }

    return '';
  };

  namespace.PriceDecimalFutureF64.prototype.getNumericFrom256th = function () {
    return this.getRegexResults()[4] ? 4 / 32 / 8 : 0;
  };

  /**
   *
   * @class PriceDecimalFutureF128 CFETI_PRICETYPE_DECIMAL_FUTURE_F128 price type
   */
  namespace.PriceDecimalFutureF128 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.((?:[0-2][0-9]|3[0-1]))(0|2|5|7)?$)?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalFutureF128.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalFutureF128.prototype.getStringFrom256th = function (n256s) {
    const lastCharacter = '0';

    if (n256s >= 2 && n256s < 4) {
      return '2';
    }

    if (n256s >= 4 && n256s < 6) {
      return '5';
    }

    if (n256s >= 6 && n256s < 8) {
      return '7';
    }

    return lastCharacter;
  };

  namespace.PriceDecimalFutureF128.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();


    return matches[4] ? (Number(matches[4]) || 4) / 32 / 8 : 0;
  };

  /**
   *
   * @class PriceFutureForFutureF64 CFETI_PRICETYPE_EXCH_FUTURE_FOR_FUTURE_F64 price type
   */
  namespace.PriceFutureForFutureF64 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.((?:[0-2][0-9]|3[0-1]))(0|5)?$)?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceFutureForFutureF64.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceFutureForFutureF64.prototype.getStringFrom256th = function (n256s) {
    let lastCharacter = '0';

    if (n256s >= 4 && n256s < 8) {
      lastCharacter = '5';
    }

    return lastCharacter;
  };

  namespace.PriceFutureForFutureF64.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();


    return matches[4] ? (Number(matches[4]) || 4) / 32 / 8 : 0;
  };

  /**
   *
   * @class PriceFutureForFutureF128 CFETI_PRICETYPE_EXCH_FUTURE_FOR_FUTURE_F128 price type
   */
  namespace.PriceFutureForFutureF128 = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.((?:[0-2][0-9]|3[0-1]))(0|2|5|7)?$)?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceFutureForFutureF128.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceFutureForFutureF128.prototype.getStringFrom256th = function (price) {
    let lastCharacter = '0';
    const one256th = 1 / 256;
    const whole256ths = ~~(price * 256);
    const fraction = Math.abs(price - (whole256ths / 256));
    const n256s = ~~round(fraction / one256th);


    if (n256s >= 2 && n256s < 4) {
      lastCharacter = '2';
    } else if (n256s >= 4 && n256s < 6) {
      lastCharacter = '5';
    } else if (n256s >= 6 && n256s < 8) {
      lastCharacter = '7';
    }

    return lastCharacter;
  };

  namespace.PriceFutureForFutureF128.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();
    let n256s = 0;

    if (matches[3] > 0 && matches[3] < 7) {
      n256s = matches[3] / 256;
    }

    return Number((matches[1] || '') + (((matches[2] || 0) / 32) + n256s));
  };

  /**
   *
   * @class PriceTBill CFETI_PRICETYPE_TBILL price type
   */
  namespace.PriceTBill = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+?(?:\.\d{2})?)(0|1|3|5)?$/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceTBill.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWithTick.prototype);

  namespace.PriceTBill.prototype.getStringFromTick = function (fractionTicks) {
    let lastCharacter = '';

    switch (fractionTicks) {
      case 1:
        lastCharacter = '1';
        break;
      case 2:
        lastCharacter = '5';
        break;
      case 3:
        lastCharacter = '3';
        break;
    }

    return lastCharacter;
  };

  namespace.PriceTBill.prototype.getNumericFromTick = function (fractionTicks) {
    let lastDigit = 0;

    switch (fractionTicks) {
      case '1':
        lastDigit = '25';
        break;
      case '3':
        lastDigit = '75';
        break;
      case '5':
        lastDigit = '50';
        break;
    }

    return lastDigit;
  };

  /**
   *
   * @class PriceDecimalF16OfF32 CFETI_PRICETYPE_DECIMAL_F16_OF_F32 price type
   */
  namespace.PriceDecimalF16OfF32 = function (price, customDecimalSeparator) {
    this.customDecimalSeparator = customDecimalSeparator;
    const separator = this.customDecimalSeparator || '[.-]';

    this.characters = ['00', '01', '1', '03', '2', '05', '3', '07', '+', '09', '5', '11', '6', '13', '7', '15'];
    PriceRegexMatcher.call(this, new RegExp(`^(-|\\+)?(\\d+)?(?:${separator}((?:[0-2][0-9]|3[0-1]))(00|01|1|03|2|05|3|07|\\+|8|09|5|11|6|13|7|15)?$)?`));
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalF16OfF32.prototype, Price.prototype, PriceRegexMatcher.prototype, PriceWith32nd.prototype);

  namespace.PriceDecimalF16OfF32.prototype.getStringPriceFromNumber = function (price) {
    const fraction = roundToNth(getFraction(price), 512);
    const fraction32 = (fraction * 32) | 0;
    const fraction512 = Math.abs(fraction * 512 - fraction32 * 16);

    let priceString = (sign(price) * (getWhole(price) + fraction32 / 100)).toFixed(2) + this.characters[fraction512];

    if (this.customDecimalSeparator) {
      priceString = priceString.replace('.', this.customDecimalSeparator);
    }

    return priceString;
  };

  namespace.PriceDecimalF16OfF32.prototype.getNumericFrom256th = function () {
    const matches = this.getRegexResults();

    return matches[4] ? this.characters.indexOf(String(matches[4] === '8' ? '+' : matches[4])) / 512 : 0;
  };

  /**
   *
   * @class PriceCxSpread CFETI_PRICETYPE_CX_SPREAD price type
   */
  namespace.PriceCxSpread = function () {
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\.(\d{1})$)?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCxSpread.prototype, Price.prototype, PriceRegexMatcher.prototype);

  namespace.PriceCxSpread.prototype.getStringPriceFromNumber = function (price) {
    const one8thOfA32nd = 1 / 32 / 8;
    let whole32nds = ~~(price * 32);
    const fraction = Math.abs(price - (whole32nds / 32));
    let iEighthsOf32nds = ~~round(fraction / one8thOfA32nd);

    if (iEighthsOf32nds > 7) {
      if (price < 0) {
        whole32nds -= 1;
      } else {
        whole32nds += 1;
      }
      iEighthsOf32nds = 0;
    }

    return (whole32nds + (iEighthsOf32nds / 10)).toFixed(1);
  };

  namespace.PriceCxSpread.prototype.getNumericPriceFromString = function () {
    if (!this.isValid()) {
      return 'NaN';
    }

    const matches = this.getRegexResults();
    let n256s = 0;

    if (matches[3] > 0 && matches[3] < 7) {
      n256s = matches[3] / 256;
    }

    return Number((matches[1] || '') + (((matches[2] || 0) / 32) + n256s));
  };

  /**
   *
   * @class PriceVulgarF8 CFETI_PRICETYPE_VULGAR_F8 price type
   */
  namespace.PriceVulgarF8 = function () {
    this.eights = ['1/8', '1/4', '3/8', '1/2', '5/8', '3/4', '7/8'];
    PriceRegexMatcher.call(this, /^(-|\+)?(\d+)?(?:\s((?:1\/8|1\/4|3\/8|1\/2|5\/8|3\/4|7\/8)$))?/);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceVulgarF8.prototype, Price.prototype, PriceRegexMatcher.prototype);

  namespace.PriceVulgarF8.prototype.getStringPriceFromNumber = function (price) {
    const whole = ~~price;
    const eights = ~~Math.abs((price - whole) / 0.125);
    const lastCharacter = eights ? ` ${this.eights[eights - 1]}` : '';

    return whole + lastCharacter;
  };

  namespace.PriceVulgarF8.prototype.getNumericPriceFromString = function () {
    if (!this.isValid()) {
      return 'NaN';
    }

    const matches = this.getRegexResults();
    let fraction = 0;

    if (matches[3]) {
      fraction = matches[3][0] / matches[3][2];
    }

    return Number((matches[1] || '') + (~~matches[2] + fraction));
  };

  /**
   *
   * @class PriceDecimal CFETI_PRICETYPE_DECIMAL price type
   */
  namespace.PriceDecimal = function () {
    PriceWithDecimal.call(this, 4);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimal.prototype, Price.prototype, PriceWithDecimal.prototype);

  namespace.PriceDecimal.prototype.getNumericPriceFromString = function (price) {
    return Number(Number(price).toFixed(this.decimalPlaces));
  };

  /**
   *
   * @class PriceDecimalD0 CFETI_PRICETYPE_DECIMAL_D0 price type
   */
  namespace.PriceDecimalD0 = function () {
    PriceWithDecimal.call(this, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD0.prototype, Price.prototype, PriceWithDecimal.prototype);

  /**
   *
   * @class PriceDecimalD1 CFETI_PRICETYPE_DECIMAL_D1 price type
   */
  namespace.PriceDecimalD1 = function () {
    PriceWithDecimal.call(this, 1);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD1.prototype, Price.prototype, PriceWithDecimal.prototype);

  /**
   *
   * @class PriceDecimalD2 CFETI_PRICETYPE_DECIMAL_D2 price type
   */
  namespace.PriceDecimalD2 = function () {
    PriceWithDecimal.call(this, 2);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD2.prototype, Price.prototype, PriceWithDecimal.prototype);

  /**
   *
   * @class PriceDecimalD2Plus CFETI_PRICETYPE_DECIMAL_D2_PLUS price type
   */
  namespace.PriceDecimalD2Plus = function () {
    PriceWithDecimal.call(this, 3);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD2Plus.prototype, Price.prototype, PriceWithDecimal.prototype);

  namespace.PriceDecimalD2Plus.prototype.getCharFromLastDecimal = function (lastDecimal) {
    if (lastDecimal > 2 && lastDecimal < 8) {
      return '+';
    }

    return ' ';
  };

  namespace.PriceDecimalD2Plus.prototype.getStringPriceFromNumber = function (price) {
    const lastDecimal = String(getFraction(Number(Number(price).toFixed(this.decimalPlaces)))).charAt(this.decimalPlaces + 1);

    // eslint-disable-next-line eqeqeq
    if (lastDecimal == 8 || lastDecimal == 9) {
      return String(Number((Number(price) + 1).toFixed(this.decimalPlaces)));
    }

    return this.fixedToNth(price, this.decimalPlaces - 1) + this.getCharFromLastDecimal(lastDecimal);
  };

  /**
   *
   * @class PriceDecimalD3 CFETI_PRICETYPE_DECIMAL_D3 price type
   */
  namespace.PriceDecimalD3 = function () {
    PriceWithDecimal.call(this, 3);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD3.prototype, Price.prototype, PriceWithDecimal.prototype);

  /**
   *
   * @class PriceDecimalD4Plus CFETI_PRICETYPE_DECIMAL_D4_PLUS price type
   */
  namespace.PriceDecimalD4Plus = function (price) {
    PriceWithDecimal.call(this, getWhole(price) >= 10 ? 3 : 5);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD4Plus.prototype, Price.prototype, PriceWithDecimal.prototype);

  namespace.PriceDecimalD4Plus.prototype.getCharFromLastDecimal = function (lastDecimal) {
    if (lastDecimal == 5) {
      return '+';
    } if (lastDecimal == 0) {
      return ' ';
    }

    return lastDecimal;
  };

  namespace.PriceDecimalD4Plus.prototype.getStringPriceFromNumber = function (price) {
    const lastDecimal = String(getFraction(this.fixedToNth(price, this.decimalPlaces))).charAt(this.decimalPlaces + 1);


    return this.fixedToNth(price, this.decimalPlaces - 1) + this.getCharFromLastDecimal(lastDecimal);
  };

  /**
   *
   * @class PriceDecimalDVar	CFETI_PRICETYPE_DECIMAL_DVAR price type
   */
  namespace.PriceDecimalDVar = function (price, enabled, decimalPlaces) {
    PriceWithDecimal.call(this, decimalPlaces.max, decimalPlaces.min);
    GivePickUpEnabled.call(this, enabled);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalDVar.prototype, Price.prototype, PriceWithDecimal.prototype, GivePickUpEnabled.prototype);

  namespace.PriceDecimalDVar.prototype.getStringPriceFromNumber = function (price) {
    let prefix = '';
    let formattedPrice;
    let numDecimals;

    if (this.getGivePickUpEnabled()) {
      if (price < 0) {
        prefix = 'P ';
      } else if (price > 0) {
        prefix = 'G ';
      }
    }

    if (utils.compareFPNumEQ(price, 0)) {
      formattedPrice = (0).toFixed(this.decimalPlaces);
    } else {
      formattedPrice = Number(price).toFixed(this.decimalPlaces);
    }

    numDecimals = utils.getDecimalPrecision(formattedPrice);
    while (formattedPrice.endsWith('0') && numDecimals > this.minDecimalPlaces) {
      formattedPrice = formattedPrice.substr(0, formattedPrice.length - 1);
      --numDecimals;
    }
    if (formattedPrice.endsWith('.')) {
      formattedPrice = formattedPrice.substr(0, formattedPrice.length - 1);
    }

    return prefix + formattedPrice;
  };

  namespace.PriceDecimalDVar.prototype.getNumericPriceFromString = function (price) {
    return Number(Number(price));
  };

  /**
   *
   * @class PriceCbot32nd		CFETI_PRICETYPE_CBOT_32ND price type
   */
  namespace.PriceCbot32nd = function (price) {
    PriceWithCbot.call(this, 100, 2);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbot32nd.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotHalf32nd 		CFETI_PRICETYPE_CBOT_HALF_32ND price type
   */
  namespace.PriceCbotHalf32nd = function (price) {
    PriceWithCbot.call(this, 1000, 3);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotHalf32nd.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotQtr32nd		CFETI_PRICETYPE_CBOT_QTR_32ND price type
   */
  namespace.PriceCbotQtr32nd = function (price) {
    namespace.PriceCbotHalf32nd.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotQtr32nd.prototype, namespace.PriceCbotHalf32nd.prototype);

  /**
   *
   * @class PriceCbot64th		CFETI_PRICETYPE_CBOT_64TH price type
   */
  namespace.PriceCbot64th = function (price) {
    PriceWithCbot.call(this, 100, 2);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbot64th.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotHalf64th		CFETI_PRICETYPE_CBOT_HALF_64TH price type
   */
  namespace.PriceCbotHalf64th = function (price) {
    PriceWithCbot.call(this, 1000, 3);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotHalf64th.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotFourths	CFETI_PRICETYPE_CBOT_FOURTHS price type
   */
  namespace.PriceCbotFourths = function (price) {
    PriceWithCbot.call(this, 10, 1);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotFourths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotEighths	CFETI_PRICETYPE_CBOT_EIGHTHS price type
   */
  namespace.PriceCbotEighths = function (price) {
    PriceWithCbot.call(this, 10, 1);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotEighths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbot3dHalves	CFETI_PRICETYPE_CBOT_3D_HALVES price type
   */
  namespace.PriceCbot3dHalves = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbot3dHalves.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotHalves	CFETI_PRICETYPE_CBOT_HALVES price type
   */
  namespace.PriceCbotHalves = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotHalves.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotModFourths	CFETI_PRICETYPE_CBOT_MOD_FOURTHS price type
   */
  namespace.PriceCbotModFourths = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotModFourths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotTenths	CFETI_PRICETYPE_CBOT_TENTHS price type
   */
  namespace.PriceCbotTenths = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotTenths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotTwentieths	CFETI_PRICETYPE_CBOT_TWENTIETHS price type
   */
  namespace.PriceCbotTwentieths = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotTwentieths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotModFortieths	CFETI_PRICETYPE_CBOT_MOD_FORTIETHS price type
   */
  namespace.PriceCbotModFortieths = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotModFortieths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotHundredths	CFETI_PRICETYPE_CBOT_HUNDREDTHS price type
   */
  namespace.PriceCbotHundredths = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotHundredths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceCbotHalfHundredths	CFETI_PRICETYPE_CBOT_HALF_HUNDREDTHS price type
   */
  namespace.PriceCbotHalfHundredths = function (price) {
    PriceWithCbot.call(this, 1, 0);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceCbotHalfHundredths.prototype, Price.prototype, PriceWithCbot.prototype);

  /**
   *
   * @class PriceDecimalD3Short		CFETI_PRICETYPE_D3_SHORT	 price type
   */
  namespace.PriceDecimalD3Short = function (price) {
    PriceWithDecimal.call(this, 3);
    Price.apply(this, arguments);
  };

  _.extend(namespace.PriceDecimalD3Short.prototype, Price.prototype, PriceWithDecimal.prototype);

  namespace.PriceDecimalD3Short.prototype.getStringPriceFromNumber = function (price) {
    if (price > -1 && price < 1) {
      return String(Number(price).toFixed(this.decimalPlaces)).replace(/0/, '');
    }

    return String(Number(price).toFixed(this.decimalPlaces));
  };
}(window.BGC.utils, window.BGC.priceTypes = window.BGC.priceTypes || {}));
