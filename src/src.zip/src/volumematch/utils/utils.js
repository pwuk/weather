/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */
///////////////////////////////////////////////////////////////////////////////
// file utils.js
// Miscellaneous utilities.
///////////////////////////////////////////////////////////////////////////////

// Polyfill for Object.assign
import getApp from '../index';
import {logger} from '@core-tech/web-api';

if (typeof Object.assign != 'function') {
    // Must be writable: true, enumerable: false, configurable: true
    Object.defineProperty(Object, "assign", {
        value: function assign(target, varArgs) { // .length of function is 2
            'use strict';
            if (target == null) { // TypeError if undefined or null
                throw new TypeError('Cannot convert undefined or null to object');
            }

            var to = Object(target);

            for (var index = 1; index < arguments.length; index++) {
                var nextSource = arguments[index];

                if (nextSource != null) { // Skip over if undefined or null
                    for (var nextKey in nextSource) {
                        // Avoid bugs when hasOwnProperty is shadowed
                        if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                            to[nextKey] = nextSource[nextKey];
                        }
                    }
                }
            }
            return to;
        },
        writable: true,
        configurable: true
    });
}

(function (namespace, undefined) {
    "use strict";

    // Convenience definitions when handling keyboard interaction
    namespace.KeyCodes = {
        ENTER: 13,
        ESC: 27,
        LEFT: 37,
        UP: 38,
        RIGHT: 39,
        DOWN: 40,
        F5: 116,
        F6: 117,
        F7: 118,
        TAB: 9,
        MINUS: 189,
        MINUS_NUMPAD: 100,
        SUBTRACT: 109,
        PERIOD: 190,
        DECIMAL_POINT: 110,
        BACKSPACE: 8,
        DELETE: 46,
        ZERO: 48,
        NINE: 57,
        ZERO_NUMPAD: 96,
        ONE_NUMPAD: 97,
        TWO_NUMPAD: 98,
        THREE_NUMPAD: 99,
        FOUR_NUMPAD: 100,
        FIVE_NUMPAD: 101,
        SIX_NUMPAD: 102,
        SEVEN_NUMPAD: 103,
        EIGHT_NUMPAD: 104,
        NINE_NUMPAD: 105,
        S:83,
        SPACE: 32,
        NUMLOCK: 144
    };

    // Global (module private) timer details for synchronized invocation of a sequence of callbacks on one timer event
    var synchroTimers = {
        ms500: null,
        ms1000: null
    };

    var synchroTimerCallbackList = {
        ms500: {},
        ms1000: {}
    };

    // Utility debug configuration.
    namespace.debug = {
        // The view will render against the maximum frame rate.
        // Use this option for profiling / debugging purposes only.
        useMaxFps: false,
        // Display the current fps. Note that this number may be inaccurate if useMaxFps is OFF
        // since the frame rate is forcibly throttled to optimize CPU/Data usage.
        showFps: false,
        // Allows drawing of debug information at runtime.
        // This option will automatically draw an overlay for background-less elements and
        // draw a temporary frame around a pod while being redrawn.
        debugDraw: false,
        // Activates console logging via utility trace function, which otherwise does nothing
        debugTrace: false
    };

    // QoS interactivity timers
    namespace.interactivity = {
        timers: {},
        maxQoSTime: 20000 // assume user has given up if > this delay
    };

    namespace.trace = function (message) {
        if (!namespace.debug.debugTrace) {
            return;
        }
        var timeNow = new Date(),
            logTime = timeNow.getHours() + ":" + timeNow.getMinutes() + ":" + timeNow.getSeconds() + "." + timeNow.getMilliseconds();
        console.log(logTime + " : " + message);
    };

    // Functions that facilitate interactivity timings/logging
    namespace.startInteractivityQoSTimer = function (interactionType, instType, instName) {
        if (namespace.interactivity.timers[interactionType] === undefined) {
            namespace.interactivity.timers[interactionType] = { timerId: null, startTime: 0, instType: "", instName: "" };
        }

        if (namespace.interactivity.timers[interactionType].timerId !== null) {
            // Timer is already running, reset it before restarting
            namespace.cancelInteractivityQoSTimer(interactionType);
        }

        namespace.interactivity.timers[interactionType].startTime = Date.now();
        namespace.interactivity.timers[interactionType].instType = instType || "";
        namespace.interactivity.timers[interactionType].instName = instName || "";
        namespace.interactivity.timers[interactionType].timerId = setTimeout(function (timeoutType) {
            namespace.interactivity.timers[timeoutType] = { timerId: null, startTime: 0, instType: "", instName: "" };
        }.bind(window, interactionType), namespace.interactivity.maxQoSTime);
    };

    namespace.cancelInteractivityQoSTimer = function (interactionType) {
        var interactionId;

        if (interactionType === "oebActivated") {
            interactionId = "instrumentClick";
        } else {
            interactionId = interactionType;
        }

        if (interactionId === undefined || namespace.interactivity.timers[interactionId] === undefined) {
            throw new TypeError("Attempt to cancel an invalid interactivity timer type");
        }

        if (namespace.interactivity.timers[interactionId].timerId !== null) {
            clearTimeout(namespace.interactivity.timers[interactionId].timerId);
            namespace.interactivity.timers[interactionId] = { timerId: null, startTime: 0, instType: "", instName: "" };
        }
    };

    namespace.generateInteractivityQoSMetric = function (endInteractionType) {
        var startInteractionType,
            qosEvent = {
                    type: "orderEntryInterval",
                    databaseKeyName: "HTML_VM_OP",
                    startTimeUtc: 0,
                    message: "InteractivityType[" + endInteractionType + "]",
                    alertThresholdMilliSecs: 3000
                };

        if (endInteractionType === "oebActivated") {
            startInteractionType = "instrumentClick";
        } else {
            startInteractionType = endInteractionType;
        }

        if (startInteractionType === undefined) {
            throw new TypeError("No interactivity timer type specified to QoS metric generation code");
        } else if (namespace.interactivity.timers[startInteractionType] === undefined) {
            // Attempt to stop a timer that wasn't started - not a critical error but log it
            BGC.logger.logWarning("Interactivity QoS Reporting", "Attempt to terminate and report on a QoS event whose interactivity timer wasn't started: Start Event = " + startInteractionType + ", EndEvent = " + endInteractionType);
            return;
        }

        if (namespace.interactivity.timers[startInteractionType].timerId !== null) {
            qosEvent.startTimeUtc = namespace.interactivity.timers[startInteractionType].startTime;
            qosEvent.message += ", InstrumentType[" + namespace.interactivity.timers[startInteractionType].instType + "], Instrument[" + namespace.interactivity.timers[startInteractionType].instName + "]"

            clearTimeout(namespace.interactivity.timers[startInteractionType].timerId);
            namespace.interactivity.timers[startInteractionType] = { timerId: null, startTime: 0, instType: "", instName: "" };

            BGC.logger.sendQoSEvent(qosEvent);
        }
    };

    // Allow objects with unique Ids to register a callback to fire at a certain interval.
    // An object may register a different callback for different intervals.
    // An object may only register one callback per interval value.
    // Callback firing order is indeterminate, but all will be fired each time the interval period elapses.
    namespace.addGloballySynchronizedTimerCallback = function (requesterId, context, callback, interval) {
        var synchroTimerId = "ms" + interval,
            callbackList = synchroTimerCallbackList[synchroTimerId];

        if (!requesterId) {
            return;
        }

        // If this is an as yet unused global timer interval period, add an empty callback list for it
        if (!callbackList) {
            synchroTimerCallbackList[synchroTimerId] = {};
            callbackList = synchroTimerCallbackList[synchroTimerId];
        }

        // Add the details of the callback and its context to the list of stuff to be executed
        // when the timer for this interval period fires
        if (!callbackList[requesterId]) {
            callbackList[requesterId] = {
                context: context,
                callback: callback
            };

            // If the timer for this inerval period hasn't been started yet, start it now
            if (!synchroTimers[synchroTimerId]) {
                synchroTimers[synchroTimerId] = setInterval(namespace.onGloballySynchronizedTimerFired.bind(window, synchroTimerId), interval);
            }
        }
    };

    namespace.onGloballySynchronizedTimerFired = function (synchroTimerId) {
        var callbackList = synchroTimerCallbackList[synchroTimerId],
            callbackListEntryKeys = Object.keys(callbackList);

        // Plough through the list of registered callback function calls for this interval timer,
        // calling each in the context which it should be called in
        callbackListEntryKeys.forEach(function (key) {
            var callbackDetail = callbackList[key];

            callbackDetail.callback.call(callbackDetail.context);
        });
    };

    namespace.removeGloballySynchronizedTimerCallback = function (requesterId, interval) {
        var synchroTimerId = "ms" + interval,
            callbackList = synchroTimerCallbackList[synchroTimerId];

        if (callbackList && callbackList[requesterId]) {
            delete callbackList[requesterId];

            // If there are no longer any registered callbacks for this timer interval, stop the timer
            if (Object.keys(callbackList).length === 0) {
                clearInterval(synchroTimers[synchroTimerId]);
                synchroTimers[synchroTimerId] = null;
            }
        }
    };

    // Create an enum (typeName) with enumerators and add it to the specified context.
    // All properties will be made enumerable (i.e. hasOwnProperty) and read-only.
    // The first enumerator has a value of 0, and each successive enumerator is one larger
    // than the value of the previous one.
    namespace.createEnumeration = function (context, typeName, enumerators) {
        var i, obj;
        obj = context[typeName] = {};
        for (i = 0; i < enumerators.length; ++i) {
            Object.defineProperty(obj, enumerators[i], { value: i, writable: false, enumerable: true });
        }
    };

    /**
	 * Silences exception if a passed string cannot be parsed.
	 * In case of error returns empty object.
	 *
	 * @returns {Object} - an empty object
	 */
    namespace.parseJSONSafe = function (jsonString) {
        var JSONObject = {};

        try {
            JSONObject = JSON.parse(jsonString);
        }
        catch (ignore) { }

        return JSONObject;
    };

    /**
     * For dealing with floating point inaccuracies inherent in their hardware representation
     * This value represents the tolerance epsilon within which we assume two FP numbers to be equal.
     */
    namespace.gnatsChuff = 2.2204460492503131e-10;

    /**
     * For dealing with floating point inaccuracies inherent in their hardware representation.
     * Returns true if the numbers are effectively equal within our tolerance epsilon, false otherwise
     */
    namespace.compareFPNumEQ = function (a, b, precision) {
        var delta = Math.abs(a - b),
            epsilon = precision || namespace.gnatsChuff;

        if (delta <= epsilon) {
            return true;
        }
        return false;
    };


    /**
    * For dealing with floating point inaccuracies inherent in their hardware representation.
    * Returns true if the numbers are different within our tolerance epsilon, false otherwise
    */
    namespace.compareFPNumNOT_EQ = function (a, b, precision) {
        return !namespace.compareFPNumEQ(a, b, precision);
    };

    /**
     * For dealing with floating point inaccuracies inherent in their hardware representation
     * Returns true if a > b within our tolerance epsilon, false otherwise
     */
    namespace.compareFPNumGT = function (a, b, precision) {
        var epsilon = precision || namespace.gnatsChuff;

        if (a > b) {
            if (!namespace.compareFPNumEQ(a, b, epsilon)) {
                return true;
            }
        }

        return false;
    };

    /**
     * For dealing with floating point inaccuracies inherent in their hardware representation
     * Returns true if a < b within our tolerance epsilon, false otherwise
     */
    namespace.compareFPNumLT = function (a, b, precision) {
        var epsilon = precision || namespace.gnatsChuff;

        if (a < b) {
            if (!namespace.compareFPNumEQ(a, b, epsilon)) {
                return true;
            }
        }

        return false;
    };

    /**
     * For dealing with floating point inaccuracies inherent in their hardware representation
     * Returns true if a > b or a and b are effectively equal within our tolerance epsilon, false otherwise
     */
    namespace.compareFPNumGTEQ = function (a, b, precision) {
        var epsilon = precision || namespace.gnatsChuff;

        if (!namespace.compareFPNumEQ(a, b, epsilon)) {
            if (a < b) {
                return false;
            }
        }

        return true;
    };

    /**
     * For dealing with floating point inaccuracies inherent in their hardware representation
     * Returns true if a < b or a and b are effectively equal within our tolerance epsilon, false otherwise
     */
    namespace.compareFPNumLTEQ = function (a, b, precision) {
        var epsilon = precision || namespace.gnatsChuff;

        if (!namespace.compareFPNumEQ(a, b, epsilon)) {
            if (a > b) {
                return false;
            }
        }

        return true;
    };

    namespace.pointInRect = function (x, y, rect) {
        return (x > rect.left && x < (rect.left + rect.width) && y > rect.top && y < (rect.top + rect.height));
    };

    namespace.isRectEmpty = function (rect) {
        return (rect.right <= rect.left) || (rect.bottom <= rect.top);
    };

    namespace.getRectArea = function (rect) {
        return (rect.right - rect.left) * (rect.bottom - rect.top);
    };

    namespace.intersectRect = function (a, b) {
        return {
            left: Math.min(Math.max(a.left, b.left), b.right),
            top: Math.min(Math.max(a.top, b.top), b.bottom),
            right: Math.max(Math.min(a.right, b.right), b.left),
            bottom: Math.max(Math.min(a.bottom, b.bottom), b.top)
        };
    };

    // Basic helper function to create objects using the mixin pattern.
    namespace.mixin = function () {
        var i, len, prop, child = {};
        for (i = 0, len = arguments.length; i < len; i++) {
            for (prop in arguments[i]) {
                if (arguments[i].hasOwnProperty(prop)) {
                    if (typeof arguments[i][prop] === "object" && arguments[i][prop] !== null) {
                        child[prop] = namespace.mixin(arguments[i][prop]);
                    }
                    else {
                        child[prop] = arguments[i][prop];
                    }
                }
            }
        }
        return child;
    };

    // Preload images with completion callback.
    namespace.loadImages = function (sources, caller, callback) {
        var i, len, images = {}, loadedImages = 0, source,
            onLoad = function () {
                if (++loadedImages === len && callback) {
                    callback.call(caller, images);
                }
            };

        for (i = 0, len = sources.length; i < len; ++i) {
            source = sources[i];
            images[source.id] = new Image();
            images[source.id].onload = onLoad;
            images[source.id].src = source.src;
            if (typeof source.imgList === "object" && Array.isArray(source.imgList)) {
                source.imgList.push(images[source.id]);
            }
        }
    };

    // Preload additional CSS files (not named in the HTML) with completion callback
    namespace.loadCss = function (sources, caller, callback) {
        var i, len, loadedFiles = 0, head = $("head"), link,
            onLoad = function () {
                // Ensure the file is initially disabled
                $(this).prop("disabled", true);
                if (++loadedFiles === len && callback) {
                    callback.call(caller);
                }
            };

        // If no sources specified, simply call the callback anyway -
        // this will ensure that any flag indicating waiting for CSS will get reset
        if (!sources.length) {
            callback.call(caller);
        }

        for (i = 0, len = sources.length; i < len; ++i) {
            link = document.createElement("link");
            link.rel = "stylesheet";
            link.type = "text/css";
            link.onload = onLoad;
            link.href = sources[i];
            head.append(link);
        }
    };

    namespace.AsyncEventSynchronizer = function (completionContext, completionFunction) {
        if (!(this instanceof namespace.AsyncEventSynchronizer)) {
            throw new Error("Constructor called as a function.");
        }
        var that = this;

        _.extend(this, Backbone.Events);
        this.eventCount = 0;

        function eventTriggered() {
            that.eventCount -= 1;
            if (that.eventCount === 0) {
                completionFunction.call(completionContext);
            }
        }

        this.addEvent = function (eventSource, eventName) {
            this.listenTo(eventSource, eventName, eventTriggered);
            this.eventCount++;
        };
    };
    namespace.AsyncEventSynchronizer.prototype.constructor = namespace.AsyncEventSynchronizer;

    // Use this function with a canvas 2d context instance.
    namespace.roundRect = function (context) {
        return function (x, y, width, height, radius, fill, stroke) {
            context.beginPath();
            context.moveTo(x + radius, y);
            context.lineTo(x + width - radius, y);
            context.quadraticCurveTo(x + width, y, x + width, y + radius);
            context.lineTo(x + width, y + height - radius);
            context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
            context.lineTo(x + radius, y + height);
            context.quadraticCurveTo(x, y + height, x, y + height - radius);
            context.lineTo(x, y + radius);
            context.quadraticCurveTo(x, y, x + radius, y);
            context.closePath();
            if (fill === true) { context.fill(); }
            if (stroke === true) { context.stroke(); }
        };
    };

    // Convert a Windows COLORREF value to a JavaScript color string of the form "rgb(r, g, b)"
    // Note that bytes in a COLORREF are actually stored in the order b,g,r
    // This is a rare exception when it is actually right and proper
    // to use bitwise operators in JavaScript, so tell JSList to let it through.
/*jslint bitwise: true */
    namespace.rgbFromCOLORREF = function (colorRef) {
        var r = colorRef & 0xFF,
            g = (colorRef & 0xFF00) >>> 8,
            b = (colorRef & 0xFF0000) >>> 16;
        return "rgb(" + [r, g, b].join(",") + ")";
    };
/*jslint bitwise: false */

    /*
     * Creates an object by grouping the elements in the array based on the predicate functions.
     * - arr        : Array
     * - predicates : Array of Function, so nested grouping is also possible
     */
    namespace.groupBy = function (arr, predicates) {
        var result, i, len, field;

        // guard
        if (predicates.length === 0) {
            return arr;
        }

        // group by first predicate
        result = {};
        for (i = 0, len = arr.length; i < len; i++) {
            field = predicates[0](arr[i]);
            if (!result.hasOwnProperty(field)) {
                result[field] = [];
            }
            result[field].push(arr[i]);
        }

        // group by other predicates
        for (field in result) {
            if (result.hasOwnProperty(field)) {
                result[field] = namespace.groupBy(result[field], predicates.slice(1));
            }
        }

        return result;
    };

    /*
     * Formats resources strings.
     * - str    : String, resource string with {0}, {1}, ... as placeholders
     * - values : Array
     */
    namespace.format = function (str, values) {
        return str.replace(/\{([0-9]+)\}/g, function (match, index) {
            return values[index];
        });
    };

    /*
     * Swaps DOM elements, parameters are DOM elements
     */
    namespace.swapElements = function (element1, element2) {
        var parent1 = element1.parentNode,
            parent2 = element2.parentNode,
            next1 = element1.nextSibling,
            next2 = element2.nextSibling;

        parent1.insertBefore(element2, next1);
        parent2.insertBefore(element1, next2);
    };

    /*
     * returns the relative position of the element within the container (relativeTo)
     */
    namespace.getRelativeOffset = function (element, relativeTo) {
        var eOffset = element.offset(),
		    rOffset = relativeTo.offset();

        return {
            top: eOffset.top - rOffset.top,
            left: eOffset.left - rOffset.left
        };
    };

	// Function to return a parameter as specified in the URL of the page when running
	// in a browser. Taken from http://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
	// Didn't seem worth adding a library dependancy.
	namespace.getURLParam = function(n) {
	  var half = location.search.split(n + '=')[1];
	  return half !== undefined ? decodeURIComponent(half.split('&')[0]) : null;
	};

	/* Trading system works to 10 dp */
	namespace.toleranceScale = 1e+10;

	/**
	 * Verifies if given string is a valid float number.
	 * parseFloat strips characters that are not related to
	 * float representation eg. 1.23zzzj parses to 1.23.
	 * In order to avoid marking such values as valid float numbers,
	 * this method compares parsed number to a number produced
	 * by string to number conversion.
	 *
	 * @param {String} value
	 * @returns {Boolean}
	 */
	namespace.isValidFloat = function(value) {
		return parseFloat(value) === +value;
	};

	/**
	 * The function below assumes that all increments are a divisor of 1.0 which is true for all known
	 * increments at this time.  This is the same logic as implemented in the TS and as such if there are problems
	 * found in this code in future the GTS check_fractional_part function may also need to be modified so we keep in
	 * step with the TS.
	 *
	 * Turn the figures after the decimal point into an integer and then use integer arithmetic to validate against
	 * the increment. This avoids all manner of rounding errors and representation problems with the previous double
	 * implementation.
	 *
	 * @param {Number|String} value
	 * @param {Number} increment
	 * @returns {Boolean}
	 */
	namespace.isMultipleOfIncrement = function(value, increment) {
		var scaledIncrement = Math.floor(increment * namespace.toleranceScale),
			positiveValue = Math.abs(value),
			fraction = (Math.round(positiveValue * namespace.toleranceScale) - (Math.floor(positiveValue) * namespace.toleranceScale));
		return !(fraction % scaledIncrement);
	};

	/**
	 * Formats given number to a decimal string representation with the
	 * given number of digits that should appear after the decimal point.
	 *
	 * @param {Number} value
	 * @param {Number} digits
	 * @returns {String}
	 */
	namespace.formatDecimal = function(value, digits) {
		return String((+value).toFixed(digits));
	};

	/**
	 * Returns numbers of decimal places after decimal point
	 * for given value.
	 *
	 * @param {Number|String} value
	 * @returns {Number}
	 */
	namespace.getDecimalPrecision = function(value) {
		return (("" + value).split(".")[1] || []).length;
	};

    /**
     * Creates an RFC 4122 version 4 randomly generated UUID and returns it as a string.
     *
     * @returns {String}
     */
	namespace.createUuid = function () {
	    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
	        var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
	        return v.toString(16);
	    });
	};

	/**
	 * Parses a string containing key-value pairs, separated by the specified delimiter and returns a
     * JavaScript object representing the key-value pairs as properties.
	 *
	 * e.g "width=420,height=230,status=1" : This string will be parsed and return as the object below:
	 * {
     *     width: 420,
     *     height: 230,
     *     status: 1
	 * }
	 *
	 * @param {String} str
	 * @param {String) delimiter
	 * @returns {Object}
	 */
	namespace.stringToMap = function(str, delimiter) {
	    var map = {},
            keyValuePairs,
            i,
            keyValue;

		if(str) {
		    keyValuePairs = str.split(delimiter);

		    for (i = 0; i < keyValuePairs.length; ++i) {
		        keyValue = keyValuePairs[i].split("=");

		        if (keyValue[0]) {
		            map[keyValue[0]] = keyValue[1];
				}
			}
		}

		return map;
	};

    namespace.queryTemplate = function (viewId) {
        const element = $(viewId);

        if (element && element.html()) {
            return _.template(element.html());
        }

        if (!getApp().id) {
            // This is the dashboard - Log warning and return empty string as the templates are not used by the Dashboard
            logger.logWarning('Dashboard', `Ignoring attempt to load VM view template ${viewId}.`);
        } else {
            logger.logError('VM Page', `Failed to load VM view template ${viewId}.`);
        }

        return '';
    };
}(window.BGC.utils));

// Helper function to center an element on screen.
jQuery.fn.center = function () {
    "use strict";

    this.css("position", "absolute");
    this.css("top", Math.max(0, (($(window).height() - $(this).outerHeight()) / 2) + $(window).scrollTop()) + "px");
    this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) + $(window).scrollLeft()) + "px");
    return this;
};

// Since array does not have a move function.
Array.prototype.move = function (oldindex, newindex) {
    "use strict";

    if (newindex >= this.length) {
        var k = newindex - this.length;
        while ((k--) + 1) {
            this.push(undefined);
        }
    }
    this.splice(newindex, 0, this.splice(oldindex, 1)[0]);
};

// Since array does not have a swap function.
Array.prototype.swap = function (srcindex, destindex) {
    "use strict";

    var temp = this[srcindex];
    this[srcindex] = this[destindex];
    this[destindex] = temp;
};

String.prototype.endsWith = function (s) {
	"use strict";
    return this.substr(this.length - s.length) === s;
};

String.prototype.startsWith = function (s) {
	"use strict";
    return this.substr(0, s.length) === s;
};
