/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, jQuery: false, $: false, _:false, Backbone: false, tv4: false, tinycolor: false */
///////////////////////////////////////////////////////////////////////////////
// file validators.js
// Price utilities.
///////////////////////////////////////////////////////////////////////////////

(function(utils, resources, namespace, undefined) {
	"use strict";

	/**
	 * Executes validator and checks output for any errors.
	 *
	 * @param {validators.Validator} validator
	 * @param {Boolean} reportError - whether to report an invalid value as an error
	 * @param {String} context - object context for the not valid value
	 * @param {String} value - value currently being validated
	 * @param {String} title - title to display within popup dialog
	 * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
	 */
	function executeValidator(validator, reportError, context, value, title) {
		var error = _.first(validator.validate());

		if (error && reportError) {
			BGC.logger.logError(context, utils.format( "[ {0} ] {1}", [value, error] ));
			BGC.ui.viewUtils.displayErrorMessage(title, error);
		}

		return {
			valid : !error,
			numericValue : error ? undefined : +value
		};
	}

	function isValidSizeIncrement(size, sizeIncrement) {
		return utils.compareFPNumGTEQ(sizeIncrement, 1) ?
			utils.compareFPNumEQ(size % sizeIncrement, 0) :
			utils.isMultipleOfIncrement(size, sizeIncrement);
	}

	// Size has to be numeric and positive number 
	function isValidSizeEntered(size) {
	    return !isNaN(Math.abs(size)) && utils.compareFPNumGT(size, 0);
	}

	/**
	 * Generic validator that contains functionality 
	 * common to all derived validators.
	 *
	 * @param {Object} attributes
	 * @class Validator
	 */
	var Validator = function(attributes) {
		if (!(this instanceof Validator)) {
            throw new Error("Constructor called as a function.");
		}

		this.validators = [];
		this.initializeAttributes(attributes);
		this.registerValidators();
	};

	/**
	 * Validates provided values against registered validators and returns
	 * list of errors if any occured.
	 *
	 * @returns {Array}
	 * @method
	 */
	Validator.prototype.validate = function() {
		var failedValidators = this.validators.filter(function(v) { return !v.validate(); });

		return _.pluck(failedValidators, "message");
	};

	/**
	 * Implements validator for the size value, that ensures that
	 * - size is a multiple of the given increment
	 *
	 * @param {Object} attributes
	 * @class SizeValidator
	 */
	namespace.SizeValidator = function(attributes) {
		if (!(this instanceof namespace.SizeValidator)) {
            throw new Error("Constructor called as a function.");
		}

		Validator.apply(this, arguments);
	};

	namespace.SizeValidator.prototype = Object.create(Validator.prototype);

	/**
	 * Assigns given values to the internal attributes.
	 *
	 * @param {Object} attributes
	 * @method
	 */
	namespace.SizeValidator.prototype.initializeAttributes = function(attributes) {
		this.size = attributes.size;
		this.sizeIncrement = attributes.sizeIncrement;
		this.sizeMultiplier = attributes.sizeMultiplier;
		this.minSize = attributes.minSize;
		this.orderExecuted = !!attributes.orderExecuted;
	    this.orderUpsizingMode = attributes.orderUpsizingMode;
		this.filledSize = attributes.filledSize;
		this.unfilledSize = attributes.unfilledSize;
		this.allowTopSpeedSizeIncrement = attributes.allowTopSpeedSizeIncrement;
		this.topSpeedSizeIncrement = attributes.topSpeedSizeIncrement;
	};

	/**
	 * Registers validators that verify if given size is a valid one.
	 *
	 * @method
	 */
	namespace.SizeValidator.prototype.registerValidators = function () {
	    var requestedUnfilledSize;

	    // Check whether the entered size is numeric and greater than 0
	    this.validators.push({
	        message: resources.IDS_MSG_SIZE_NOT_VALID_FLOAT,
	        validate: _.partial(isValidSizeEntered, this.size)
	    });

	    if (!this.orderExecuted) {
	        this.validators.push({
	            message: utils.format(resources.IDS_MSG_MINIMUM_SIZE, [this.minSize + this.sizeMultiplier]),
	            validate: _.partial(utils.compareFPNumGTEQ, +this.size, +this.minSize)
	        });

	        this.validators.push({
	            message: utils.format(resources.IDS_MSG_SIZE_INCREMENT, [this.sizeIncrement + this.sizeMultiplier]),
	            validate: _.partial(isValidSizeIncrement, +this.size, +this.sizeIncrement)
	        });
	    } else {
	        if (this.orderUpsizingMode === 1) {
	            // Total mode
	            this.validators.push({
	                message: utils.format(resources.IDS_MSG_MINIMUM_SIZE, [this.minSize + this.sizeMultiplier]),
	                validate: _.partial(utils.compareFPNumGTEQ, +this.size, +this.minSize)
	            });

	            requestedUnfilledSize = +this.size - (+this.filledSize);
	        } else {
                // Incremental mode
	            this.validators.push({
	                message: utils.format(resources.IDS_MSG_MINIMUM_SIZE, [this.minSize + this.sizeMultiplier]),
	                validate: _.partial(utils.compareFPNumGTEQ, +this.size + (+this.filledSize), +this.minSize)
	            });

	            requestedUnfilledSize = +this.size;
	        }
	        requestedUnfilledSize = parseFloat(requestedUnfilledSize.toFixed(10)); // Eliminate FP addition errors

	        if (this.allowTopSpeedSizeIncrement) {
	            if (!utils.compareFPNumEQ(this.topSpeedSizeIncrement, 0) &&
                    !isValidSizeIncrement(this.filledSize, this.sizeIncrement) &&
                    isValidSizeIncrement(this.filledSize, this.topSpeedSizeIncrement)) {

	                this.validators.push({
	                    message: utils.format(resources.IDS_MSG_UNFILLED_MIN_SIZE, [requestedUnfilledSize + this.sizeMultiplier, this.sizeIncrement + this.sizeMultiplier]),
	                    validate: _.partial(utils.compareFPNumGTEQ, requestedUnfilledSize, this.sizeIncrement)
	                });

	                this.validators.push({
	                    message: utils.format(resources.IDS_MSG_UNFILLED_SIZE_INCREMENT, [requestedUnfilledSize, this.topSpeedSizeIncrement + this.sizeMultiplier]),
	                    validate: _.partial(isValidSizeIncrement, requestedUnfilledSize, this.topSpeedSizeIncrement)
	                });
	            } else {
	                this.validators.push({
	                    message: utils.format(resources.IDS_MSG_UNFILLED_SIZE_INCREMENT, [requestedUnfilledSize, this.sizeIncrement + this.sizeMultiplier]),
	                    validate: _.partial(isValidSizeIncrement, requestedUnfilledSize, this.sizeIncrement)
	                });
	            }
	        } else {
	            this.validators.push({
	                message: utils.format(resources.IDS_MSG_UNFILLED_SIZE_INCREMENT, [requestedUnfilledSize, this.sizeIncrement + this.sizeMultiplier]),
	                validate: _.partial(isValidSizeIncrement, requestedUnfilledSize, this.sizeIncrement)
	            });
	        }
	    }

	    //Total mode and incremental mode size validation
		if (this.orderUpsizingMode === 1) { //TOTAL mode
            //Check whether the size that is entered is greater than the traded size.
		    this.validators.push({
		        message: utils.format(resources.IDS_MSG_TOTAL_SIZE_NOT_LARGER_THAN_TRADED, [this.filledSize + this.sizeMultiplier]),
		        validate: _.partial(utils.compareFPNumGT, +this.size, +this.filledSize)
		    });

            //Check whether the size that is entered is not same as the current total size.
		    this.validators.push({
		        message: utils.format(resources.IDS_MSG_TOTAL_SIZE_NOT_DIFFERENT_THAN_TOTAL, [(+this.filledSize + +this.unfilledSize) + this.sizeMultiplier]),
		        validate: _.partial(utils.compareFPNumNOT_EQ, +this.size, (+this.filledSize + +this.unfilledSize))
		    });
		}
		else { //INCREMENTAL mode
            //Check whether the size that is entered is not same as the current outstanding size.
		    this.validators.push({
		        message: utils.format(resources.IDS_MSG_ENTERED_SIZE_NOT_DIFFERENT_THAN_CURRENT_OUTSTANDING_SIZE, [this.unfilledSize + this.sizeMultiplier]),
		        validate: _.partial(utils.compareFPNumNOT_EQ, +this.size, +this.unfilledSize)
		    });
		}
	};

	/**
	 * Implements validator for the price value, that ensures that:
	 * - price is a valid float
	 * - price is a multiple of the given price increment
	 * - price is greater than zero if negative and zero prices not allowed
	 *
	 * @param {Object} attributes
	 * @class PriceValidator
	 */
	namespace.PriceValidator = function(attributes) {
		if (!(this instanceof namespace.PriceValidator)) {
            throw new Error("Constructor called as a function.");
		}

		Validator.apply(this, arguments);
	};

	namespace.PriceValidator.prototype = Object.create(Validator.prototype);

	/**
	 * Assigns given values to the internal attributes.
	 *
	 * @param {Object} attributes
	 * @method
	 */
	namespace.PriceValidator.prototype.initializeAttributes = function (attributes) {
	    const {ignoreIncrement = false} = attributes;
		const priceOptions = { priceDecimalDVarMinMaxDecimalPlaces : attributes.priceDecimals };

	    this.priceObject = BGC.priceTypes.getPriceObject(attributes.priceType, attributes.price, priceOptions);
		this.priceIncrement = attributes.priceIncrement;
		this.allowsNegativeOrZero = attributes.allowsNegativeOrZero || false;
		this.minPrice = attributes.minPrice;
		this.maxPrice = attributes.maxPrice;
		this.ignoreIncrement = ignoreIncrement;

		this.formatPrice = attributes.priceFormatter || function(price) {
			// default decimal precision is set to 2
			return utils.formatDecimal(price, 2);
		};
	};

	/**
	 * Registers validators that verify if given price is a valid one.
	 *
	 * @method
	 */
	namespace.PriceValidator.prototype.registerValidators = function() {
		this.validators = [];

		if (this.priceObject.stringValue !== "NaN" && this.priceObject.numericValue !== "NaN") {
		    if (!this.ignoreIncrement) {
                this.validators.push({
                    message: resources.IDS_MSG_PRICE_INCREMENT,
                    validate: _.partial(utils.isMultipleOfIncrement, this.priceObject.numericValue, this.priceIncrement)
                });
            }

		    if (!this.allowsNegativeOrZero) {
		        this.validators.push({
		            message: resources.IDS_MSG_PRICE_GREATER_ZERO,
		            validate: _.partial(utils.compareFPNumGT, this.priceObject.numericValue, 0)
		        });
		    }

		    if (this.minPrice) {
		        this.validators.push({
		            message: utils.format(resources.IDS_MSG_PRICE_GREATER_OR_EQUAL, [this.formatPrice(this.minPrice)]),
		            validate: _.partial(utils.compareFPNumGTEQ, this.priceObject.numericValue, +this.minPrice)
		        });
		    }

		    if (this.maxPrice) {
		        this.validators.push({
		            message: utils.format(resources.IDS_MSG_PRICE_LESS_OR_EQUAL, [this.formatPrice(this.maxPrice)]),
		            validate: _.partial(utils.compareFPNumLTEQ, this.priceObject.numericValue, +this.maxPrice)
		        });
		    }
		} else {
		    this.validators.push({
		        message: resources.IDS_INVALID_PRICE_FORMAT,
		        validate: function () { return false; }
		    });
		}
	};
	
	/**
	 * Helper function that executes size validator.
	 *
	 * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
	 * @function executeSizeValidator
	 * @memberof validators
	 */
	namespace.executeSizeValidator = function(validator, showMsgBox, context) {
		return executeValidator(validator, showMsgBox, context, validator.size, BGC.resources.IDS_INVALID_SIZE);
	};

	/**
	 * Helper function that executes price validator.
	 *
	 * @returns {Object} validation result, valid - is value is valid or not, numericValue - value converted to numeric type
	 * @function executePriceValidator
	 * @memberof validators
	 */
	namespace.executePriceValidator = function (validator, showMsgBox, context) {
	    var result = executeValidator(validator, showMsgBox, context, validator.priceObject.stringValue, BGC.resources.IDS_INVALID_PRICE);
	    if (result.valid) {
	        // Because validators are generic to both sizes and prices, they return a numericValue attribute
	        // based purely on a simple numeric conversion of the string value passed in above (i.e. +value).
	        // This doesn't work for strange fractional pricetype representations (e.g. "1.01+")
            // so we have to substitute it here with the number generated by the regexp matching process in Price
	        return { valid: true, numericValue: validator.priceObject.numericValue };
	    }
	    return result;
	};
}(window.BGC.utils,
  window.BGC.resources,
  window.BGC.validators = window.BGC.validators || {}));
