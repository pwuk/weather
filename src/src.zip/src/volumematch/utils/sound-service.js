import {logger} from '@core-tech/web-api';
import tadaSound from './sound/tada-sound';
import notifySound from './sound/notify-sound';
import counterPartyTradeSound from './sound/counterparty-trade-sound';

const sounds = {
  OWN_TRADE           : 'own_trade',
  COUNTER_PARTY_TRADE : 'counter_party_trade',
  VM_START            : 'vm_start'
};

function play (sound) {
  const soundEffect = new Audio(sound);

  soundEffect.play();
}

function playSound (sound) {
  switch (sound) {
    case sounds.OWN_TRADE:
      play(tadaSound);
      break;
    case sounds.COUNTER_PARTY_TRADE:
      play(counterPartyTradeSound);
      break;
    case sounds.VM_START:
      play(notifySound);
      break;
    default:
      logger.warn(`[SoundService::playSound] Invalid parameter${sound}`);
  }

  const soundEffect = new Audio(counterPartyTradeSound);

  soundEffect.play();
}

export {playSound, sounds};
