/* eslint-disable no-magic-numbers, max-lines, func-names, max-statements, max-params, complexity, no-param-reassign, max-len */
/* global BGCAPP: false, BGC: false */

// //////////////////////////////////////////////////////////////////////
// file loghandler.js
// Bridge to the main application logging mechanisms
// //////////////////////////////////////////////////////////////////////

import {logger} from '@core-tech/web-api';

(function (namespace) {
  const asciiLookup = [
    'NUL', 'SOH', 'STX', 'ETX', 'EOT', 'ENQ', 'ACK', 'BEL', 'BS', 'TAB', 'LF', 'VT', 'FF', 'CR', 'SO', 'SI',
    'DLE', 'DC1', 'DC2', 'DC3', 'DC4', 'NAK', 'SYN', 'ETB', 'CAN', 'EM', 'SUB', 'ESC', 'FS', 'GS', 'RS', 'US',
    'Space', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3',
    '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
    'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']',
    '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
    's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~'
  ];

  function getLogContext (id) {
    if (id) {
      return BGC.dataStore.getField() || id;
    }

    return BGC.dataStore.defaultLogContext;
  }

  // If the APP (BGCAPP) has registered its context globally we will invoke its event handlers.

  /**
   * @function
   * @param {String} logType
   * @param {String} id
   * @param {String} logText
   * @param {?Boolean} persistToServer
   */
  function doLogging (logType, id, logText, persistToServer) {
    if (window.BGCAPP === undefined) {
      try {
        switch (logType) {
          case 'ERR':
            logger.error(`[${id}] ${logText}`);
            break;
          case 'WRN':
            logger.warn(`[${id}] ${logText}`);
            break;
          case 'INF':
            logger.info(`[${id}] ${logText}`);
            break;
          case 'QOS':
            logger.qos(logText);
            break;
          case 'KEY':
            logger.key(logText);
            break;
          default:
            break;
        }
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error(error);
      }
    } else {
      BGCAPP.doLogging(id, logType, logText, persistToServer);
      BGC.utils.trace(`${id}: ${logType}: ${logText}`);
    }
  }

  function getKeyDetailsText (event) {
    let key = '';
    const {KeyCodes} = BGC.utils;

    switch (event.which) {
      case KeyCodes.ENTER:
        key = 'ENTER';
        break;
      case KeyCodes.ESC:
        key = 'ESC';
        break;
      case KeyCodes.LEFT:
        key = 'LEFT-ARROW';
        break;
      case KeyCodes.RIGHT:
        key = 'RIGHT-ARROW';
        break;
      case KeyCodes.UP:
        key = 'UP-ARROW';
        break;
      case KeyCodes.DOWN:
        key = 'DOWN-ARROW';
        break;
      case KeyCodes.F5:
        key = 'F5';
        break;
      case KeyCodes.F6:
        key = 'F6 (Buy)';
        break;
      case KeyCodes.F7:
        key = 'F7 (Sell)';
        break;
      case KeyCodes.TAB:
        key = 'TAB';
        break;
      case KeyCodes.MINUS:
        key = 'MINUS';
        break;
      case KeyCodes.MINUS_NUMPAD:
        key = 'MINUS_NUMPAD';
        break;
      case KeyCodes.SUBTRACT:
        key = 'SUBTRACT';
        break;
      case KeyCodes.PERIOD:
        key = '.';
        break;
      case KeyCodes.DECIMAL_POINT:
        key = '. NUMPAD';
        break;
      case KeyCodes.BACKSPACE:
        key = 'BACKSPACE';
        break;
      case KeyCodes.DELETE:
        key = 'DELETE';
        break;
      case KeyCodes.ZERO_NUMPAD:
        key = '0 NUMPAD';
        break;
      case KeyCodes.ONE_NUMPAD:
        key = '1 NUMPAD';
        break;
      case KeyCodes.TWO_NUMPAD:
        key = '2 NUMPAD';
        break;
      case KeyCodes.THREE_NUMPAD:
        key = '3 NUMPAD';
        break;
      case KeyCodes.FOUR_NUMPAD:
        key = '4 NUMPAD';
        break;
      case KeyCodes.FIVE_NUMPAD:
        key = '5 NUMPAD';
        break;
      case KeyCodes.SIX_NUMPAD:
        key = '6 NUMPAD';
        break;
      case KeyCodes.SEVEN_NUMPAD:
        key = '7 NUMPAD';
        break;
      case KeyCodes.EIGHT_NUMPAD:
        key = '8 NUMPAD';
        break;
      case KeyCodes.NINE_NUMPAD:
        key = '9 NUMPAD';
        break;
      case KeyCodes.SPACE:
        key = 'SPACE';
        break;
      case KeyCodes.NUMLOCK:
        key = 'NUMLOCK KEY';
        break;
      default:
        break;
    }

    if (!key && event.which > 32 && event.which < 127) {
      key = asciiLookup[event.which];
    }

    // This code deals with jQuery events and plain old JS events
    const details = [
      `Code: ${event.which} (${event.originalEvent ? event.originalEvent.keyIdentifier : event.keyIdentifier})`,
      `Character: ${key || (event.originalEvent ? event.originalEvent.keyCode : event.keyCode)}`,
      `Alt: ${event.altKey}`,
      `Shift: ${event.shiftKey}`,
      `Ctrl: ${event.ctrlKey}`
    ].join(', ');

    return details;
  }

  // If element doesn't have a unique Id, build its context out of its class
  // and the context text of each of its parents. Include data attributes such as
  // instrument name in order to provide further contextual information.
  function getContextText (element) {
    const elemId = element.getAttribute('id') || '';
    const elemClass = element.getAttribute('class');
    let dataAttrib = element.getAttribute('data-instrument') || '';
    let contextText = element.nodeName;

    if (elemId) {
      contextText += `#${elemId}`;
    }

    if (elemClass) {
      contextText += '.';
      contextText += elemClass;
    }

    if (dataAttrib) {
      contextText += `[data-instrument='${dataAttrib}']`;
    }

    dataAttrib = element.getAttribute('data-tile') || '';
    if (dataAttrib) {
      contextText += `[data-tile='${dataAttrib}']`;
    }

    // Recurse to work our way back up the element hierarchy.
    // In order to limit the length of context logging, add some conditions to stop recursion early.
    const parent = element.parentElement;

    if (parent && (element.nodeName !== 'BODY' && !element.classList.contains('scrollable-content'))) {
      contextText += ' | ';
      contextText += getContextText(parent);
    }

    return contextText;
  }

  function getHtmlText (element) {
    let htmlText = '';

    if (element.nodeName === 'INPUT') {
      htmlText = element.value;
    } else if (element.innerText === element.innerHTML) {
      // Only log text context if it is the only thing in this element
      // - not loads of child html elements' text
      htmlText = element.innerText;
    }

    return htmlText;
  }


  // Public logging functions

  namespace.logUserInteraction = function (event) {
    const contextText = getContextText(event.target);
    const htmlText = event.target.nodeName.toLowerCase() === 'body' ? '' : getHtmlText(event.target);
    let keyDetails = null;

    switch (event.type) {
      case 'mousedown':
        namespace.logKey('', `Mouse clicked on HTML element [Context = ${contextText}]${htmlText === '' ? '' : ` [Text = ${htmlText}]`}`);
        break;
      case 'keydown':
        keyDetails = getKeyDetailsText(event);
        namespace.logKey('', `Key pressed [${keyDetails}] [Context = ${contextText}]${htmlText === '' ? '' : ` [Text = ${htmlText}]`}`);
        break;
      default:
        break;
    }
  };

  namespace.logKey = function (id, logText) {
    doLogging('KEY', getLogContext(id), logText);
  };

  /**
   * @function
   * @param {String} id
   * @param {String} logText
   * @param {?Boolean} persistToServer
   */
  namespace.logInformation = function (context, logText, persistToServer = false) {
    doLogging('INF', context ? `vm-app:${context}` : 'vm-app', logText, persistToServer);
  };

  namespace.logWarning = function (context, logText) {
    doLogging('WRN', context ? `vm-app:${context}` : 'vm-app', logText, true);
  };

  namespace.logError = function (context, logText) {
    doLogging('ERR', context ? `vm-app:${context}` : 'vm-app', logText, true);
  };

  namespace.logTrace = function (id, logText) {
    doLogging('TRC', getLogContext(id), logText);
  };

  namespace.logQOS = function (logText) {
    doLogging('QOS', '', logText);
  };

  namespace.sendSupportNotification = function (notificationMsg) {
    doLogging('EMS', '', notificationMsg);
  };

  // Format:
  // {
  //     type: String                                         The QoS event type
  //     databaseKeyName: String                              The Qos database key name
  //     isInstantaneousEvent: Boolean [optional]             Indicates if the QoS event is an instantaneous event (e.g.,, the sudden breach of a threshold) or a timed event (e.g., the time taken to populate an auction window)
  //     startTimeUtc: Number                                 The QoS event start time stamp in milliseconds since 1970 (UTC)
  //     endTimeUtc: Number [optional]                        The QoS event end time stamp in milliseconds since 1970 (UTC) - this is automatically populated using Date.now() if not specified and the QoS event is not instantaneous
  //     message: String [optional]                           A message describing the QoS event
  //     alertThresholdMilliSecs: Number [optional]           If the duration is greater than this millisecond threshold, an EMS alert is sent
  //     eventReportDelayMilliSecs: Number [optional]         The time in milliseconds the QoS report has been delayed, if any
  //     clientProcessingDurationMilliSecs: Number [optional] The time in milliseconds taken by any client-side processing
  // }
  namespace.sendQoSEvent = function (qosEvent) {
    if (!qosEvent.isInstantaneousEvent && qosEvent.endTimeUtc === undefined) {
      qosEvent.endTimeUtc = Date.now();
    }

    // notify BGC Application layer
    BGC.eventsHandler.onClick('QoS', 'notifyQoSEvent', JSON.stringify(qosEvent));
  };

  window.onerror = function (error, url, lineNumber) {
    const errorMessage = ` ${error} [${url}]:${lineNumber}`;

    namespace.logError(document.title, errorMessage);
  };
}(window.BGC.logger));
