/* jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/* global console:false, BGC:false, fin:false*/

(function (namespace) {
  // Private
  const isOpenFinDeployed = window.fin !== undefined;
  let isOpenFinInitialised = false;
  const consoleLogFunc = console.log;
  const consoleInfoLogFunc = console.info;
  const consoleErrorFunc = console.error;
  const consoleWarnFunc = console.warn;
  let isReenteringLogFunc = false;
  const openFinEventListeners = {};
  let openFinApplication = null;
  let mainOpenFinWindow = null;
  const openFinWindowData = {};

  // OpenFin Initialisation
  namespace.isOpenFinDeployed = function () {
    return isOpenFinDeployed;
  };
  namespace.isOpenFinInitialised = function () {
    return isOpenFinInitialised;
  };
  namespace.getApplication = function () {
    return openFinApplication;
  };
  namespace.getMainWindow = function () {
    return mainOpenFinWindow;
  };

  // Logging
  namespace.logToConsoleOnly = function (msg) {
    consoleLogFunc.apply(console, arguments);
  };
  namespace.logInfoToConsoleOnly = function (msg) {
    consoleInfoLogFunc.apply(console, arguments);
  };
  namespace.logErrorToConsoleOnly = function (msg) {
    consoleErrorFunc.apply(console, arguments);
  };
  namespace.logWarnToConsoleOnly = function (msg) {
    consoleWarnFunc.apply(console, arguments);
  };

  // Private....

  // Finds each immediate parent application of the specified child application recursively until the main
  // application which has no parent application is found and returns its UUID.
  function recursivelyFindMainApplication (applicationInfoList, childUUID) {
    let applicationInfo;
    let parentUUID = childUUID;
    let i;

    for (i = 0; i < applicationInfoList.length; i++) {
      applicationInfo = applicationInfoList[i];

      if (applicationInfo.uuid === childUUID) {
        if (applicationInfo.parentUuid) {
          parentUUID = recursivelyFindMainApplication(applicationInfoList, applicationInfo.parentUuid);
        }

        break;
      }
    }

    return parentUUID;
  }

  // Finds each immediate child application of the specified parent application and adds them to the associated
  // parent node.
  function recursivelyGetOpenFinApplicationChildren (applicationInfoList, parentNode) {
    applicationInfoList.forEach(applicationInfo => {
      let nextChildNode;

      if (applicationInfo.parentUuid && (applicationInfo.parentUuid === parentNode.uuid)) {
        nextChildNode = {
          uuid       : applicationInfo.uuid,
          parentNode,
          childNodes : []
        };

        parentNode.childNodes.push(nextChildNode);

        // Find each immediate child application of this child application and add them to the
        // this child application's node.
        recursivelyGetOpenFinApplicationChildren(applicationInfoList, nextChildNode);
      }
    });
  }

  // Builds a tree of the OpenFin applications of which the current application forms a part.
  // Each node has the following structure:
  // {
  //     uuid,
  //     parentNode,
  //     childNodes[]
  // }
  function getOpenFinApplicationTree (callback, errorCallback) {
    fin.desktop.System.getAllApplications(applicationInfoList => {
      const mainUUID = recursivelyFindMainApplication(applicationInfoList, openFinApplication.uuid);
      const parentNode = {
        uuid       : mainUUID,
        parentNode : null,
        childNodes : []
      };

      recursivelyGetOpenFinApplicationChildren(applicationInfoList, parentNode);

      if (callback) {
        callback(parentNode);
      }
    }, reason => {
      if (errorCallback) {
        errorCallback(reason);
      }
    });
  }

  // Returns a promise to close the specified OpenFin application.
  function closeOpenFinApplication (uuid) {
    return new Promise((resolve, reject) => {
      console.log(`Closing OpenFin application for: ${uuid}`);

      const openFinApplicationToClose = fin.desktop.Application.wrap(uuid);

      openFinApplicationToClose.close(true, () => {
        console.log(`Closed OpenFin application: ${uuid}`);

        resolve();
      }, () => {
        console.log(`Failed to close OpenFin application: ${uuid}`);

        reject();
      });
    });
  }

  // Forcibly closes the specified OpenFin application tree.
  function forceCloseOpenFinApplicationTree (parentNode) {
    const closePromises = [];

    // Recursively force-close each child application.
    parentNode.childNodes.forEach(childNode => {
      const childClosePromises = forceCloseOpenFinApplicationTree(childNode);

      childClosePromises.forEach(closePromise => {
        closePromises.push(closePromise);
      });
    });

    // Force-close the parent application unless it is the current application.
    if (parentNode.uuid !== openFinApplication.uuid) {
      closePromises.push(closeOpenFinApplication(parentNode.uuid));
    }

    return closePromises;
  }

  // Stores the last window and frame size of the specified OpenFin window and returns it.
  // We cannot calculate the size of the window, captions and borders while the window is
  // minimised.
  function GetLastOpenFinWindowAndFrameSize (openFinWindow) {
    let windowData = openFinWindowData[openFinWindow.name];
    const nativeWindow = openFinWindow.getNativeWindow();
    const x = nativeWindow.screenX;
    const y = nativeWindow.screenY;
    const width = nativeWindow.outerWidth;
    const height = nativeWindow.outerHeight;
    const frameWidth = width - nativeWindow.innerWidth;
    const frameHeight = height - nativeWindow.innerHeight;

    // Check to see if any last frame size has been stored.
    if (!windowData) {
      windowData = {};
      openFinWindowData[openFinWindow.name] = windowData;
    }
    if (!windowData.lastWindowAndFrameSize) {
      windowData.lastWindowAndFrameSize = {
        x           : 0,
        y           : 0,
        width       : 0,
        height      : 0,
        frameWidth  : 16, // Aero Basic defaults
        frameHeight : 48
      };
    }

    // Check to make sure the current client and frame size is valid - if it is not, use
    // the last valid position and size.
    if (width > 0) {
      windowData.lastWindowAndFrameSize.x = x;
      windowData.lastWindowAndFrameSize.width = width;
    }
    if (height > 0) {
      windowData.lastWindowAndFrameSize.y = y;
      windowData.lastWindowAndFrameSize.height = height;
    }
    if (frameWidth > 0) {
      windowData.lastWindowAndFrameSize.frameWidth = frameWidth;
    }
    if (frameHeight > 0) {
      windowData.lastWindowAndFrameSize.frameHeight = frameHeight;
    }

    return windowData.lastWindowAndFrameSize;
  }

  // Hides then shows an OpenFin window after it has been restored to ensure the renderer
  // starts up.
  function onOpenFinWindowRestored (message) {
    const openFinWindow = fin.desktop.Window.wrap(message.uuid, message.name);

    openFinWindow.removeEventListener('restored', onOpenFinWindowRestored);
    BGC.logger.logInformation('', 'OpenFin window restored', true);

    // Hide then show the window.
    openFinWindow.hide(() => {
      openFinWindow.show(false);
    });
  }

  // Ensures that the specified function is either executed immediately if OpenFin
  // has been initialised or is not present or immediately after initialisation if
  // we are still waiting for initialisation.
  namespace.executeAfterInit = function (callback) {
    const callbackArgs = Array.prototype.slice.call(arguments, 1, arguments.length);

    if (!namespace.isOpenFinDeployed() || namespace.isOpenFinInitialised()) {
      callback.apply(callbackArgs);
    } else {
      namespace.addOpenFinEventListener('initialised', () => {
        callback.apply(callbackArgs);
      });
    }
  };

  // OpenFin Events (e.g., "initialisation")
  namespace.addOpenFinEventListener = function (type, callback) {
    let callbackArray = openFinEventListeners[type];

    // Check to see if we need to create a new array to hold the topic's callback.
    if (!callbackArray) {
      callbackArray = [];
      openFinEventListeners[type] = callbackArray;
    }

    callbackArray.push(callback);
  };
  namespace.removeOpenFinEventListener = function (type, callback) {
    const callbackArray = openFinEventListeners[type];
    let callbackIndex = -1;

    if (callbackArray) {
      callbackIndex = callbackArray.indexOf(callback);

      if (callbackIndex !== -1) {
        // Check to see if there are any remaining callbacks for this topic
        // and delete the entire array if so.  Otherwise, remove the callback
        // from the array.
        if (callbackArray.length === 1) {
          delete openFinEventListeners[type];
        } else {
          callbackArray.splice(callbackIndex, 1);
        }
      }
    }
  };
  namespace.notifyOpenFinEvent = function (type, isOneTimeEvent) {
    const callbackArray = openFinEventListeners[type];
    let tempCallbackArray;
    let i;

    // Check to see if there are any callbacks associated with this topic.
    if (callbackArray) {
      tempCallbackArray = callbackArray.slice(); // copy the array so that the for-loop is not disturbed if listeners remove themselves from within their callback

      // Call each callback.
      for (i = 0; i < tempCallbackArray.length; i += 1) {
        tempCallbackArray[i](type);
      }

      // If this is one-time event, take the opportunity to delete the
      // callback array.
      if (isOneTimeEvent) {
        delete openFinEventListeners[type];
      }
    }
  };

  // Application Management...

  /**
   * @function
   * @param uuid
   * @param windowName
   * @param url
   * @param autoShow
   * @param alwaysOnTop
   * @param windowState
   * @param saveWindowState
   * @param isMinimisedOnClose
   * @param taskbarIconGroup
   * @param callback
   * @param errorCallback
   * @returns {fin.desktop.Application}
   */
  namespace.createApplication = function (uuid, windowName, url, autoShow, alwaysOnTop, windowState, saveWindowState, isMinimisedOnClose, taskbarIconGroup, callback, errorCallback) {
    let application;
    const options = {
      name              : windowName,
      uuid,
      url,
      applicationIcon   : BGC.ui.theme.getBrandLogoImagePath(),
      mainWindowOptions : {
        name            : windowName,
        autoShow        : windowState && (windowState === 'minimized') ? false : !!autoShow,
        defaultCentered : false,
        alwaysOnTop     : !!alwaysOnTop,
        saveWindowState : !!saveWindowState,
        icon            : BGC.ui.theme.getBrandWindowIconPath(),
        taskbarIcon     : BGC.ui.theme.getBrandTaskbarIconPath(),
        taskbarIconGroup
      },
      accelerator : {
        reload : true
      }
    };

    // If an initially minimised window state is specified, hide the window and manually
    // minimise the window after any saved window state is restored or else the "minimize"
    // window state variable will override the saved state and any saved window position
    // and size will not be restored.
    if (windowState && (windowState !== 'minimized')) {
      options.mainWindowOptions.windowState = windowState;
    }

    // Create the application.
    application = new fin.desktop.Application(options, () => {
      console.log(`Created OpenFin application for: ${uuid}`);

      const newMainWindow = application.getWindow();

      // Add any event listeners.
      if (windowState && (windowState === 'minimized')) {
        // Hides then shows an OpenFin window after it has been restored to ensure the
        // renderer starts up.
        newMainWindow.addEventListener('restored', onOpenFinWindowRestored);
      }
      if (isMinimisedOnClose) {
        // Minimimize the application main window if the user clicks the close button.
        newMainWindow.addEventListener('close-requested', () => {
          BGC.logger.logInformation('', 'Minimizing main OpenFin application window due to user clicking the Close button', true);
          newMainWindow.minimize();
        });
      }

      // Start the application.
      application.run(() => {
        if (windowState && (windowState === 'minimized')) {
          // Minimise the application's window if requested now that the application is
          // running - we do this after the window has been created to ensure any saved
          // window state is restored.
          newMainWindow.minimize(() => {
            if (autoShow) {
              newMainWindow.show(false, () => {
                if (callback) {
                  callback();
                }
              }, reason => {
                console.log(`Error showing OpenFin application window for ${uuid} because: ${reason}`);

                // Treat this is as a success since the window has been created.
                if (callback) {
                  callback();
                }
              });
            } else if (callback) {
              callback();
            }
          }, reason => {
            console.log(`Error minimising OpenFin application window for ${uuid} because: ${reason}`);

            // Treat this is as a success since the window has been created.
            if (callback) {
              callback();
            }
          });
        } else if (callback) {
          callback();
        }
      }, reason => {
        console.log(`Error starting OpenFin application for ${uuid} because: ${reason}`);

        if (errorCallback) {
          errorCallback(reason);
        }
      });
    }, reason => {
      console.log(`Error creating OpenFin application for ${uuid} because: ${reason}`);

      if (errorCallback) {
        errorCallback(reason);
      }
    });

    return application;
  };

  // Closes the main OpenFin application if any, else closes ourselves.  This function recursively walks up
  // the process tree to find the main application.
  namespace.closeMainOpenFinApplication = function (force) {
    let closePromises;
    let completionPromise;
    const closeCurrentApplication = function () {
      BGC.logger.logInformation('', 'closeMainOpenFinApplication: Closing main OpenFin application window', true);
      mainOpenFinWindow.close(true);
    };

    getOpenFinApplicationTree(parentNode => {
      if (force) {
        // Force-close the entire application tree.
        closePromises = forceCloseOpenFinApplicationTree(parentNode);

        // Force-close the current application.
        completionPromise = Promise.all(closePromises);
        completionPromise.then(closeCurrentApplication, closeCurrentApplication);
        completionPromise.catch(closeCurrentApplication);
      } else {
        const mainApplication = fin.desktop.Application.wrap(parentNode.uuid);

        // Request to close the main application.
        mainApplication.getWindow().close(false);
      }
    }, () => {
      closeCurrentApplication();
    });
  };

  // Closes any applications created by this application then closes the current application.
  namespace.closeAllOpenFinApplications = function () {
    const closeCurrentApplication = function () {
      BGC.logger.logInformation('', 'closeAllOpenFinApplications: Closing main OpenFin application window', true);
      mainOpenFinWindow.close(true);
    };

    fin.desktop.System.getAllApplications(applicationInfoList => {
      const {uuid} = openFinApplication;
      const closePromises = [];
      let completionPromise;

      // Create promises to close any applications created by this application.
      applicationInfoList.forEach(applicationInfo => {
        if (applicationInfo.parentUuid && (applicationInfo.parentUuid === uuid)) {
          closePromises.push(closeOpenFinApplication(applicationInfo.uuid));
        }
      });

      // Create a promise to wait for all applications to close.
      if (closePromises.length > 0) {
        completionPromise = Promise.all(closePromises);
        completionPromise.then(closeCurrentApplication, closeCurrentApplication);
        completionPromise.catch(closeCurrentApplication);
      } else {
        closeCurrentApplication();
      }
    }, () => {
      closeCurrentApplication();
    });
  };

  // Window Management...

  // Function useful for remapping the native JavaScript function window.open(URL, name, specs, replace)
  // to the OpenFin API.
  namespace.createOpenFinWindow = function (url, name, specs, replace, callback, errorCallback) {
    var options = window.BGC.utils.stringToMap(specs, ','),
      openFinWindow = new fin.desktop.Window({
        name,
        url,
        defaultWidth  : options.width ? Number(options.width) : 100,
        defaultHeight : options.height ? Number(options.height) : 100,
        defaultTop    : options.top ? Number(options.top) : undefined,
        defaultLeft   : options.left ? Number(options.left) : undefined,
        autoShow      : options.autoShow === undefined ? true : options.autoShow === 'true',
        alwaysOnTop   : options.alwaysOnTop === undefined ? true : !!options.alwaysOnTop === 'true'
      }, () => {
        console.log(`Created OpenFin window for: ${url}`);
        BGC.logger.logInformation(url, `Created OpenFin window with alwaysOnTop set to [${openFinWindow.alwaysOnTop}], autoShow set to [${openFinWindow.autoShow}]`, true);

        openFinWindow.focus();

        if (callback) {
          callback();
        }
      }, reason => {
        console.log(`Error creating OpenFin window for ${url} because: ${reason}`);

        if (errorCallback) {
          errorCallback(reason);
        }
      });

    return openFinWindow;
  };

  // Calls the specified callback to tell it whether the specified window is visible or not.
  namespace.isOpenFinWindowVisible = function (openFinWindow, callback, errorCallback) {
    openFinWindow.isShowing(showing => {
      openFinWindow.getState(state => {
        if (callback) {
          callback(showing && (state !== 'minimized'));
        }
      }, errorCallback);
    }, errorCallback);
  };

  // Repositions and resizes the specified window - the desired position must be in screen
  // co-ordinates and the dimensions must represent the desired client area.
  namespace.resizeOpenFinWindow = function (openFinWindow, newX, newY, newClientWidth, newClientHeight) {
    if ((newX === undefined) &&
      (newY === undefined) &&
      (newClientWidth === undefined) &&
      (newClientHeight === undefined)) {
      return;
    }

    // Get the last window and frame size.
    const lastClientAndFrameSize = GetLastOpenFinWindowAndFrameSize(openFinWindow);

    // Check to see if we should modify the entire bounds, only the position or only the size.
    if ((newX !== undefined) && (newY !== undefined)) {
      if ((newClientWidth !== undefined) && (newClientHeight !== undefined)) {
        BGC.logger.logInformation('', `Setting OpenFin window position and size to X=${newX}, Y=${newY}, Width=${newClientWidth + lastClientAndFrameSize.frameWidth}, Height=${newClientHeight + lastClientAndFrameSize.frameHeight}`, true);
        openFinWindow.setBounds(newX, newY, newClientWidth + lastClientAndFrameSize.frameWidth, newClientHeight + lastClientAndFrameSize.frameHeight);
      } else {
        BGC.logger.logInformation('', `Setting OpenFin window position to X=${newX}, Y=${newY}`, true);
        openFinWindow.moveTo(newX, newY);
      }
    } else if ((newClientWidth !== undefined) && (newClientHeight !== undefined)) {
      BGC.logger.logInformation('', `Setting OpenFin window size to Width=${newClientWidth + lastClientAndFrameSize.frameWidth}, Height=${newClientHeight + lastClientAndFrameSize.frameHeight}`, true);
      openFinWindow.resizeTo(newClientWidth + lastClientAndFrameSize.frameWidth, newClientHeight + lastClientAndFrameSize.frameHeight, 'top-left');
    }
  };

  namespace.resizeOpenFinWindowAndLimitToTaskBar = function (openFinWindow, newX, newY, newClientWidth, newClientHeight) {
    fin.desktop.System.getMonitorInfo(monitorInfo => {
      const lastWindowAndFrameSize = GetLastOpenFinWindowAndFrameSize(openFinWindow);
      let tempNewX = newX;
      let tempNewY = newY;
      let tempNewClientWidth = newClientWidth;
      let tempNewClientHeight = newClientHeight;
      let windowR;
      let overlappedMonitorR;
      let overlappedArea;
      let tempOverlappedArea;

      // Fill in any missing parameters.
      if (newX === undefined) {
        tempNewX = lastWindowAndFrameSize.x;
      }
      if (newY === undefined) {
        tempNewY = lastWindowAndFrameSize.y;
      }
      if (newClientWidth === undefined) {
        tempNewClientWidth = lastWindowAndFrameSize.width - lastWindowAndFrameSize.frameWidth;
      }
      if (newClientHeight === undefined) {
        tempNewClientHeight = lastWindowAndFrameSize.height - lastWindowAndFrameSize.frameHeight;
      }

      windowR = {
        left   : tempNewX,
        top    : tempNewY,
        right  : tempNewX + tempNewClientWidth + lastWindowAndFrameSize.frameWidth,
        bottom : tempNewY + tempNewClientHeight + lastWindowAndFrameSize.frameHeight
      };
      overlappedMonitorR = monitorInfo.primaryMonitor.monitorRect;
      overlappedArea = BGC.utils.getRectArea(BGC.utils.intersectRect(windowR, overlappedMonitorR));

      // Find the rectangle which overlaps the desired window rectangle the most.
      monitorInfo.nonPrimaryMonitors.forEach(monitor => {
        tempOverlappedArea = BGC.utils.getRectArea(BGC.utils.intersectRect(windowR, monitor.monitorRect));

        if (tempOverlappedArea > overlappedArea) {
          overlappedMonitorR = monitor.monitorRect;
          overlappedArea = tempOverlappedArea;
        }
      });

      // If the desired window rectangle does not overlap any monitor, default to
      // the primary monitor.
      if (overlappedArea <= 0) {
        overlappedMonitorR = monitorInfo.primaryMonitor.monitorRect;
      }

      // If the task bar is present on the monitor the desired window rectangle overlaps
      // the most, ensure the window height is constrained so that it does not overlap
      // the task bar.
      if ((monitorInfo.taskbar.rect.edge === 'bottom') && !BGC.utils.isRectEmpty(BGC.utils.intersectRect(monitorInfo.taskbar.rect, overlappedMonitorR))) {
        windowR.bottom = Math.min(windowR.bottom, monitorInfo.taskbar.rect.top);
      }

      // Resize the window.
      namespace.resizeOpenFinWindow(openFinWindow,
        newX === undefined ? undefined : windowR.left,
        newY === undefined ? undefined : windowR.top,
        newClientWidth === undefined ? undefined : (windowR.right - windowR.left) - lastWindowAndFrameSize.frameWidth,
        newClientHeight === undefined ? undefined : Math.min(windowR.bottom - windowR.top, overlappedMonitorR.bottom - overlappedMonitorR.top) - lastWindowAndFrameSize.frameHeight);
    });
  };

  // Restore the OpenFin window and bring it to the front.  The callback is called if the window
  // was minimised at the moment it is successfully restored.
  namespace.restoreOpenFinWindowAndBringToFront = function (openFinWindow, restoredCallback) {
    openFinWindow.getState(state => {
      if (state === 'minimized') {
        BGC.logger.logInformation('', 'Restoring OpenFin window from minimized state.', true);

        openFinWindow.addEventListener('restored', function () {
          openFinWindow.removeEventListener('restored', arguments.callee);

          BGC.logger.logInformation('', 'Bringing OpenFin window to the front.', true);
          openFinWindow.bringToFront();

          if (restoredCallback) {
            restoredCallback();
          }
        });

        openFinWindow.restore(undefined, () => {
          BGC.logger.logInformation('', 'Bringing OpenFin window to the front.', true);
          openFinWindow.bringToFront();
        });
      } else {
        BGC.logger.logInformation('', 'Bringing OpenFin window to the front.', true);
        openFinWindow.bringToFront();
      }
    });
  };

  // Notifications
  namespace.displayOpenFinNotification = function (notificationTitle, notificationMessage) {
    namespace.executeAfterInit(() => {
      new fin.desktop.Notification({
        url     : `/openfin/notification.htm?brandId=${BGC.ui.theme.getBrandId()}`,
        message : JSON.stringify({
          logoImagePath : BGC.ui.theme.getBrandLogoImagePath(),
          caption       : notificationTitle,
          message       : notificationMessage
        })
      });
    });
  };

  /**
   * @function
   * @private
   * @param {String} topic
   * @param {Object} message
   * @param {?Function} callback
   * @param {?Function} errorCallback
   */
  function applicationBusPublish (topic, message, callback, errorCallback) {
    const messageWrapper = {
      uuid : openFinApplication.uuid,
      message
    };

    try {
      fin.desktop.InterApplicationBus.publish(topic, JSON.stringify(messageWrapper), callback, errorCallback);
    } catch (error) {
      console.error(error);
    }
  }

  /**
   * @function
   * @private
   * @param {String} senderUuid
   * @param {?String} name
   * @param {String} topic
   * @param {Function} listener
   * @param {?Function} callback
   * @param {?Function} errorCallback
   */
  function applicationBusSubscribe (senderUuid, name, topic, listener, callback, errorCallback) {
    try {
      fin.desktop.InterApplicationBus.subscribe(senderUuid, name, topic, listener, callback, errorCallback);
    } catch (error) {
      console.error(error);
    }
  }

  // Messaging Bus
  /**
   * @type {Object}
   * @property {Function} publish
   * @property {Function} subscribe
   */
  namespace.messagingBus = {
    publish   : applicationBusPublish,
    subscribe : applicationBusSubscribe
  };

  /**
   * @param {Function} callback
   * @param {?Function} errorCallback
   */
  function getRvmInfo (callback, errorCallback) {
    try {
      fin.desktop.System.getRvmInfo(callback, errorCallback);
    } catch (error) {
      BGC.logger.logInformation('', `${error}, probably due to function not being supported in this OpenFin version, exception safely handled.`, true);
    }
  }

  /**
   * @param {Function} callback
   * @param {?Function} errorCallback
   */
  function getVersion (callback, errorCallback) {
    try {
      fin.desktop.System.getVersion(callback, errorCallback);
    } catch (error) {
      BGC.logger.logInformation('', `${error}, probably due to function not being supported in this OpenFin version, exception safely handled.`, true);
    }
  }

  /**
   * @param {String} level
   * @param {String} message
   * @param {?Function} callback
   * @param {?Function} errorCallback
   */
  function log (level, message, callback, errorCallback) {
    fin.desktop.System.log(level, message, callback, errorCallback);
  }

  namespace.system = {
    getRvmInfo,
    getVersion,
    log
  };

  // Register our OpenFin main() function if OpenFin is detected.
  document.addEventListener('DOMContentLoaded', () => {
    if (namespace.isOpenFinDeployed()) {
      fin.desktop.main(() => {
        // Store the OpenFin application and main window.
        isOpenFinInitialised = true;
        openFinApplication = fin.desktop.Application.getCurrent();
        mainOpenFinWindow = openFinApplication.getWindow();

        // Log that the application has started.
        fin.desktop.System.log('info', `${openFinApplication.uuid} application started...`);

        // Redirect console logging to both the console and the OpenFin log.
        console.log = function (msg) {
          if (isReenteringLogFunc === true) {
            namespace.logToConsoleOnly.apply(undefined, arguments);
          } else {
            // Prevent re-entrancy since OpenFin logs to both the console and the OpenFin log file.
            isReenteringLogFunc = true;

            fin.desktop.System.log('info', msg);

            isReenteringLogFunc = false;
          }
        };
        console.info = function (msg) {
          if (isReenteringLogFunc === true) {
            namespace.logInfoToConsoleOnly.apply(undefined, arguments);
          } else {
            // Prevent re-entrancy since OpenFin logs to both the console and the OpenFin log file.
            isReenteringLogFunc = true;

            fin.desktop.System.log('info', msg);

            isReenteringLogFunc = false;
          }
        };
        console.error = function (msg) {
          if (isReenteringLogFunc === true) {
            namespace.logErrorToConsoleOnly.apply(undefined, arguments);
          } else {
            // Prevent re-entrancy since OpenFin logs to both the console and the OpenFin log file.
            isReenteringLogFunc = true;

            fin.desktop.System.log('error', msg);

            isReenteringLogFunc = false;
          }
        };
        console.warn = function (msg) {
          if (isReenteringLogFunc === true) {
            namespace.logWarnToConsoleOnly.apply(undefined, arguments);
          } else {
            // Prevent re-entrancy since OpenFin logs to both the console and the OpenFin log file.
            isReenteringLogFunc = true;

            fin.desktop.System.log('warning', msg);

            isReenteringLogFunc = false;
          }
        };

        // Register an event listener to be notified when the OpenFin main
        // window is restored - it is necessary to know this because
        // OpenFin window management operations cannot be applied while
        // a window is mimimised which can interfere with window layout.
        mainOpenFinWindow.addEventListener('restored', () => {
          namespace.notifyOpenFinEvent('main-window-restored');
        });

        // Notify any listeners that the OpenFin API has been initialised.
        namespace.notifyOpenFinEvent('initialised', true);
      });
    }
  });
}(BGC.openfin));
