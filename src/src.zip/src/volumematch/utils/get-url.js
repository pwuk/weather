import set from 'lodash/set';
import split from 'lodash/split';
import reduce from 'lodash/reduce';

export default () => {
  const url = new URL(window.location.href);

  if (typeof url.searchParams !== 'object') {
    const rawSearchStr = url.search;
    const keyValuePairs = split(rawSearchStr.slice(1), '&');
    const searchParams = reduce(keyValuePairs, (acc, keyValue) => {
      const [key, value] = split(keyValue, '=');

      return set(acc, key, value);
    }, {});

    url.searchParams = {
      get (key) {
        return searchParams[key] || null;
      }
    };
  }

  return url;
};
