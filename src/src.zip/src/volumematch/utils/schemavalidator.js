/*jslint browser: true, bitwise: false, closure: false, continue: true, eqeq: false, evil: false, forin: false, newcap: false, nomen: true, plusplus: true, unparam: true, sloppy: false, white: true, indent: 4 */
/*global BGC: false, $: false, tv4: false*/
///////////////////////////////////////////////////////////////////////////////
// file schemavalidators.js
// Common GUI Protocol Message Validation.
// Singleton implementation adapted from http://addyosmani.com/resources/essentialjsdesignpatterns/book/#singletonpatternjavascript
///////////////////////////////////////////////////////////////////////////////

(function (context, undefined) {
    "use strict";

    // Function returns singleton object
    context.schemaValidator = (function () {
        // Single instance of SchemaValidator
        var instance,

            // Constructor
            SchemaValidator = function () {

                if (!(this instanceof SchemaValidator)) {
                    throw new Error("Constructor called as a function.");
                }

                // Private instance members
                var appSchema, tv4Validator = tv4.freshApi();

                appSchema = {
                    "$schema": "http://json-schema.org/draft-04/schema",
                    "version": "1.25",
                    "type": "object",
                    "properties": {
                        "messages": {
                            "type": "array",
                            "items": {
                                "oneOf": [
                                  { "$ref": "#/definitions/heartbeatMsg" },
                                  { "$ref": "#/definitions/sessionMsg" },
                                  { "$ref": "#/definitions/dashboardMsg" },
                                  { "$ref": "#/definitions/lastErrorMsg" },
                                  { "$ref": "#/definitions/statusMsg" },
                                  { "$ref": "#/definitions/pageMsg" },
                                  { "$ref": "#/definitions/instrumentMsg" },
                                  { "$ref": "#/definitions/orderStatusMsg" },
                                  { "$ref": "#/definitions/vmOrderSummaryMsg" },
                                  { "$ref": "#/definitions/vmOrderUpdateMsg" },
                                  { "$ref": "#/definitions/tradeExecutionMsg" },
                                  { "$ref": "#/definitions/tradeCaptureReportMsg" },
                                  { "$ref": "#/definitions/vmTradeSummaryMsg" },
                                  { "$ref": "#/definitions/auctionMsg" },
                                  { "$ref": "#/definitions/eventLogMsg" },
                                  { "$ref": "#/definitions/queryResultsMsg" },
                                  { "$ref": "#/definitions/vmCreateInstrumentResponseMsg" },
                                  { "$ref": "#/definitions/excelAddInStateChangedMsg" },
                                  { "$ref": "#/definitions/midnightCleanupMsg" },
                                  { "$ref": "#/definitions/userLoginMsg" },
                                  { "$ref": "#/definitions/themeUpdateMsg" },
                                  { "$ref": "#/definitions/accountsListMsg" },
                                  { "$ref": "#/definitions/accountUpdateMsg" },
                                  { "$ref": "#/definitions/accountSelectionChangedMsg" },
                                  { "$ref": "#/definitions/selectInstrumentMsg" },
                                  { "$ref": "#/definitions/screenshotMsg" }
                                ]
                            }
                        }
                    },

                    "definitions": {
                        "heartbeatMsg": {
                            "required": ["messageName", "requestId", "serverTime"],
                            "properties": {
                                "messageName": { "enum": ["heartbeat"] },
                                "requestId": { "type": "string" },
                                "serverTime": { "type": "integer" }
                            },
                            "additionalProperties": false
                        },

                        "sessionMsg": {
                            "required": ["messageName", "userName", "userLegalEntityName", "serverVersion", "clientVersion", "msgSchemaVersion", "cmdSchemaVersion", "isProd"],
                            "properties": {
                                "messageName": { "enum": ["session"] },
                                "userId": { "type": "string" },
                                "userName": { "type": "string" },
                                "userLegalEntityName": { "type": "string" },
                                "businessId": { "type": "string" },
                                "serverVersion": { "type": "string" },
                                "serverInfo": { "type": "string" },
                                "heartbeatInterval": { "type": "integer" },
                                "heartbeatWarningThreshold": { "type": "integer" },
                                "heartbeatDisconnectThreshold": { "type": "integer" },
                                "latencyWarningThreshold": { "type": "integer" },
                                "reconnectInterval": { "type": "integer" },
                                "maxReconnectAttempts": { "type": "integer" },
                                "clientVersion": { "type": "string" },
                                "msgSchemaVersion": { "type": "string" },
                                "cmdSchemaVersion": { "type": "string" },
                                "enableGcTrigger": { "type": "boolean" },
                                "restartTime": { "type": "string" },
                                "showLiveTransitionGracePeriod": { "type": "integer" },
                                "savePreferencesInterval": { "type": "integer" },
                                "metricsSamplingInterval": { "type": "integer" },
                                "isProd": { "type": "boolean" }
                            },
                            "additionalProperties": false
                        },

                        "dashboardMsg": {
                            "required": ["messageName", "pageList"],
                            "properties": {
                                "messageName": { "enum": ["dashboard"] },
                                "pageList": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "pageId": { "type": "string" },
                                            "pageName": { "type": "string" },
                                            "currencyId": { "type": "string" },
                                            "venue": { "enum": ["clob", "vm"] }
                                        }
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "lastErrorMsg": {
                            "required": ["messageName", "message"],
                            "properties": {
                                "requestId": { "type": "string" },
                                "requestContext": { "type": "string" },
                                "messageName": { "enum": ["lastError"] },
                                "context": { "type": "string" },
                                "message": { "type": "string" },
                                "type": { "enum": ["fatFinger", "other"] }
                            },
                            "additionalProperties": false
                        },

                        "statusMsg": {
                            "required": ["messageName", "text"],
                            "properties": {
                                "messageName": { "enum": ["status"] },
                                "context": { "type": "string" },
                                "text": { "type": "string" },
                                "action": { "enum": ["popup", "fade"] }
                            },
                            "additionalProperties": false
                        },

                        "pageMsg": {
                            "required": ["messageName", "pageId", "pageName", "pageType", "nomenclature"],
                            "properties": {
                                "messageName": { "enum": ["page"] },
                                "requestId": { "type": "string" },
                                "requestContext": { "type": "string" },
                                "pageId": { "type": "string" },
                                "pageName": { "type": "string" },
                                "pageType": { "enum": ["clob", "vm"] },
                                "businessConfig": { "type": "string" },
                                "isEditable": { "type": "boolean" },
                                "nomenclature": { "enum": ["bidOffer", "payRec", "paidGiven"] },
                                "currencyId": { "type": "string" },
                                "nameMinChars": { "type": "number" },
                                "genericColumns": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "columnId": { "enum": ["maturity", "coupon", "strike1Display", "strike2Display", "crossDisplay", "deltaDisplay", "straddleDisplay", "ratioDisplay", "volume", "totalTradedSize", "sessionLowPriceDisplay", "sessionHighPriceDisplay", "sessionOpenPriceDisplay", "sessionClosePriceDisplay", "lastTradePriceDisplay", "priceBDisplay"] },
                                            "columnName": { "type": "string" }
                                        }
                                    }
                                },
                                "settings": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "required": ["name", "value"],
                                        "properties": {
                                            "name": { "type": "string" },
                                            "value": { "type": "string" }
                                        }
                                    }
                                },
                                "systemSettings": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "required": ["name", "value"],
                                        "properties": {
                                            "name": { "type": "string" },
                                            "value": { "type": "string" }
                                        }
                                    }
                                },
                                "jsonSettings": {
                                    "type": "object",
                                    "properties": {
                                        "settings": { "type": "string" }
                                    }
                                },
                                "tileLayouts": {
                                    "type": "array",
                                    "items": {
                                        "anyOf": [
                                          { "$ref": "#/definitions/tileSchema" },
                                          { "$ref": "#/definitions/matrixSchema" }
                                        ]
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "tileUpdateMsg": {
                            "required": ["messageName", "tileLayouts"],
                            "properties": {
                                "messageName": { "enum": ["tileUpdate"] },
                                "tileLayouts": {
                                    "type": "array",
                                    "items": {
                                        "anyOf": [
                                          { "$ref": "#/definitions/tileSchema" }
                                        ]
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "instrumentMsg": {
                            "required": ["messageName", "instrumentId"],
                            "properties": {
                                "messageName": { "enum": ["instrument"] },
                                "instrumentId": { "type": "string" },
                                "instrumentName": { "type": "string" },
                                "instrumentShortName": { "type": "string" },
                                "ticker": { "type": "string" },
                                "productName": { "type": "string" },
                                "securityId": { "type": "string" },
                                "securityGroup": { "type": "string" },
                                "jurisdiction": { "type": "string" },
                                "currency": { "type": "string" },
                                "isBenchmark": { "type": "boolean" },
                                "isWhenIssue": { "type": "boolean" },
                                "isLockInstrument": { "type": "boolean" },
                                "allowTopSpeedSizeIncrement": { "type": "boolean" },
                                "topSpeedSizeIncrement": { "type": "number" },
                                "blockInstrumentOf": { "type": "string" },
                                "settlement": { "type": "string" },
                                "maturity": { "type": "string" },
                                "coupon": { "type": "string" },
                                "nomenclature": { "enum": ["bidOffer", "payRec", "paidGiven"] },
                                "instrumentClassification": { "type": "number" },
                                "tileId": { "type": "string" },
                                "minDecimalPlaces": { "type": "number" },
                                "hasTradedInAuction": { "type": "boolean" },
                                "isShowGlowAlwaysEnabled": { "type": "boolean" },
                                "baseSize": { "type": "number" },
                                "isExcelLiveModeEnabled": { "type": "boolean" },
                                "canUserEnterOrders": { "type": "boolean" },
                                "supportTradeConfirmRequest": { "type": "boolean" },
                                "isInAuction": { "type": "boolean" },
                                "minOrderSize": { "type": "number" },
                                "defaultOrderSize": { "type": "number" },
                                "defaultSizes": {
                                    "type": "array",
                                    "items": { "type": "number" }
                                },
                                "commonOrderSizeConfig": {
                                    "type": "array",
                                    "items": { "$ref": "#/definitions/sizeConfigSchema" }
                                },
                                "specificOrderSizeLimits": {
                                    "type": "array",
                                    "items": {
                                        "properties": {
                                            "appliesTo": {
                                                "type": "array",
                                                "items": { "$ref": "#/definitions/orderEntryPrefSchema" }
                                            },
                                            "limits": {
                                                "type": "array",
                                                "items": { "$ref": "#/definitions/sizeConfigSchema" }
                                            }
                                        }
                                    }
                                },
                                "sizeIncrement": { "type": "number" },
                                "sizeMultiplier": { "type": "number" },
                                "priceIncrement": { "type": "number" },
                                "priceType": { "$ref": "#/definitions/priceTypeSchema" },
                                "altPriceIncrement": { "type": "number" },
                                "altPriceType": { "$ref": "#/definitions/priceTypeSchema" },
                                "spreadWeighting": { "type": "number" },
                                "buyLegRatio": { "type": "number" },
                                "isPickGivePriced": { "type": "boolean" },
                                "orderPreferences": {
                                    "type": "array",
                                    "items": { "$ref": "#/definitions/orderEntryPrefSchema" },
                                    "uniqueItems": true
                                },
                                "sortOrdinal": { "type": "integer" },
                                "isHigherBidBetter": { "type": "boolean" },
                                "isLowerOfferBetter": { "type": "boolean" },
                                "allowsNegativeOrZeroPrice": { "type": "boolean" },
                                "state": { "enum": ["tradeable", "viewOnly", "offline"] },
                                "auctions": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "auctionId": { "type": "string" },
                                            "strike1Display": { "type": "string" },
                                            "strike2Display": { "type": "string" },
                                            "deltaDisplay": { "type": "string" },
                                            "straddleDisplay": { "type": "string" },
                                            "ratioDisplay": { "type": "string" },
                                            "crossDisplay": { "type": "string" },
                                            "volume": { "type": "string" },
                                            "priceBDisplay": { "type": "string" },
                                            "vega": { "type": "number" },
                                            "priceIncrement": { "type": "number" },
                                            "sizeIncrement": { "type": "number" },
                                            "minOrderSize": { "type": "number" },
                                            "defaultOrderSize": { "type": "number" },
                                            "defaultSizes": {
                                                "type": "array",
                                                "items": { "type": "number" }
                                            },
                                            "minBidPrice": { "type": "number" },
                                            "minOfferPrice": { "type": "number" },
                                            "maxBidPrice": { "type": "number" },
                                            "maxOfferPrice": { "type": "number" },
                                            "midPrice": { "type": "number" },
                                            "priceDisplay": { "type": "string" },
                                            "midPriceDirection": { "enum": ["none", "better", "worse"] },
                                            "isMidPriceIndicative": { "type": "boolean" },
                                            "thirdPartyInterest": { "enum": ["none", "behindMid", "atMidBelowMarketSize", "atMid", "aheadOfMid"] },
                                            "hasSameLeBuyInterest": { "type": "boolean" },
                                            "hasSameLeSellInterest": { "type": "boolean" },
                                            "hasTraded": { "type": "boolean" },
                                            "hasTradedAtMidPrice": { "type": "boolean" },
                                            "lastAuctionMidPriceDirection": { "enum": [ "none", "better", "worse" ] },
                                            "isPricingAwayFromMidAllowed": { "type": "boolean" }
                                        },
                                        "additionalProperties": false
                                    }
                                },
                                "lastBidPriceDisplay": { "type": "string" },
                                "lastOfferPriceDisplay": { "type": "string" },
                                "lastBidDateTime": { "type": "string" },
                                "lastOfferDateTime": { "type": "string" },
                                "lastTradeDirection": { "$ref": "#/definitions/priceDirectionSchema" },
                                "indicativeBidPriceDisplay": { "type": "string" },
                                "indicativeOfferPriceDisplay": { "type": "string" },
                                "lastTradePriceDisplay": { "type": "string" },
                                "sessionDate": { "type": "string" },
                                "sessionLowPriceDisplay": { "type": "string" },
                                "sessionHighPriceDisplay": { "type": "string" },
                                "sessionOpenPriceDisplay": { "type": "string" },
                                "sessionClosePriceDisplay": { "type": "string" },
                                "totalTradedSize": { "type": "string" },
                                "spread": {
                                    "type": "object",
                                    "properties": {
                                        "underLyingIds": {
                                            "type": "array",
                                            "items": { "type": "string" }
                                        },
                                        "weighting": { "type": "number" },
                                        "isSpreadWeightingCustom": { "type": "boolean" },
                                        "displayUnderlyingPrices": { "type": "boolean" }
                                    },
                                    "additionalProperties": false
                                }
                            },
                            "additionalProperties": false
                        },

                        "priceSchema": {
                            "required": ["number", "string"],
                            "properties": {
                                "number": { "type": "number" },
                                "string": { "type": "string" }
                            }
                        },

                        "orderEntryPrefSchema": {
                            "enum": ["gtt", "gtc", "lmt", "fok", "fak"]
                        },

                        "sizeConfigSchema": {
                            "properties": {
                                "type": { "enum": ["min", "max", "default"] },
                                "value": { "type": "number" }
                            }
                        },

                        "priceTypeSchema": {
                            "enum": ["priceTypeF512", "priceTypeF256", "priceTypeF128", "priceTypeF64", "priceTypeF32", "priceTypeDecimal"]
                        },

                        "priceWithTypeSchema": {
                            "required": ["number", "string"],
                            "properties": {
                                "number": { "type": "number" },
                                "string": { "type": "string" },
                                "priceType": { "$ref": "#/definitions/priceTypeSchema" }
                            }
                        },

                        "priceDirectionSchema": {
                            "enum": ["none", "hit", "tak"]
                        },

                        "orderStatusMsg": {
                            "required": ["messageName", "requestId", "orderId", "userId", "instrumentId", "status"],
                            "properties": {
                                "messageName": { "enum": ["orderStatus"] },
                                "requestId": { "type": "string" },
                                "requestContext": { "type": "string" },
                                "orderId": { "type": "string" },
                                "userId": { "type": "string" },
                                "traderName": { "type": "string" },
                                "deskName": { "type": "string" },
                                "companyName": { "type": "string" },
                                "instrumentId": { "type": "string" },
                                "status": { "enum": ["live", "inactive", "killed"] },
                                "venue": { "enum": ["vm", "lp", "clob"] },
                                "venueDisplay": { "type": "string" },
                                "submissionTime": { "type": "number" },
                                "timeInForce": { "enum": ["gtt", "gtc", "lmt", "fok", "fak"] },
                                "cpcCode": { "type": "string" },
                                "order": {
                                    "type": "object",
                                    "properties": {
                                        "type": { "enum": ["own", "myDesk", "myFirm", "other"] },
                                        "price": {
                                            "type": "array",
                                            "items": { "$ref": "#/definitions/priceWithTypeSchema" }
                                        },
                                        "side": { "enum": ["buy", "sell"] },
                                        "totalSize": { "type": "number" },
                                        "filledSize": { "type": "number" },
                                        "unfilledSizes": {
                                            "type": "array",
                                            "items": { "type": "number" }
                                        },
                                        "allowedActions": {
                                            "type": "array",
                                            "items": {
                                                "enum": ["canCancel", "canModify"]
                                            }
                                        }
                                    },
                                    "additionalProperties": false
                                }
                            },
                            "additionalProperties": false
                        },

                        "vmOrderUpdateMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["vmOrderUpdate"]
                                },
                                "instrumentId": { "type": "string" },
                                "orderId": { "type": "string" },
                                "accountId": { "type": "string" },
                                "userId": { "type": "string" },
                                "orderType": { "type": "string" },
                                "orderPrice": { "type": "number" },
                                "hasInstrumentTradedAtOrderPrice": { "type": "boolean" },
                                "singleSide": { "type": "string" },
                                "buySize": { "type": "number" },
                                "sellSize": { "type": "number" },
                                "buyCanBeCancelled": { "type": "boolean" },
                                "sellCanBeCancelled": { "type": "boolean" },
                                "boughtSize": { "type": "number" },
                                "soldSize": { "type": "number" },
                                "isLiveBuy": { "type": "boolean" },
                                "isLiveSell": { "type": "boolean" },
                                "isBuyFootprint": { "type": "boolean" },
                                "isSellFootprint": { "type": "boolean" },
                                "wasBuyPublishedByExcel": { "type": "boolean" },
                                "wasSellPublishedByExcel": { "type": "boolean" }
                            },
                            "additionalProperties": false
                        },

                        "vmOrderSummaryMsg": {
                            "required": ["messageName", "userId", "instrumentId", "order"],
                            "properties": {
                                "messageName": { "enum": ["vmOrderSummaryMsg"] },
                                "userId": { "type": "string" },
                                "instrumentId": { "type": "string" },
                                "order": {
                                    "type": "object",
                                    "properties": {
                                        "type": { "enum": ["own", "myFirm"] },
                                        "price": { "$ref": "#/definitions/priceSchema" },
                                        "buySize": { "type": "number" },
                                        "sellSize": { "type": "number" },
                                        "boughtSize": { "type": "number" },
                                        "soldSize": { "type": "number" }
                                    },
                                    "additionalProperties": false
                                }
                            },
                            "additionalProperties": false
                        },

                        "tradeExecutionMsg": {
                            "required": ["messageName", "instrumentId", "instrumentName", "isNotification", "execution"],
                            "properties": {
                                "messageName": { "enum": ["tradeExecution"] },
                                "traderId": { "type": "string" },
                                "accountId": { "type": "string" },
                                "instrumentId": { "type": "string" },
                                "instrumentName": { "type": "string" },
                                "isNotification": { "type": "boolean" },
                                "nomenclature": { "enum": ["bidOffer", "payRec", "paidGiven", "traded"] },
                                "execution": { "$ref": "#/definitions/tradeSchema" }
                            },
                            "additionalProperties": false
                        },

                        "tradeCaptureReportMsg": {
                            "required": ["messageName", "traderId", "instrumentId", "instrumentName", "match"],
                            "properties": {
                                "messageName": { "enum": ["tradeCaptureReport"] },
                                "traderId": { "type": "string" },
                                "traderName": { "type": "string" },
                                "traderCompany": { "type": "string" },
                                "traderDesk": { "type": "string" },
                                "instrumentId": { "type": "string" },
                                "instrumentName": { "type": "string" },
                                "accountId": { "type": "string" },
                                "nomenclature": { "enum": ["bidOffer", "payRec", "paidGiven", "traded"] },
                                "tradeLegId": { "type": "integer" },
                                "match": { "$ref": "#/definitions/tradeSchema" },
                                "executions": {
                                    "type": "array",
                                    "items": { "$ref": "#/definitions/tradeSchema" }
                                }
                            },
                            "additionalProperties": false
                        },

                        "vmTradeSummaryMsg": {
                            "required": ["messageName", "traderId", "instrumentId", "instrumentName", "match"],
                            "properties": {
                                "messageName": { "enum": ["vmTradeSummary"] },
                                "traderId": { "type": "string" },
                                "instrumentId": { "type": "string" },
                                "instrumentName": { "type": "string" },
                                "accountId": { "type": "string" },
                                "nomenclature": { "enum": ["bidOffer", "payRec", "paidGiven", "traded"] },
                                "match": { "$ref": "#/definitions/tradeSchema" }
                            },
                            "additionalProperties": false
                        },

                        "tradeSchema": {
                            "type": "object",
                            "required": ["type", "price", "venue", "size"],
                            "properties": {
                                "id": { "type": "string" },
                                "executionId": { "type": "string" },
                                "matchId": { "type": "string" },
                                "structureGroupingId": { "type": "string"},
                                "orderId": { "type": "string" },
                                "type": { "enum": ["own", "myDesk", "myFirm", "thirdParty"] },
                                "venue": { "enum": ["vm", "clob", "lp"] },
                                "venueDisplay": { "type": "string" },
                                "side": { "enum": ["none", "buy", "sell"] },
                                "price": { "$ref": "#/definitions/priceSchema" },
                                "priceViews": {
                                    "type": "array",
                                    "items": { "$ref": "#/definitions/priceWithTypeSchema" }
                                },
                                "tradeDirection": { "$ref": "#/definitions/priceDirectionSchema" },
                                "tradeTime": { "type": "integer" },
                                "tradeTimeDisplay": { "type": "string" },
                                "size": { "type": "number" },
                                "counterparty": { "type": "string" },
                                "strike1Display": { "type": "string" },
                                "strike2Display": { "type": "string" },
                                "crossDisplay": { "type": "string" },
                                "deltaDisplay": { "type": "string" },
                                "straddleDisplay": { "type": "string" },
                                "ratioDisplay": { "type": "string" },
                                "priceBDisplay": { "type": "string" },
                                "postTradeDetails": {
                                    "properties": {
                                        "companyName": { "type": "string" },
                                        "deskName": { "type": "string" },
                                        "settlementDate": { "type": "integer" },
                                        "brokerageAmount": { "type": "number" },
                                        "currency": { "type": "string" },
                                        "productSpecifics": {
                                            "properties": {
                                                "cusip": { "type": "string" },
                                                "isin": { "type": "string" },
                                                "maturityDate": { "type": "string" },
                                                "issueDate": { "type": "string" },
                                                "couponRate": { "type": "number" },
                                                "interestAccrualDate": { "type": "string" },
                                                "accruedInterest": { "type": "number" },
                                                "accruedInterestDays": { "type": "integer" },
                                                "settlementDateType": { "type": "string" }
                                            },
                                            "additionalProperties": false
                                        },
                                        "valuation": {
                                            "properties": {
                                                "yield": { "type": "number" },
                                                "allInPrice": { "type": "number" },
                                                "allInYield": { "type": "number" },
                                                "pv01": { "type": "number" }
                                            },
                                            "additionalProperties": false
                                        }
                                    },
                                    "additionalProperties": false
                                }
                            },
                            "additionalProperties": false
                        },

                        "tileSchema": {
                            "type": "object",
                            "properties": {
                                "clientId": { "type": "string" },
                                "pageId": { "type": "string" },
                                "tileId": { "type": "string" },
                                "isCentral": { "type": "boolean" },
                                "customizesTileId": { "type": "string" },
                                "tileName": { "type": "string" },
                                "layoutType": {
                                    "enum": [
                                      "list",
                                      "outright",
                                      "spread"
                                    ]
                                },
                                "tileLocation": {
                                    "type": "object",
                                    "properties": {
                                        "beforeTileId": { "type": "string" }
                                    },
                                    "additionalProperties": false
                                },
                                "itemList": {
                                    "type": "array",
                                    "items": { "$ref": "#/definitions/tileItemSchema" }
                                },
                                "orderingType": { "enum": ["explicit", "rule"] },
                                "selectionType": { "enum": ["explicit", "rule"] },
                                "orderingRules": {
                                    "type": "array",
                                    "items": { "type": "string" }
                                },
                                "selectionRules": {
                                    "type": "array",
                                    "items": { "type": "string" }
                                },
                                "instrumentList": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "required": ["instrumentId"],
                                        "properties": {
                                            "instrumentId": { "type": "string" },
                                            "sortOrdinal": { "type": "number"}
                                        }
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "tileItemSchema": {
                            "type": "object",
                            "properties": {
                                "type": { "enum": ["label", "reference"] },
                                "value": { "type": "string" }
                            },
                            "additionalProperties": false
                        },

                        "matrixSchema": {
                            "type": "object",
                            "properties": {
                                "matrixId": { "type": "string" },
                                "matrixName": { "type": "string" },
                                "layoutType": { "enum": ["matrix", "triangle", "triangle-inverted"] },
                                "defaultLinkedMatrixIndex": { "type": "integer" },
                                "columnLinkIndex": { "type": "integer" },
                                "rowHeaderList": {
                                    "type": "array",
                                    "items": { "type": "string" }
                                },
                                "columnHeaderList": {
                                    "type": "array",
                                    "items": { "type": "string" }
                                },
                                "instrumentList": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "instrumentId": { "type": "string" },
                                            "rowIndex": { "type": "integer" },
                                            "columnIndex": { "type": "integer" }
                                        },
                                        "additionalProperties": false
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "auctionMsg": {
                            "required": ["messageName", "event", "auctionId"],
                            "properties": {
                                "messageName": { "enum": ["auction"] },
                                "event": { "enum": ["start", "update", "end"] },
                                "auctionId": { "type": "string" },
                                "auctionName": { "type": "string" },
                                "nowTime": { "type": "number" },
                                "startTime": { "type": "number" },
                                "endTime": { "type": "number" },
                                "orderPhaseText": { "type": "string" },
                                "hiddenColumns": { "type": "array", items: { "type": "string" } },
                                "auctionPhase": { "enum": ["prorataPhase", "vmplusPhase"] },
                                "phaseoneEndtime": { "type": "number" },
                                "settings": {
                                    "type": "object",
                                    "properties": {
                                        "showInterestGlows": { "type": "boolean" },
                                        "showTradeIndicators": { "type": "boolean" },
                                        "showInterestAndTradeIndicators": { "type": "boolean" }
                                    },
                                    "additionalProperties": false
                                }
                            },
                            "additionalProperties": false
                        },

                        "eventLogMsg": {
                            "required": ["messageName", "messages"],
                            "properties": {
                                "messageName": { "enum": ["eventLog"] },
                                "messages": {
                                    "type": "array",
                                    "items": {
                                        "$ref": "#/definitions/eventLogItemSchema"
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "eventLogItemSchema": {
                            "properties": {
                                "time": { "type": "integer" },
                                "text": { "type": "string" },
                                "typeDisplay": { "type": "string" },
                                "eventType": {
                                    "enum": [
                                      "general",
                                      "newOrderRequest",
                                      "newOrderAccepted",
                                      "orderUpdateRequest",
                                      "orderUpdated",
                                      "orderCancelRequest",
                                      "orderCancelled",
                                      "orderRejected",
                                      "orderFilled",
                                      "orderPartiallyFilled",
                                      "toppedOrder"
                                    ]
                                },
                                "level": {
                                    "enum": ["error", "warn", "info"]
                                },
                                "attributes": {
                                    "properties": {
                                        "instrumentId": { "type": "string" },
                                        "orderId": { "type": "string" },
                                        "tradeId": { "type": "string" },
                                        "sizeUnit": { "type": "string" },
                                        "newPrice": { "type": "string" }
                                    },
                                    "additionalProperties": false
                                }
                            },
                            "additionalProperties": false
                        },

                        "queryResultsMsg": {
                            "required": ["messageName", "requestId", "commandSource", "resultType", "results"],
                            "properties": {
                                "messageName": { "enum": ["queryResults"] },
                                "requestId": { "type": "string" },
                                "requestContext": { "type": "string" },
                                "commandSource": { "type": "string" },
                                "type": {
                                    "enum": ["trade", "eventLog", "instruments", "tileItem", "orderAdmin"]
                                },
                                "resultType": { "enum": ["snapshot", "update", "invisible", "snapshotNoUpdates"] },
                                "results": {
                                    "type": "array",
                                    "items": {
                                        "anyOf": [
                                          { "$ref": "#/definitions/tradeCaptureReportMsgSchema" },
                                          { "$ref": "#/definitions/eventLogItemSchema" },
                                          { "$ref": "#/definitions/instrumentTupleSchema" },
                                          { "$ref": "#/definitions/tileItemSchema" },
                                          { "$ref": "#/definitions/orderAdminHierarchySchema" }
                                        ]
                                    }
                                },
                                "totalAvailable": { "type": "integer" },
                                "updateAction": {
                                    "enum": ["insert", "update", "delete"]
                                },
                                "updateAt": { "type": "integer" },
                                "invisibility": {
                                    "enum": ["outOfRange", "filteredOut"]
                                }
                            },
                            "additionalProperties": false
                        },

                        "instrumentTupleSchema": {
                            "properties": {
                                "instrumentId": { "type": "string" },
                                "instrumentName": { "type": "string" }
                            },
                            "additionalProperties": false
                        },

                        "orderAdminHierarchySchema": {
                            "properties": {
                                "productId": {
                                    "type": "string"
                                },
                                "userOrderActions": {
                                    "type": "array",
                                    "items": {
                                        "$ref": "#/definitions/userOrderActionsSchema"
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "userOrderActionsSchema": {
                            "type": "object",
                            "properties": {
                                "orderSources": {
                                    "type": "array",
                                    "items": {
                                        "enum": ["gui", "api", "all"]
                                    }
                                },
                                "type": { "enum": ["user", "desk", "legalEntity"] },
                                "display": { "type": "string" },
                                "id": { "type": "string" },
                                "members": {
                                    "type": "array",
                                    "items": {
                                        "$ref": "#/definitions/userOrderActionsSchema"
                                    }
                                }
                            },
                            "additionalProperties": false
                        },

                        "vmCreateInstrumentResponseMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["vmCreateInstrumentResponse"]
                                },
                                "instrumentCreationID": { "type": "string" },
                                "isSuccessful": { "type": "boolean" }
                            },
                            "additionalProperties": false
                        },

                        "excelAddInStateChangedMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["excelAddInStateChanged"]
                                },
                                "isExcelAddInEnabled": { "type": "boolean" },
                                "areAllExcelLiveLinksEnabled": { "type": "boolean" }
                            },
                            "additionalProperties": false
                        },

                        "midnightCleanupMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["midnightCleanup"]
                                }
                            },
                            "additionalProperties": false
                        },

                        "userLoginMsg": {
                            "required": ["messageName", "userId", "userType"],
                            "properties": {
                                "messageName": {
                                    "enum": ["userLogin"]
                                },
                                "userId": { "type": "string" },
                                "userType": {
                                    "enum": ["broker", "trader", "salesTrader"]
                                }
                            }
                        },

                        "themeUpdateMsg": {
                            "required": ["messageName", "themeSuffix"],
                            "properties": {
                                "messageName": { "enum": ["themeUpdate"] },
                                "themeSuffix": { "type": "string" }
                            },
                            "additionalProperties": false
                        },

                        "accountData": {
                            "type": "object",
                            "properties": {
                                "id": { "type": "string" },
                                "accountId": { "type": "string" },
                                "screenName": { "type": "string" },
                                "shortName": { "type": "string" },
                                "enabled": { "type": "boolean" },
                                "accountType": { "type": "number" },
                                "displayIndex": { "type": "number" }
                            },
                            "additionalProperties": false
                        },

                        "accountsListMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["accountsList"]
                                },
                                "accounts": {
                                    "type": "array",
                                    "items": { "$ref": "#/definitions/accountDataSchema" }
                                }
                            },
                            "additionalProperties": false
                        },

                        "accountUpdateMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["accountUpdate"]
                                },
                                "data": { "$ref": "#/definitions/accountDataSchema" },
                                "operation": {
                                    "enum": ["add", "update", "remove"]
                                }
                            },
                            "additionalProperties": false
                        },

                        "accountSelectionChangedMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["accountSelectionChanged"]
                                },
                                "accountId": { "type": "string" }
                            },
                            "additionalProperties": false
                        },

                        "selectInstrumentMsg": {
                            "properties": {
                                "messageName": {
                                    "enum": ["selectInstrument"]
                                },
                                "instrumentId": { "type": "string" }
                            },
                            "additionalProperties": false
                        },

                        "screenshotMsg": {
                            "required": ["requestId", "messageName"],
                            "properties": {
                                "requestId": { "type": "string" },
                                "messageName": { "enum": ["screenshot"] },
                                "messageParams": {
                                    "type": "object",
                                    "properties": {
                                        "screenshots": {
                                            "type": "array",
                                            "items": {
                                                "type": "object",
                                                "properties": {
                                                    "id": { "type": "string" },
                                                    "image": { "type": "string" },
                                                    "description": { "type": "string" }
                                                }
                                            },
                                            "additionalProperties": false
                                        }
                                    },
                                    "additionalProperties": false
                                }
                            },
                            "additionalProperties": false
                        }
                    }
                };

                // Public instance methods
                SchemaValidator.prototype.augmentSchema = function (dataStore) {
                    _.each(appSchema.definitions, function (definition, name) {
                        if (name.endsWith('Msg')) {
                            dataStore.augmentSchema(name, definition);
                        } else {
                            dataStore.addSchemaDataDefinition(name, definition);
                        }
                    });
                };

                SchemaValidator.prototype.validateMessage = function (schema, message, validationError) {
                    var isValid = tv4Validator.validate(message, schema);

                    if (!isValid) {
                        validationError = { code: tv4Validator.error.code, message: tv4Validator.error.message };
                    }

                    return isValid;
                };

            }; // Constructor

        return {

            getInstance: function () {
                if (!instance) {
                    instance = new SchemaValidator();
                }
                return instance;
            },

            // trade side
            BUY_SIDE: "buy",
            SELL_SIDE: "sell",

            // third party interest
            INTEREST_BEHIND_MID: "behindMid",
            INTEREST_AT_MID_BELOW_MKTSIZE: "atMidBelowMarketSize",
            INTEREST_AT_MID: "atMid",
            INTEREST_AHEAD_OF_MID: "aheadOfMid",

            // order/trade ownership
            OWNERSHIP_MINE: "own",
            OWNERSHIP_MY_FIRM: "myFirm",
            OWNERSHIP_SHARED_ACCOUNT: "sharedAccount"
        };

    }());

    BGC.schemaValidator.getInstance();

}(window.BGC));
