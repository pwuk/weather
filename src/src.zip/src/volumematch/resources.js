/* eslint-disable max-lines, max-len, func-names */
/* global BGC: false */

// /////////////////////////////////////////////////////////////////////////////
// file resources.js
// BGC View module implementation.
// /////////////////////////////////////////////////////////////////////////////

// eslint-disable-next-line max-statements
(function (moduleContext) {
  const context = moduleContext;

  context.resources = context.resources || {};

  // strings
  context.resources.SPREAD = 'Spread';
  context.resources.IDS_INSTRUMENT = 'Instrument';
  context.resources.IDS_INSTRUMENT_A = 'Instrument A';
  context.resources.IDS_INSTRUMENT_B = 'Instrument B';
  context.resources.IDS_STRIKE1 = 'Strike A';
  context.resources.IDS_STRIKE2 = 'Strike B';
  context.resources.IDS_CROSS = 'Cross';
  context.resources.IDS_PRICE = 'Price';
  context.resources.IDS_PRICE_A = 'Price A';
  context.resources.IDS_PRICE_B = 'Price B';
  context.resources.IDS_RATIO = 'Ratio';
  context.resources.IDS_TRADE_STATUS = 'Trade Status';
  context.resources.IDS_COUNTERPARTY = 'Counterparty';
  context.resources.IDS_COUNTERPARTIES = 'Counterparties';
  context.resources.IDS_TIME = 'Time';
  context.resources.IDS_TIME_LEFT = 'Time Left';
  context.resources.IDS_ZOOM = 'Zoom';
  context.resources.IDS_FULLY_ANONYMOUS = 'Fully Anonymous';
  context.resources.IDS_YOUR_ORDERS = 'Orders';
  context.resources.IDS_YOUR_TRADES = 'Trades';
  context.resources.IDS_TRADES_FOR_FIRM = 'My Firm';
  context.resources.IDS_TRADES_FOR_GROUP = 'Show All';
  context.resources.IDS_VM_HEADER = 'bgc Volume Match';
  context.resources.IDS_VM_HEADER_AUSIRO = 'bgc VM Auction';
  context.resources.IDS_VM_HEADER_BGC_AUREL = 'aurel bgc Volume Match';
  context.resources.IDS_VM_HEADER_MINT = 'MINT Volume Match';
  context.resources.IDS_VM_HEADER_GBX = 'GBX Volume Match';
  context.resources.IDS_VM_HEADER_RPMARTIN = 'Martin Brokers Volume Match';
  context.resources.IDS_VM_HEADER_FENICS = 'Fenics Volume Match';
  context.resources.IDS_VM_HEADER_GFI = 'GFI Matching';
  context.resources.IDS_VM_HEADER_COLLEX = 'Collex Volume Match';
  context.resources.IDS_VM_HEADER_FREEDOM = 'Freedom Volume Match';
  context.resources.IDS_VM = 'Volume Match';
  context.resources.IDS_VM_AUSIRO = 'VM Auction';
  context.resources.IDS_VM_GFIFXO = 'Matching';
  context.resources.IDS_OF_SEPARATOR = ' of ';
  context.resources.IDS_YES = 'Yes';
  context.resources.IDS_NO = 'No';
  context.resources.IDS_CANCEL = 'Cancel';
  context.resources.IDS_CANCEL_ALL = 'Cancel All';
  context.resources.IDS_INVALID_SIZE = 'Invalid Size';
  context.resources.IDS_INVALID_PRICE = 'Invalid Price';
  context.resources.IDS_PRINT_CONFIRMS = 'Print Confirms';
  context.resources.IDS_PRINT_CONFIRMS_TOOLTIP = 'Generate trade confirms';
  context.resources.IDS_INVALID_UNDERLYING = 'Invalid Underlying Instrument';
  context.resources.IDS_SUBMIT = 'Submit Spread';
  context.resources.IDS_CREATE = 'Create Spread';
  context.resources.IDS_CLEAR = 'Clear';
  context.resources.IDS_TYPE_SPREAD = 'Type / Add Spread';
  context.resources.IDS_COPY_EXCEL_LINKS = 'Copy Excel Links';
  context.resources.IDS_CLEAR_AUCTION_TOTALS = 'Clear Auction Totals';
  context.resources.IDS_ENABLE_ALL_EXCEL_LIVE_LINKS = 'Enable All Excel Live Links';
  context.resources.IDS_DISABLE_ALL_EXCEL_LIVE_LINKS = 'Disable All Excel Live Links';
  context.resources.IDS_SETTINGS = 'Settings';
  context.resources.IDS_SETTINGS_SECOND_LOOK = 'Enable second look for orders';
  context.resources.IDS_SETTINGS_SPREAD_SECOND_LOOK = 'Enable second look for spread creation';
  context.resources.IDS_SETTINGS_SPREAD_AND_ORDER_SECOND_LOOK = 'Enable second look for spread orders';
  context.resources.IDS_SETTINGS_FAVORITES_SECOND_LOOK = 'Enable second look for favorite orders';
  context.resources.IDS_SETTINGS_ENABLE_IN_PLACE_ORDER_ENTRY = 'Enable In-place Order Entry';
  context.resources.IDS_SETTINGS_TILES_COMPACT = 'Use compact layout for tiles';
  context.resources.IDS_SETTINGS_ALLOW_BROKER_REPRICE = 'Allow broker live VM reprice';
  context.resources.IDS_SETTINGS_FIXED_HEIGHT_ORDERS_VIEW = 'Fixed height orders/trades area';
  context.resources.IDS_SETTINGS_ORDER_ANIMATION_DURATION = 'Active order animation frequency';
  context.resources.IDS_SETTINGS_FIXED_HEIGHT_ORDERS_ROW_COUNT = 'Number of fixed rows';
  context.resources.IDS_SETTINGS_CENTRE_OEDB = 'Position OEDB central to price cell';
  context.resources.IDS_INVALID_FIXED_HEIGHT_ORDERS_ROW_COUNT_ENTRY = 'Invalid number of fixed rows';
  context.resources.IDS_INVALID_ORDER_ANIMATION_DURATION_ENTRY = 'Invalid number for animation frequency';
  context.resources.IDS_MAX_QUANTITY_MULTIPLIER = 'Controls the maximum size an order can <br> placed at without triggering a warning <br> message. The value is a multiple of the <br>instrument\'s default size, e.g., 10.';
  context.resources.IDS_ACCOUNT = 'Account';
  context.resources.IDS_ACCOUNT_REQUIRED = 'Account Required';
  context.resources.IDS_MY_SIZE = 'My Size';
  context.resources.IDS_UPSIZING = 'Upsizing';
  context.resources.IDS_INCREMENTAL = 'Incremental';
  context.resources.IDS_TOTAL = 'Total';
  context.resources.IDS_THEMECHANGE = 'Theme';
  context.resources.IDS_PEARL_THEME = 'Pearl';
  context.resources.IDS_CHARCOAL_THEME = 'Charcoal';
  context.resources.IDS_SAPPHIRE_THEME = 'Sapphire';
  context.resources.IDS_IVORY_THEME = 'Ivory';
  context.resources.IDS_ROSE_THEME = 'Rose';
  context.resources.IDS_AMETHYST_THEME = 'Amethyst';
  context.resources.IDS_ONYX_THEME = 'Onyx';
  context.resources.IDS_MAXIMUM_QUANTITY = 'Max Quantity Multiple';
  context.resources.IDS_BUY = 'Buy';
  context.resources.IDS_BUY_SIZE = 'Buy Size';
  context.resources.IDS_BUY_SIZE_PLACEHOLDER = '<Buy Sz>';
  context.resources.IDS_BOUGHT = 'Bought';
  context.resources.IDS_PAY = 'Pay';
  context.resources.IDS_PAY_QTY = 'Pay Qty';
  context.resources.IDS_PAY_QTY = 'Pay Qty';
  context.resources.IDS_PAY_QTY_PLACEHOLDER = '<Pay Qty>';
  context.resources.IDS_PAID = 'Paid';
  context.resources.IDS_SELL = 'Sell';
  context.resources.IDS_SELL_SIZE = 'Sell Size';
  context.resources.IDS_SELL_SIZE_PLACEHOLDER = '<Sell Sz>';
  context.resources.IDS_SOLD = 'Sold';
  context.resources.IDS_RECEIVE = 'Receive';
  context.resources.IDS_RECEIVE_QTY = 'Receive Qty';
  context.resources.IDS_RECEIVE_QTY_PLACEHOLDER = '<Rcv Qty>';
  context.resources.IDS_RECEIVED = 'Received';
  context.resources.IDS_GIVEN = 'Given';
  context.resources.IDS_LHS_TRADED_STC = 'LHS Traded STC';
  context.resources.IDS_RHS_TRADED_STC = 'RHS Traded STC';
  context.resources.IDS_MENU_ITEM_INSERT_BEFORE = 'Insert before';
  context.resources.IDS_MENU_ITEM_INSERT_AFTER = 'Insert after';
  context.resources.IDS_MENU_ITEM_EDIT_ROW = 'Edit row';
  context.resources.IDS_MENU_ITEM_REMOVE_ROW = 'Remove row';
  context.resources.IDS_CREATE_NEW_ROW = 'Create a new row';
  context.resources.IDS_EDIT_ROW = 'Edit row';
  context.resources.IDS_REMOVE_ROW = 'Remove row {0}';
  context.resources.IDS_OEB_BUY_PLACEHOLDER = '<Bid Px>';
  context.resources.IDS_OEB_SELL_PLACEHOLDER = '<Offer Px>';
  context.resources.IDS_OEB_ASK_PLACEHOLDER = '<Ask Px>';
  context.resources.IDS_OEB_PICKUP_PLACEHOLDER = '<Pick Up>';
  context.resources.IDS_OEB_GIVEUP_PLACEHOLDER = '<Give Up>';
  context.resources.IDS_OEB_NUDGE = 'Nudge {0} {1}';
  context.resources.IDS_OEB_NUDGE_LIVE = 'Live nudge {0} {1}';
  context.resources.IDS_OEB_NUDGE_UP = 'up to';
  context.resources.IDS_OEB_NUDGE_DN = 'down to';
  context.resources.IDS_OEB_INVALID_ENTRY = 'Invalid Entry';
  context.resources.IDS_MY_ORDERS_ONLY = 'My orders only';
  context.resources.IDS_PEER_ORDERS_ONLY = 'Peer group orders only';
  context.resources.IDS_ALL_ORDERS = 'ALL orders, mine and peers';
  context.resources.IDS_INTEREST_COUNT = 'Interest Count';
  context.resources.IDS_TRADE_COUNT = 'Trade Count';
  context.resources.IDS_MY_TRADE_COUNT = 'My Trade Count';
  context.resources.IDS_MY_ORDER_COUNT = 'My Order Count';
  context.resources.IDS_LIVE_MODE_SHOW_ALL = 'Showing All';
  context.resources.IDS_LIVE_MODE_MINE_AND_GLOWS = 'My Orders and Glows';
  context.resources.IDS_LIVE_MODE_MINE_ONLY = 'My Orders';
  context.resources.IDS_LIVE_MODE_GLOWS_AND_TRADES = 'Glows and Trades';
  context.resources.IDS_LIVE_MODE_TITLE = 'Filtering';
  context.resources.IDS_CHANGE_PASSWORD = 'Change Password';
  context.resources.IDS_CHANGE_PASSWORD_CONFIRM = 'Are you sure you want to change your current password ?';
  context.resources.IDS_EXPAND = 'Expand';
  context.resources.IDS_COLLAPSE = 'Collapse';
  context.resources.IDS_INVALID_ENTRY_AND_REVERT = 'The value was invalid and has been reverted';
  context.resources.IDS_INVALID_MAX_MULTIPLE_ENTRY = 'Invalid Max Quantity Multiple';
  context.resources.IDS_CLOSE = 'Close';
  context.resources.IDS_SPREADS_BAR_ACTIVE = 'Spread Builder Active';
  context.resources.IDS_VM_ALWAYS_ON_TOP = 'Always show {0} windows on top of others';
  context.resources.IDS_SUBMIT_FAVORITES = 'Submit';
  context.resources.IDS_MY_FAVORITES = 'Favorites';
  context.resources.IDS_CONFIRM_SUBMIT_FAVORITES = 'Submitting {0} Order(s) ...';
  context.resources.IDS_SETTINGS_FAVORITE_SIZE_BUTTONS = 'Display size buttons in My Favorites view';
  context.resources.IDS_PIN_WINDOW = 'Remember window height and position';
  context.resources.IDS_INST_COUNT_BADGE_TIP = 'Active Instrument Count';
  context.resources.IDS_PRODUCT = 'Product';
  context.resources.IDS_VERSUS = 'vs';
  context.resources.IDS_PICK_UP = 'Pick Up';
  context.resources.IDS_GIVE_UP = 'Give Up';
  context.resources.IDS_DESCRIPTION = 'Description';
  context.resources.IDS_CUSIP = 'CUSIP';
  context.resources.IDS_ISIN = 'ISIN';
  context.resources.IDS_LIMIT = 'Limit';
  context.resources.IDS_SIZE = 'Size';
  context.resources.IDS_PORTFOLIO = 'Orders';
  context.resources.IDS_STATUS = 'Status';
  context.resources.IDS_GOOD_TILL = 'Good Till';
  context.resources.IDS_OVERNIGHT = 'Overnight';
  context.resources.IDS_END_OF_DAY = 'End Of Day';
  context.resources.IDS_REPOST = 'Repost';
  context.resources.IDS_ENABLE_OCO = 'Order Cancels Order(s)';
  context.resources.IDS_OCO_BID_OFFER_SPECIFIC = 'OCO Behaviour: Bid/Offer Specific';
  context.resources.VM_WINDOWS = 'VM Windows:';
  context.resources.FRAMING_DISCLOSURE = 'Framing Disclosure';
  context.resources.PRICES_FRAMED_DISCLOSURE = 'Prices may be framed, please see';
  context.resources.PRICES_FRAMED_DISCLOSURE_LINK = 'http://bgchistory.eu.ad.espeed.com/FramingDisclosure/BGCFramingDisclosure.htm';
  context.resources.IDS_NVM_PEARL_THEME = 'Pearl';
  context.resources.IDS_NVM_CHARCOAL_THEME = 'Charcoal';
  context.resources.IDS_NVM_ONYX_THEME = 'Onyx';
  context.resources.IDS_LOG_LEVEL = 'Log level';

  // messages
  context.resources.IDS_MSG_MINIMUM_SIZE = 'Please enter a size of at least {0}';
  context.resources.IDS_MSG_SIZE_INCREMENT = 'Please enter a size that is a valid multiple of {0}';
  context.resources.IDS_MSG_UNFILLED_SIZE_INCREMENT = 'The resulting unfilled order size of {0} must be a valid multiple of {1}';
  context.resources.IDS_MSG_UNFILLED_MIN_SIZE = 'This would result in unfilled order size of {0}. Please enter an order with at least {1} unfilled size';
  context.resources.IDS_MSG_TOTAL_SIZE_NOT_LARGER_THAN_TRADED = 'Please enter a size greater than your current total traded size of {0}';
  context.resources.IDS_MSG_TOTAL_SIZE_NOT_DIFFERENT_THAN_TOTAL = 'The size entered is the same as your current total of {0}';
  context.resources.IDS_MSG_ENTERED_SIZE_NOT_DIFFERENT_THAN_CURRENT_OUTSTANDING_SIZE = 'The size entered is the same as your current outstanding size of {0}';
  context.resources.IDS_MSG_SIZE_NOT_VALID_FLOAT = 'Please enter a number greater than 0';
  context.resources.IDS_MSG_PRICE_NOT_VALID_FLOAT = 'Please enter a valid number';
  context.resources.IDS_MSG_PRICE_INCREMENT = 'The price entered is not a valid multiple of the price increment';
  context.resources.IDS_MSG_PRICE_GREATER_ZERO = 'Please enter a price greater than zero';
  context.resources.IDS_MSG_PRICE_GREATER_OR_EQUAL = ' Please enter a price greater than or equal to {0}';
  context.resources.IDS_MSG_PRICE_LESS_OR_EQUAL = ' Please enter a price less than or equal to {0}';
  context.resources.IDS_MSG_SECOND_LOOK_CONFIRM = '<b><span>{0}</span> {1} {2} at {3} {4}</b>';
  context.resources.IDS_MSG_SECOND_LOOK_SPREAD_CONFIRM = '<b>Create {0} at {1} {2}</b><br>- vs -<br><b>{3} at {4} {5}</b>';
  context.resources.IDS_MSG_SECOND_LOOK_SPREAD_AND_ORDER_CONFIRM = '<b>{0} {1} {2} at {3} {4}</b><br>- vs -<br><b>{5} {6} {7} at {8} {9}</b>';
  context.resources.IDS_MSG_SECOND_LOOK_LE_CONFIRM = '<b>A trader within your firm has already placed a {0} order on this instrument.<br><br><strong>Do you want to <span>{1}</span> {2} {3} at {4} {5}?</strong></b>';
  context.resources.IDS_MSG_SECOND_LOOK_CONFIRM_PICKGIVE = '<b><span>{0}</span> {1} {2} {3} @ {4} {5}</b>';
  context.resources.IDS_MSG_SECOND_LOOK_LE_CONFIRM_PICKGIVE = '<b>A trader within your firm has already placed a {0} order on this instrument.<br><br><strong>Do you want to <span>{1}</span> {2} {3} {4} @ {5} {6}?</strong></b>';
  context.resources.IDS_MSG_PRINT_CONFIRMS_PROMPT = 'Print confirms for \'{0}\' trades?';
  context.resources.IDS_MSG_INVALID_VEGA = 'The instrument {0} cannot be used to create a spread instrument because the broker has not specified a vega for the instrument.';
  context.resources.IDS_MSG_INVALID_UNDERLYING_NOT_TRADING = 'The instrument {0} cannot be used to create a spread instrument because it is no longer trading in VM.';
  context.resources.IDS_MSG_INVALID_SPREAD_PAIR = 'The instruments {0} and {1} can\'t be used to form a spread instrument.';
  context.resources.IDS_MSG_INVALID_UNDERLYING = 'The instrument {0} can\'t be used to form a spread instrument.';
  context.resources.IDS_ACCOUNT_REQUIRED_PROMPT = 'You must select an button in the accounts bar before submitting an order';
  context.resources.IDS_MSG_PRICE_CHANGED = 'The price of the instrument has changed. Please resubmit your order if you wish to trade at the new price.';
  context.resources.IDS_INVALID_PRICE_FORMAT = 'The price is not in a valid format';
  context.resources.IDS_PROMPT_ORDERTYPE_TO_CANCEL = 'Please select which kind(s) of orders to cancel';
  context.resources.IDS_MSG_OVERLIMIT_WARNING = '<br><b>The <i>total</i> size of {0} would break your soft {1} size limit of {2} for this instrument.</b>';
  context.resources.IDS_MSG_INVALID_ENTRY_AND_REVERT = 'The value was invalid and has been reverted. The value must be within the range of 0-100.';
  context.resources.IDS_MAX_QUANTITY_MULTIPLIER = 'Controls the maximum size an order can <br> placed at without triggering a warning <br> message. The value is a multiple of the <br>instrument\'s default size, e.g., 10.';
  context.resources.IDS_MSG_WAITING_FOR_NEXT = 'Waiting for {0}...';
  context.resources.IDS_MSG_FIXED_HEIGHT_ORDERS_ROW_COUNT_INVALID_ENTRY_AND_REVERT = 'The value was invalid and has been reverted. The value must be within the range of 2-20.';
  context.resources.IDS_MSG_ORDER_ANIMATION_COUNT_INVALID_ENTRY_AND_REVERT = 'The value was invalid and has been reverted. The value must be within the range of 0-10.';
  context.resources.IDS_MSG_FIXED_HEIGHT_ORDERS_ROW_COUNT_TOOLTIP = 'The number of rows shown in the fixed height orders/trades area.';
  context.resources.IDS_MSG_ORDER_ANIMATION_DURATION_TOOLTIP = 'The number of seconds the flipping animation last on active orders in the matrix area.';
  context.resources.IDS_MSG_CLEAR_SPREADS_BAR = 'Changing the selection will clear the unsubmitted spread instrument in the spread builder bar. Continue?';
  context.resources.IDS_MSG_PICKUP_CANNOT_BE_NEGATIVE = 'Pick Up prices cannot be negative';
  context.resources.IDS_MSG_GIVEUP_CANNOT_BE_POSITIVE = 'Give Up prices cannot be positive';
  context.resources.IDS_MSG_CONFIRM_CANCEL = 'Are you sure you want to cancel the order ?';
  context.resources.IDS_MSG_PORTFOLIO_SELECT_TARGET = 'Click to Paste Orders';
  context.resources.IDS_MSG_PORTFOLIO_PASTE_TARGET = 'PASTE Orders';

  // images
  context.resources.srcImageMap = {
    CAD   : './assets/images/flags/cad.svg',
    USD   : './assets/images/flags/usd.svg',
    EGP   : './assets/images/flags/egp.svg',
    MENA  : './assets/images/flags/mena.svg',
    NGA   : './assets/images/flags/ngn.svg',
    AUD   : './assets/images/flags/aud.svg',
    CNH   : './assets/images/flags/cny.svg',
    JPY   : './assets/images/flags/jpy.svg',
    CZK   : './assets/images/flags/czk.svg',
    EUR   : './assets/images/flags/eur.svg',
    FRA   : './assets/images/flags/fr.svg',
    GBP   : './assets/images/flags/gbp.svg',
    GGB   : './assets/images/flags/grc.svg',
    GILTS : './assets/images/flags/gbp.svg',
    HUF   : './assets/images/flags/hun.svg',
    PGB   : './assets/images/flags/prt.svg',
    PLN   : './assets/images/flags/pol.svg',
    RON   : './assets/images/flags/rom.svg',
    TRY   : './assets/images/flags/tur.svg',
    BRL   : './assets/images/flags/brl.svg',
    PEN   : './assets/images/flags/pen.svg',
    COP   : './assets/images/flags/cop.svg',
    CLP   : './assets/images/flags/clp.svg',
    NZD   : './assets/images/flags/nzd.svg',
    ZAR   : './assets/images/flags/zar.svg',
    IRL   : './assets/images/flags/irl.svg',
    FIN   : './assets/images/flags/fin.svg'
  };

  // eslint-disable-next-line complexity
  context.resources.getAdjustedNomenclature = function (stringId, nomenclature) {
    let adjustedStringId = stringId;
    const enumValue = BGC.enums.ENomenclature[nomenclature];

    switch (enumValue) {
      case BGC.enums.ENomenclature.payRec:
        switch (stringId) {
          case 'IDS_BUY':
            adjustedStringId = 'IDS_PAY';
            break;
          case 'IDS_BUY_SIZE':
            adjustedStringId = 'IDS_PAY_QTY';
            break;
          case 'IDS_BUY_SIZE_PLACEHOLDER':
            adjustedStringId = 'IDS_PAY_QTY_PLACEHOLDER';
            break;
          case 'IDS_BOUGHT':
            adjustedStringId = 'IDS_PAID';
            break;
          case 'IDS_SELL':
            adjustedStringId = 'IDS_RECEIVE';
            break;
          case 'IDS_SELL_SIZE':
            adjustedStringId = 'IDS_RECEIVE_QTY';
            break;
          case 'IDS_SELL_SIZE_PLACEHOLDER':
            adjustedStringId = 'IDS_RECEIVE_QTY_PLACEHOLDER';
            break;
          case 'IDS_SOLD':
            adjustedStringId = 'IDS_RECEIVED';
            break;
          case 'IDS_OEB_SELL_PLACEHOLDER':
            adjustedStringId = 'IDS_OEB_ASK_PLACEHOLDER';
            break;
          default:
            break;
        }
        break;
      case BGC.enums.ENomenclature.paidGiven:
        switch (stringId) {
          case 'IDS_BOUGHT':
            adjustedStringId = 'IDS_PAID';
            break;
          case 'IDS_SOLD':
            adjustedStringId = 'IDS_GIVEN';
            break;
          default:
            break;
        }
        break;
      case BGC.enums.ENomenclature.traded:
        switch (stringId) {
          case 'IDS_BOUGHT':
            adjustedStringId = 'IDS_LHS_TRADED_STC';
            break;
          case 'IDS_SOLD':
            adjustedStringId = 'IDS_RHS_TRADED_STC';
            break;
          default:
            break;
        }
        break;
      default:
        break;
    }

    return context.resources[adjustedStringId];
  };

  window.resources = context.resources;
}(window.BGC));
