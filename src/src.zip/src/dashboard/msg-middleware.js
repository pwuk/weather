/* eslint-disable import/no-cycle, max-statements */
import {logger} from '@core-tech/web-api';
import {getUserSettingsStore} from '@core-tech/web-api/user-settings';
import {tradesEmitter} from './store/trades';
import {MutationTypes as TradesMutations} from './store/trades/mutations';
import {MutationTypes as DashBoardMutations} from './store/dashboard/mutations';
import getStore from './store';
import getApp from './index';
import {getSupportedThemes} from './utils';

const MILLIS_IN_SEC = 1000;

const autoCloseChildOnAuctionEnd = appId => {
  const autoCloseInterval = getUserSettingsStore().get('autoCloseOnAuctionEndInterval');

  logger.info(`[processAuctionMsg] Auto-closing child ${appId} page in ${autoCloseInterval}s`);

  setTimeout(() => {
    // If auto-close is configured and there are no running auctions for this application, close the child popup window.
    if (getStore().getters['dashboard/appRunningAuctionCount'](appId) === 0) {
      getApp().closeChildPage({
        id : appId,
        hide : true
      });
    } else {
      logger.info(`[processAuctionMsg] Auto-close ${appId} page aborted - auction is running.`);
    }
  }, autoCloseInterval * MILLIS_IN_SEC);
};

const normalizeAuction = auction => ({
  auctionId   : auction.auctionId,
  auctionName : auction.auctionName,
  linkName    : auction.appId,
  isRunning   : true,

  /* We need to calculate the timeOffset to account for any system time differences between server and local PC */
  timeOffset : Math.floor(Date.now() / MILLIS_IN_SEC - auction.nowTime) * MILLIS_IN_SEC,
  startTime  : auction.startTime * MILLIS_IN_SEC,
  endTime    : auction.endTime * MILLIS_IN_SEC
});

function displayStatus (statusMsg) {
  const store = getStore();
  const {context = 'dashboard', statusText = ''} = statusMsg;

  store.dispatch('dashboard/updateStatus', {
    context,
    statusText,
    displaySplash : true
  });
}

function processAuctionMsg (message) {
  const store = getStore();
  const userSettings = getUserSettingsStore();
  const {appId, auctionId, event} = message;

  logger.info(`[msg-middleware] Processing Auction-${event} '${auctionId}' message for '${appId}' page.`);

  const childPage = store.getters['dashboard/pageList'].find(page => page.linkName === appId);

  if (childPage) {
    const app = getApp();

    // If this is a new auction notification
    if (event === 'start' && !store.getters['dashboard/isAuctionRunning'](auctionId)) {
      const {desk, currencyId, brandId} = childPage;

      // Update the Vue Store
      store.commit(`dashboard/${DashBoardMutations.SET_AUCTION}`, normalizeAuction(message));

      if (!app.isEmbedded && (!app.isChildWindowOpen(appId) || getStore().getters['dashboard/appRunningAuctionCount'](appId) === 1)) {
        // If this is a native browser, open the child page when the auction starts
        const childProperties = {
          id : appId,
          desk,
          brandId
        };

        app.openChildPage(childProperties);

        // Trigger 'Auction Started' (toaster) notification
        app.mainWindow.showNotification(`Running: ${message.auctionName}`, {
          id        : appId,
          title     : 'Auction Started',
          themeId   : getSupportedThemes()[getUserSettingsStore().get('themeSelected')],
          duration  : 5000,
          icon      : `assets/images/flags/${currencyId.toString().toLowerCase()}.svg`,
          flashIcon : 'assets/images/gavel.png',
          onclick   : () => app.openChildPage(childProperties, true)
        });
      }
    } else if (event === 'end') {
      store.commit(`dashboard/${DashBoardMutations.UPDATE_AUCTION}`, message);

      // If auto-close is configured and there are no running auctions for this application, close the child popup window.
      if (userSettings.get('autoClosePopupOnAuctionEnd')) {
        autoCloseChildOnAuctionEnd(appId);
      }
    } else {
      store.commit(`dashboard/${DashBoardMutations.UPDATE_AUCTION}`, message);
    }
  } else {
    logger.warn(`[msg-middleware->processAuctionMsg] Ignoring 'Auction-${event}' message - unknown child application: ${appId}`);
  }
}

// This will process all the messages from backend that the dashboard cares for
// and will update the dashboard vuex store for the components to pick up the changes
const dashboardMsgProcessor = message => {
  try {
    const {UPDATE_TRADE_CONFIRMS} = TradesMutations;
    const jsonMessageData = typeof message === 'string' ? JSON.parse(message) : message;

    for (let counter = 0; counter < jsonMessageData.messages.length; counter += 1) {
      const parsedMessage = jsonMessageData.messages[counter];

      switch (parsedMessage.messageName) {
        case 'auction':
          processAuctionMsg(parsedMessage);
          break;
        case 'TransportStatus':
          displayStatus(parsedMessage);
          break;
        case 'tradeCaptureReport':
          tradesEmitter.emit(UPDATE_TRADE_CONFIRMS, parsedMessage);
          break;
        default:
      }
    }
  } catch (err) {
    logger.error(`[dashboardMsgProcessor] Error parsing message: ${err}`);
  }
};

export {
  dashboardMsgProcessor,
  displayStatus
};
