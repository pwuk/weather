export default {
  currentUser (state) {
    return state.user;
  },
  username (state, {currentUser}) {
    return currentUser ? currentUser.username : '';
  },
  name (state, {currentUser}) {
    return currentUser ? currentUser.name : '';
  },
  login (state, {currentUser}) {
    return currentUser ? currentUser.login : '';
  },
  displaySplash (state) {
    return state.status.displaySplash;
  },
  statusText (state) {
    return state.status.statusText;
  },
  pageList (state) {
    return state.pageList;
  },
  displayAnalytics (state) {
    return state.displayAnalytics;
  },
  genericColumns (state) {
    return state.genericColumns;
  },
  brandId (state) {
    return state.brandId;
  },

  isAuctionRunning : state => auctionId => state.auctionList.find(auction => auction.auctionId === auctionId && auction.isRunning),

  appRunningAuctionCount : state => appId => state.auctionList.filter(auction => auction.linkName === appId && auction.isRunning).length,

  /* Return only the running auctions where linkName match*/
  auctionList : state => linkName => state.auctionList.filter(auction => auction.linkName === linkName && auction.isRunning)
};
