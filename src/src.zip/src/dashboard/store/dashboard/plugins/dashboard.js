import _ from 'lodash';
import {MutationTypes} from '../mutations';
import {setFavIcon} from '../../../utils';

const {
  SET_PAGE_LIST, UPDATE_PAGE_LIST, SET_USER, SET_ANALYTICS, SET_GENERIC_COLUMNS, SET_BRANDID
} = MutationTypes;

export default function (plugin) {
  return store => {
    plugin.addListener(SET_PAGE_LIST, payload => {
      store.commit(`${plugin.namespace}/${SET_PAGE_LIST}`, payload);
    });
    plugin.addListener(UPDATE_PAGE_LIST, payload => {
      store.commit(`${plugin.namespace}/${UPDATE_PAGE_LIST}`, payload);
    });
    plugin.addListener(SET_USER, payload => {
      store.commit(`${plugin.namespace}/${SET_USER}`, payload);
    });
    plugin.addListener(SET_ANALYTICS, payload => {
      store.commit(`${plugin.namespace}/${SET_ANALYTICS}`, payload);
    });
    plugin.addListener(SET_GENERIC_COLUMNS, payload => {
      store.commit(`${plugin.namespace}/${SET_GENERIC_COLUMNS}`, payload);
    });
    plugin.addListener(SET_BRANDID, () => {
      const pageList = store.getters['dashboard/pageList'];
      const brandIdList = _.uniqBy(pageList, 'brandId');
      const brandId = brandIdList.length > 1 ? 'GBX' : brandIdList[0].brandId;

      setFavIcon(brandId);

      store.commit(`${plugin.namespace}/${SET_BRANDID}`, brandId);
    });
  };
}
