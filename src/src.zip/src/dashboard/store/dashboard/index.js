import actions from './actions';
import getters from './getters';
import mutations from './mutations';
import createDashboardPlugin from './plugins/dashboard';
import StoreEventEmitter from '../StoreEventEmitter';

const dashboardEmitter = new StoreEventEmitter('dashboard');
const dashboardListenerPlugin = createDashboardPlugin(dashboardEmitter);

export default {
  namespaced : true,
  actions,
  getters,
  mutations,
  state () {
    return {
      user   : null,
      status : {
        context       : 'Dashboard',
        statusText    : 'Application Loading ...',
        displaySplash : true
      },
      pageList         : null,
      displayAnalytics : true,
      auctionList      : [],
      genericColumns   : [],
      brandId          : 'BGCIRO'
    };
  }
};

export {dashboardEmitter, dashboardListenerPlugin};
