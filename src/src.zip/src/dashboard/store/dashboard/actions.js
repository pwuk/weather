import {MutationTypes} from './mutations';

const {
  SET_USER, SET_PAGE_LIST, UPDATE_PAGE_LIST, SET_AUCTION, SET_ANALYTICS, SET_GENERIC_COLUMNS, UPDATE_STATUS, SET_BRANDID
} = MutationTypes;

export default {
  updateStatus (context, payload) {
    context.commit(UPDATE_STATUS, {
      ...payload
    });
  },
  setUser (context, payload) {
    context.commit(SET_USER, {
      ...payload
    });
  },
  setPageList (context, payload) {
    context.commit(SET_PAGE_LIST, {
      ...payload
    });
  },
  updatePageList (context, payload) {
    context.commit(UPDATE_PAGE_LIST, {
      ...payload
    });
  },
  setAuction (context, payload) {
    context.commit(SET_AUCTION, {
      ...payload
    });
  },
  setAnalytics (context, payload) {
    context.commit(SET_ANALYTICS, {
      ...payload
    });
  },
  setGenericColumns (context, payload) {
    context.commit(SET_GENERIC_COLUMNS, {
      ...payload
    });
  },
  setBrandId (context, payload) {
    context.commit(SET_BRANDID, {
      ...payload
    });
  }
};
