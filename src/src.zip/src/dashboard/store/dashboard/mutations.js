const PACKAGE = 'DASHBOARD';
const MILLIS_IN_SEC = 1000;

export const MutationTypes = {
  UPDATE_STATUS       : `${PACKAGE}/UPDATE_STATUS`,
  SET_USER            : `${PACKAGE}/SET_USER`,
  SET_PAGE_LIST       : `${PACKAGE}/SET_PAGE_LIST`,
  UPDATE_PAGE_LIST    : `${PACKAGE}/UPDATE_PAGE_LIST`,
  SET_AUCTION         : `${PACKAGE}/SET_AUCTION`,
  UPDATE_AUCTION      : `${PACKAGE}/UPDATE_AUCTION`,
  SET_ANALYTICS       : `${PACKAGE}/SET_ANALYTICS`,
  SET_GENERIC_COLUMNS : `${PACKAGE}/SET_GENERIC_COLUMNS`,
  SET_BRANDID         : `${PACKAGE}/SET_BRANDID`
};

export default {
  [MutationTypes.UPDATE_STATUS] (state, payload) {
    const {status = {}} = state;

    state.status = {
      ...status,
      ...payload
    };
  },
  [MutationTypes.SET_USER] (state, payload) {
    state.user = payload;
  },

  /* Expected payload is a snapshot of the User Entitlements*/
  [MutationTypes.SET_PAGE_LIST] (state, payload) {
    state.pageList = payload;
  },

  /* Expected payload is a delta of the User Entitlements,
   a snapshot of the entitlements set via SET_PAGE_LIST is expected to be received first*/
  [MutationTypes.UPDATE_PAGE_LIST] (state, payload) {
    if (payload.add) {
      state.pageList = state.pageList.concat(payload.add.applications);
    } else if (payload.remove) {
      state.pageList = state.pageList.filter(el => !payload.remove.applications.some(toRemove => toRemove.linkName === el.linkName));
    }
  },
  [MutationTypes.SET_AUCTION] (state, payload) {
    state.auctionList.push(payload);
  },
  [MutationTypes.UPDATE_AUCTION] (state, payload) {
    const updatedAuctions = state.auctionList.map(auction => {
      /* If its an auction update message then only update the endTime */
      if (auction.auctionId === payload.auctionId && payload.event === 'update') {
        return {...auction, endTime : payload.endTime * MILLIS_IN_SEC};
      }

      /* If its an auction end message then mark isRunning to false */
      if (auction.auctionId === payload.auctionId && payload.event === 'end') {
        return {...auction, isRunning : false};
      }

      return auction;
    });

    state.auctionList = updatedAuctions.slice();
  },
  [MutationTypes.SET_ANALYTICS] (state, payload) {
    state.displayAnalytics = payload;
  },
  [MutationTypes.SET_GENERIC_COLUMNS] (state, payload) {
    state.genericColumns = payload;
  },
  [MutationTypes.SET_BRANDID] (state, payload) {
    state.brandId = payload;
  }
};
