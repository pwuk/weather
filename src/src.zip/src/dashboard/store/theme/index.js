import actions from './actions';
import getters from './getters';
import mutations from './mutations';
import createThemePlugin from './plugins/theme';
import StoreEventEmitter from '../StoreEventEmitter';

const themeEmitter = new StoreEventEmitter('theme');
const themeListenerPlugin = createThemePlugin(themeEmitter);

export default {
  namespaced : true,
  state () {
    return {current : null};
  },
  actions,
  getters,
  mutations
};

export {themeEmitter, themeListenerPlugin};
