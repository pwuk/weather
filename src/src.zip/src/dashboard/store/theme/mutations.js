const PACKAGE = 'THEME';

export const MutationTypes = {
  SET_THEME : `${PACKAGE}/SET_THEME`
};

export default {
  [MutationTypes.SET_THEME] (state, payload) {
    state.current = payload;
  }
};
