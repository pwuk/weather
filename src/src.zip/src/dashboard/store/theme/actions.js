import {MutationTypes} from './mutations';

const {SET_THEME} = MutationTypes;

export default {
  setTheme (context, payload) {
    context.commit(SET_THEME, payload);
  }
};
