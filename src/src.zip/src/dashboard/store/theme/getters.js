export default {
  currentTheme (state) {
    return state.current;
  }
};
