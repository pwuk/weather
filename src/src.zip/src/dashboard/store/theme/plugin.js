import {MutationTypes} from './mutations';

const {SET_THEME} = MutationTypes;

export default store => ({
  setTheme : theme => {
    store.commit(`theme/${SET_THEME}`, theme);
  }
});
