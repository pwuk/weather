import {MutationTypes} from '../mutations';

const {SET_THEME} = MutationTypes;

const htmlElement = document.querySelector('html');

export default function (plugin) {
  return store => {
    plugin.addListener(SET_THEME, payload => {
      htmlElement.className = `volumematch-${payload}`;

      store.commit(`${plugin.namespace}/${SET_THEME}`, payload);
    });
  };
}
