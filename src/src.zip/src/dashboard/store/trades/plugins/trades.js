// import {DateTime} from 'luxon';
import {MutationTypes} from '../mutations';

const {UPDATE_TRADE_CONFIRMS, UPDATE_GROUP_TRADE_CONFIRMS} = MutationTypes;
const MILLIS_IN_SEC = 1000;
const OWN_TRADE = 'own';

const getNormalizedTradeTimeDisplay = (tradeTime, tradeTimeDisplay) => {
  const tradeDate = new Date(tradeTime * MILLIS_IN_SEC);
  const timeDisplay = tradeTimeDisplay || tradeDate.toTimeString().split(' ')[0];

  return `${timeDisplay} ${tradeDate.getDate()}/${tradeDate.getMonth() + 1}`;
};

const normalizeTradeConfirms = report => ({
  counterparty        : report.match.counterparty,
  instrumentName      : report.instrumentName,
  millis              : report.match.tradeTime * MILLIS_IN_SEC,
  price               : report.match.price.number,
  priceDisplay        : report.match.price.string,
  size                : report.match.size,
  strike1Display      : report.match.strike1Display || '',
  strike2Display      : report.match.strike2Display || '',
  time                : getNormalizedTradeTimeDisplay(report.match.tradeTime, report.match.tradeTimeDisplay),
  tradeId             : report.match.id,
  type                : report.match.side,
  accountId           : report.accountId,
  accountName         : report.accountName,
  venue               : report.match.venue,
  matchId             : report.match.matchId,
  structureGroupingId : report.match.structureGroupingId,
  tradeLegId          : report.tradeLegId,
  key                 : `${report.match.id}_${report.match.matchId}_${report.match.tradeTime}_${report.tradeLegId}`
});

export default function (plugin) {
  return store => {
    plugin.addListener(UPDATE_TRADE_CONFIRMS, payload => {
      const {tradeConfirms = []} = store.state.trades;

      // Dashboard should show just own trades
      if (payload.match.type === OWN_TRADE && !tradeConfirms.find(trade => trade.tradeId === payload.match.id)) {
        const newTradeConfirm = normalizeTradeConfirms(payload);

        store.commit(`${plugin.namespace}/${UPDATE_TRADE_CONFIRMS}`, newTradeConfirm);
      }
    });
    plugin.addListener(UPDATE_GROUP_TRADE_CONFIRMS, payload => {
      store.commit(`${plugin.namespace}/${UPDATE_GROUP_TRADE_CONFIRMS}`, payload);
    });
  };
}
