/* eslint-disable no-param-reassign */
const PACKAGE = 'TRADES';

export const MutationTypes = {
  UPDATE_TRADE_CONFIRMS       : `${PACKAGE}/UPDATE_TRADE_CONFIRMS`,
  UPDATE_GROUP_TRADE_CONFIRMS : `${PACKAGE}/UPDATE_GROUP_TRADE_CONFIRMS`
};


function groupTradeConfirms (originalTradeConfirms) {
  const tradeConfirms = originalTradeConfirms;
  const parentTrades = new Map();

  tradeConfirms.sort(tradeSorter);

  const structuredTradeConfirms = tradeConfirms.filter(trade => trade.structureGroupingId);

  structuredTradeConfirms.forEach(trade => {
    const groupKey = trade.structureGroupingId;

    if (parentTrades.has(groupKey)) {
      trade.isChild = true;
      parentTrades.get(groupKey).children.push(trade);
    } else {
      trade.children = [];
      parentTrades.set(groupKey, trade);
    }
  });

  const nonStructuredTradeConfirms = tradeConfirms.filter(trade => !trade.structureGroupingId);

  return [...parentTrades.values(), ...nonStructuredTradeConfirms];
}

function tradeSorter (trade1, trade2) {
  let compare = 0;

  if (trade1.millis < trade2.millis) {
    compare = 1;
  } else if (trade1.millis > trade2.millis) {
    compare = -1;
  } else if (trade1.matchId < trade2.matchId) {
    compare = 1;
  } else if (trade1.matchId > trade2.matchId) {
    compare = -1;
  } else if (trade1.tradeLegId < trade2.tradeLegId) {
    compare = -1;
  } else if (trade1.tradeLegId > trade2.tradeLegId) {
    compare = 1;
  }

  return compare;
}

export default {
  [MutationTypes.UPDATE_TRADE_CONFIRMS] (state, payload) {
    state.tradeConfirms.push(payload);
  },
  [MutationTypes.UPDATE_GROUP_TRADE_CONFIRMS] (state) {
    state.groupedTradeConfirms = groupTradeConfirms(state.tradeConfirms);
  }
};
