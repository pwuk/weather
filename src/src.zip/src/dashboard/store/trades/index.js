import getters from './getters';
import mutations from './mutations';
import createTradesPlugin from './plugins/trades';
import StoreEventEmitter from '../StoreEventEmitter';

const tradesEmitter = new StoreEventEmitter('trades');
const tradesListenerPlugin = createTradesPlugin(tradesEmitter);

export default {
  namespaced : true,
  getters,
  mutations,
  state () {
    return {tradeConfirms: [], groupedTradeConfirms: []};
  }
};

export {tradesEmitter, tradesListenerPlugin};
