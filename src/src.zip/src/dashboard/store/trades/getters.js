export default {
  tradeConfirms (state) {
    return state.tradeConfirms;
  },
  groupedTradeConfirms (state) {
    return state.groupedTradeConfirms;
  }
};
