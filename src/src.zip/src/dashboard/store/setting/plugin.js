import {MutationTypes} from './mutations';

const {SET_SETTING} = MutationTypes;

export default store => ({
  setSetting : theme => {
    store.commit(`setting/${SET_SETTING}`, theme);
  }
});
