export default {
  getValue(state) {
    return (settingName) => {
      return state[settingName];
    }
  }
};
