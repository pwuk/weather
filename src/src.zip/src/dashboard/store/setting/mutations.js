const PACKAGE = 'SETTING';

export const MutationTypes = {
  SET_SETTING : `${PACKAGE}/SET_SETTING`
};

export default {
  [MutationTypes.SET_SETTING] (state, payload) {
    var settingName = payload.name;
    state[settingName] = payload.value;
  }
};
