import {MutationTypes} from './mutations';

const {SET_SETTING} = MutationTypes;

export default {
  setSetting (context, payload) {
    context.commit(SET_SETTING, {
      ...payload
    });
  }
};
