import {MutationTypes} from '../mutations';

const {SET_SETTING} = MutationTypes;

export default function (plugin) {
  return store => {
    plugin.addListener(SET_SETTING, payload => {
      store.commit(`${plugin.namespace}/${SET_SETTING}`, payload);
    });
  };
}
