import actions from './actions';
import getters from './getters';
import mutations from './mutations';
import createSettingPlugin from './plugins/setting';
import StoreEventEmitter from '../StoreEventEmitter';

const settingEmitter = new StoreEventEmitter('setting');
const settingListenerPlugin = createSettingPlugin(settingEmitter);

export default {
  namespaced : true,
  actions,
  getters,
  mutations,
  state () {
    return {
      restoreWindowOnOwnTrade     : false,
      playSoundWhenVMLaunch       : false,
      playSoundWhenAnyOrderTrades : false,
      loglevels                   : {KEY : 'KEY', INF : 'INF'},
      playSoundWhenMyOrderTrades  : false
    };
  }
};

export {settingEmitter, settingListenerPlugin};
