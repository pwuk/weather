const PACKAGE = 'ANALYTICS';

export const AnalyticsMutationTypes = {
  GET_ANALYTICS_DATA       : `${PACKAGE}/GET_ANALYTICS_DATA`,
  GET_PRODUCTS_OF_CURRENCY : `${PACKAGE}/GET_PRODUCTS_OF_CURRENCY`,
  SET_CURRENCY             : `${PACKAGE}/SET_CURRENCY`,
  SET_PRODUCT              : `${PACKAGE}/SET_PRODUCT`
};

export default {
  [AnalyticsMutationTypes.GET_ANALYTICS_DATA] (state, response) {
    if (response.length > 0) {
      state.jsonResponse = response;
    }
  },
  [AnalyticsMutationTypes.GET_PRODUCTS_OF_CURRENCY] (state, ccy) {
    state.products = [...new Set(state.jsonResponse.filter(data => data.currency.match(ccy)).map(grid => grid.name))];
    [state.product] = state.products;
  },
  [AnalyticsMutationTypes.SET_CURRENCY] (state, ccy) {
    state.currency = ccy;
  },
  [AnalyticsMutationTypes.SET_PRODUCT] (state, product) {
    state.product = product;
  }
};
