import axios from 'axios';
import {logger} from '@core-tech/web-api';

export function getJsondata (url) {
  return axios.get(url, {
    dataType : 'json',
    headers  : {
      Accept         : 'application/json',
      'Content-Type' : 'application/json'
    },
    mode        : 'no-cors',
    credentials : 'include'
  }).then(response => response.data).catch(error => {
    logger.warn(`[analytics-data-service] Error requesting analytics data: ${error}`);

    return [];
  });
}

// This function shapes analytics product data in to hierarachy defined by gridType
export function getHierarchialAnalyticsData (jsonData, currency) {
  const productTree = {};

  // First lets filter by currency
  const dataForCurrency = jsonData.filter(data => data.currency.match(currency));

  // Now groupby gridType
  dataForCurrency.forEach(grid => {
    if (!(grid.gridType in productTree)) {
      productTree[grid.gridType] = [];
    }
    productTree[grid.gridType].push(grid.name);
  });

  return productTree;
}
