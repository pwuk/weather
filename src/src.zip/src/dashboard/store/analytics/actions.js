import {AnalyticsMutationTypes} from './mutations';
import {getJsondata} from './analytics-data-service';


const {
  GET_ANALYTICS_DATA,
  GET_PRODUCTS_OF_CURRENCY,
  SET_CURRENCY,
  SET_PRODUCT
} = AnalyticsMutationTypes;

export default {
  async getAnalyticsData (context, url) {
    context.commit(GET_ANALYTICS_DATA, await await getJsondata(url));
  },
  getProductsOfCurrency (context, ccy) {
    context.commit(GET_PRODUCTS_OF_CURRENCY, ccy);
  },
  setCurrency (context, ccy) {
    context.commit(SET_CURRENCY, ccy);
  },
  setProduct (context, product) {
    context.commit(SET_PRODUCT, product);
  }
};
