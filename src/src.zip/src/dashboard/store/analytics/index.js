import actions from './actions';
import getters from './getters';
import mutations from './mutations';

export default {
  namespaced : true,
  state () {
    return {
      jsonResponse : [],
      currency     : null,
      product      : null,
      products     : []
    };
  },
  actions,
  getters,
  mutations
};
