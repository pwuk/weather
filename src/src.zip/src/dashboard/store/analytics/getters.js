import {ConfigAnalytics} from '../../components/analytics/config';

export default {
  jsonResponse (state) {
    return state.jsonResponse && state.jsonResponse !== null ? state.jsonResponse : [];
  },
  products (state) {
    return state.products && state.products !== null ? state.products : [];
  },
  currency (state) {
    return state.currency ? state.currency : ConfigAnalytics.CURRENCY.EUR.toString();
  },
  product (state) {
    return state.product ? state.product : '';
  }
};
