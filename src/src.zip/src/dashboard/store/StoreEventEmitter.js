/* eslint-disable no-underscore-dangle */

class StoreEventEmitter {
  constructor (namespace) {
    this.namespace = namespace;
    this._observers = new Map();
  }

  emit (type, payload) {
    const listeners = this._observers.get(type);

    if (listeners) {
      listeners.forEach(listener => {
        setImmediate(() => {
          listener(payload);
        });
      });
    }
  }

  addListener (type, listener) {
    if (!this._observers.get(type)) {
      this._observers.set(type, new Set());
    }

    this._observers.get(type).add(listener);
  }

  removeListener (type, listener) {
    this._observers.get(type).delete(listener);
  }
}

export default StoreEventEmitter;
