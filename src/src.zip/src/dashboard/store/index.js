import Vue from 'vue';
import Vuex from 'vuex';
import theme, {themeListenerPlugin} from './theme';
import setting, {settingListenerPlugin} from './setting';
import trades, {tradesListenerPlugin} from './trades';
import dashboard, {dashboardListenerPlugin} from './dashboard';
import analytics from './analytics';

Vue.use(Vuex);

const store = new Vuex.Store({
  strict  : process.env.NODE_ENV !== 'production',
  modules : {
    dashboard, theme, trades, analytics, setting
  },
  plugins : [
    dashboardListenerPlugin,
    tradesListenerPlugin,
    themeListenerPlugin,
    settingListenerPlugin
  ]
});


export default () => store;
