import {logger} from '@core-tech/web-api';
import {restoreSettings, getUserSettingsStore} from '@core-tech/web-api/user-settings';
import {dashboardEmitter} from './store/dashboard';
import getStore from './store';
import {ConfigAnalytics} from './components/analytics/config';
import {MutationTypes as DashBoardMutations} from './store/dashboard/mutations';
import {MutationTypes as ThemeMutations} from './store/theme/mutations';
import {themeEmitter} from './store/theme';

function closeSplash () {
  const {UPDATE_STATUS} = DashBoardMutations;

  getStore().commit(`dashboard/${UPDATE_STATUS}`, {
    context       : '',
    statusText    : '',
    displaySplash : false
  });
}

function setLogin (userLogin) {
  const {SET_USER} = DashBoardMutations;
  const {
    name,
    login,
    role,
    username
  } = userLogin;

  logger.info(`[dashboard] Setting primary user login: ${username}|${login}`);

  dashboardEmitter.emit(SET_USER, {
    name,
    login,
    role,
    username
  });
}

// eslint-disable-next-line max-statements
function renderDashboard (app) {
  const userSettings = getUserSettingsStore();
  const {pageList = [], settings = {}, genericColumns = []} = app.layout;
  const {
    SET_PAGE_LIST, SET_ANALYTICS, SET_GENERIC_COLUMNS, SET_BRANDID
  } = DashBoardMutations;

  logger.info(`[Dashboard] Building dashboard, rendering  ${pageList.length} tiles`);

  dashboardEmitter.emit(SET_PAGE_LIST, pageList);
  dashboardEmitter.emit(SET_BRANDID);
  dashboardEmitter.emit(SET_ANALYTICS, settings.displayAnalytics || false);
  dashboardEmitter.emit(SET_GENERIC_COLUMNS, genericColumns || []);

  if (settings.displayAnalytics) {
    getStore().dispatch('analytics/getAnalyticsData', ConfigAnalytics.DATAGRIDS_URL);
  }

  if (Reflect.has(settings, 'autoClosePopupOnAuctionEnd')) {
    userSettings.set('autoClosePopupOnAuctionEnd', settings.autoClosePopupOnAuctionEnd);
  } else {
    userSettings.set('autoClosePopupOnAuctionEnd', false);
  }

  if (Reflect.has(settings, 'autoCloseOnAuctionEndInterval')) {
    userSettings.set('autoCloseOnAuctionEndInterval', settings.autoCloseOnAuctionEndInterval);
  } else {
    userSettings.set('autoCloseOnAuctionEndInterval', -1);
  }
}

async function initDashboard (app) {
  try {
    const {SET_THEME} = ThemeMutations;
    const {tradingSession, userSettings, layout} = app;

    // Restore the user settings store
    restoreSettings(userSettings, {
      path   : app.path,
      userId : app.userId
    });

    // Set previously persisted theme
    themeEmitter.emit(SET_THEME, `theme${Number(getUserSettingsStore().get('themeSelected')) + 1}`);

    // Set primary login details
    setLogin(tradingSession.login);

    // Render dashboard layout
    renderDashboard(app);

    // Open all child application page windows and subscribe to the page securities
     for (const page of layout.pageList) {
      await app.subscribe({
        context : page.linkName,
        pageKey : page.subscriptionKey
      });

      app.subscribeToTrades({
        context : page.linkName
      });

      if (app.isEmbedded) {
        const {linkName : id, desk, brandId} = page;

        app.openChildPage({id, desk, brandId});
      }
    };

    // Close the splash screen
    closeSplash();
  } catch (err) {
    logger.error(`[initDashboard] Error initializing 'Dashboard' view: ${err}`);
  }
}

export default initDashboard;
