const getSupportedThemes = () => ({
  2 : 'Pearl',
  3 : 'Charcoal',
  4 : 'Onyx'
});

const setFavIcon = brandId => {
  const favIconLinkElement = document.querySelector('link[rel="shortcut icon"]');

  if (favIconLinkElement) {
    const logoMap = {
      BGC       : 'bgc-favicon.ico',
      BGCIRO    : 'bgc-favicon.ico',
      GFI       : 'gfi.ico',
      GBX       : 'bgc-favicon.ico',
      'GFI-FXO' : 'gfi.ico'
    };

    favIconLinkElement.setAttribute('href', `assets/images/${logoMap[brandId]}`);
  }
};

export {getSupportedThemes, setFavIcon};
