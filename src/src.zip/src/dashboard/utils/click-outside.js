export default {
  bind (el, binding) {
    el.ClickOutsideHandler = event => { // eslint-disable-line no-param-reassign
      // here I check that click was outside the el and its children
      if (!(el === event.target || el.contains(event.target))) {
        // and if it did, call method provided in attribute value
        binding.value(event);
      }
    };
    document.body.addEventListener('click', el.ClickOutsideHandler);
  },
  unbind (el) {
    document.body.removeEventListener('click', el.ClickOutsideHandler);
  }
};
