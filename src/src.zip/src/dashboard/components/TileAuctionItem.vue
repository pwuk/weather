<template>
  <div class="dashboard-tile__auction-item">
    <a-tooltip
      :mouse-leave-delay="0.2"
      :mouse-enter-delay="0.5"
      placement="right"
    >
      <template
        slot="title"
      >
        {{ auctionItem.auctionName }}
      </template>
      <div class="dashboard-tile__auction-item-name">
        {{ auctionItem.auctionName }}
      </div>
    </a-tooltip>
    <div class="dashboard-tile__auction-item-progress-bar">
      <progress-bar
        :start-time="auctionItem.startTime"
        :end-time="auctionItem.endTime"
        :time-offset="auctionItem.timeOffset"
        :show-tooltip="true"
        :tooltip-message="tooltipMessage"
      />
    </div>
  </div>
</template>

<script>
/* eslint-disable no-magic-numbers */
import progressBar from './ProgressBar.vue';

const resources = {
  AUCTION_TIME_REMAINING : 'Remaining auction time'
};

export default {
  name       : 'TileAuctionItem',
  components : {
    progressBar
  },
  props : {
    auctionItem : {
      required : true,
      type     : Object
    }
  },
  data () {
    return {
      tooltipMessage : resources.AUCTION_TIME_REMAINING
    };
  }
};
</script>

<style>
.dashboard-tile__auction-item{
  align-items: center;
  justify-content: space-between;
  font-size: 1.2rem;
  margin-bottom: 0.5rem;
}

.dashboard-tile__auction-item-name {
  margin-left: 0.5rem;
  margin-right: 0.5rem;
  align-items: left;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 85%;
}

.dashboard-tile__auction-item-progress-bar {
  margin-left: 0.5rem;
  margin-right: 0.5rem;
  margin-top: 0.2rem;
}
</style>
