<template>
  <div v-if="open">
    <slot />
  </div>
</template>

<script>

function copyStyles (sourceDoc, targetDoc) {
  Array.from(sourceDoc.styleSheets).forEach(styleSheet => {
    if (styleSheet.cssRules) {
      // for <style> elements
      const newStyleEl = sourceDoc.createElement('style');

      Array.from(styleSheet.cssRules).forEach(cssRule => {
        // write the text of each rule into the body of the style element
        newStyleEl.appendChild(sourceDoc.createTextNode(cssRule.cssText));
      });

      targetDoc.head.appendChild(newStyleEl);
    } else if (styleSheet.href) {
      // for <link> elements loading CSS from a URL
      const newLinkEl = sourceDoc.createElement('link');

      newLinkEl.rel = 'stylesheet';
      newLinkEl.href = styleSheet.href;
      targetDoc.head.appendChild(newLinkEl);
    }
  });
}

export default {
  model : {
    prop  : 'open',
    event : 'close'
  },
  props : {
    open : {
      type    : Boolean,
      default : false
    },
    name : {
      type    : String,
      default : null
    }
  },
  data () {
    return {
      windowRef : null
    };
  },
  watch : {
    open (newOpen) {
      if (newOpen) {
        this.openPortal();
      } else {
        this.closePortal();
      }
    }
  },
  mounted () {
    if (this.open) {
      this.openPortal();
    }
  },
  beforeDestroy () {
    if (this.windowRef) {
      this.closePortal();
    }
  },
  methods : {
    openPortal () {
      const title = `BGC Trader : ${this.name}`;
      // eslint-disable-next-line max-len
      const windowFeatures = 'directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=yes,width=830,height=530,left=200,top=200';

      this.windowRef = window.open('', title, windowFeatures);
      this.windowRef.document.title = title;
      this.windowRef.document.body.appendChild(this.$el);
      copyStyles(window.document, this.windowRef.document);
      this.windowRef.addEventListener('beforeunload', this.closePortal);
      this.windowRef.addEventListener('onunload', this.closePortal);
      this.windowRef.addEventListener('onbeforeunload', this.closePortal);
      this.windowRef.addEventListener('unload', this.closePortal);
      this.windowRef.addEventListener('close', this.closePortal);
    },
    closePortal () {
      if (this.windowRef) {
        this.windowRef.close();
        this.windowRef = null;
        this.$emit('close');
      }
    }
  }
};
</script>
