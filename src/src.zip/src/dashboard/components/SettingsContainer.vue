<template>
  <div>
    <setting-item
      type="switch"
      :desc="resources.IDS_RESTORE_WINDOW_ON_OWN_TRADE"
      :value="getValue('restoreWindowOnOwnTrade')"
      name="restoreWindowOnOwnTrade"
    />
    <setting-item
      type="switch"
      :desc="resources.IDS_PLAY_SOUND_ON_VM_LAUNCH"
      :value="getValue('playSoundWhenVMLaunch')"
      name="playSoundWhenVMLaunch"
    />
    <setting-item
      type="switch"
      :desc="resources.IDS_PLAY_SOUND_ON_TRADE"
      :value="getValue('playSoundWhenAnyOrderTrades')"
      name="playSoundWhenAnyOrderTrades"
    />
    <setting-item
      type="switch"
      :desc="resources.IDS_PLAY_SOUND_ON_MY_TRADE"
      :value="getValue('playSoundWhenMyOrderTrades')"
      name="playSoundWhenMyOrderTrades"
    />
    <setting-item
      type="select"
      :desc="resources.IDS_LOG_LEVEL"
      :values="getValue('loglevels')"
      :value="getCurrentValueFromSettings('loglevel')"
      name="loglevel"
    />
    <setting-item
      type="select"
      :desc="resources.IDS_THEMECHANGE"
      :values="getSupportedThemes()"
      name="themeSelected"
      :value="getCurrentValueFromSettings('themeSelected')"
    />
  </div>
</template>
<script>

import {mapGetters, mapActions} from 'vuex';
import {getUserSettingsStore} from '@core-tech/web-api/user-settings';
import SettingItem from './SettingItem.vue';

import {getSupportedThemes} from '../utils';

export default {
  name       : 'SettingContainer',
  components : {
    SettingItem
  },
  props : {
    links : {
      type     : Array,
      required : false,
      default  : undefined
    }
  },
  computed : {
    ...mapGetters('setting', ['getValue'])
  },
  data () {
    return {
      resources : {
        IDS_RESTORE_WINDOW_ON_OWN_TRADE : 'Popup window when my order trades',
        IDS_PLAY_SOUND_ON_VM_LAUNCH     : 'Play sound when session starts',
        IDS_PLAY_SOUND_ON_TRADE         : 'Play sound when instrument trades',
        IDS_PLAY_SOUND_ON_MY_TRADE      : 'Play sound when my order trades',
        IDS_LOG_LEVEL                   : 'Log level',
        IDS_THEMECHANGE                 : 'Theme'
      }
    };
  },
  mounted () {
    const userSettings = getUserSettingsStore();

    // Update settings
    this.updateSetting('playSoundWhenVMLaunch', userSettings.get('playSoundWhenVMLaunch'));
    this.updateSetting('restoreWindowOnOwnTrade', userSettings.get('restoreWindowOnOwnTrade'));
    this.updateSetting('playSoundWhenAnyOrderTrades', userSettings.get('playSoundWhenAnyOrderTrades'));
    this.updateSetting('playSoundWhenMyOrderTrades', userSettings.get('playSoundWhenMyOrderTrades'));

    // Set Theme
    this.updateSetting('themeSelected', userSettings.get('themeSelected'));
  },
  methods : {
    ...mapActions('setting', ['setSetting']),
    ...mapActions('theme', ['setTheme']),
    getCurrentValueFromSettings (value) {
      return getUserSettingsStore().get(value);
    },
    getSupportedThemes : () => getSupportedThemes(),
    updateSetting (name, value) {
      this.setSetting({
        name,
        value,
        id : 'volumeMatch'
      });
    },
    updateTheme (currentlySelectedTheme) {
      const themeId = Number(currentlySelectedTheme) + 1;

      this.setTheme(`theme${themeId}`);
    }
  }
};

</script>
