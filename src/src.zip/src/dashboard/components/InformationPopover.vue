<template>
    <a-popover
            placement="bottomRight"
            trigger="click"
    >
        <information-container slot="content" />
        <i class="fa fa-info-circle user-menu__settings" />
    </a-popover>
</template>

<script>
  import InformationContainer from './InformationContainer.vue';

  export default {
    name       : 'InformationPopover',
    components : {
      InformationContainer
    }
  };

</script>
