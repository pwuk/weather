<template>
  <a-popover
    placement="bottomRight"
    trigger="click"
  >
    <settings-container
      slot="content"
    />
    <i class="fa fa-cog user-menu__settings" />
  </a-popover>
</template>

<script>
import SettingsContainer from './SettingsContainer.vue';

export default {
  name       : 'SettingsPopover',
  components : {
    SettingsContainer
  }
};

</script>

<style>
.ant-popover {
  min-width: calc(100% / 4);
}

.ant-popover-inner-content {
    color: var(--dashboard-content-text) !important;
}

.ant-popover-inner {
  border: 3px solid var(--dashboard-content-header-background) !important;
  background-color: var(--dashboard-content-background) !important;
  color: var(--dashboard-content-text) !important;
}

.ant-popover-placement-bottom > .ant-popover-content > .ant-popover-arrow,
.ant-popover-placement-bottomLeft > .ant-popover-content > .ant-popover-arrow,
.ant-popover-placement-bottomRight > .ant-popover-content > .ant-popover-arrow {
  border-color: var(--dashboard-content-header-background) transparent transparent
  var(--dashboard-content-header-background)  !important;
}
</style>
