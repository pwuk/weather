<template>
  <div :class="statusGridClass">
    <table class="analytics-grid__table">
      <thead class="analytics-grid__header">
        <th class="analytics-grid__header_cell analytics-grid__header_cell_name" />
        <th
          v-for="col in analyticsData.ylabels"
          :key="col"
          class="analytics-grid__header_cell"
        >
          {{ col }}
        </th>
      </thead>
      <tbody>
        <tr
          v-for="(row, rowIndex) in analyticsData.xlabels"
          :key="row"
        >
          <td class="analytics-grid__row_cell analytics-grid__row_cell_first">
            {{ row }}
          </td>
          <td
            v-for="(rowdata, colKey, colIndex) in analyticsData.grids"
            :key="rowdata.key"
            :cell-background="getBackground(analyticsData.name, analyticsData.gridType, rowIndex, colIndex)"
            :cell-flash="getFlash(rowIndex, colIndex, Number(rowdata[row]))"
            class="analytics-grid__row_cell"
          >
            {{ rowdata[row] }}
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
const CELL_BACKGROUND = {
  DARK  : 'dark',
  LIGHT : 'light'
};

const CELL_FLASHING = {
  INCREASE : 'increase',
  DECREASE : 'decrease',
  NONE     : 'none'
};

export default {
  props : {
    analyticsData : {
      required : true,
      type     : Object
    },
    isInPopup : {
      required : true,
      type     : Boolean
    }
  },
  data () {
    return {
      previousPrice  : {},
      gridBackground : {}
    };
  },
  computed : {
    statusGridClass () {
      const popupClass = 'analytics-grid : true, analytics-grid__popup : true';
      const dashClass = 'analytics-grid : true, analytics-grid__dashboard : true';

      return this.isInPopup ? popupClass : dashClass;
    }
  },
  methods : {
    getKeyFromCoordinates (row, col) {
      return `${row.toString()}-${col.toString()}`;
    },
    /* check if checkerboard style does need to be applied to grid*/
    isCheckerboardStyle(name, gridType) {
      //Apply checkerboard for grid if grid type is 'ATM Swaptions' ( excluding 'midcurve') and 'Swaption Skew'
      return (name.toString().toLowerCase() !== 'midcurve' && gridType === 'ATM Swaptions') || gridType === 'Swaption Skew';
    },
    /* eslint-disable no-magic-numbers, max-params, complexity, max-statements */
    getBackground (name, gridType, rIndex, cIndex) {
      let rowIndex = rIndex;
      let colIndex = cIndex;

      // Apply checkerboard pattern only for 'Swaption Skew' grids and 'ATM Swaptions' ( excluding Midcurve grid)
      // This is required here as the data we receive from Java service is flat and there
      // is no structure defined for a product type

      if (!this.isCheckerboardStyle(name, gridType)) {
        return CELL_BACKGROUND.LIGHT;
      }

      // Flatten the background colour history matrix for performance reasons
      const key = this.getKeyFromCoordinates(rIndex, cIndex);

      // If key exists on the map then return if not then calculate based on row and column
      if (this.gridBackground[key]) {
        return this.gridBackground[key];
      }

      // On the checker board, the rows follow a pattern every 11 rows (5 dark and 6 light)
      rowIndex %= 11;

      // And columns follow a pattern every 10 colunms (5 dark and 5 light)
      colIndex %= 10;

      // The first 5 rows should be dark
      if (rowIndex <= 4) {
        // The first 5 columns should be dark followed by light for next 5 columns
        if (colIndex <= 4) {
          return CELL_BACKGROUND.DARK;
        }

        return CELL_BACKGROUND.LIGHT;
      }

      // For next 6 rows, the column backgrounds should be flipped
      // i.e The first 5 columns should be light followed by dark for next 5 columns
      if (colIndex <= 4) {
        return CELL_BACKGROUND.LIGHT;
      }

      return CELL_BACKGROUND.DARK;
    },
    getFlash (rowIndex, colIndex, price) {
      // Flatten the price history matrix for performance reasons
      const key = this.getKeyFromCoordinates(rowIndex, colIndex);

      // Get previous price from the flattened matrix to check if price has increased or decreased
      const previous = this.previousPrice[key];

      // If no previous price then do nothing, just store the current price in previousPrice map
      if (!(key in this.previousPrice)) {
        this.previousPrice[key] = price;

        return CELL_FLASHING.NONE;
      }

      // Do nothing if price is unchanged
      if (previous === price) {
        return CELL_FLASHING.NONE;
      }

      // Store the current price into previousPrice flattened matrix
      this.previousPrice[key] = price;

      return previous < price ? CELL_FLASHING.INCREASE : CELL_FLASHING.DECREASE;
    }
  }
};
</script>
