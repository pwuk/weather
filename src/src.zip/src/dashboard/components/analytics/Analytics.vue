<template>
  <div v-if="jsonResponse.length">
    <analytics-main :default-ccy="defaultCcy" />
  </div>
</template>

<script>
import {mapActions, mapGetters} from 'vuex';
import AnalyticsMain from './Main.vue';
import {ConfigAnalytics} from './config';

export default {
  name       : 'Analytics',
  components : {
    AnalyticsMain
  },
  props : {
    defaultCcy : {
      required : true,
      type     : String
    }
  },
  data () {
    return {
      interval : null
    };
  },
  computed : {
    ...mapGetters('analytics', ['jsonResponse'])
  },
  mounted () {
    this.getProductsOfCurrency(this.defaultCcy);
    this.pollData();
  },
  beforeDestroy () {
    clearInterval(this.interval);
  },
  methods : {
    ...mapActions('analytics', ['getAnalyticsData', 'getProductsOfCurrency']),
    pollData () {
      this.interval = setInterval(() => {
        this.resetPoll();
      }, ConfigAnalytics.FETCH_DATA_REFRESH_INTERVAL);
    },
    resetPoll () {
      if (this.jsonResponse.length > 0) {
        this.getAnalyticsData(ConfigAnalytics.DATAGRIDS_URL);
      }
    }
  }
};
</script>
