<template>
  <div class="analytics-main__container">
    <div class="analytics-header__container">
      <div
        v-for="ccy in currencies"
        :key="ccy.currencyCode"
        class="analytics-ccy__container"
      >
        <img
          :id="ccy.ccyCode"
          :class="statusCurrencyClass(ccy.ccyCode)"
          :src="ccy.imageLocation"
          @click="onCurrencyIconClicked(ccy.ccyCode)"
        >
        <popup
          v-model="ccy.showPopup"
          :ccy="ccy"
          :tree-data="getTreeData()"
          @close="ccy.showPopup = false"
        />
      </div>
      <a-tree-select
        v-model="selectedProduct"
        size="small"
        show-search
        tree-default-expand-all
        dropdown-class-name="analytics-grid__select__dropdown"
        :tree-data="getTreeData()"
        style="font-family:sans-serif !important; font-size: var(--analytics-grid-font-size-base);
          width: 300px;  margin-left: 10px; margin-top: 4px; cursor: pointer; "
        @change="selectedProductChanged()"
      />
      <i
        class="fa fa-2x fa-fw pull-right fa-external-link-square"
        style="color: var(--analytics-grid-popup) !important; margin-top: 5px; cursor: pointer"
        @click="onPopupClicked()"
      />
    </div>
    <div class="analytics-grid__container">
      <analytics-grid
        :analytics-data="filteredResult[0]"
        :is-in-popup="false"
      />
    </div>
  </div>
</template>

<script>

import {mapActions, mapGetters} from 'vuex';
import AnalyticsGrid from './Grid.vue';
import Popup from './Popup.vue';
import {ConfigAnalytics} from './config';
import {getHierarchialAnalyticsData} from '../../store/analytics/analytics-data-service';

export default {
  components : {
    AnalyticsGrid,
    Popup
  },
  props : {
    defaultCcy : {
      required : true,
      type     : String
    }
  },
  data () {
    return {
      selectedCurrency : this.currency,
      selectedProduct  : this.product,
      ccyChanged       : true,
      currencies       : [{
        ccyCode         : ConfigAnalytics.CURRENCY.EUR.toString(),
        imageLocation   : 'assets/images/flags/eur.svg',
        productForPopup : null,
        showPopup       : false,
        clicked         : 0
      },
      {
        ccyCode         : ConfigAnalytics.CURRENCY.USD.toString(),
        imageLocation   : 'assets/images/flags/usd.svg',
        productForPopup : null,
        showPopup       : false,
        clicked         : 0
      },
      {
        ccyCode         : ConfigAnalytics.CURRENCY.GBP.toString(),
        imageLocation   : 'assets/images/flags/gbp.svg',
        productForPopup : null,
        showPopup       : false,
        clicked         : 0
      }]
    };
  },
  computed : {
    ...mapGetters('analytics', ['jsonResponse', 'products', 'currency', 'product']),
    statusCurrencyClass () {
      const ccyActive = 'analytics-ccy : true, analytics-ccy__active : true';
      const ccyInActive = 'analytics-ccy : true, analytics-ccy__inactive : true';

      return selectedCurr => {
        if (this.selectedCurrency && this.selectedCurrency !== null) {
          return this.selectedCurrency.toString().toUpperCase() === selectedCurr ? ccyActive : ccyInActive;
        }

        return 'analytics-ccy : true';
      };
    },
    filteredResult () {
      if (this.ccyChanged) {
        this.changedCcy();
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.selectedProduct = this.product;
      }

      return this.jsonResponse.filter(data => data.currency.match(this.selectedCurrency) &&
                data.name.indexOf(this.selectedProduct) >= 0);
    }
  },
  mounted () {
    this.selectedCurrency = this.currency;
    this.selectedProduct = this.product;
  },
  beforeDestroy () {
    this.setCurrency(this.selectedCurrency);
    this.setProduct(this.selectedProduct);
  },
  methods : {
    ...mapActions('analytics', ['getProductsOfCurrency', 'setCurrency', 'setProduct']),
    getTreeNode (value, isParent) {
      return {
        title    : value,
        value,
        key      : value,
        selectable      : !isParent,
        children : isParent ? [] : undefined
      };
    },
    getTreeData () {
      const productTree = getHierarchialAnalyticsData(this.jsonResponse, this.currency);
      const treeData = [];

      // Using the productTree now shape the data to antd treeData
      // Antd tree-select component expects the data to be in a treeData format
      // Please refer to antdv tree-select documentation
      Object.keys(productTree).forEach(key => {
        const parentnode = this.getTreeNode(key, true);

        productTree[key].forEach(product => {
          parentnode.children.push(this.getTreeNode(product, false));
        });
        treeData.push(parentnode);
      });

      return treeData;
    },
    changedCcy () {
      this.getProductsOfCurrency(this.selectedCurrency);
    },
    onCurrencyIconClicked (curr) {
      this.selectedCurrency = curr;
      this.setCurrency(this.selectedCurrency);
      this.ccyChanged = true;
    },
    selectedProductChanged () {
      this.setProduct(this.selectedProduct);
      this.ccyChanged = false;
    },
    onPopupClicked () {
      this.setCurrency(this.selectedCurrency);
      this.setProduct(this.selectedProduct);
      const ccy = this.currencies.find(currency => currency.ccyCode === this.selectedCurrency);

      if (ccy) {
        ccy.showPopup = true;
        ccy.productForPopup = this.selectedProduct;
        ccy.clicked += 1;
      }
    }
  }
};
</script>

<style>
  .analytics-ccy__container {
    display: inline;
    border: 1px;
    position: relative;
    vertical-align: center;
  }

  .analytics-ccy {
    width : 35px;
    height : 20px;
    background-size : 35px 20px;
    border: none;
    margin-left: 5px;
    margin-bottom: 5px;
  }

  .analytics-ccy:hover {
    box-shadow: 0 1px 5px var(--tile-shadow);
    color: var(--analytics-grid-shadow) !important;
  }

  .ant-select-tree li .ant-select-tree-node-content-wrapper.ant-select-tree-node-selected {
    background-color: var(--analytics-tree-select-selection) !important;
  }

  .ant-select-tree li .ant-select-tree-node-content-wrapper:hover {
    background-color: var(--analytics-tree-select-selection-hover) !important;
  }
</style>
