/* eslint-disable import/prefer-default-export */

export const ConfigAnalytics = Object.freeze({
  FETCH_DATA_REFRESH_INTERVAL : 15000,
  DATAGRIDS_URL               : '/api/datagrids',
  GET_ANALYTICS_DATA          : 'irodatagrids',
  CURRENCY                    : {
    EUR : 'EUR',
    USD : 'USD',
    GBP : 'GBP'
  }
});
