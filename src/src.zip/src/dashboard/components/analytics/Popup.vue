<template>
  <div
    v-if="open"
    class="analytics-main__container"
  >
    <div
      :id="ccy.ccyCode"
      class="analytics-header__container"
    >
      <img
        class="analytics-ccy__popup"
        style="width : 35px; height : 24px; background-size : 35px 24px;"
        :src="ccyImage.src"
      >
      <a-tree-select
        v-model="product"
        size="small"
        show-search
        tree-default-expand-all
        dropdown-class-name="analytics-grid__select__dropdown"
        :get-popup-container="getContainer()"
        :tree-data="treeData"
        style="font-family:sans-serif !important; font-size: 11px;  width: 300px;
         position: fixed; margin-left: 10px; margin-top: 2px; margin-bottom: 3px; cursor: pointer;"
      />
    </div>
    <div class="analytics-grid__container">
      <analytics-grid
        :analytics-data="filteredResult[0]"
        :is-in-popup="true"
      />
    </div>
  </div>
</template>

<script>

import {mapGetters} from 'vuex';
import AnalyticsGrid from './Grid.vue';

function copyDataThemes (sourceDoc, targetDoc) {
  const parentThemes = sourceDoc.querySelectorAll('[data-theme]');
  const favIcon = sourceDoc.querySelector('link[rel="shortcut icon"]');
  const newFavIconLink = targetDoc.createElement('link');

  newFavIconLink.rel = favIcon.rel;
  newFavIconLink.href = favIcon.href;

  // eslint-disable-next-line no-param-reassign
  targetDoc.documentElement.className = sourceDoc.documentElement.className;
  targetDoc.head.appendChild(newFavIconLink);

  Array.from(sourceDoc.styleSheets).forEach(styleSheet => {
    if (styleSheet.cssRules) {
      const newStyleEl = sourceDoc.createElement('style');

      Array.from(styleSheet.cssRules).forEach(cssRule => {
        // write the text of each rule into the body of the style element
        newStyleEl.appendChild(sourceDoc.createTextNode(cssRule.cssText));
      });
      targetDoc.head.appendChild(newStyleEl);
    }
  });
  parentThemes.forEach(theme => {
    const newLinkEl = targetDoc.createElement('link');

    newLinkEl.rel = 'stylesheet';
    newLinkEl.href = theme.href;
    newLinkEl.disabled = theme.disabled;
    newLinkEl.setAttribute('data-theme', theme.dataset.theme);
    targetDoc.head.appendChild(newLinkEl);
  });
}

export default {
  components : {
    AnalyticsGrid
  },
  model : {
    prop  : 'open',
    event : 'close'
  },
  props : {
    open : {
      type    : Boolean,
      default : false
    },
    ccy : {
      required : true,
      type     : Object
    },
    treeData : {
      required : true,
      type     : Array
    }
  },
  data () {
    return {
      windowRef : null,
      products  : [],
      product   : null,
      ccyImage  : null,
      clicked   : 0
    };
  },
  computed : {
    ...mapGetters('analytics', ['jsonResponse']),
    ...mapGetters('theme', ['currentTheme']),
    filteredResult () {
      return this.jsonResponse.filter(data => data.currency.match(this.ccy.ccyCode) &&
            data.name.indexOf(this.product) >= 0);
    }
  },
  watch : {
    open (newOpen) {
      if (newOpen) {
        this.openPortal();
      } else {
        this.closePortal();
      }
    },
    ccy : {
      handler (value) {
        this.handleCcyChange(value);
      },
      deep : true
    },
    currentTheme (newTheme, oldTheme) {
      this.updateTheme(oldTheme, true);
      this.updateTheme(newTheme, false);
    }
  },
  mounted () {
    if (this.open) {
      this.openPortal();
    }
  },
  beforeDestroy () {
    if (this.windowRef) {
      this.closePortal();
    }
  },
  methods : {
    // getContainer is required for the antd tree-select component to know where to inject the select dropdown
    // as this is a popup - otherwise it injects the dropdown to main window which is the default behaviour
    getContainer () {
      return () => this.windowRef.document.getElementById(this.ccy.ccyCode);
    },
    openPortal () {
      const title = `BGC Trader : ${this.ccy.ccyCode}`;
      // eslint-disable-next-line max-len
      const windowFeatures = 'directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=yes,width=830,height=530,left=200,top=200';

      this.windowRef = window.open('', title, windowFeatures);
      this.windowRef.document.title = title;
      copyDataThemes(window.document, this.windowRef.document);
      this.windowRef.document.body.appendChild(this.$el);
      this.windowRef.addEventListener('beforeunload', this.closePortal);
      this.windowRef.addEventListener('onunload', this.closePortal);
      this.windowRef.addEventListener('onbeforeunload', this.closePortal);
      this.windowRef.addEventListener('unload', this.closePortal);
      this.windowRef.addEventListener('close', this.closePortal);
      this.product = this.ccy.productForPopup;
      this.clicked = 0;
      this.ccyImage = this.windowRef.opener.document.getElementById(this.ccy.ccyCode);
      this.products = [
        ...new Set(this.jsonResponse.filter(data => data.currency.match(this.ccy.ccyCode)).map(grid => grid.name))
      ];
    },
    closePortal () {
      if (this.windowRef) {
        this.windowRef.close();
        this.windowRef = null;
        this.products = null;
        this.product = null;
        this.clicked = 0;
        this.$emit('close');
      }
    },
    handleCcyChange (newValue) {
      if (newValue && newValue !== null) {
        if (newValue.productForPopup) {
          this.product = newValue.productForPopup;
        }
        if (this.clicked !== newValue.clicked) {
          this.clicked = newValue.clicked;
          this.bringFocusOnFront();
        }
      }
    },
    bringFocusOnFront () {
      if (this.windowRef && this.windowRef.document) {
        this.windowRef.blur();
        this.windowRef.focus();
      }
    },
    updateTheme (theme, disabled) {
      if (this.windowRef && this.windowRef.document !== null) {
        const themes = this.windowRef.document.querySelectorAll('[data-theme]');

        if (theme && theme !== null) {
          const themeId = theme.toString().charAt(theme.length - 1);

          this.windowRef.document.documentElement.className = document.documentElement.className;

          if (themes[themeId - 1].dataset.theme === theme) {
            themes[themeId - 1].disabled = disabled;
          }
        }
      }
    }
  }
};
</script>
