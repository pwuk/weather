<template>
  <div class="main-content">
    <div class="main-content-block">
      <span class="brand-logo" />
      <div class="message-block">
        <div class="message-header">
          {{ statusText }}
        </div>
        <a-spin />
        <div class="line-separator" />
        <div class="message-desc">
          <span>If you require further assistance please contact our support team using the contact information below.
            We would be very happy to help you.</span>
        </div>
      </div>
      <div class="contact-support-separator" />
      <table class="contact-details">
        <tbody>
          <tr>
            <td class="title">
              Support:
            </td>
            <td class="detail">
              <a href="mailto:support@bgcpartners.com">support@bgcpartners.com</a>
            </td>
          </tr>
          <tr>
            <td class="title">
              London:
            </td>
            <td class="detail">
              +44 (0)20 7894 8600
            </td>
          </tr>
          <tr>
            <td class="title">
              New York:
            </td>
            <td class="detail">
              +1 212 610 2300
            </td>
          </tr>
          <tr>
            <td class="title">
              Tokyo:
            </td>
            <td class="detail">
              +81 3 4589 9138
            </td>
          </tr>
          <tr>
            <td class="title">
              Singapore:
            </td>
            <td class="detail">
              +65 65123315
            </td>
          </tr>
          <tr>
            <td class="title">
              Hong Kong:
            </td>
            <td class="detail">
              +852 3477 7827
            </td>
          </tr>
          <tr>
            <td class="title">
              Sydney:
            </td>
            <td class="detail">
              18 0007 4894
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>

import {mapGetters} from 'vuex';

export default {
  computed : {
    ...mapGetters('dashboard', ['pageList', 'displaySplash', 'statusText'])
  }
};
</script>

<style>

a {
    text-decoration: underline;
}

a:hover {
  text-decoration: underline;
  color: blue;
  cursor: pointer;
}

table.contact-details {
  clear: both;
  table-layout: fixed;
  width: 360px;
  text-transform: uppercase;
  margin: auto;
  font-size: 80%;
}

table.contact-details td {
  padding: 3px;
  text-transform: uppercase;
}

table td.title {
  text-align: right;
  overflow: hidden;
  width: 40%;
}

table td.detail {
  text-align: left;
}

.message-block{
  text-align: center;
  background-color: #F5F5F5;
  margin-top: 2em;
  padding: 1.5em;
}

.message-header{
  font-size: 200%;
  padding:20px 20px 0px 20px;
  text-align:center;
}

.message-details {
  display: block;
  padding-bottom: 1em;
}

.line-separator {
  color: #f00;
  background: #f00;
  width: 10%;
  height: 2px;
  margin:auto;
}

.message-desc{
  padding:20px;
  line-height: 1.5;
  text-align: left;
}

.contact-support-separator {
  color: #F5F5F5;
  background: #F5F5F5;
  width: 100%;
  height: 2px;
  margin: 2.5em 0px;
}

.contact-support {
  padding-bottom: 1em;
  text-transform: uppercase;
  color:#f00;
  font-weight: bold;
}

.brand-logo{
  display: inline-block;
  width: 240px;
  height: 120px;
  content: var(--dashboard-bgc-logo-url);
}

body {
  background-color: #ffffff;
  font-family: Arial, Sans-Serif;
}

.main-content {
  opacity: 0.4;
  display: table;
  text-align: center;
  min-height: 100%;
  margin: 0 auto;
  max-width: 50em;
  -webkit-user-select: none;
}

.main-content-block {
  display: table-cell;
  vertical-align: middle;
  text-align: center;
}

.ant-spin-dot-item {
background-color: black !important;
}

</style>
