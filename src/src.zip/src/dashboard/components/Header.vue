<template>
  <header>
    <div class="container">
      <div class="header">
        <button
          v-if="brandId === 'GFI'"
          class="header__logo__GFI"
          alt="bgc logo"
        />
        <button
          v-else-if="brandId === 'GBX'"
          class="header__logo__GBX"
          alt="bgc logo"
        />
        <button
          v-else-if="brandId === 'CAVENTOR'"
          class="header__logo__CAVENTOR"
          alt="bgc logo"
        />
        <button
          v-else-if="brandId === 'AUREL'"
          class="header__logo__AUREL"
          alt="aurel logo"
        />
        <button
          v-else
          class="header__logo"
          alt="bgc logo"
        />
        <h2 class="header__header">
          <slot />
        </h2>
        <div class="user-menu">
          <a-tooltip
            :mouse-leave-delay="0.2"
            :mouse-enter-delay="0.5"
            placement="left"
          >
            <template slot="title">
              <span class="tooltip-text">{{ status }}</span>
            </template>
            <div
              :state="status"
              class="user-menu__status"
            />
          </a-tooltip>
          <div class="user-card">
            <div class="user-card__name">
              <a
                v-if="!isEmbeddedBrowser"
                title="Click to logout"
                class="fa fa-sign-out-after"
                @click="logoutClickHandler()"
              >
                {{ username || resources.UPDATING }}
              </a>
              <span v-if="isEmbeddedBrowser">
                {{ username || resources.UPDATING }}
              </span>
            </div>
          </div>
          <settings-popover />
          <information-popover />
        </div>
      </div>
    </div>
  </header>
</template>

<script>
import {logger} from '@core-tech/web-api';
import {mapGetters} from 'vuex';
import SettingsPopover from './SettingsPopover.vue';
import InformationPopover from './InformationPopover.vue';
import getApp from '../index';

const resources = {
  UPDATING     : 'Updating...',
  CONNECTED    : 'connected',
  INTERMITTENT : 'intermittent',
  DISCONNECTED : 'disconnected'
};

export default {
  components : {
    SettingsPopover,
    InformationPopover
  },
  model : {
    event : 'toggle-dashboard-settings'
  },
  data () {
    return {
      isEmbeddedBrowser : true,
      resources,
      sessionStatus     : {
        'session:latencyNormal'  : resources.CONNECTED,
        'session:latencyWarning' : resources.INTERMITTENT,
        'session:end'            : resources.DISCONNECTED
      },

      // Status is all green (connected) until the rountrip time indicates otherwise
      status : resources.CONNECTED
    };
  },
  computed : {
    ...mapGetters('dashboard', ['name', 'login', 'brandId', 'username'])
  },
  updated () {
    const app = getApp();

    this.isEmbeddedBrowser = app.isEmbedded;
  },
  mounted () {
    // Start listening to the websocket events published by bgct-session module
    document.addEventListener('session:latencyNormal', this.receiveEvent);
    document.addEventListener('session:latencyWarning', this.receiveEvent);
    document.addEventListener('session:end', this.receiveEvent);
  },
  methods : {
    logoutClickHandler () {
      const app = getApp();

      logger.info(`[dashboard] User logout : ${app.userId}`);
      window.location = `${app.path}/logout`;
    },
    receiveEvent (event) {
      this.status = this.sessionStatus[event.type];
    }
  }
};
</script>

<style scoped>
  .container {
    margin  : 0 var(--dashboard-header-gutter) 0 var(--dashboard-header-gutter);
  }

  .header {
    display        : flex;
    padding-top    : 1px;
    padding-bottom : 1px;
    background : var(--dashboard-header-background);
    flex-direction  : row;
    justify-content : space-between;
    align-items     : center;
    border-bottom : 5px solid var(--dashboard-header-separator-color);
  }

  .header__header {
    padding-top : 10px;
    color: var(--dashboard-header-text) !important;
    font-size      : 22px;
    font-weight    : bold;
    font-stretch   : 100%;
    text-transform : uppercase;
    font-family : sans-serif;
  }

  .header__logo {
    margin-top      : -6px;
    margin-right    : 1%;
    width           : 8rem;
    height          : 8rem;
    border          : none;
    background      : var(--dashboard-bgc-logo-url) no-repeat;
    background-size : 8rem 8rem;
    pointer-events  : none;
    }

  .header__logo__GFI {
    margin-right    : 1%;
    width           : 10rem;
    height          : 7rem;
    border          : none;
    background      : var(--dashboard-gfi-logo-url) no-repeat;
    background-size : 10rem;
    pointer-events  : none;
  }

  .header__logo__CAVENTOR {
    margin-right    : 1%;
    width           : 18rem;
    height          : 7rem;
    border          : none;
    background      : var(--dashboard-cav-logo-url) no-repeat;
    background-size : 18rem;
    pointer-events  : none;
  }

  .header__logo__AUREL {
    margin-right    : 1%;
    width           : 18rem;
    height          : 5.5rem;
    border          : none;
    background      : var(--dashboard-aur-logo-url) no-repeat;
    background-size : 18rem;
    pointer-events  : none;
  }

  .header__logo__GBX {
  margin-top      : -6px;
  margin-right    : 1%;
  width           : 10rem;
  height          : 8rem;
  border          : none;
  background      : var(--dashboard-gbx-logo-url) no-repeat;
  background-size : 11rem;
  background-position: center;
  pointer-events  : none;
  }

  .user-menu {
    display     : flex;
    gap         : 4px;
    align-items : center ;
  }

  .user-card {
    display        : flex;
    flex-direction : column;
    align-items    : flex-end;
  }

  .user-card__name {
    font-size   : 18px;
  }

  .user-card__name a, .user-card__name span {
    margin-right: 6px;
    padding: 4px;
    font-size: inherit;
    font-family: inherit;
    font-weight: bold;
    color: var(--dashboard-header-text);
  }

  .user-card__name a:hover {
    background: var(--dashboard-header-text);
    color : var(--dashboard-header-background);
  }

  /* this is retain the origin font in the href and also show the FA Icon */
  .fa-sign-out-after:after {
    font-family: FontAwesome;
  }

  .user-menu__status {
    content  : '';
    width  : 11px;
    height : 11px;
    margin-right: 4px;
    border-radius    : 50%;
    background-color : transparent;
  }

  [state = "connected"] {
    background-color : var(--dashboard-header-connection-connected);
  }

  [state = "intermittent"] {
    background-color : var(--dashboard-header-connection-intermittent);
  }

  [state = "disconnected"] {
    background-color : var(--dashboard-header-connection-disconnected);
  }

  .user-card__login {
    margin-top    : -4px;
    margin-bottom : 4px;
    font-size     : 14px;
  }

  .user-menu__settings {
    border       : none;
    color: var(--dashboard-header-text);
    cursor : pointer;
    font-size: var(--dashboard-header-setting-font-size);
    margin-right: 6px;
  }

  .user-menu__settings:hover {
    color: var(--dashboard-header-setting-hover-colour);
  }


  .user-menu__settings:focus {
    border  : none;
    outline : none;
  }

  .tooltip-text {
    text-transform: capitalize;
  }
</style>
