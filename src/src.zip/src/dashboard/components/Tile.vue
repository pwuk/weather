<template>
  <div>
    <button
      class="dashboard-tile"
      @click="openChildPage()"
    >
      <a-tooltip
        :mouse-leave-delay="0.2"
        :mouse-enter-delay="0.5"
        placement="top"
      >
        <template
          slot="title"
        >
          {{ pageItem.displayName }}
        </template>
        <div class="dashboard-tile__header">
          {{ displayName }}
        </div>
      </a-tooltip>
      <div class="dashboard-tile__list">
        <img
          :id="pageItem.currencyId"
          :src="getImageSource(pageItem.currencyId)"
          class="dashboard-tile__ccy"
        >
        <div
          v-if="auctions === undefined || auctions.length < 1"
          class="dashboard-tile__msg"
        >
          {{ resources.AUCTION_WAIT_MSG }}
        </div>

        <div
          v-for="auctionItem in auctions"
          v-else
          :key="auctionItem.auctionId"
          class="dashboard-tile__auction-list"
        >
          <tile-auction-item :auction-item="auctionItem" />
        </div>
      </div>
    </button>
  </div>
</template>

<script>
import {mapGetters} from 'vuex';
import tileAuctionItem from './TileAuctionItem.vue';
import getApp from '../index';

const resources = {
  AUCTIONS         : 'Auctions:',
  TILE_STATUS      : 'Status:',
  TILE_CURRENCY    : 'Currency:',
  TILE_WINDOW      : 'Window:',
  AUCTION_WAIT_MSG : 'Waiting for auction to start ...'
};

export default {
  name       : 'Tile',
  components : {
    tileAuctionItem
  },
  props : {
    pageItem : {
      required : true,
      type     : Object
    }
  },
  data () {
    return {
      resources
    };
  },
  computed : {
    ...mapGetters('dashboard', ['auctionList']),
    auctions () {
      return this.auctionList(this.pageItem.linkName);
    },
    statusClass () {
      return this.pageItem.status &&
       this.pageItem.status === 'ACTIVE' ? 'dashboard-tile__status--active' : 'dashboard-tile__status';
    },
    displayName () {
      const maxLength = 30;

      if (this.pageItem.displayName.length >= maxLength) {
        // eslint-disable-next-line no-magic-numbers
        return `${this.pageItem.displayName.substring(0, maxLength - 3)}...`;
      }

      return this.pageItem.displayName;
    }
  },
  beforeDestroy () {
    const app = getApp();

    app.closeChildPage({
      id : this.pageItem.linkName
    });
  },
  methods : {
    openChildPage () {
      const app = getApp();
      const {linkName : id, desk, brandId} = this.pageItem;

      app.openChildPage({id, desk, brandId}, true);
    },
    getImageSource (ccyCode) {
      return `assets/images/flags/${ccyCode.toString().toLowerCase()}.svg`;
    }
  }
};
</script>

<style scoped>

.dashboard-tile__list {
  min-height: 6.65rem;
}

.dashboard-tile__msg {
  font-size: 1.2rem;
  margin-top: 0.9rem;
  margin-left: 0.5rem;
}

.dashboard-tile {
  background-color: var(--dashboard-content-background);
  border: 1px solid var(--dashboard-content-header-background);
  border-radius: 0.3rem;
  color: inherit;
  cursor: pointer;
  font-family: inherit;
  font-size: 16px;
  margin: 0.5rem;
  padding: 0;
  position: relative;
  text-align: inherit;
  width: 17.75rem;
  outline: 10;
  appearance: button;
}

.dashboard-tile:focus{
  box-shadow: 0 1px 5px var(--tile-shadow);
  border: 1px solid var(--dashboard-content-text);
  outline:0 !important;
}

.dashboard-tile__header {
  background-color: var(--dashboard-content-header-background);
  color: var(--dashboard-content-header-text);
  text-transform: uppercase;
  padding: 0.5rem;
  height: 4rem;
  text-align: center;
  font-size: 1.4rem;
  display: flex;
  align-items: center;
    justify-content: center;

}

.dashboard-tile:hover .dashboard-tile__header {
  color:var(--tile-shadow);
}

.dashboard-tile__status {
  border-radius: 1rem;
  text-transform: uppercase;
  color:var(--dashboard-content-text);
  font-weight: 700;
}

.dashboard-tile__status--active {
  background-color: var(--tile-status-active);
  color: var(--dashboard-content-text);
  padding: 0.25rem 0.875rem;
  border-radius: 20px;
  font-weight: bold;
}

.dashboard-tile__auction-list {
  padding: 0;
  margin-top: 0.5rem;
  overflow: auto;
}

.dashboard-tile__ccy {
  margin-top: 0.5rem;
  margin-left: 0.5rem;
  width : 41px;
  height : 25px;
  background-size : 41px 25px;
  border: none;
}

</style>
