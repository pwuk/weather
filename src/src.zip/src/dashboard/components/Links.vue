<template>
    <div>
        <div>
            <label class="information-label">Terms/Rules</label>
        </div>
        <button
                v-for="link in links"
                :key="link.desc"
                class="dashboard-header__settings__link"
                @click="openUrl(true, link)"
        >
            {{link.desc }}
        </button>
    </div>
</template>

<script>

  export default {
    name       : 'Links',
    data () {
      return {
        links : [{href:'http://bgchistory.eu.ad.espeed.com/MTF/MTF.htm',desc:'MTF Rulebook'},
          {href:'http://bgchistory.eu.ad.espeed.com/OTF/OTF.htm',desc:'OTF Rulebook'},
          {href:'https://www.bgcpartners.com/legal/disclosures-terms-use-global-broker-exchange-gbx/', desc:'Terms of Business'}]
      }
    },
    methods : {
      openUrl (visible, link) {
        if (window.JxBrowserApp) {
          window.JxBrowserApp.openWindow(link.desc, link.href, visible);
        } else {
          window.open(link.href, link.link, 'noreferrer,noopener');
        }
      }
    }
  };

</script>

<style>

    .dashboard-header__settings__link {
        --font-size-sm: 12px;
        font-size: var(--font-size-sm);
        font-weight: var(--dashboard-header-setting-link-font-weight);
        font-family: inherit;
        margin-left: 20px;
        margin-right: 10px;
        cursor: pointer;
        text-decoration: underline;
        color: var(--dashboard-link-color);
        background: none !important;
        border: none !important;
        /* Disable the box shadow on button after its clicked */
        outline: none;
        box-shadow: none;
    }

</style>
