<template>
  <div  class="trade-grid-container" >
    <div @contextmenu="onContextMenu">
      <div v-click-outside="onCloseMenu" class="trade-grid-context-menu" v-if="isViewMenu" ref="right" :style="{top:top, left:left}">
        <h3 class="trade-grid-context-menu__header">
          {{resources.FILTER_HISTORY}}
        </h3>
        <ul  class="trade-grid-context-menu__checkbox-container ">
          <li v-for="(item, key) in filteredKeys">
            <a-checkbox type="checkbox" :checked="isChecked(item)" :value="item" id="key" @change="onCheck(item)" class="trade-grid-context-menu__checkbox-wrapper" >
              {{key}}
            </a-checkbox>
          </li>
        </ul>
        <button @click="onCopyRows" class="trade-grid-context-menu__copy-rows-btn">
          {{resources.COPY_ALL_ROWS}}
        </button>
      </div>

      <div class="trade-grid">
        <a-config-provider :class="tableClass" :prefixCls="prefixCls">
          <a-table :size="size" :expandIconColumnIndex="1" :defaultExpandAllRows="true" :indentSize=6 :expandedRowKeys="expandedRowKeys" :rowClassName="rowClassName" :columns="filteredColumns" :components="components" :data-source="filteredData" :pagination="false"/>
        </a-config-provider>
      </div>

    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import VueDraggableResizable from 'vue-draggable-resizable'
import VueClipboard from 'vue-clipboard2'
import clickOutside from '../utils/click-outside.js'
import { mapGetters } from 'vuex'
import {tradesEmitter} from '../store/trades';
import {MutationTypes as TradesMutations} from '../store/trades/mutations';
import {throttle} from 'lodash';

const {UPDATE_GROUP_TRADE_CONFIRMS} = TradesMutations;

Vue.use(VueClipboard)
Vue.component('vue-draggable-resizable', VueDraggableResizable)

const MILLIS_PER_DAY = 86400000;

const tradeConfirmsInterval = 250;

const resources = {
  FILTER_HISTORY: 'Filter History',
  COPY_ALL_ROWS: 'Copy all rows',
  TRADE_GRID_ID_COLUMN: 'Trade Id #',
  TRADE_GRID_ACCOUNT_ID_COLUMN: 'Account',
  TRADE_GRID_TIME_COLUMN: 'Time',
  TRADE_GRID_INSTRUMENT_NAME_COLUMN: 'Instrument Name',
  TRADE_GRID_STRIKE_A_COLUMN: 'Strike A',
  TRADE_GRID_STRIKE_B_COLUMN: 'Strike B',
  TRADE_GRID_TYPE_COLUMN: 'Type',
  TRADE_GRID_SIZE_COLUMN: 'Size',
  TRADE_GRID_PRICE_COLUMN: 'Price',
  TRADE_GRID_COUNTERPARTY_ID_COLUMN: 'Counterparty'
}

const columns = [
  {
    key: 'time',
    title: resources.TRADE_GRID_TIME_COLUMN,
    dataIndex: 'time',
    width: 120,
    defaultSortOrder: 'descend',
    sorter: (a, b) => a.millis - b.millis,
    className : 'trade-grid__time'
  },
  {
    title: resources.TRADE_GRID_INSTRUMENT_NAME_COLUMN,
    dataIndex: 'instrumentName',
    width: 200,
    sorter: (a, b) => a.instrumentName.localeCompare(b.instrumentName),
    className : 'trade-grid__name'
  },
  {
    title: resources.TRADE_GRID_TYPE_COLUMN,
    dataIndex: 'type',
    width: 80,
    align: 'center',
    className : 'trade-grid__side-col'
  },
  {
    title: resources.TRADE_GRID_SIZE_COLUMN,
    dataIndex: 'size',
    align: 'center',
    width: 80,
    className : 'trade-grid__size'
  },
  {
    title: resources.TRADE_GRID_PRICE_COLUMN,
    dataIndex: 'priceDisplay',
    width: 70,
    align: 'center',
    className : 'trade-grid__price',
  },
  {
    title: resources.TRADE_GRID_COUNTERPARTY_ID_COLUMN,
    dataIndex: 'counterparty',
    width: 270,
    className : 'trade-grid__counterparty'
  },
  {
    key: 'tradeId',
    title: resources.TRADE_GRID_ID_COLUMN,
    dataIndex: 'tradeId',
    width: 160,
    className : 'trade-grid__trade'
  },
  {
    key: 'accountName',
    title: resources.TRADE_GRID_ACCOUNT_ID_COLUMN,
    dataIndex: 'accountName',
    width: 160,
    className : 'trade-grid__trade'
  }
];

const delim = '\t';

const getRowText = (columns, trade) => columns
  .reduce((acc, {dataIndex}) => (trade[dataIndex] ? `${acc}${trade[dataIndex]}${delim}` : `${acc}${delim}`), '');

const draggingMap = {};

columns.forEach(col => {
  draggingMap[col.key] = col.width;
});

const draggingState = Vue.observable(draggingMap);


// A vue render function to render the resizable cell on the ant design table
const renderResizeableTitle = (h, props, children) => {

  let thDom = null;

  const { key, ...restProps } = props;

  const col = columns.find(col => {
    const k = col.dataIndex || col.key;
    return k === key;
  });

  if (!col.width) {
    return <th {...restProps}>{children}</th>;
  }

  const onDrag = x => {
    draggingState[key] = 0;
    col.width = Math.max(x, 1);
  };

  const onDragstop = () => {
    draggingState[key] = thDom.getBoundingClientRect().width;
  };

  return (
    <th {...restProps} v-ant-ref={r => (thDom = r)} width={col.width} class="resize-table-th">
      {children}
      <vue-draggable-resizable
        key={col.key}
        class="table-draggable-handle"
        w={10}
        x={draggingState[key] || col.width}
        z={1}
        axis="x"
        draggable={true}
        resizable={false}
        onDragging={onDrag}
        onDragstop={onDragstop}
      ></vue-draggable-resizable>
    </th>
  );
};

export default {
  name: 'trade-grid',
  directives: {
    clickOutside
  },
  data() {
    this.components = {
      header: {
        cell: renderResizeableTitle,
      },
    };
    return {
      columns,
      resources,
      prefixCls: 'trade-grid',
      size: 'small',
      tableId: 'trade-grid-table',
      defaultExpandAllRows: true,
      tableClass: 'trade-grid__table',
      isViewMenu: false,
      top: '0px',
      left: '0px',
      defaultCheckboxValue: 1,
      filterByDayFields: {
      '1 Day'  : 1,
      '2 Days' : 2,
      '3 Days' : 3,
      '4 Days' : 4,
      '5 Days' : 5,
      '6 Days' : 6,
      '7 Days' : 7
      },
    };
  },
  computed:{
    filteredData () {
      return this.getFilteredData();
    },

    filteredColumns () {
      const {role : userRole = 'trader'} = this.currentUser || {};
      let cols = columns;

      // First, find index of instruementName. Second, add generic columns after instruementName
      let idx = this.columns.findIndex(ele => ele.dataIndex === "instrumentName") + 1;

      this.genericColumns.forEach(element => {
        const id = 'TRADE_GRID_' + element.columnName.replace(' ', '_').toUpperCase() + '_COLUMN';
        let col = {
          title: resources[id],
          dataIndex: element.columnId,
          width: 100,
          align: 'center',
          className : 'trade-grid__' + element.columnId.replace('Display', ''),
          genericColumns : true
        }
        cols.splice(idx, 0, col);
        idx++;
      })

      // Remove 'accountId' column if user is trader
      if (userRole === 'trader') {
        cols = cols.filter(column => column.key !== 'accountName');
      }
      return cols;
    },

    expandedRowKeys () {
      return this.getExpandedRowKeys();
    },

    filteredKeys () {
      let currentVal = this.defaultCheckboxValue;

      return this.filterByDayFields
    },
    ...mapGetters('trades', ['tradeConfirms','groupedTradeConfirms']),
    ...mapGetters('dashboard', ['currentUser', 'genericColumns']),
  },
  watch:{
    tradeConfirms(newTradeConfirms, oldTradeConfirms) {
      this.updateGroupedTradeConfirms();
    }
  }
  ,
  methods:{
    rowClassName: (record) => {
      const isParent = (record.children && record.children.length) ? 'parent' : '' ;
      const isChild = (record.isChild ) ? 'child' : '' ;
      return `trade-grid__table-${record.type}-row ${isParent} ${isChild}`;
    },

    getExpandedRowKeys () {
      return this.groupedTradeConfirms.filter(row => row.children && row.children.length).map (row => row.key);
    },

    getFilteredData () {
      let daysToSubtract = this.defaultCheckboxValue * MILLIS_PER_DAY;
      // let startTime = new Date().getMilliseconds() - daysToSubtract;
      let startTime = Date.now() - daysToSubtract;

      return this.groupedTradeConfirms.filter(row => row.millis > startTime);
    },

    setMenu: function(top, left) {
      var largestHeight = window.innerHeight - this.$refs.right.offsetHeight - 25;
      var largestWidth = window.innerWidth - this.$refs.right.offsetWidth - 25;

      if (top > largestHeight) {
        top = largestHeight;
      }

      if (left > largestWidth) {
        left = largestWidth;
      }

      this.top = top + 'px';
      this.left = left + 'px';
    },

    onCloseMenu: function() {
        this.isViewMenu = false;
    },

    onContextMenu: function(e) {
      this.isViewMenu = true;

      Vue.nextTick(function() {
       this.$refs.right.focus();
       this.setMenu(e.y, e.x)
      }.bind(this));

      e.preventDefault();
    },

    onCheck(item) {
      this.defaultCheckboxValue === item ? this.defaultCheckboxValue = 100 : this.defaultCheckboxValue = item;
    },

    isChecked(item) {
      return this.defaultCheckboxValue === item;
    },

    // eslint-disable-line no-param-reassign
    onCopyRows(){
      var copyText = this.getFilteredData().reduce((acc, trade) => {
        const isParent = trade.children.length > 0;
        if (isParent) {
          // We want to only display time and instrument name on parent trades
          const parentTrade = {
            time: trade.time,
            instrumentName: trade.instrumentName,
          };
          acc += getRowText(columns, parentTrade);
          acc += '\n';

          // Now process all the child trades
          Object.keys(trade.children).forEach(function(key) {
            let {time, ...others} = trade.children[key];
            // We don't want to display time on child trades
            acc += getRowText(columns, others);
            acc += '\n';
          });
        } else {
          acc += getRowText(columns, trade);
          acc += '\n';
        }

        return acc;
      }, '');
      this.$copyText(copyText)
    },
    updateGroupedTradeConfirms : throttle(() => {
      tradesEmitter.emit(UPDATE_GROUP_TRADE_CONFIRMS);
    }, tradeConfirmsInterval)
  }
};
</script>

<style>

.trade-grid-container {
  display: inherit;
  flex-direction: inherit;
  flex: 1 1 auto;
}

.trade-grid {
  display: inherit;
  flex-direction: inherit;
  flex: 1 1 auto;
  /* Push the trade grid to the bottom of the page */
  position: absolute;
  bottom: 0;
  width: 100%;
}

/* Add vertical scroll to trade grid and ensure 8 grid rows are displayed by default */
.trade-grid__table {
  display: inherit;
  flex-direction: inherit;
  flex: 1 1 auto;
  overflow-x: hidden;
  overflow-y: auto;
  /* Trade grid should not have scroll when the window is on minimum size */
  height: 20rem;
  /* Match the table header gutter with the main header gutter */
  margin: 0 var(--dashboard-header-gutter) var(--dashboard-header-gutter) var(--dashboard-header-gutter);
}

.trade-grid__table div {
  display: inherit;
  flex-direction: inherit;
  flex: 0.9 0.5 auto;
}

.trade-grid__table-buy-row,
.trade-grid__table-sell-row {

  /* stylelint-disable-next-line no-unknown-animations */
  animation: 0.2s forwards fadeIn;
  opacity: 0;
}

/* stylelint-disable-next-line selector-no-qualifying-type */
td.trade-grid__side-col {
  text-transform: uppercase;
}

.trade-grid__table-buy-row .trade-grid__side-col {
  color: var(--trade-grid-buy-row);
}

.trade-grid__table-sell-row .trade-grid__side-col {
  color: var(--trade-grid-sell-row);
}

.parent .trade-grid__strike1,.parent .trade-grid__side-col, .parent .trade-grid__strike2,.parent .trade-grid__size,
.parent .trade-grid__price,.parent .trade-grid__counterparty,.parent .trade-grid__trade {
    color: rgba(255,255,255,0) !important;
}

.child .trade-grid__time {
    color: rgba(255,255,255,0);
}

.resize-table-th {
  position: relative;
}
.resize-table-th .table-draggable-handle {
  height: 100% !important;
  bottom: 0;
  left: auto !important;
  right: -5px;
  cursor: col-resize;
  touch-action: none;
  color: var(--trade-grid-row-divider-color);
}

.trade-grid-context-menu {
  background: var(--trade-grid-text-secondary);
  background-color: var(--trade-grid-text-secondary);
  box-shadow: 3px 3px 2px 1px var(--trade-grid-text-primary);
  display: block;
  list-style: none;
  margin: 0;
  padding: 10px;
  position: absolute;
  min-width: 200px;
  max-width: 500px;
  z-index: 999999;
}

.trade-grid-context-menu__checkbox-wrapper {

  /* stylelint-disable declaration-no-important */
  margin-left: 0 !important;

  /* stylelint-enable declaration-no-important */
  width: 100%;
}

.trade-grid-context-menu__checkbox-wrapper:hover {
  background: var(--trade-grid-context-menu-hover);
}

.trade-grid-context-menu__header {
  font-size: var(--font-size-base);
  color: var(--trade-grid-text-primary);
  font-weight: var(--trade-grid-font-weight);
  margin: 0;
  padding-bottom: 5px;
  border-bottom: 1px solid var(--trade-grid-row-divider-color);
}

.trade-grid-context-menu__checkbox-container {
  display: flex;
  flex-direction: column;
  margin: 5px 0 5px 5px;
  list-style-type:none;
  padding-inline-start: 0px;
}

.trade-grid-context-menu .checkbox {
  font-size: var(--trade-grid-font-size-sm);
  font-weight: var(--trade-grid-context-menu-font-weight);
}

.trade-grid-context-menu__copy-rows-btn {
  color: var(--trade-grid-text-primary);
  font-weight: var(--trade-grid-font-weight);
  text-align: center;
  margin: 0;
  background: 0;
  border: 0;
  border-top: 1px solid var(--trade-grid-row-divider-color);
  font-size: var(--font-size-base);
  text-transform: uppercase;
  display: flex;
  justify-content: center;
  align-items: center;
}

.trade-grid-context-menu__copy-rows-btn:active {
  background: var(--trade-grid-context-menu-hover);
}

/* Context menu checkbox gets default blue colour from ant design class which needs to be overridden using theme colour */
.ant-checkbox-checked .ant-checkbox-inner {
    background-color: var(--dashboard-content-header-background) !important;
    border-color: var(--dashboard-content-header-background) !important;
}

.trade-grid-table-body table {
  width: 100%;
  border-spacing: 0;
  font-size: var(--trade-grid-font-size-xsm);
  color: var(--dashboard-header-text);
  background: var(--dashboard-content-background);
}

.trade-grid-table-thead {
  background-color:  var(--dashboard-content-header-background);
  color: var(--dashboard-content-header-text);
}

.trade-grid-table-thead th {
  font-weight: var(--trade-grid-table-thead-font-weight);
  text-align: center;
  /* Trade grid header should not scroll */
  background-color: var(--dashboard-content-header-background);
  position: sticky !important;
  top: 0;
  z-index: 10;
}

.trade-grid-table-thead th:not(:first-child) {
  border-left: 1px solid var(--trade-grid-draggable-handle);
}

.trade-grid-table-tbody td {
  border: 0 solid var(--trade-grid-row-divider-color);
  border-width: 1px 2px 1px 1px;
  padding: 2px 2px 0 3px;
}

.trade-grid-table-tbody .child td {
    border-top-style: hidden !important;
}

.trade-grid-table-placeholder {
  display: flex;
  justify-content: center;
  color: var(--dashboard-content-background);
  background: var(--dashboard-content-background);
}

.trade-grid-table-placeholder .trade-grid-empty-normal {
  margin-top: 15px;
  text-align: center;
  color: var(--dashboard-content-text);
}

/* stylelint-disable */
.trade-grid-table-thead > tr > th .trade-grid-dropdown-trigger {
  position: absolute;
  top: 0;
  right: 0;
  width: 28px;
  height: 100%;
  color: var(--trade-grid-text-secondary);
  font-size: 14px;
  text-align: center;
  cursor: pointer;
  transition: transform 0.1s;
  display: flex;
  align-items: center;
  justify-content: center;
  outline: none;
}

.trade-grid-table-thead > tr > th .trade-grid-dropdown-trigger:hover {
  transform: scale(1.2);
}

.trade-grid-table-thead > tr > th.trade-grid-table-column-has-actions {
  position: relative;
  background-clip: padding-box;
  -webkit-background-clip: border-box;
}

/**
* Table sorters. Only show a single arrow
*/

.trade-grid-table-column-sorters {
  display: flex;
  justify-content: space-around;
}

.trade-grid-table-column-sorter-inner {
  cursor: pointer;
  margin-left: 0.4rem;
}

.trade-grid-table-column-sorter-inner > .off {
  color: var(--trade-grid-sorter-off);
}

.ant-empty-description {
    color: var(--dashboard-header-text);
    margin: 0;
}

/* When window is on minimum size, No data envelope that ant grid displays causes the scroll to appear */
.ant-empty-normal {
  margin: 6rem 0 !important;
}

/* Gutter on trade grid header needs to match the content background colour */
.trade-grid-table-content {
  background-color: var(--dashboard-content-background);
}
</style>

