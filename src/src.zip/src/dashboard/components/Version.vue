<template>
  <div>
    <div class="version-copy"
         :title="resources.COPY_TO_CLIPBOARD"
         role="button"
         @click="onCopyToClipboardClicked()"
    >
      <label class="information-label">{{ resources.VERSION_INFORMATION }}</label>
      <i
        class="fa fa-fw fa-copy"
        :title="resources.COPY_TO_CLIPBOARD"
        @click="onCopyToClipboardClicked()"
      />
    </div>
    <div>
      <div class="version-popover__version">
        <label class="version-popover__version-label">{{ resources.PACKAGE_VERSION }}</label>
        <label
          :title="resources.BUILD_DATE"
          class="version-popover__version-label version-popover__version-value"
        > {{ getPackageVersion() }}</label>
      </div>
      <div class="version-popover__version overflow">
        <label class="version-popover__version-label">{{ resources.GTI_SERVER_VERSION }}</label>
        <label
          class="version-popover__version-label version-popover__version-value"
        >{{ getTradingServiceVersion() }} {{ isProduction() ? null : `(${getTradingServiceName()})` }}
        </label>
      </div>
      <div class="version-popover__version">
        <label class="version-popover__version-label">{{ resources.BGC_PORTAL_SERVER_VERSION }}</label>
        <label class="version-popover__version-label version-popover__version-value"> {{ getPortalVersion() }} {{ `(${getHostName()})` }} </label>
      </div>
    </div>
  </div>
</template>
<script>

import {mapGetters} from 'vuex';
import packagejs from '../../../package.json';
import sha from '../../../buildInfo.json';
import getApp from '..';

// Retrieves the trading session settings from the global 'singleton' App object (created in the index bundle)
const getSessionSettings = () => {
  const app = getApp();

  return app.tradingSession ? app.tradingSession.sessionSettings : {};
};

const getServerInfo = () => {
  const app = getApp();

  return app.tradingSession.serverInfo || {};
};

export default {
  name     : 'Version',
  computed : {
    ...mapGetters('dashboard')
  },
  methods : {
    getPackageVersion () {
      return `${packagejs.version} (${sha.git_sha})`;
    },
    getPortalVersion () {
      return getSessionSettings().portalVersion;
    },
    getHostName () {
      return getSessionSettings().hostname || '';
    },
    getTradingServiceVersion () {
      return getServerInfo().serverVersion;
    },
    getTradingServiceName () {
      return getServerInfo().serverName;
    },
    isProduction () {
      return getServerInfo().isProduction;
    },
    onCopyToClipboardClicked () {
      const {resources} = this.$data;
      let copyText = `${resources.PACKAGE_VERSION} ${this.getPackageVersion()} (${resources.BUILD_DATE})`;

      copyText += '\n';
      copyText += `${resources.GTI_SERVER_VERSION} ${this.getTradingServiceVersion()} (${this.getTradingServiceName()})\n`;
      copyText += `${resources.BGC_PORTAL_SERVER_VERSION} ${this.getPortalVersion()} (${this.getHostName()}) \n`;
      this.$copyText(copyText);
    }
  },
  data () {
    return {
      resources : {
        PACKAGE_VERSION           : 'BGC Volume Match: ',
        GTI_SERVER_VERSION        : 'GTI Middleware:',
        BGC_PORTAL_SERVER_VERSION : 'BGCT Portal:',
        VERSION_INFORMATION       : 'Version Information',
        COPY_TO_CLIPBOARD         : 'copy to clipboard',
        BUILD_DATE                : sha.date
      }
    };
  }
};

</script>

<style>

    .version-copy {
        pointer-events: auto;
        border : none;
        color: var(--dashboard-header-text);
        cursor : pointer;
        font-size: var(--dashboard-header-setting-font-size);
        margin-top: 0.6rem;
    }
    .version-copy label {
      cursor: pointer;
    }

    .version-copy:hover {
        color: var(--dashboard-header-setting-hover-colour);
    }

    .version-copy:focus {
        border  : none;
        outline : none;
    }

    .version-popover__version {
        margin-left: 25px;
    }

    .version-popover__version-label {
        --font-size-xsm: 11px;
        font-size: var(--font-size-xsm);
        font-weight: var(--dashboard-header-setting-font-weight);
    }

    .version-popover__version-value {
        color: #5F5F5F;
    }

    .overflow {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

</style>
