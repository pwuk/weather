<template>
  <fragment>
    <vm-splash v-show="displaySplash"/>
    <vm-header v-show="!displaySplash">{{ getBrandTitle(brandId) }}</vm-header>
    <vm-main v-show="!displaySplash" :default-ccy="defaultCcy">
      <vm-tile
        v-for="pageItem in pageList"
        slot="tiles"
        :key="pageItem.pageName"
        :page-item="pageItem"
      />
      <vm-trade-grid slot="tradeGrid" />
    </vm-main>
    <footer />
  </fragment>
</template>

<script>

import {Fragment} from 'vue-fragment';
import {mapGetters} from 'vuex';
import VmHeader from './Header.vue';
import VmMain from './Main.vue';
import VmTile from './Tile.vue';
import VmTradeGrid from './TradeGrid.vue';
import VmSplash from './Splash.vue';

export default {
  components : {
    Fragment,
    VmHeader,
    VmMain,
    VmTile,
    VmSplash,
    VmTradeGrid
  },
  props : {
    defaultCcy : {
      default : 'EUR',
      type    : String
    }
  },
  computed : {
    ...mapGetters('dashboard', ['pageList', 'displaySplash', 'brandId'])
  },
  methods : {
    getBrandTitle (brandId) {
      const titleMap = {
        "BGC": "BGC VM DASHBOARD",
        "BGCIRO": "BGC VM DASHBOARD",
        "GFI": "GFI MATCHING DASHBOARD",
        "GFI-FXO": "GFI MATCHING DASHBOARD",
        "GBX": "GBX RATES VM DASHBOARD",
        "CAVENTOR": "CAVENTOR DASHBOARD",
        "AUREL": "AUREL VM DASHBOARD"
      };
      return titleMap[brandId];
    }
  }
};
</script>

<style scoped>

</style>
