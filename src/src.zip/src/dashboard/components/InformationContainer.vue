<template>
    <div>
        <div><links /></div>
        <div><version /></div>
    </div>
</template>
<script>
  import Version from './Version.vue';
  import Links from './Links.vue';

  export default {
    name       : 'InformationContainer',
    components : {
      Version,
      Links
    }
  };

</script>

<style>

    .information-label {
        font-size: 15px;
        font-weight: bold;
    }

</style>
