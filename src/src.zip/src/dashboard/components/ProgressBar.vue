<template>
  <div>
    <a-tooltip
      :mouse-leave-delay="0.2"
      :mouse-enter-delay="0.5"
      placement="right"
    >
      <template
        v-if="showTooltip"
        slot="title"
      >
        {{ tooltipMessage + ': ' + parseRemainingSeconds }}
      </template>
      <div class="progress-bar-container">
        <div
          :state="state"
          class="progress-bar-progress"
          :style="getStyle"
        />
      </div>
    </a-tooltip>
  </div>
</template>

<script>
/* eslint-disable no-magic-numbers */

const SECS_PER_HOUR = 60 * 60 * 1000;
const SECS_PER_MIN = 60 * 1000;
const RED_THRESHOLD = 30;
const STATE = {
  RED    : 'red',
  NORMAL : 'normal',
  ZERO   : 'zero'
};

/* Calculates the progress state based on the thresholds and time remaining in seconds*/
function progressState (remainingSeconds) {
  // eslint-disable-next-line init-declarations
  let state;

  if (remainingSeconds <= 0) {
    state = STATE.ZERO;
  } else if (remainingSeconds <= RED_THRESHOLD) {
    state = STATE.RED;
  } else {
    state = STATE.NORMAL;
  }

  return state;
}

const resources = {
  AUCTION_TIME_REMAINING_DEFAULT : 'Time remaining'
};

export default {

  name  : 'ProgressBar',
  props : {
    startTime : {
      type     : Number,
      required : true
    },
    endTime : {
      type     : Number,
      required : true
    },
    timeOffset : {
      type     : Number,
      required : true
    },
    showTooltip : {
      type    : Boolean,
      default : true
    },
    tooltipMessage : {
      type    : String,
      default : resources.AUCTION_TIME_REMAINING_DEFAULT
    }
  },
  data () {
    return {
      progressWidth    : 0,
      remainingSeconds : 0,
      state            : STATE.NORMAL
    };
  },
  computed : {
    getStyle () {
      if (this.state === STATE.RED) {
        return {
          width : `${this.progressWidth}%`
        };
      }
      if (this.state === STATE.NORMAL) {
        return {
          width : `${this.progressWidth}%`
        };
      }

      return {
        width : '0%'
      };
    },

    parseRemainingSeconds () {
      const hh = Math.floor(this.remainingSeconds / SECS_PER_HOUR);
      const mm = Math.floor((this.remainingSeconds - hh * SECS_PER_HOUR) / SECS_PER_MIN);
      const ss = parseInt((this.remainingSeconds - hh * SECS_PER_HOUR - mm * SECS_PER_MIN) / 1000, 10);

      const ifTimeIsNaN = Number.isNaN(hh) || Number.isNaN(mm) || Number.isNaN(ss);

      return ifTimeIsNaN ? '-- -- --' : `${this.formatTime(hh)}: ${this.formatTime(mm)}: ${this.formatTime(ss)}`;
    }
  },
  mounted () {
    this.startProgress();
  },
  methods : {
    startProgress () {
      const int = setInterval(() => {
        /* The timeOffset should be added to client now time to account for time sync
        issues between server and client PC */
        const serverNow = Date.now() - this.timeOffset;

        if (serverNow >= this.endTime) {
          this.progressWidth = 0;
          clearInterval(int);

          return;
        }

        this.remainingSeconds = this.endTime - serverNow;
        this.state = progressState(this.remainingSeconds / 1000);
        this.progressWidth = 100 - (((serverNow - this.startTime) / (this.endTime - this.startTime)) * 100);
      }, 100);
    },

    formatTime (time) {
      return time.toLocaleString(undefined, {minimumIntegerDigits : 2});
    }
  }
};
</script>

<style>

.progress-bar-container {
  height: 0.9rem;
  border: 2px solid var(--progress-bar-bg-primary);
  border-radius: 0.4rem;
}

.progress-bar-progress {
  height: 100%;
  width: 0%;
}

[state = "zero"] {
  background-color : var(--progress-bar-bg-secondary);
}

[state = "normal"] {
  background-color : var(--progress-bar-bg-primary);
}

[state = "red"] {
  background-color : var(--progress-bar-red);
}

</style>
