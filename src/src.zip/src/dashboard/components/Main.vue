<template>
  <main class="dashboard-main">
    <div class="dashboard-main-container">
      <div classs="dashboard-main__header">
        <div class="dashboard-main__framing-disclosure">
          {{ resources.PRICES_FRAMED_DISCLOSURE }}
          <button
            class="dashboard-main__framing-disclosure-link"
            @click="openUrl(true)"
          >
            {{ resources.FRAMING_DISCLOSURE }}
          </button>
        </div>
      </div>
      <div class="dashboard-split-container">
        <div class="dashboard-main__list-container">
          <slot name="tiles" />
        </div>
        <div
          v-if="displayAnalytics"
          class="dashboard-analytics"
        >
          <vm-analytics :default-ccy="defaultCcy" />
        </div>
      </div>
    </div>
    <slot name="tradeGrid" />
  </main>
</template>

<script>
import {mapGetters} from 'vuex';
import VmAnalytics from './analytics/Analytics.vue';

export default {
  components : {
    VmAnalytics
  },
  props : {
    defaultCcy : {
      required : true,
      type     : String
    }
  },
  data () {
    return {
      resources : {
        PRICES_FRAMED_DISCLOSURE      : 'Prices may be framed, please see',
        FRAMING_DISCLOSURE            : 'Framing Disclosure',
        BGC_FRAMING_DISCLOSURE        : 'BGC Framing Disclosure',
        PRICES_FRAMED_DISCLOSURE_LINK : 'http://bgchistory.eu.ad.espeed.com/FramingDisclosure/BGCFramingDisclosure.htm'
      }
    };
  },
  computed : {
    ...mapGetters('dashboard', ['displayAnalytics'])
  },
  methods : {
    openUrl (visible) {
      if (window.JxBrowserApp) {
        window.JxBrowserApp.openWindow(this.resources.BGC_FRAMING_DISCLOSURE,
          this.resources.PRICES_FRAMED_DISCLOSURE_LINK, visible);
      } else {
        window.open(this.resources.PRICES_FRAMED_DISCLOSURE_LINK,
          this.resources.BGC_FRAMING_DISCLOSURE, 'noreferrer,noopener');
      }
    }
  }
};
</script>

<style scoped>

    .dashboard-main {
      display: flex;
      flex-direction: column;
      flex: 1 1 auto;
    }

    .dashboard-main-container {
        font-family: inherit;
        padding: 0 2rem 1rem;
        max-height: 51rem;
        background-color: var(--dashboard-content-background);
        color: var(--dashboard-content-text);
    }

    .dashboard-main__header {
        display: flex;
        justify-content: space-between;
        margin: 0 0 1.5rem;
    }

    .dashboard-main__framing-disclosure {
        text-align: right;
        font-size: 11px;
        padding-top: 3px;
    }

    .dashboard-main__framing-disclosure-link {
        background: none!important;
        border: none;
        padding: 0!important;
        color: var(--dashboard-link-color);
        font-size: 11px;
        text-decoration: underline;
        cursor: pointer;
        /* Disable the box shadow on button after its clicked */
        outline: none;
        box-shadow: none;
    }

    .dashboard-main__list-container {
        display: grid;
        grid-template-rows: repeat(var(--dashboard-tile-grid-rows), 1fr);
        grid-template-columns: var(--dashboard-tile-grid-column-width) 1fr;
        grid-auto-flow: column;
        margin-right: 3rem;
        row-gap: 0.9rem !important;
    }

    .dashboard-main__list-container div {
        grid-column-start: auto;
        grid-row-start: auto;
    }

    .dashboard-analytics {
        flex : 1 1 auto;
        min-width: 550px;
    }

    .dashboard-split-container {
        display: flex;
    }

</style>
