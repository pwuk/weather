<!-- eslint-disable vue/no-mutating-props -->
<template>
  <div>
    <div
      v-if="type !== 'version'"
      class="settings-popover__item"
    >
      <a-switch
        v-if="type === 'switch'"
        :disabled="!enabled"
        size="small"
        :checked="value"
        @change="valueChanged"
      />
      <a-select
        v-if="type === 'select'"
        :default-value="value"
        style="width: 120px"
        :disabled="!enabled"
        @change="onChange"
      >
        <a-select-option
          v-for="(description, val) in values"
          :key="val"
          :value="val"
        >
          {{ description }}
        </a-select-option>
      </a-select>
      <a-input-number
        v-if="type === 'number'"
        v-model="value"
        size="small"
        :min="min"
        :max="max"
        :disabled="!enabled"
        style="width: 120px"
      />
      <label
        class="settings-popover__item-label"
        title=""
      >{{ desc }}</label>
    </div>
  </div>
</template>

<script>

import {mapGetters} from 'vuex';
import {logger} from '@core-tech/web-api';
import {getUserSettingsStore} from '@core-tech/web-api/user-settings';
import {themeEmitter} from '../store/theme';
import {MutationTypes as ThemeMutations} from '../store/theme/mutations';

const {SET_THEME} = ThemeMutations;

export default {
  name  : 'SettingItem',
  props : {
    desc : {
      type     : String,
      required : true
    },
    values : {
      type     : Object,
      required : false,
      default  : undefined
    },
    enabled : {
      type     : Boolean,
      required : false,
      default  : true
    },
    // eslint-disable-next-line vue/require-prop-types
    value : {
      required : false,
      default  : undefined
    },
    min : {
      type     : Number,
      required : false,
      default  : undefined
    },
    max : {
      type     : Number,
      required : false,
      default  : undefined
    },
    type : {
      type     : String,
      required : true
    },
    name : {
      type     : String,
      required : true
    }
  },
  computed : {
    ...mapGetters('setting', ['getValue'])
  },
  methods : {
    valueChanged (value) {
      getUserSettingsStore().set(this.name, value);

      this.$parent.setSetting({
        name : this.name,
        value,
        id   : 'volumeMatch'
      });
    },
    setLogLevel (level) {
      logger.changeLogLevel(level);

      // Set log level in user setting store
      getUserSettingsStore().set('loglevel', level);
    },
    validLogLevel (value) {
      // log levels from vuex store & check if value exists in log level array
      return Object.keys(this.getValue('loglevels')).includes(value);
    },
    onChange (value) {
      // if valid log level value then set log level
      if (this.validLogLevel(value)) {
        this.setLogLevel(value);
      } else {
        this.themeChanged(value);
      }
    },
    themeChanged (currentlySelectedTheme) {
      getUserSettingsStore().set(this.name, currentlySelectedTheme);

      const themeId = Number(currentlySelectedTheme) + 1;

      themeEmitter.emit(SET_THEME, `theme${themeId}`);
    }
  }
};

</script>

<style>

.settings-popover__item {
  align-items: center;
  display: flex;
  padding: 10px 0;
}

.settings-popover__item:not(:first-child) {
    --background-color-dark-blue: #3C5290;
  border-top: 1px solid var(--background-color-dark-blue);
}

.settings-popover__item > label {
  margin: 0 5px;
  vertical-align: middle;
}

/** Short Height **/

@media (max-height : 550px) {
  .settings-popover {
    flex-flow: row wrap;
    width: 95vw;
  }

.settings-popover__item {
    border-top: 1px solid var(--background-color-dark-blue);
    flex: 1 1 25%;
  }
}

/** Tiny Height **/

@media (max-height : 300px) {
  .settings-popover__item {
    padding: 5px 0;
  }
}

.settings-popover__item-label {
  --font-size-xsm: 11px;
  font-size: var(--font-size-xsm);
  font-weight: var(--dashboard-header-setting-font-weight);
}

.settings-popover__item-icon {
  cursor: pointer;
  vertical-align: middle;
}

.ant-switch-checked {
    background-color: var(--switch-on-background) !important;
}
</style>
