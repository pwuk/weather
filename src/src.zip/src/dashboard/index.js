import Vue from 'vue';
import Antd from 'ant-design-vue';
import {logger, postEventMetric} from '@core-tech/web-api';
import createApp from '@core-tech/web-api/app';
import configureStore from './store';
import Dashboard from './components/Dashboard.vue';
import 'ant-design-vue/dist/antd.css';
import pkg from '../../package.json';
import {dashboardMsgProcessor, displayStatus} from './msg-middleware';
import initDashboard from './dashboard';

Vue.prototype.window = window;
Vue.use(Antd);

// 'Singleton' application instance
let app = null;

const getApp = () => app;

(async function createDashboardApp () {
  async function asyncOp (op, status) {
    displayStatus({
      context    : 'createDashboardApp',
      statusText : status
    });

    await op();
  }

  try {
    // Configure the Vuex store instance
    const store = configureStore();
    const pageStartTimeUtc = Date.now();

    // Render the Vue Dashboard - this initially displays a splash screen
    // eslint-disable-next-line no-new
    new Vue({
      el     : '#dashboard-app',
      render : hyperScript => hyperScript(Dashboard),
      store
    });


    // Create the primary App instance
    app = await createApp({
      appVersion : pkg.version,
      isPrimary  : true
    }, dashboardMsgProcessor);

    // Open a (web-socket) connection to the (GTI) trading session
    await asyncOp(app.connect.bind(app), 'Opening GTI Trading Session');

    // Build the 'Dashboard' layout
    await asyncOp(app.loadAppDashboard.bind(app), 'Building Dashboard Layout');

    // Load the User's application  settings
    await asyncOp(app.loadUserSettings.bind(app), 'Loading User Settings');

    // Build and render the Dashboard
    await asyncOp(initDashboard.bind(this, app), 'Rendering Dashboard');

    // Sending page loader time to web-session
    postEventMetric(app.path, 'pageLoader', {
      appId      : 'DASHBOARD',
      rtt        : Date.now() - pageStartTimeUtc,
      user       : app.userId,
      desk       : app.desk,
      isEmbedded : app.isEmbedded,
      clientTime : new Date().toISOString()
    });
  } catch (err) {
    logger.error(`[createDashboardApp] Error initializing primary Dashboard application v${pkg.version}: error[${err}]`);

    logger.info(`[createDashboardApp] Forcing page reload: ${window.location}`);

    // Force page reload after 180 seconds
    // eslint-disable-next-line no-magic-numbers
    setTimeout(() => window.location.reload(), 180000);
  }
}());

window.onbeforeunload = () => {
  logger.info('[createDashboardApp] Application is shutting down normally, flushing all log statements.');

  if (app) {
    app.close();
  }
};

export default getApp;
